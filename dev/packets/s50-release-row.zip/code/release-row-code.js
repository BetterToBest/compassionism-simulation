// The Compassionism Simulation engine: the code that the release row and its no-programme pair run (Reference, Adverse and Stress), in source order.
// Cut by dev/packets/make_s50_reference.js from the script harness.js builds (index.html's engine first, then harness.js's own code), under V8 block coverage over seeds 1-20 of all six rows.
// Included: every top-level function that ran, and every top-level value such code names. Each piece is headed by the file and line it comes from.
// In this file, code inside an included function that never ran in those runs is folded to ⟦not run⟧ (the whole text is in release-row-code-full.js).
// "Never ran" is measured, not proved: a branch that runs only on a rare seed would be folded too, so check release-row-code-full.js before relying on a fold.

// index.html line 2072
var CFG = {
  /* v4.13: POVERTY_LINE carries no citation anywhere in this codebase — flagged as an open
   * `calibration:` item in CONTRIBUTING.md's Calibration Validation table since v4.10, but
   * with nothing at the constant itself to warn a reader who only ever looks at the code.
   * Noted here so the gap is visible where the number lives. It is a pure post-hoc
   * reporting threshold with exactly one read site (calcMetrics()), never touching RNG or
   * dynamics — which is why the v4.10 Threshold Sensitivity charts can sweep across it
   * freely, and why an uncited value here is a reporting-clarity problem rather than a
   * mechanics one. For reference, the 2026 HHS one-person federal guideline is $15,960
   * (FED_POVERTY_LINE_1P, below); $25,000 is noticeably higher and its basis is unknown.
   * v5.3 (B3, Oct 7, 2026; DECISIONS Session 39): settled as a design threshold with a stated reading. Where $25,000 came from is still
   * undocumented, but it is within 1.3% of six months of one adult's cost of living (half of LIVING_WAGE_ANNUAL, $24,685), which is how the
   * model reads it from v5.3: the household reading uses six months of each household's own costs (CFG.HH_WEALTH_MONTHS). Stricter than the
   * asset-poverty literature's line (net worth below three months of the poverty line: Haveman and Wolff 2004). Kept at $25,000 here so the
   * adult-only figures stay comparable across releases. */
  POVERTY_LINE:25000, BLEI_CRISIS_MAX:7, BLEI_PRECARIOUS_MAX:30,
  BLEI_THRESHOLD_MAX:120, BLEI_STABLE_MAX:365, BLEI_SECURE_MAX:730,
  BASE_DAILY_COST:68.33, CCO_PTH_DAILY_COST:31.67,
  /* v4.7: previously an anonymous lognormal(10.5,1.2) literal inline in
   * makeLatentAgent() — promoted to named constants purely for discoverability
   * (identical values, so zero change to RNG consumption or any simulation
   * output). Comment doubles as an open calibration flag: median wealth =
   * e^WEALTH_INIT_MU ≈ $36,316, matching this constant's own long-standing
   * "Fed SCF 2022" citation elsewhere in this file and in the ODD panel below
   * — but the actual 2022 Survey of Consumer Finances reports median
   * household net worth at ≈$193,000 (Kuhn & Ríos-Rull, NBER working paper,
   * 2025, using 2022 SCF microdata), roughly 5.3x higher. Gini of a lognormal
   * is 2Φ(σ/√2)−1 — a function of WEALTH_INIT_SIGMA alone, no μ term — so this
   * is independent of the wealth-init distribution's separately-documented
   * inherent Gini ≈0.60 (see the Empirical Calibration panel); correcting the
   * median here would shift absolute wealth-poverty rates, especially in
   * early simulated years against the fixed-dollar POVERTY_LINE, without
   * moving Gini at all. Not changed this pass — every downstream wealth/Gini/
   * BLEI/poverty figure the model produces starts from this draw, so revising
   * it needs the same mechanics-audit-plus-large-N-restudy treatment as
   * v4.0/v4.3/v4.4, not a value swap in a hygiene release. Logged as an open
   * calibration: item in CONTRIBUTING.md's Model Architecture Feedback. */
  WEALTH_INIT_MU:10.5, WEALTH_INIT_SIGMA:1.2,
  SZH_ALL_RESIDENTS:0.06, SZH_PTF_BONUS:0.05,
  /* v4.0: network-density-gated synergy coefficient θ (BLEI paper Table 6: "Synergy
   * coefficient θ ... Network-density-gated: 0 below 55% PTF density; scales to 0.25
   * at 90%"). Previously applied as a plain linear function of szhCoh with no
   * threshold — see szhTheta().
   * v4.17 correction: the threshold is applied to szhCoh, the SZH zone-coherence SLIDER, as a
   * stand-in for PTF merchant density. Realised PTF density never enters θ — the reference
   * run's θ is 0.121 whether realised PTF membership is 18% or 53%. Logged as a decision. */
  SZH_THETA_THRESHOLD:0.55, SZH_THETA_MAX_COH:0.90, SZH_THETA_MAX:0.25,
  EDC_BASELINE_LO:0.62, EDC_BASELINE_HI:0.72, EDC_PTH_CAP:0.10,
  PROG_PIVOT:3.0, PROG_RATE:0.040, PROG_TAX_MAX:0.75,
  /* v4.13: corrected comment. This previously read "retained for CCO/PTF/PTH cost-factor
   * calc only" — not true: the cost factor (cf) in runYear() is a product of dimensionless
   * multipliers (0.88 / 0.65 / 0.80) and never touches this constant. Grep confirms
   * CFG.SIM_COST_SCALE has ZERO read sites in the live code today; it appears only here and
   * in prose. Kept rather than deleted so pre-v4.3 exported CSV/JSON files and this file's
   * own historical worked examples (which quote a wage×12/SIM_COST_SCALE ratio) stay
   * interpretable — that is now its entire remaining purpose. */
  SIM_COST_SCALE:1500,     // historical constant only — read by no function in this file (v4.3 wealth loop uses WAGE_TO_USD/LIVING_WAGE_ANNUAL; v4.4 retired SIU_TO_USD, its last consumer)
  WAGE_MEDIAN_SIU:35,      // reference for diminishing-returns calculation
  WEALTH_FLOOR:-10000,     // v4.8: N=500-seed sweep across 4 candidate values run and validated — see CONTRIBUTING.md; default unchanged, this is data for a decision not a decision itself
  WAGE_BASE_GROWTH:0.010, WAGE_BLEI_BONUS:0.008, WAGE_OCTAVE_BONUS:0.003,
  AI_DISPLACEMENT_YEAR_1:5, AI_DISPLACEMENT_YEAR_2:15,
  AI_DISPLACEMENT_RATE_1:0.012, AI_DISPLACEMENT_RATE_2:0.022,
  TARGET_WEALTH:82000, TARGET_STABILITY:0.90, TARGET_POVERTY:0.05,
  TARGET_FLOURISHING:0.50, TARGET_GINI:0.25, TARGET_EDC:0.10,
  NORDIC_GINI:0.28, CCO_OPTIMAL_BU:1200,
  /* v4.17: the papers' "minimum viable" CCO participation. Used ONLY for a run warning — no
   * line of runYear() reads aggregate CCO participation, so nothing in the dynamics changes
   * at 55% (sweep in CONTRIBUTING.md v4.17; NEEC maintainers' note 7). Whether to build a
   * participation-dependent network effect is logged as a decision for Duke. */
  CCO_MIN_PARTICIPATION:0.55,
  PTF_OPTIMAL_SHARE:0.18, PTF_DISTORTION:0.30,
  PHI_RATIO:1.618, PHI_QUALITY_THRESH:0.70,
  /* v4.0 additions — see BLEI paper (basic-living-economic-index.html) §8 Table 6
   * and Index IV (FBS) for the specification these implement. */
  FBS_LAMBDA_LO:0.0001654, FBS_LAMBDA_HI:0.0013233,   // per-agent capability coefficient λ ~ U(lo,hi), units 1/USD — v4.4: rescaled ÷(WAGE_TO_USD/legacy SIU_TO_USD ≈6.0456) from the pre-v4.4 0.001/0.008. The FBS gate's wage-derived income term (Yusd, below) was redefined from the legacy SIU_TO_USD anchor to the empirically-grounded WAGE_TO_USD anchor as part of the v4.4 wage-scale unification, ~6.05× larger at any given wage — but FBS also includes fixed-dollar terms (BU face value, basic cost) that did NOT rescale, so FBS as a whole does not scale by a single clean factor, and this rescale is a CHOSEN behavioral recalibration to restore useful advancement-probability variation across the population, not a dimensionally-forced conversion (an earlier version of this comment overstated that). Left unscaled, λ×fbs saturates pAdvance (→1) for nearly all agents regardless of BU level, which measurably weakened the BU-monotonicity VAL_TEST (4/5→ties at n=200, one seed) AND, more fundamentally, leaves little of λ's intended role as an "individual capability coefficient": even the BLEI paper's own published range (0.001-0.008) already produces 89.8-100% advancement probability at the paper's own $2,281/month worked example. Rescaling preserves the HI/LO=8× heterogeneity shape and restores 5/5 on VAL_TESTS — that demonstrates internal behavioral consistency, not empirical correctness of these specific values; λ's empirical grounding remains open, same as before v4.4 (see the BLEI paper's own Index IV note and CONTRIBUTING.md's "λ Calibration Status — Open" for the full account, including a recommended future reparameterization by half-saturation point FBS₅₀=ln(2)/λ rather than a raw 1/USD coefficient).
  FBS_EDC_RESIDUAL_BASE:0.12, FBS_EDC_RESIDUAL_PTH:0.025, // EDC_residual (consumer-debt-only), Table 1b worked values
  FBS_CIP_LAMBDA_BOOST:0.20,   // CIP support raises effective λ by up to +20% at cipDemo=1 (replaces old flat advancement-probability bump)
  BASELINE_CPI_RATE:0.03,      // US Welfare Baseline anchors to documented 3% CPI, not the user's inflation slider
  PTH_EQUITY_CONTRIB_SHARE:0.25, // share of PTH's annual housing-cost saving that routes to Acre Equity (payment→equity), vs. staying as direct liquid relief
  /* v4.5: tenure-cohort-varying liquidity haircut, replacing the flat 50% share of
   * annual Acre Equity appreciation that counted as immediately-liquid wealth (see
   * pthLiquidShare() and the runYear() PTH block). BLEI paper Table 1a describes this
   * schedule qualitatively as "~10-20% at 6 months rising to ~80-90% at 5+ years" —
   * we don't have a closed-form curve from the paper, only these two anchor points, so
   * this is a linear interpolation between them, a documented interpretation choice
   * pending a fuller citation, same honesty standard as PTH_EQUITY_CONTRIB_SHARE above.
   * Anchors use the midpoint of each cited range (15%/85%) rather than either endpoint.
   * pthTenure is incremented to 1 on an agent's first year in PTH (see runYear()), so
   * tenure=1 is the point in the schedule closest to the paper's "6 months" anchor;
   * tenure>=5 holds flat at the "5+ years" anchor rather than continuing to rise. */
  PTH_LIQUID_SHARE_YEAR1:0.15, PTH_LIQUID_SHARE_YEAR5PLUS:0.85, PTH_LIQUID_SHARE_MATURE_YR:5,
  PTF_BASS_Q:0.05,      // Bass (1969) imitation coefficient for PTF adoption — see runYear
  /* v4.3: main wealth-accumulation loop unit fix (highest-priority open item as of
   * v4.2 — see CONTRIBUTING.md Model Architecture Feedback). Two new constants:
   * WAGE_TO_USD converts the wage side; LIVING_WAGE_ANNUAL anchors the cost side.
   * WAGE_TO_USD ≈ 100.52 = $42,220 median personal income (Census/BLS CPS ASEC 2023,
   * all workers 15+) ÷ (35 SIU × 12). LIVING_WAGE_ANNUAL = $49,370/yr — a national
   * living-wage figure for a single adult, no children ($23.735/hr average across
   * 50 states + DC × 2,080 hrs/yr; World Population Review's MIT-sourced table; an
   * *unweighted* average across jurisdictions, not population-weighted like MIT's
   * own Living Wage Calculator product, which is paid and requests no scraping —
   * see CONTRIBUTING.md for that caveat). Replaces netting WAGE_TO_USD-converted wage
   * against BASE_DAILY_COST (a bare-subsistence floor, correct for BLEI's poverty-line
   * use, wrong for a 20-year compounding loop netted against real wage): that anchor
   * produced an ~11x wealth explosion and broke BU-monotonicity (2/5 seeds). All six
   * VAL_TESTS pass under the LIVING_WAGE_ANNUAL anchor, including BU-monotonicity
   * (5/5) — the strongest evidence this anchor is structurally right, not just
   * numerically smaller. dollarCost/BASE_DAILY_COST — the COST side — is unchanged
   * everywhere else (BLEI, FBS, Gini) — only the main loop's cost side changes here.
   * (v4.4 note: this is about the cost side specifically. BLEI/FBS/Gini's WAGE-side
   * conversion, separately, moved off the legacy SIU_TO_USD approximation onto this
   * same WAGE_TO_USD constant in v4.4 — see Cumulative Bug Fixes. The two changes
   * are independent; this comment's claim about the cost side is still accurate.)
   * This is NOT a clean win: correcting the units also redistributes, not just grows
   * — see the redistribution note under CONTRIBUTING.md Model Architecture Feedback
   * and the Known Limitations entry below before reading the headline wealth figure
   * alone. */
  WAGE_TO_USD:100.52,
  LIVING_WAGE_ANNUAL:49370,
  /* v4.3: Social Security-anchored income-comparison figures — reference points only,
   * not a simulated cohort mechanism (see the fixed-income cohort study, Known
   * Limitations, and CONTRIBUTING.md). SSA 2026 COLA Fact Sheet
   * (ssa.gov/news/en/cola/factsheets/2026.html): SSI federal payment standard,
   * individual, $994/mo; SSDI average, all disabled workers, $1,630/mo; average
   * retired-worker benefit, $2,071/mo. */
  SS_ANCHOR_SSI_ANNUAL:11928, SS_ANCHOR_SSDI_ANNUAL:19560, SS_ANCHOR_RETIRE_ANNUAL:24852,
  /* v4.10: external reference only — NOT a simulation parameter, same category as
   * NORDIC_GINI above (never read by runYear()/calcMetrics()/agentBLEI() or any other
   * mechanics function; used only as a labeled comparison point in
   * renderThresholdSensitivity's callout text, below). 2026 HHS ASPE federal poverty
   * guideline, one-person household, 48 contiguous states + DC: $15,960/yr. Verified this
   * session directly against aspe.hhs.gov/poverty-guidelines's cited methodology plus an
   * independently-dated primary-source PDF (a Lifeline Safe Connections Act eligibility
   * table, citing HHS directly and dated January 15, 2026, showing 200% of this same
   * guideline as $31,920 for one person — i.e. the underlying guideline is exactly
   * $15,960); a first fetch attempt against the live ASPE page returned a stale cached
   * 2017 snapshot, caught and cross-checked rather than used — see CONTRIBUTING.md's v4.10
   * Release Notes for the full verification trail. Published annually, ~mid-to-late
   * January; update this figure — and its year label in the callout text — when a fresher
   * guideline is published, the same discipline CONTRIBUTING.md already applies to
   * SS_ANCHOR_* above. */
  FED_POVERTY_LINE_1P:15960, FED_POVERTY_LINE_YEAR:2026,
  /* v4.18: EXTREME POVERTY OVERLAY — homeless, with necessities provided by charity if at all.
   * The engine has no housing market, mental-health state or vocation, so this measure is an
   * overlay on engine state, not an engine output (see extremePovertyOf()). Draws no RNG. */
  EP_Y0_RATE:0.0022,     // year-0 rate: HUD 2025 AHAR Part 1 PIT count, 745,652 people on one night in Jan 2025, ~22 per 10,000
  EP_SMI_SHARE:0.25,     // share of that total unhoused because of serious mental illness: Gutwinski et al. 2021 (PLoS Med 18(8)) meta-analysis, schizophrenia spectrum 12.4% + major depression 12.6%
  EP_VOL_SHARE:0.02,     // share living this way by choice (ascetics, itinerant monastics, renunciants). Set by Duke (v4.18); no US source located. The true share may vary and should be updated as data sources become available
  EP_WZ_EFFECT:0.50,     // relative reduction in SMI homelessness from PTH+SZH wellness zones at full zone coherence: At Home/Chez Soi RCT, last 6 months housed none of the time 16% (Housing First) vs 46% (usual care); housed all of the time 62% vs 31%
  /* v4.19: AUTOMATIC STABILIZERS. Every lever is off by default (ST.stab, ST.cola), so no
   * documented figure moves. Reference values are the Research Hub's own crisis protocols
   * (Integrated Implementation Roadmap, Appendix G) and this engine's calibration of them —
   * `node harness.js stabilizer` reproduces every figure. See CONTRIBUTING.md v4.19. */
  /* v4.19, Option B: CCO cost relief = min(CCO_RELIEF_CAP, CCO_RELIEF_AT_REF x effective BU / CCO_RELIEF_REF_BU).
   * v4.21: effective BU is read in year-0 dollars (divided by the basket's price index), because
   * CCO_RELIEF_REF_BU is a year-0 amount and the relief multiplies the nominal basket. See runYear(). */
  CCO_RELIEF_AT_REF:0.20, // the historical flat relief, now its value at the reference BU
  CCO_RELIEF_REF_BU:1200, // the reference BU ($/month) at which relief is 20% of the basket
  CCO_RELIEF_CAP:0.50,    // ceiling on the relief share. PLACEHOLDER set in v4.19 (binds from $3,000 of effective BU); no source located
  STAB_HUB_MULT:1.20,    // Recession Protocol: "increase basic units 20%"
  STAB_HUB_THRESH:0.02,  // ...when "GDP decline >2% for 2 quarters". No GDP in the engine: read as a >=2% population income loss. Every engine recession (5-30% loss) clears it
  STAB_NEUTRAL_MULT:1.35,// shock-neutral multiplier for CCO participants at the reference settings, with cost relief scaling with BU (harness.js stabilizer 300: x1.36 unrounded; x1.35 in Adverse Environment and CCO Only)
  STAB_NEUTRAL_K:2.8,    // the scaled rule's equivalent: BU increase = k x income-loss share (k ~ 2.8 at the reference settings)
  STAB_MULT_MAX:4,       // slider maximum; the in-page shock-neutral search stops here
  STAB_EMERG_TAKEUP:0.50,// share of non-participants taking up emergency enrollment when triggered. PLACEHOLDER set in v4.19: no source located
  COLA_HUB_THRESH:0.05,  // Inflation Surge Protocol: "CPI >5%" -> COLA adjustments to basic units
  STAB_STUDY_SEEDS:30,   // paired seeds for the in-page shock-response study
  /* v4.20: automationRisk mixture, pi x Beta(AUTO_HIGH_A,1) + (1-pi) x Beta(1,AUTO_LOW_B).
   * Source: Frey & Osborne (2013), appendix (pp. 57-72), 702 SOC-2010 occupations, weighted by
   * May-2016 BLS OES employment (plotly/datasets job-automation-probability.csv, numbEmployed;
   * every row checked against the paper's appendix in v4.20 and matching on SOC code, rank
   * and probability). Employment-weighted mean probability 0.592; share at or above 0.5,
   * 0.660; share above 0.7, 0.501. v4.3-v4.19 used 0.47 — F&O's headline share of 2010 US
   * employment above 0.7 — as the mixture weight, which gives a mean of 0.479. 0.63 matches
   * the data's mean, and automationRisk enters runYear() linearly (wage drag = displacement
   * rate x risk), so the mean sets the population's aggregate drag; it is also the closest of
   * the candidates to the data's distribution (harness.js automation fit). Shapes are kept
   * from v4.3; the within-group means they imply (0.857/0.143) are close to the data's
   * (0.835/0.120). Drawn INDEPENDENTLY of wage, although across occupations log median wage
   * and probability correlate at -0.65 (employment-weighted): see CONTRIBUTING.md v4.20. */
  AUTO_HIGH_SHARE:0.63,
  AUTO_HIGH_A:6,
  AUTO_LOW_B:6
};

// index.html line 2312
var RNG=Math.random;

// index.html line 2313
function mulberry32(seed){var s=seed>>>0;return function(){s=(s+0x6D2B79F5)>>>0;var t=Math.imul(s^(s>>>15),1|s);t=(t+Math.imul(t^(t>>>7),61|t))^t;return((t^(t>>>14))>>>0)/4294967296;};}

// index.html line 2715
function szhTheta(coh){
  coh=isNaN(coh)⟦not run⟧:coh;
  if(coh<CFG.SZH_THETA_THRESHOLD)return 0;
  return Math.min(CFG.SZH_THETA_MAX,(coh-CFG.SZH_THETA_THRESHOLD)/(CFG.SZH_THETA_MAX_COH-CFG.SZH_THETA_THRESHOLD)*CFG.SZH_THETA_MAX);
}


// index.html line 2727
function pthLiquidShare(tenure){
  var t=Math.max(1,Math.min(CFG.PTH_LIQUID_SHARE_MATURE_YR,isNaN(tenure)⟦not run⟧:tenure));
  var span=CFG.PTH_LIQUID_SHARE_MATURE_YR-1;
  return span>0?CFG.PTH_LIQUID_SHARE_YEAR1+(t-1)/span*(CFG.PTH_LIQUID_SHARE_YEAR5PLUS-CFG.PTH_LIQUID_SHARE_YEAR1)⟦not run⟧;
}


// index.html line 2748
function agentBLEI(a,buAlloc,ccoOn,pthOn,szhOn,szhCoh,ptfOn){
  var liquid=Math.max(0,(isNaN(a.wealth)⟦not run⟧:a.wealth)*0.20);
  var gammaV=(ccoOn&&a.inCCO)?0.20:0.12;
  var mInc=Math.max(isNaN(a.wage)⟦not run⟧:a.wage,0.1)*CFG.WAGE_TO_USD;
  var buFood=(ccoOn&&a.inCCO&&buAlloc>0)?((CONVERSION_MODEL==='framework'&&a._fwBUm!==undefined)?a._fwBUm⟦not run⟧):0;  // session 2, N3: framework credits one month of the BU the agent spends on essentials (fwB0 in runYear: the budget capped at essentials, before any price cut; audit V5-02: this year's with GATE_CURRENT)
  var szhD=szhOn?szhCoh*CFG.SZH_ALL_RESIDENTS:0;
  if(szhOn&&ptfOn&&a.inPTF)szhD+=szhTheta(THETA_GATE==='density'&&THETA_DENS!==null?(CMS⟦not run⟧:THETA_DENS)⟦not run⟧)*0.20;  // session 5 (C08): harness-only gate
  var baseCost=(ccoOn&&a.inCCO&&pthOn&&a.inPTH)?CFG.CCO_PTH_DAILY_COST:CFG.BASE_DAILY_COST;
  var dc=Math.max(baseCost*(1-szhD),0.1)*(a._hhD||1);  // v5.3 B3: an adult's share of the household's daily cost of basic living (households only)
  var r=(liquid+gammaV*mInc+buFood)/dc;
  return(isNaN(r)||!isFinite(r))⟦not run⟧:Math.max(0,r);
}


// index.html line 2781
function agentEDC(a,ccoOn,pthOn){
  var mInc=Math.max(isNaN(a.wage)⟦not run⟧:a.wage,1);
  var w=CFG.WAGE_MEDIAN_SIU;
  if(ccoOn&&a.inCCO&&pthOn&&a.inPTH)return Math.min(CFG.EDC_PTH_CAP,(CFG.EDC_PTH_CAP*w)/mInc);
  if(!ccoOn||!a.inCCO)return Math.min(0.75,Math.min(0.50,(0.50*w)/mInc)+0.08);
  return Math.min(0.42,Math.min(0.35,(0.35*w)/mInc)+0.03);
}


// index.html line 2823
function updateRecession(recSt){
  if(recSt.active){recSt.yearsLeft--;if(recSt.yearsLeft<=0){recSt.active=false;recSt.incomeMultiplier=1.0;}}
  else if(RNG()<0.10){recSt.active=true;recSt.yearsLeft=1+Math.floor(RNG()*3);recSt.incomeMultiplier=0.70+beta(5,2)*0.25;}
}

// index.html line 2835
function buildRecessionPath(years,seed){
  var path=[],saved=RNG;
  RNG=(seed===null||seed===undefined||isNaN(seed))⟦not run⟧:mulberry32(seed+700000);
  var st={active:false,incomeMultiplier:1.0,yearsLeft:0};
  for(var y=0;y<years;y++){
    if(y>0)updateRecession(st);
    path.push({active:st.active,incomeMultiplier:st.incomeMultiplier});
  }
  RNG=saved;
  return path;
}

// index.html line 2871
function standardNormal(){var u=Math.max(1e-14,1-RNG()),v=RNG();return Math.sqrt(-2*Math.log(u))*Math.cos(2*Math.PI*v);}

// index.html line 2889
var AUTOMATION_SAMPLER_LEGACY = false;

// index.html line 2890
function drawAutomationRisk(){
  if(AUTOMATION_SAMPLER_LEGACY)⟦not run, 4 lines⟧
  var c=RNG(),v=RNG();
  return c<CFG.AUTO_HIGH_SHARE?Math.pow(v,1/CFG.AUTO_HIGH_A):1-Math.pow(1-v,1/CFG.AUTO_LOW_B);
}

// index.html line 2898
function makeLatentAgent(){
  var uCCO=RNG(),uPTF=RNG(),uPTH=RNG();  // unconditional — see comment above
  return{uCCO:uCCO,uPTF:uPTF,uPTH:uPTH,
    wealth:lognormal(CFG.WEALTH_INIT_MU,CFG.WEALTH_INIT_SIGMA),wage:lognormal(3.5,0.5),
    octaveShape:beta(2,5),qualityZ:standardNormal(),
    automationRisk:drawAutomationRisk(),lambda:CFG.FBS_LAMBDA_LO+RNG()*(CFG.FBS_LAMBDA_HI-CFG.FBS_LAMBDA_LO)};
}

// index.html line 2905
function makeLatentPopulation(n){var pop=[];for(var i=0;i<n;i++)pop.push(makeLatentAgent());return pop;}

// index.html line 2906
function instantiateAgent(latent,cfgP){
  var qN=cfgP.cip?(1-cfgP.cipDemo*0.5):1.0;
  var maxOct=cfgP.maxOct⟦not run⟧,maxMult=cfgP.maxMult⟦not run⟧;
  var inPTH=!!(cfgP.pth&&latent.uPTH<cfgP.pthUptake);
  return{wealth:latent.wealth,wage:latent.wage,
    /* v4.5: snapshot of year-0 wage, kept alongside the mutable a.wage (which grows
     * every runYear() call). Needed to tag agents into the Social Security-anchored
     * cohorts by their INITIAL wage, matching CONTRIBUTING.md's documented methodology
     * ("agents tagged by initial wage at or below each anchor's SIU-equivalent") — see
     * ssAnchorCohorts(). Purely additive; nothing existing reads this field. */
    initialWage:latent.wage,
    octave:Math.floor(latent.octaveShape*maxOct),
    quality:Math.min(maxMult,Math.max(0,Math.exp(Math.log(maxMult*0.5)+0.4*latent.qualityZ)*qN)),
    automationRisk:latent.automationRisk,lambda:latent.lambda,
    uCCO:latent.uCCO,  // v4.19: kept for deterministic emergency take-up (no RNG)
    inCCO:!!(cfgP.ccoOn&&latent.uCCO<cfgP.partRate),inPTF:!!(cfgP.ptf&&latent.uPTF<cfgP.ptfShare),inPTH:inPTH,
    buBalance:0,acreEquity:inPTH?5000:0,
    /* v4.3: per-agent PTH tenure in years (first step toward tenure-cohort liquidity
     * haircut per BLEI paper Table 1a / CONTRIBUTING.md). Incremented each year the
     * agent remains in PTH; reset to 0 on exit. Variable haircut formula itself is a
     * follow-up PR — this only gets the tracking data flowing and exported. */
    pthTenure:0};
}

// index.html line 3418
/* ==== RELEASE ENGINE: ported verbatim from harness.js by dev/tools/port_engine.py (plan step 10). Do not edit here. ==== */
CFG.FBS_HALF_SAT_LO = Math.log(2) / CFG.FBS_LAMBDA_HI;

// index.html line 3419
CFG.FBS_HALF_SAT_HI = Math.log(2) / CFG.FBS_LAMBDA_LO;

// index.html line 3423
/* v5.2 round, step 2 (Oct 3, 2026; Duke's answer d148). The US official poverty threshold for one person under 65 in 2025 (the model's year 0 is in 2025 dollars):
 * $16,749 (US Census Bureau, Poverty Thresholds for 2025 by Size of Family and Number of Related Children Under 18 Years, "one person (unrelated individual), under 65
 * years"; quoted in Congressional Research Service, Poverty in 2025, IN12737, Sept 16, 2026). Read only by the v5.2 reporting option (tbRepYear); no engine rule reads it. */
CFG.POVERTY_THRESHOLD_ONE = 16749;

// index.html line 3424
CFG.POVERTY_THRESHOLD_SENIOR = 15440;  /* v5.2 step 5: the same table's threshold for one person aged 65 and over (Census P60-290, Appendix A), used where adults age */

// index.html line 3437
/* v5.2 round, step 5 (Oct 3, 2026): the readings that close known gaps between the no-programme run and US data (LATENT; sources/scf_singles.py derives the figures).
 * The comparison group in the 2022 Survey of Consumer Finances (Federal Reserve; summary extract, five implicates pooled, weighted): single heads with no children,
 * aged 25-66, with wage income (2,700 records, 16.8 million families), dollars taken to 2025 with CPI-U.
 *  SCF_NETWORTH_PCTL     their net worth at the 0.5th, 1.5th, ..., 99.5th percentiles, 2025 dollars (median $74,422; 12.6% in debt).
 *  SCF_WAGE_WEALTH_RHO   the normal-score (Gaussian-copula) correlation of their wage income with their net worth: 0.3585.
 *  SCF_WAGE_SIGMA        the lognormal spread that gives their wage-income Gini (0.4577): 0.8617 (the model draws log wages with 0.5, a Gini of 0.276). The
 *                        standard deviation of their log wage income is 1.049, but a lognormal with that spread would have a Gini of 0.54, far above theirs,
 *                        because the very low annual wages of part-year workers dominate the log scale; the Gini is the figure the comparison is about.
 *  FO_RISK_WAGE_RHO      the employment-weighted normal-score correlation of log median wage with automation probability across Frey and Osborne's
 *                        occupations (700 with a wage; May 2016 BLS employment), -0.5313: the Gaussian copula's own parameter (sources/fo_risk_wage.py). The
 *                        figure quoted since v4.20, -0.65, is the plain correlation of log wage with the probability, which mixes the link with the two
 *                        distributions' shapes. Both are across occupations' median wages, so they overstate the link for one person (a stated limit). */
CFG.SCF_NETWORTH_PCTL = [-168690,-110095,-78374,-59977,-43453,-42243,-28987,-21813,-17491,-11419,-8325,-4888,-703,22,330,550,1100,2599,4205,4581,4972,6903,7371,8441,9736,10451,11001,12046,12740,13751,14403,15198,16309,18501,20956,23112,25216,27108,29372,33002,36017,39041,43937,46562,48496,53517,57230,60515,67699,70933,76235,78436,83848,87842,92114,101129,108326,111257,121660,132149,137340,145550,153350,157613,166338,173027,183992,194788,211641,228658,238387,248898,262005,277769,289925,300109,320343,342047,376904,422591,454553,463540,486421,503640,524757,568960,631369,740681,798477,839114,907348,979719,1048972,1164655,1385996,1688747,1826853,2170113,2675192,10801768];

// index.html line 3438
CFG.SCF_WAGE_WEALTH_RHO = 0.3585;

// index.html line 3439
CFG.SCF_WAGE_SIGMA = 0.8617;

// index.html line 3440
CFG.SCF_WAGE_MEDIAN = 54698;  /* v5.2 step 5: the comparison group's median wage income, 2025 dollars (the model's year-0 median is 35 x 12 x 100.52 = $39,945 at log mean 3.5) */

// index.html line 3441
CFG.FO_RISK_WAGE_RHO = -0.5313;

// index.html line 3446
/* S34 (Oct 30, 2026; dev/reports/baseline-realism.md): the earnings of US adults aged 25-64, Census CPS ASEC 2026 (income year 2025; sources/baseline_realism_us.py),
 * for the LATENT wage readings lt.s and lt.m set to 'all' (adults with earnings) or 'ft' (full-time, year-round workers) in place of the SCF's (lt.s, lt.m = 1).
 * median: the weighted median of earnings (PEARNVAL); sigma: the spread of log earnings read from the quartiles, (ln p75 - ln p25)/(2 x 0.6745).
 * The model's own wage scale (WAGE_TO_USD) was set from the median personal income of everyone aged 15 and over, earners or not. Labelled readings, off by default. */
CFG.CPS_EARN = {all:{median:60000, sigma:0.7370}, ft:{median:70000, sigma:0.6258}};

// index.html line 3462
/* v5.2 round, step 6 (Oct 5, 2026; ledger s85; decision B): the middle backing reading and normal-times slack (dev/DECISIONS.md, Session 35, step 6).
 *  KENYA_ABSORB_PEAK     0.16: cash transfers equal to about 16% of a year's local GDP in the peak 12 months of disbursement were met by local output with
 *                        prices up 0.1% on average (under 1% even where transfers were largest) and a local multiplier of 2.5: Egger, Haushofer, Miguel,
 *                        Niehaus and Walker (2022), "General Equilibrium Effects of Cash Transfers: Experimental Evidence from Kenya", Econometrica 90(6),
 *                        2603-2643, Section 2.2 and abstract.
 *  KENYA_ABSORB_ROLLOUT  0.12: the same study's whole rollout, 24% of a year's GDP over 24 months, as a share a year.
 *  US_UNDERUSE           0.080: BLS U-6 (unemployed, marginally attached and part-time for economic reasons, as a share of the labour force plus the
 *                        marginally attached), 2025 average (11 months; October 2025 was not collected): BLS, Alternative Measures of Labor Underutilization
 *                        for States, 2025 11-month Averages (national total).
 *  US_UNDERUSE_LOW       0.069: U-6's lowest annual average since the series began in 1994 (6.9% in 2022 and in 2023; monthly, seasonally adjusted,
 *                        BLS series LNS13327709, via the DBnomics mirror of the BLS database). U-6 above this level is the part that has come and gone with demand.
 *  MULT_NORMAL           0.6: output per dollar of spending in normal times, the low end of Ramey and Zubairy's estimates ("most estimates of the multiplier
 *                        are between 0.6 and 1", with no evidence that they differ with slack): Ramey and Zubairy (2018), "Government Spending Multipliers in
 *                        Good Times and in Bad", Journal of Political Economy 126(2), 850-901 (NBER WP 20719). Auerbach and Gorodnichenko (2012, AEJ: Economic
 *                        Policy 4(2)) find about zero in expansions, which is the layer switched off. */
CFG.KENYA_ABSORB_PEAK = 0.16;

// index.html line 3463
CFG.KENYA_ABSORB_ROLLOUT = 0.12;

// index.html line 3464
CFG.US_UNDERUSE = 0.080;

// index.html line 3465
CFG.US_UNDERUSE_LOW = 0.069;

// index.html line 3466
CFG.MULT_NORMAL = 0.6;

// index.html line 3481
/* v5.2 round, step 7 (Oct 5, 2026; ledger s86; decision C): the robustness readings (dev/DECISIONS.md, Session 35, step 7).
 *  HOUSING_CAPTURE       0.5: landlords' share of each extra dollar of rent subsidy, taken as higher rent: every $1 increase in the voucher rent ceiling
 *                        raised rents by about $0.50, with little or no gain in unit or neighbourhood quality (Collinson and Ganong 2018, "How Do Changes in
 *                        Housing Voucher Design Affect Rent and Neighborhood Quality?", American Economic Journal: Economic Policy 10(2), 62-89).
 *  HOUSING_CAPTURE_HIGH  1.41: vouchers raised the rent paid by low-income non-recipients by $8.2 billion while giving recipients $5.8 billion (rents of
 *                        low-income housing up 16% in the 90 largest metropolitan areas): Susin (2002), "Rent vouchers and the price of low-income housing",
 *                        Journal of Public Economics 83(1), 109-152; 8.2 / 5.8 = 1.41 dollars of higher rent per subsidy dollar.
 *  REVIEW_AUDIT          0.5: the share of unearned high conversion rates that the Collectives' audits catch. Not specified by the Hub (its papers describe
 *                        graduated scrutiny, multi-stakeholder review and auditable scoring, with no detection rate): a labelled design parameter, read
 *                        with 0 (no audit catches anything) beside it.
 *  FED_STD_DED, FED_BRACKETS  the 2025 federal income tax for a single filer: standard deduction $15,750 (raised from $15,000 by Public Law 119-21, July 4,
 *                        2025) and the brackets of IRS Revenue Procedure 2024-40 (10% from $0, 12% from $11,925, 22% from $48,475, 24% from $103,350,
 *                        32% from $197,300, 35% from $250,525, 37% from $626,350 of taxable income); used for the shape of the progressive income tax
 *                        reading, not its level, which is set to pay for the programme. */
CFG.HOUSING_CAPTURE = 0.5;

// index.html line 3482
CFG.HOUSING_CAPTURE_HIGH = 1.41;

// index.html line 3483
CFG.REVIEW_AUDIT = 0.5;

// index.html line 3484
CFG.FED_STD_DED = 15750;

// index.html line 3485
CFG.FED_BRACKETS = [[0, 0.10], [11925, 0.12], [48475, 0.22], [103350, 0.24], [197300, 0.32], [250525, 0.35], [626350, 0.37]];

// index.html line 3497
/* v5.2 round, step 4 (Oct 3, 2026; ledger s83): the ageing switch's inputs (read only when AGE is on; sources/demography.py derives the two arrays).
 *  AGE_WEIGHTS  US resident population at each age 25..66, thousands, July 1, 2024 (Census Bureau, Vintage 2024 national estimates by single year of age,
 *               nc-est2024-agesex-res.csv): the starting ages of the model's working-age adults are drawn in these proportions.
 *  DEATH_Q      probability of dying between ages x and x + 1, x = 25..100, the 2022 US period life table for the total population (Arias, Xu and Kochanek,
 *               United States Life Tables, 2022, NVSR 74(2), April 2025, Table 1; 100 and over: 1). Stands in for the SSA's period life table for 2022 (2025
 *               Trustees Report), which ssa.gov would not serve to this environment; at age 67 the two agree within 0.3%.
 *  SS_RETIRE_ANNUAL  the average retired-worker benefit in 2025 dollars: $2,015 a month before the 2026 cost-of-living adjustment (SSA, 2026 COLA Fact Sheet;
 *               the same sheet as SS_ANCHOR_RETIRE_ANNUAL, $2,071 after it) x 12 = $24,180 a year.
 *  SS_BEND_POINTS  2025 primary-insurance-amount bend points, $1,226 and $7,391 a month (SSA, Benefit formula bend points), for the earnings-linked reading:
 *               90% of average monthly earnings up to the first, 32% up to the second, 15% above.
 *  RETIRE_AGE 67 (full retirement age for everyone born in 1960 or later; SSA); ENTRY_AGE 25 (new adults join at 25). */
CFG.AGE_WEIGHTS = [4467,4459,4467,4496,4571,4660,4728,4826,4888,4892,4747,4655,4595,4594,4580,4477,4531,4512,4439,4411,4225,4124,4066,3922,3957,3875,3919,4099,4334,4259,4095,4001,4007,4055,4201,4292,4283,4286,4265,4176,4084,4036];

// index.html line 3498
CFG.DEATH_Q = [0.001231,0.001316,0.001406,0.001499,0.001591,0.001682,0.001769,0.001851,0.001927,0.002002,0.00208,0.002164,0.002257,0.002359,0.002469,0.002593,0.002725,0.002854,0.00298,0.003113,0.003271,0.003466,0.003695,0.00395,0.004226,0.004515,0.004833,0.005204,0.005647,0.006162,0.006709,0.007285,0.00793,0.008641,0.009392,0.010173,0.01096,0.011741,0.012524,0.01334,0.014218,0.01528,0.016329,0.017524,0.018824,0.020179,0.021711,0.023521,0.025618,0.028122,0.030467,0.034339,0.03738,0.0415,0.045247,0.050833,0.056254,0.062471,0.069526,0.076869,0.086054,0.094545,0.106195,0.118983,0.132946,0.148104,0.164457,0.181983,0.20063,0.22032,0.240942,0.262361,0.284411,0.306908,0.32965,1.0];

// index.html line 3499
CFG.SS_RETIRE_ANNUAL = 2015*12;

// index.html line 3500
CFG.SS_BEND_POINTS = [1226, 7391];

// index.html line 3501
CFG.RETIRE_AGE = 67;

// index.html line 3502
CFG.ENTRY_AGE = 25;


// index.html line 3509
/* v4.16: counterfactual switch for the PTH appreciation-accounting question logged in
 * CONTRIBUTING.md's v4.16 notes. false (the default, and the only value any validated mode
 * uses) reproduces index.html exactly: the FULL appreciation is added to acreEquity AND the
 * tenure-based liquid share is credited to wealth. true is the value-conserving alternative
 * (acreEquity keeps only the non-liquid remainder). Read only by the `pth-accounting` mode. */
var PTH_APPR_CONSERVE = false;

// index.html line 3514
/* v5.3 B2 (Oct 6, 2026; dev/DECISIONS.md Session 39): the accounting check found that, in the two readings where landlords raise the rent of tenants paying with
 * BU (HCAP), the ESP surplus split sizes its uniform price cut on each customer's essentials before the mark-up but applies it to the essentials after it, so it
 * hands out up to 4% more than the pool holds in a year (dollars from nowhere). SURP_CUT_MARKUP = true sizes the cut on the same bill it is applied to (the
 * mark-up included for the BU customers it falls on); false (the default) is v5.2 exactly. It changes nothing without HCAP. No random draw. */
var SURP_CUT_MARKUP = false;

// index.html line 3524
/* v4.19: two harness-only switches recording the decision on how the BU amount reaches a
 * household (CONTRIBUTING.md v4.19; Duke chose Option B, which index.html now ships). Both
 * default to index.html's behaviour, bit-identically.
 *  BU_ALLOCATIONS_PER_YEAR — BU allocations credited per simulated year (index.html: 1). 12
 *    approximates monthly tranches at expiry=1: each month's allocation is spent at the year's
 *    spend fraction and the remainder expires. The 3x cap scales with it.
 *    (Option A, not adopted.)
 *  CCO_RELIEF_FLAT — true restores v4.18's flat 0.80 CCO cost relief (index.html: false, i.e.
 *    Option B: relief scales with the effective BU). For before/after comparisons only. */
var BU_ALLOCATIONS_PER_YEAR = 1;

// index.html line 3525
var CCO_RELIEF_FLAT = false;

// index.html line 3529
/* v4.21: harness-only switch. true restores v4.19-v4.20's CCO relief share, read off NOMINAL
 * effective BU against the year-0 $1,200 reference (an unindexed BU kept its real relief under
 * inflation, and COLA counted inflation twice). Inert at 0% inflation. index.html: false. */
var RELIEF_PRICE_LEGACY = false;

// index.html line 3540
/* v4.21: harness-only switches for the `pathways` and `saving` modes (CONTRIBUTING.md v4.21). Both
 * default to the shipped engine, bit-identically (checked by `validate`).
 *  PATHWAY_OFF — switch off one channel through which CCO or PTH reaches wealth, CRN-paired:
 *    relief (CCO cost relief), conversion (conversion proceeds), octave (octave advancement),
 *    octaveWage (the octave wage-growth bonus), bleiWage (the BLEI-gated wage-growth bonus),
 *    pthCost (PTH's 35% cost reduction, and with it the equity routing it funds),
 *    pthEquity (equity routing and liquid appreciation; the saving stays in wealth).
 *    The v4.14 pathway-decomposition item (Good First Issues, v4.14 (b)).
 *  SURPLUS_CONSUMPTION_SHARE — the share of income above the agent's own basket cost that the
 *    agent consumes. The engine consumes exactly the basket (0), so every dollar above it is saved. */
var PATHWAY_OFF = {relief:false, conversion:false, octave:false, octaveWage:false, bleiWage:false, pthCost:false, pthEquity:false};

// index.html line 3541
var SURPLUS_CONSUMPTION_SHARE = 0;

// index.html line 3545
/* Session 7 (dashboard i3-1, s23): harness-only switch. The engine's FBS gate on octave advancement reads the monthly basic cost
 * AFTER the CCO relief discount and then adds effective BU on top, so BU enters FBS twice (the framework branch already reads the
 * cost before the relief). true: the engine branch reads the pre-relief cost, as the framework branch does. index.html: false. */
var FBS_BU_ONCE = false;

// index.html line 3554
/* Session 9 (dashboard i3-2): N7 attribution of the BLEI-gated wage raise. The N7 split counts the octave and CIP raises as
 * program-induced and the BLEI-gated raise as not, since the Baseline has it too. But in a design the raise can fire only
 * because the design's own support lifts the adult over the gate. N7_BLEI true counts the BLEI raise as program-induced in
 * exactly those adult-years: the gate passes as the run reads it (the shipped or the design-neutral gate) and fails on Baseline
 * rules with no program support (agentBLEI(a, 0, false, ...)). Direct, same-year attribution only: a raise that passes on
 * Baseline rules is not attributed, even where program-built wealth put the adult there. The same rule applies to every
 * design. It moves the labor module's raise (uncompensated response) and, where aw < 1, the price module's unmatched
 * premium; the raise itself is unchanged. Default false (the attribution through session 8). No RNG. */
var N7_BLEI = false;

// index.html line 3561
/* Session 1 of the Sep 26 plan: which income SURPLUS_CONSUMPTION_SHARE applies to. 'wage' (the v4.21
 * behaviour): the share of wage income above the agent's basket, taken right after the wage step, so
 * conversion proceeds and PTH liquid appreciation are always saved in full. 'cash': the share of ALL cash
 * surplus that year (wage + net conversion + liquid PTH appreciation − basket − PTH equity routing), taken at the end of the
 * agent's year, before the floor clamp; conversion proceeds first offset any wage deficit. Inert when the
 * share is 0 (the default), so every shipped figure is bit-identical. For the consumption-rule decision. */
var SURPLUS_CONSUMPTION_BASE = 'wage';

// index.html line 3568
/* A1 issuance ledger (Next Round Plan, Sep 26 2026): harness-only and reporting-only. When LEDGER is
 * an object, runYear() adds each money flow it already computes to it, by year. It draws no random
 * number and writes nothing any dynamic reads (the one per-agent field, _ledFloor, is read only by the
 * `ledger` mode), so a run is bit-identical with it on or off; `ledger` checks this on every scenario.
 * null (the default, and index.html's behaviour) skips every ledger line. Flows are nominal dollars;
 * each year also records its price index so the report can deflate to year-0 dollars. */
var LEDGER = null;

// index.html line 3569
var LEDGER_RATE_TIERS = [1.5, 3, 6, 9];  /* conversion-rate tier upper bounds: <1.5, 1.5-3, 3-6, 6-9, >=9 (3 = PROG_PIVOT, 9 = maxMult) */

// index.html line 3590
/* v5.3 B2 (Oct 6, 2026; plan item B2, dev/DECISIONS.md Session 39): THE ACCOUNTING IDENTITIES, AS AN OPTIONAL RUNTIME CHECK. ACCT = null (the default, and
 * the page's) skips every ACCT line, so a run is bit-identical with or without it (the unit suite checks this on the release rows). When ACCT is an object
 * (acctNew()), runYear records each flow where it happens (per adult, fields _ac*; no random draw; nothing any rule reads) and checks, every year:
 *  money     each adult's ending money wealth = beginning + interest + wage earnings - living costs + Social Security + cash transfers less the contribution
 *            + conversion income - PTH equity contribution + PTH appreciation paid out in cash - surplus consumed + debt written off at the floor; every
 *            term but the PTH and interest ones is the adult's own yearly record that the income and poverty measures read (yrWageUSD, yrConvUSD, ...);
 *  equity    each PTH member's ending Acre Equity = beginning + equity contribution + appreciation not paid out (the cash part leaves the equity);
 *  bu        each adult's BU balance (engine model) = beginning + issued - expired - spent; and in the framework model the year's BU stock (the ESP payroll
 *            pool, the project pool, BU adults hold for later conversion, BU directed but not yet allocated) = the stock at the start + BU issued
 *            (allowances and the launch gift) - BU converted (by adults, by the ESP) - BU destroyed (expired BU not directed, BU beyond a cap);
 *  premium   the ESP's conversion premium paid out this year (with last year's carries) = price cuts delivered + dollars paid to adults + reinvestment
 *            + capital charges + what carries to next year (without the surplus split: the premium = the dollars paid out);
 *  books     the Source's ledger (testbed rows) = the households' books: BU face value paid = BU spent by adults; conversion paid = adults' conversion
 *            income + the split's price cuts + reinvestment + capital charges; BU issued = allowances; and the price module's injection = the same less
 *            the price cuts;
 *  source    (tbRunCore, Source financing) what the Source pays = new money + the output that backs it.
 * The tolerance is relative: a gap passes when |gap| <= ACCT.tol x max(1, gross size of the flows in dollars or BU), tol = 1e-9. A failure is recorded in
 * ACCT (count, the first ACCT.keep cases with their size; the gaps' sum by identity in ACCT.sum), never thrown, so a study can count them; a NaN fails. BU that
 * adults held for later conversion when they died are tallied in ACCT.lostDeath (they lapse, as unspent BU do). No figure depends on ACCT. */
var ACCT = null;

// index.html line 3639
/* ─── Next-round session 2 (Sep 26 2026; Duke assigns the version). Harness-only switches, every one inert by
 * default, so index.html and every shipped figure are unchanged (`validate` and domtest's parity checks).
 *
 * CFG.BASKET (decision N10): components of LIVING_WAGE_ANNUAL as shares of the pre-tax budget. Source: MIT Living
 * Wage Calculator (data of Feb 15, 2026), 1 adult, 0 children, "Typical Expenses". LIVING_WAGE_ANNUAL is the
 * unweighted mean of the 51 state living wages x 2,080 (checked in-session: $49,369.82). The site asks not to be
 * scraped, so the components come from 8 state pages read by hand (AL, CA, CT, HI, ID, IN, ME, WV; about one per
 * sixth of the 2026 ranking): each component's dollars regressed on the state's pre-tax total, evaluated at $49,370.
 * Housing is HUD Fair Market Rent, which includes tenant-paid utilities. `taxes` is income and payroll tax, which no
 * discount can reduce. See session-2-handoff.md for the sample and the fit.
 * ESSENTIALS: the components BU can buy and P_E prices (food, housing incl. utilities, medical: 43.5% of the basket). */
CFG.BASKET = {food:0.0901, housing:0.2761, medical:0.0685, transport:0.1955, civic:0.0663, internet:0.0314, other:0.0924, taxes:0.1797};

// index.html line 3640
CFG.BASKET_KEYS = ['food','housing','medical','transport','civic','internet','other','taxes'];

// index.html line 3641
CFG.ESSENTIALS = ['food','housing','medical'];

// index.html line 3649
/* v5.3 B3f (Oct 7, 2026; Duke's answer d173 on the dashboard, Oct 6: "the full list is the design; v5.3 adds it first as a labelled reading"): what BU can
 * buy. BU_SCOPE 'core' (the default; the model since September, decision N10): food, housing (with utilities) and medical care, CFG.ESSENTIALS. 'hub': the
 * Hub's list (glossary, "Basic Units": housing, food, healthcare, education and transportation; draft Act section 103: "Housing, Food, Transportation
 * (non-luxury), Healthcare, Education, PTF services"), so transport too (CFG.ESSENTIALS_HUB) and, for households, childcare (PTF childcare centres;
 * schooling has no fee in the model, so education reaches BU through childcare). Only what BU can buy changes: the price module's essentials keep their
 * sourced responses (food, housing, medical), and transport and childcare keep the general price level, which already rises with the Source's unbacked
 * payout (no source gives their own response to demand: a stated limit). buEss() is the list BU purchases, open enrolment and the split read. */
var BU_SCOPE = 'core';

// index.html line 3650
CFG.ESSENTIALS_HUB = ['food','housing','medical','transport'];

// index.html line 3651
function buEss(){ return BU_SCOPE === 'hub' ? CFG.ESSENTIALS_HUB : CFG.ESSENTIALS; }

// index.html line 3655
/* PTF_MODE (decision D4): 'shipped' = PTF cuts the whole basket by 12% (+4% x SZH coherence), as index.html does;
 * 'food30' = 30% off the food component only (the NYC public-grocery pilot's PROMISED cut, not an observed one);
 * 'food62' = 62% off food only (the hub's eps_food = 2.64: 1 - 1/2.64). Food modes ignore the SZH add-on. */
var PTF_MODE = 'shipped';

// index.html line 3656
var PTF_FOOD_CUT = {food30:0.30, food62:0.62};

// index.html line 3669
/* CONVERSION_MODEL (decisions N1-N4). 'engine' = index.html: each participant converts one allocation of their own
 * spent balance; CCO relief is 20% of the basket. 'framework' = the Research Hub's description:
 *  N3: one BU budget, 12 x effective BU a year per participant.
 *  N4: BU buy essentials at the agent's own (PTF/PTH-discounted) prices, up to the budget; a BU is worth $1 to all.
 *  N1: businesses convert the BU they accept at FW.bizRate (placeholder; hub cafe example 2-4x) on FW.bizCap of it
 *      (operational cap, placeholder; the rest converts at par), under the engine's progressive tax. The premium over
 *      a cash sale (net proceeds - BU accepted) is paid out the next year to ALL agents in proportion to wage income,
 *      standing in for business revenue paid out as wages and profit (the model has no firms: an assumption).
 *  N2: unspent BU expire; FW.directedShare of them go to projects and are converted the next year by participants
 *      in proportion to octave capacity x quality, at each one's own engine rate, within octave capacity
 *      (FW.octaveCapBase x 2^octave BU a month; engine octave k = hub octave k+1). The rest are destroyed.
 * Year-0 pools are empty and the last year's pools are never paid out (the run ends). */
var CONVERSION_MODEL = 'engine';

// index.html line 3670
var FW = {bizRate:3, bizCap:1, directedShare:1, octaveCapBase:1000};

// index.html line 3671
var FWS = null;  /* per-run framework state (pools carried from one year to the next); reset by runYear at yr 0 */

// index.html line 3699
/* N1, session 15 (dashboard s33; decisions d58-d65; N1-design-project-hiring.md): PROJECT HIRING PAID IN EXPIRED BU, the design's
 * mechanism in place of the octave wage raise (d46). PROJ = null (the default) leaves every run bit-identical (checked by `unit`).
 * When an object, in both conversion models:
 *  pool   last year's expired BU x share (engine: the unspent balance that expires, A0 flow 3, destroyed when PROJ is off; framework:
 *         the BU budget left unspent, N2's pool), plus the launch gift (rollout plan: 1,000 expired BU per participant) collected
 *         in year 0 and paid in year 1 when giftMode is 'forward'. Pool that finds no worker carries to the next year.
 *  pay    contract pay, BU per project hour in year-0 dollars, indexed to the basket price level (default: the model's living wage,
 *         $49,370 / 2,080 hours, at par; d63).
 *  alloc  'capq': participants for whom a project hour pays more, after conversion and tax, than an hour of their own wage, weighted
 *         by octave capacity x quality (d61); 'capqAll': the same weights, no willingness test (the framework model's N2 rule);
 *         'low': the willing, lowest wage first, each up to capacity; 'equal': equal shares among the willing.
 *  rate   'max': the higher of the worker's own rate and the contract rate, the capacity x quality-weighted mean own rate of
 *         participants (R4, R5; d62); 'own': own rate only. Progressive conversion tax, CIP bonus and income shock as in the engine.
 *  cap    false (d64, Duke's pick): no conversion cap. true: each participant converts at most 12 x FW.octaveCapBase x 2^octave BU a year: project BU fill what the engine's own
 *         spent-balance conversion leaves (that conversion is left uncapped; it never reaches the smallest capacity at $1,200 BU);
 *         BU above it are saved and converted in later years (d64).
 *  hours  'side' (d63, Duke's pick): project hours are added on top of wage work; 'displace': each project hour replaces an hour
 *         of wage work at the worker's own wage. 'low' allocation always fills each worker up to octave capacity. Project
 *         pay is earned, so it carries no income effect. The testbed's hours measure counts wage plus project hours.
 *  giftMode 'forward' | 'holder' (each participant converts their own gift at their own rate from year 1, with no hours: an
 *         unconditional dollar, so it enters the labor module's rent channel) | 'none'.
 *  giftFin how the testbed's flat contribution pays for the gift's proceeds (d66; issue i7, session 16): 'payg' (Duke's pick) in
 *         the year they are paid, so the year-2 contribution rises; 'run' spread over the remaining years of the run, the rule
 *         the testbed applies to the asset endowment (d26). The cost counted is the same; only its timing, and so the work
 *         response to the contribution, differs. Read only by the testbed's tax and hybrid financing.
 * Allocation is deterministic: no RNG draw is added (CRN holds). With PROJ on, the framework model's N2 allocation is replaced.
 * PJS: per-run state, reset by runYear at yr 0; PJS.acc tallies the flows in year-0 dollars for the testbed and the unit tests. */
var PROJ = null;

// index.html line 3700
var PROJ_DEFAULTS = {share:1, gift:1000, giftMode:'forward', giftFin:'payg', pay:CFG.LIVING_WAGE_ANNUAL/2080, alloc:'capq', rate:'max', hours:'side', cap:false, hrsYr:2080};  /* Duke's picks (Sep 30): d63 side hours, d64 no cap, d66 pay as you go */

// index.html line 3701
var PJS = null;

// index.html line 3702
function pjOwnRate(a, p, pcb){ var oc = 1 + (a.octave/Math.max(1, p.maxOct))*(Math.max(1, p.maxMult) - 1), qf = Math.min(1, a.quality/Math.max(1, p.maxMult));
  var ph = (p.phi && a.quality > p.maxMult*CFG.PHI_QUALITY_THRESH) ? CFG.PHI_RATIO : 1.0, pb = (p.ptf && a.inPTF) ? pcb : 1.0;
  return Math.min((1 + qf*(oc - 1))*ph*pb, p.maxMult*(p.phi ? CFG.PHI_RATIO ⟦not run⟧)); }

// index.html line 3705
function pjTax(p, r){ var bT = p.cip ? p.tax*(1 - p.cipDemo*0.18) ⟦not run⟧; return Math.min(CFG.PROG_TAX_MAX, bT + Math.max(0, (r - CFG.PROG_PIVOT)*CFG.PROG_RATE)); }

// index.html line 3706
function pjNewAcc(){ return {pool:0, gift:0, exp:0, alloc:0, carry:0, conv:0, giftConv:0, gross:0, net:0, giftNet:0, hrs:0, disp:0, work:0, partY:0, rc:0, rcN:0, overCap:0, unwilling:0}; }

// index.html line 3736
/* N1, session 19 (s38; decisions d70-d76; N1-design-esp-payroll.md): ESP PAYROLL IN EXPIRED BU AT WORKERS' OWN RATES, the design's
 * mechanism (Duke's R7, Sep 29) for the wage part of the Hub-spec model's business conversion (N1 above). Framework model only: the
 * engine model has no business conversion and ignores ESP (d70). ESP = null (the default) leaves every run bit-identical (session 19
 * diffed full outputs against b1bc475; `unit` checks lam 0 against ESP off). When an object:
 *  lam   payroll share (d71): of the BU essential service providers accept in year t, lam are paid out as wages in year t + 1 (the
 *        premium's timing today) and the rest convert at FW.bizRate as now. 0.20 = compensation / gross output in the essential
 *        industries, weighted by CFG.BASKET's essentials (BEA GDP-by-industry, 2024 values: 0.20 on both the Jun 25 and the Sep 30, 2026 releases; range 0.15-0.26,
 *        leaning high because BEA measures a grocer's output as its margin; sources/esp_payroll_share.py).
 *  work  who the ESP workers are (d72): a share of adults (0.230 = BLS CES Table B-1, Aug 2026: grocers, food services, utilities,
 *        real estate and health care / total nonfarm; 0.152 without food services), assigned by agent index (the fractional part of
 *        (i + 1) x 0.618... below the share: no RNG, the same adults in every design and seed); 'ptf' = this year's PTF members (the
 *        Hub's "PTF workers"); 'all' = every adult (today's payout population).
 *        The pool is shared among ESP workers in proportion to last year's wage income, each share capped at that wage; any excess
 *        returns to the ESP.
 *  take  'par' (d73): a participating ESP worker whose own rate (octave, quality, Phi, PTF bonus; the rate project hiring reads) after
 *        the progressive tax, times the CIP bonus, beats par takes their share as expired notes and converts it; 'biz': only where the
 *        own rate beats FW.bizRate (a revenue-maximizing ESP). Everyone else is paid in dollars, and the ESP converts those BU itself.
 *  cap   'dollars' (d74): payroll conversion is capped at 12 x FW.octaveCapBase x 2^octave BU a year, net of this year's project BU;
 *        BU above it are paid in dollars (the ESP converts them). 'save': the excess is saved and converted first in later years (R6).
 *        'none': no cap.
 *  rest  'all' (d75): the ESP's own premium, on the share it keeps and on the BU returned to it, is paid as today: next year (the
 *        returned BU: this year, with the rest of last year's premium) to every adult by last year's wage, the stand-in for the ESP's
 *        other costs and surplus. 'esp': to its own workers by last year's wage (a worker cooperative).
 * Income: wages are unchanged, so BU pay counts at face value in wages and the contribution base; the premium over face value,
 * BU x (rate x (1 - tax) x CIP bonus x income shock - 1), is conversion income: program cost, and P_G under money or hybrid financing.
 * Labor: the premium is earned by working at an ESP, so it enters the wage elasticity as a raise, 1 + premium before the income shock /
 * last year's wage, inside the same uncompensated factor as every other raise, with no income effect (the fairness rule). The ESP's
 * own premium keeps today's treatment. No RNG is drawn in any ESP step.
 * ESS: per-run state, reset by runYear at yr 0; ESS.acc tallies the flows in year-0 dollars for the testbed and the unit tests. */
var ESP = null;

// index.html line 3737
var ESP_DEFAULTS = {lam:0.20, work:0.230, take:'par', cap:'dollars', rest:'all'};

// index.html line 3738
var ESP_GOLD = (Math.sqrt(5) - 1)/2;

// index.html line 3739
var ESS = null;

// index.html line 3740
function esNewAcc(){ return {accBU:0, ownBU:0, poolPaid:0, alloc:0, conv:0, ret:0, retNon:0, retPar:0, retCap:0, retWage:0, retNet:0, gross:0, tax:0, prem:0, rateXbu:0,
  wkY:0, wkY1:0, wage:0, partWkY:0, tk:0, capBind:0, maxShare:0, sv:0}; }

// index.html line 3782
/* Plan step 1 (Oct 1, 2026; s40; dev/background/N1-design-esp-surplus.md, decisions d97-d106 and dev/DECISIONS.md): THE ESP SURPLUS
 * SPLIT, in place of today's stand-in (the ESP's own premium paid next year to every adult by wage). Hub-spec (framework) model only;
 * SURP = null (the default) leaves every run bit-identical (full-output diffs of projcore, esp, match and a5; `unit` checks it). When an
 * object, each year the ESP's own premium from last year (FWS.prev.bizNet: the BU it kept and the payroll BU returned to it, converted
 * at FW.bizRate under the progressive tax, less face value; d97) is split:
 *  priv  'owners' (default; Duke, Oct 1: owners keep all of a private business's earnings): the premium earned on BU that PTF members
 *        spent last year is the PTFs' and is split as below; the rest is private ESPs' and is paid in dollars to owners, every adult
 *        in proportion to positive start-of-year wealth (the model has no firms or shares; wealth stands in for ownership). An
 *        unconditional dollar: one income effect (rho). 'same' (d102): one split for every ESP.
 *        'prices' (plan step 14, Oct 2, 2026; Duke's correction d140, dev/reports/v5-1-private-esp-correction.md): a private ESP
 *        passes its premium to the customers who paid it in BU as a lower BU price and stays revenue neutral (Duke: a $9/$12/$15
 *        menu becomes $3/$4/$5 in BU at 3x); nothing goes to owners. Owners compete for workers, so participating private-ESP
 *        workers are paid what a profit-share worker earns: the private premium's profit-share fraction (the PTFs' this phase) joins
 *        the profit share (the model has no firms, so the match is funded from the premium itself; every dollar stays accounted),
 *        and the rest is the private price pool. It is shared among participants who are not PTF members (the BU spent at private
 *        ESPs, by the same proxy that sizes the PTFs' share) in proportion to the BU each spent last year, capped at their own
 *        essentials; the rest carries to next year. BU buy the discounted essentials first; the BU the cut frees expire as usual.
 *  privWk 'match' (default) as above; 'none': the whole private premium becomes lower prices (sensitivity row).
 *  p1,p2 shares [price cuts, reinvestment, profit share] in phase 1 (until PTF capacity is reached) and phase 2 (S2, S3). Shares that
 *        sum below 1 leave a remainder paid as today's stand-in (by wage to every adult), for the "each part alone" rows.
 *  K     capacity: phase 2 starts the year after cumulative reinvestment per adult, in year-0 dollars, reaches K (d101: $18,862, BEA
 *        Fixed Assets Table 3.1ESI 2025 net stock of food and beverage stores, food services and utilities / Census adults 18+, 2025).
 *        Infinity = never. swYear (a number): phase 2 from that year on, whatever the capital account (the fixed-year rows).
 *  cust  who gets the price cuts: 'auto' (default) = 'ptf' under priv 'owners' (the PTFs' cuts reach the PTFs' customers, read as PTF
 *        members, the same proxy that sizes the PTFs' share) and 'all' under 'same' (d98); 'all' every adult; 'pp' participants and
 *        PTF members; 'ptf' PTF members; 'part' participants. Shared in proportion to each customer's essentials at own prices
 *        (basket x essentials share x the PTF and PTH factors), one uniform cut delta = price pool / that sum, capped at 1; the rest
 *        carries to next year's price pool.
 *  bu    'one' (d99): one price for BU and cash; a participant's BU buy the discounted essentials first, and the BU a cut frees expire
 *        and go to project hiring like every expired BU. 'cash': the cut applies to cash purchases only (no BU freed).
 *  rv    'capital' (d100): reinvestment goes to an ESP capital account no household receives (its effect on supply is plan step 2).
 *        'price': the reinvestment share is spent as price cuts (no capital is built, so phase 1 lasts the run).
 *  wk    'espPart' (default from the step-11 restudy; Duke's answer recorded in the project ledger, s40): the profit share is paid in
 *        dollars to ESP workers who take part (ESP payroll's workforce, d72), by last year's wage; it is earned, so it enters the wage
 *        elasticity as a raise (1 + share / last year's wage) with no income effect. 'esp' (d104's earlier default, used in steps 1-9):
 *        every ESP worker.
 * Accounting (d105): price cuts used, the profit share, reinvestment and the owners' dollars are parts of the ESP's conversion premium,
 * counted as conversion in the testbed (financed by the contribution under tax financing; created at a under money and hybrid). The
 * design-neutral BLEI gate keeps counting the BU a participant would have spent without the cut (price cuts enter no design's neutral
 * BLEI). No RNG is drawn in any SURP step (CRN holds). SPS: per-run state, reset at yr 0; SPS.acc tallies flows in year-0 dollars. */
var SURP = null;

// index.html line 3783
var SURP_DEFAULTS = {p1:[1/3, 1/3, 1/3], p2:[0.6, 0, 0.4], K:18862, swYear:null, cust:'auto', bu:'one', rv:'capital', priv:'owners', wk:'espPart', privWk:'match'};  /* wk 'espPart': Duke's answer (ledger, s40): only participating ESP workers share; applied from the step-11 restudy on (steps 1-9 ran 'esp', d104's earlier default) */

// index.html line 3784
var SPS = null;

// index.html line 3800
/* Plan step 2 (Oct 1, 2026; design default 1; dev/reports/02-production-side.md): THE PRODUCTION SIDE, the new output that backs the BU.
 * Hub-spec (framework) model only; PROD = null (the default) leaves every run bit-identical (full-output diffs; `unit`). When an object:
 *  cap   'ptf' (default): PTF capacity. The PTFs can serve a share c of the population: c = c0 + the ESP capital account per adult / K
 *        (SURP.K, d101), capped at 1, where c0 is the PTF members' share at the start of year 0 (the PTFs that already exist). An adult
 *        joins PTF (Bass adoption or SZH induction, with the draws the engine already makes) only while PTF members are fewer than
 *        c x adults; no member is ever removed. Reinvestment in year t serves customers from year t + 1. With the split on, phase 2
 *        starts when c reaches 1 (enough PTFs to serve demand, S3). 'none': PTF reach is unlimited, as before.
 *  match 'face' (default): project work is output valued at the cost of the hours it pays for, the contract pay (the BU's face
 *        value; hours = project BU converted / the contract pay); the conversion paid above that is a reward, not output. 'own': the
 *        hours valued at the worker's own market wage (more output for the many project workers paid above the contract rate, so
 *        the less cautious reading). The ESP split's reinvestment is output at face value (capital
 *        goods). Neither adds essentials supply. Both enter the price module only where conversion is created money (money and
 *        hybrid financing): unmatched money = (1 - a) x (conversion - matched output), so H1 (a = 1) stays a sensitivity row.
 *  mat   materials bought per dollar of project labour (0: the model has no materials; a stated limit).
 * No RNG is drawn in any PROD step (adoption reads the draws the engine makes for every agent-year). PDS: per-run state. */
var PROD = null;

// index.html line 3801
var PROD_DEFAULTS = {cap:'ptf', match:'face', mat:0, speed:'reinvest'};

// index.html line 3840
/* Plan step 15 (Oct 2, 2026; Duke's answers d137-d139; dev/reports/v5-2-creative-output-reading.md). Two more PROD options:
 *  match 'market' (Duke's reading, d138): a creative project offers its output to members far below the market price and converts the
 *        BU it receives at its earned rate, so its dollar income is about what the market would pay (revenue neutral). The whole project
 *        payout (the elevated part included) counts as output, beyond essentials. The model's project hours are the work shown: no hours,
 *        no payout. 'face' (session 30's rule) stays the cautious other reading; a = 1 (H1) the optimistic row.
 *  speed 'oneyear' (Duke's answer d137, the main run): PTF capacity grows within a year: the adults the capacity limit turned away last
 *        year (draws the engine already makes) are served this year. Capacity reinvestment has not paid for is borrowed and charged every
 *        year at depreciation plus real interest, paid from the PTFs' premium before the split (any shortfall carries). 'reinvest'
 *        (session 30): capacity grows only as reinvestment pays for it (the 5-year rule; the labelled other reading).
 * The charge (real, on capital in year-0 dollars revalued with the price level):
 *  PROD_CAP_DEP 4.528%: BEA Fixed Assets Table 3.4ESI, current-cost depreciation 2025 (utilities $166,748m, food and beverage stores
 *        $24,478m, food services and drinking places $33,202m; lines 9, 45, 95) over the mean of Table 3.1ESI net stock, yearend 2024 and
 *        2025 ($4,823,935m and $5,088,349m) (Section3All_xls.xlsx, file created Sep 28, 2026).
 *  PROD_CAP_INT 3.668%: a real corporate borrowing rate, 2025 annual means from FRED: Moody's Baa yield 5.998% (BAA) less the 10-year
 *        Treasury 4.293% (DGS10) plus the 10-year TIPS yield 1.963% (DFII10). The depreciation part buys replacement capital (output,
 *        like reinvestment); the interest part goes to lenders the model does not have (counted as conversion, unmatched; a stated limit).
 * ESP octave caps (d139): BU can only buy essentials adults already consume, which ESPs already supply, so the BU an ESP converts never
 * exceed its throughput; the cap holds by construction (v5ProdUnitSuite checks it). Individuals and Collectives have no cap (PROJ.cap
 * false, d64), and every expired BU already pays project work (PROJ.share 1), the route Duke's "6 expired BUs" describes. */
/* Plan step 16 (Oct 2, 2026; dev/reports/v5-3-spending-layer.md): THE SPENDING LAYER. Spending at businesses raises output and jobs where
 * there is idle capacity. MULT = null (the default) leaves every run bit-identical. When an object (testbed, Source financing only):
 *  push  the programme's new spending: last year's net Source payout (BU spent plus conversion paid, less the conversion tax kept), in
 *        current dollars (one-year lag; it is known at the start of the year). The multiplier is per dollar of transfer, so it already
 *        includes how much of a transfer is spent (Parker et al. 2013: 50-90% within a quarter, for context).
 *  m     output per dollar of push in a recession year: 1.5 (main; the middle of CBO's 0.8-2.2 for transfers to individuals, Estimated
 *        Impact of the American Recovery and Reinvestment Act, output multipliers table; the low end of Auerbach and Gorodnichenko 2012,
 *        AEJ: Economic Policy 4(2), 1.5-2 in recessions); 0.8 (low; CBO's low end, in line with Ramey and Zubairy 2018, JPE 126(2),
 *        multipliers below 1 with or without slack); 2.2 (high; CBO's high end).
 *  Idle capacity: only the income a recession takes away (the model's recession path). Outside recessions the model has no slack (no
 *        unemployment beyond what workers choose), so the layer adds nothing there and the published normal-times multipliers (0-0.5)
 *        never apply; spending above capacity goes to prices exactly as before. Automation's wage losses are structural, not idle demand,
 *        and are not counted (a stated limit).
 *  The wages restored = min(labour share x m x push, the recession's wage loss); they reach every adult in proportion to what the
 *        recession took from them (in the model everyone loses the same share), by raising the year's income multiplier. Labour share
 *        0.5079: compensation of employees over gross domestic income, 2025 (BEA NIPA via FRED COE and GDI, sums of the four quarters).
 *        The non-labour part of the added output is not paid to anyone (the model has no firms; a stated limit). The restored wages raise
 *        the output the price rule divides by, so they slow the created-money price rise; nothing else changes.
 * No RNG is drawn. MLS: per-run state (push, and per year the fill and wages restored). */
var MULT = null, MULT_DEFAULTS = {m:1.5}, MLS = null, MULT_LS = 62784.912/123630.857;

// index.html line 3849
/* v5.2 step 7 (ledger s86): HOUSING CAPTURE. HCAP = null (the default) leaves every run bit-identical. When {c, all} (testbed row option hc), rents
 * rise by c dollars per BU dollar spent on rent outside PTH: each year the mark-up is c x last year's BU spent on rent outside PTH / last year's rent bill
 * of the adults it falls on, who are the BU holders outside PTH (all false: landlords raise the rent of tenants who pay with BU, as voucher holders'
 * rents rose in Collinson and Ganong 2018) or every adult outside PTH (all true: the rise spreads to other renters, as in Susin 2002; with his figures,
 * $5.8 billion of subsidy and $8.2 billion of higher rent for non-recipients, this formula gives his 16%). BU pay the higher rent where they suffice and
 * count as programme cost; without BU it is paid in cash. PTH members' housing is community-owned and is not marked up (the design's answer to capture).
 * The extra rent leaves the 500 adults (the model has no landlords; a stated limit). The mark-up is a level set from last year's flows, so it does not
 * compound. No RNG is drawn. HCS: per-run state. */
var HCAP = null, HCS = null;

// index.html line 3856
/* v5.2 step 7 (ledger s86): REVIEW ERRORS AND COLLUSION in the Collectives' review of project work. REVIEW = null (the default) leaves every run
 * bit-identical. When {u, q} (testbed row option rv): each year a share u of project conversions at a rate above 1x are unearned (the work delivered is
 * worth 1x: errors and collusion together), and audits catch a share q of those (a caught conversion is paid at 1x). An unearned conversion that is not
 * caught is paid at its rate, but only the 1x value counts as new output backing it. Which conversions are unearned comes from a stream of its own
 * (seed + 800023; one number per adult a year, for every adult, so every reading sees the same draws and the shares nest: 5% within 10% within 20%), so
 * the main stream's 8 draws per adult-year are untouched. REVS: per-run state (the stream; unearned pay not caught, and pay clawed back, year-0 $). */
var REVIEW = null, REVS = null;

// index.html line 3868
var PROD_CAP_DEP = 224428/((4823935 + 5088349)/2), PROD_CAP_INT = (5.998 - 4.293 + 1.963)/100;

// index.html line 3869
var PDS = null;

// index.html line 3917
/* Plan step 18 (Oct 2, 2026): the v5.0 release row's switches beyond session 30's: private ESPs pass their premium to BU customers (step 14),
 * creative output at market value and capacity within a year (step 15), the spending layer (step 16). Read by the testbed's release section and the page. */
var REL_V5 = {sp:{priv:'prices'}, pd:{match:'market', speed:'oneyear'}, ml:{}, gc:true};  /* v5.1 (audit V5-02): gc:true = the framework BLEI gate reads this year's BU; every release-panel row carries it */

// index.html line 3921
/* v5.3 B10 (Oct 7, 2026; dev/DECISIONS.md Session 39, "B10"): what v5.3's main result adds to REL_V5, recorded before the restudy: households (pooled, the child
 * allowance at a quarter, partners' income swings at Shore's correlations, starting wealth from the SCF), the Hub's list of what BU can buy, income-graded
 * spending, and the two accounting corrections. relMainCfgs(PR) gives the no-programme and main rows the page's live run and the panel share. */
var REL_V53 = {hh:{pool:'household', childBU:0.25, shock:'shore', wealth:'scf'}, bs:'hub', sg:true, g:{PTH_APPR_CONSERVE:true, SURP_CUT_MARKUP:true}};

// index.html line 3926
/* v5.4 step 9 (Oct 7, 2026; dev/DECISIONS.md Session 41; dev/reports/v5-22-v54-report.md): what v5.4's main result adds to v5.3's, recorded before the 500-run
 * restudy (no modelling error found, so every part joins): the risk measures (reporting only), job loss and re-employment with unemployment insurance (in both
 * runs), PTH's books, PTF by sector with members who leave. The disaster is a scenario, shown as a reading. relMainCfgs(PR) carries them in both rows (the page's
 * live run and the panel); relMainCfgs(PR, true) gives v5.3's main row and its no-programme run exactly. */
var REL_V54 = {v54:{rk:true, empl:{}, pthb:{}, ptfs:{}}};

// index.html line 3960
/* Plan step 9 (Oct 1, 2026; dev/reports/09-avoided-costs.md): PUBLIC COSTS OF POVERTY AVOIDED, reported beside the programme's cost (no feedback
 * into the model). Homelessness (with the health care and justice costs that come with it): the model's extreme-poverty overlay (v4.18: HUD
 * 2025 AHAR point-in-time rate, scaled by housing distress against year 0) gives unhoused person-years; each is costed at two sourced ends:
 *  low   emergency-shelter cost only: $581 a month for an individual (Des Moines; Spellman et al., Costs Associated with First-Time
 *        Homelessness for Families and Individuals, HUD/Abt Associates, 2010; 2009 dollars) x 12 x CPI-U 321.943/214.537 = $10,462 (2025 $).
 *  high  every public cost of homeless residents: $520 million a year (Santa Clara County, 2007-2012; health care 53%, justice 34%; Flaming,
 *        Toros and Burns, Home Not Found, Economic Roundtable, 2015) / 7,631 homeless people counted in January 2013 (Santa Clara County
 *        Homeless Census) x CPI-U 321.943/218.056 (2010) = $100,608 (2025 $) per homeless person-year. High because it counts the costs of
 *        everyone homeless at any time in the year against a one-night count, and the costliest users dominate.
 * Health care and crime among adults who are poor but housed are not costed: no primary source in hand gives a causal public cost per poor
 * adult-year (stated in the report as a limit, with the direction of the omission: it understates avoided costs). */
/* Plan step 17 (Oct 2, 2026; dev/reports/v5-4-public-costs.md): WIDER PUBLIC COSTS OF POVERTY AVOIDED, reported beside the programme's cost
 * (no feedback into the model; it changes no adult's resources). Counted only where a causal estimate of income's effect exists; zero main
 * where none does; low / main / high. All in 2025 dollars per adult-year, from two paired measures against no programme: the poverty-gap
 * dollars closed (person-year FGT1 x the cost-of-living line, year-0 = 2025 dollars) and the person-years lifted above the cost of living.
 *  justice  Deshpande and Mueller-Smith (2022, QJE 137(4)): each youth removed from SSI saved the government $37,700 in SSI over two
 *           decades and created $30,200 in incarceration and $10,800 in police and court costs, i.e. $0.80 and $0.29 per dollar of
 *           income withdrawn (both in the same dollars). Their sample's annual incarceration rate is 4.7% (control mean, ages 18-38);
 *           US adults' is 0.70% (BJS, Correctional Populations in the United States, 2022: 1,827,600 in prisons and jails at yearend /
 *           261.5 million adults, Census 2022), so the main figure scales incarceration by 0.70/4.7 and leaves police and courts out
 *           (mostly fixed salaries); high: the study's own $1.09 per dollar; low: 0 (the effect may not carry to other adults). Applied to
 *           poverty-gap dollars closed (the study's income changes were up to about $10,000 a year; larger gaps are a stated limit).
 *  hospital Forget (2011, Canadian Public Policy 37(3)): a guaranteed income cut hospitalisation by 8.5%. Applied to person-years lifted
 *           above the cost of living: 8.5% x stays per person-year (35.8m / 325.1m, HCUP Statistical Brief 261, 2017) x cost per stay
 *           ($434.2bn / 35.8m) x CPI-U 2025/2017 (321.943/245.120) x the public share of hospital costs (Medicare 46.9% + Medicaid 19.4%,
 *           same brief). Low: 0 (one study, another country and decade); high: the same as main.
 *  psych    state psychiatric hospitals, outside HCUP's community hospitals: $14.8bn of state mental health agency spending, FY2024 (NRI),
 *           over 340.1m residents (Census 2024), x Forget's 8.5%, per person-year lifted. Low 0.
 *  er       emergency visits: no causal estimate for adults' income, so 0 main; high: Forget's 8.5% x treat-and-release visits per person
 *           (107.4m / 332.0m, HCUP Statistical Brief 311, 2021) x $750 a visit x CPI-U 2025/2021 (321.943/270.970) x the public share.
 *  Not costed: child welfare (the model has no children yet), ambulances (no separate source), and the Alaska dividend's short-run rise in
 *  substance-related incidents (Watson, Guettabi and Reimer 2020), which would offset some savings. */
var AVOID_WIDE = (function(){ var pub = 0.469 + 0.194, rate = 0.0070/0.047;
  return {jMain:rate*30200/37700, jHigh:(30200 + 10800)/37700, hosp:0.085*(35.8/325.1)*(434.2e9/35.8e6)*321.943/245.120*pub, psych:0.085*14.8e9/340.1e6,
    erHigh:0.085*(107.4/332.0)*750*321.943/270.970*pub}; })();

// index.html line 3973
var OCT = null;

// index.html line 3974
var OCT_DEFAULTS = {gap:3};

// index.html line 3975
var COST = null;

// index.html line 3976
var COST_DEFAULTS = {food:0.0494, util:0.0260};

// index.html line 3977
var JOIN = null;

// index.html line 3978
var JOIN_DEFAULTS = {cost:'revealed', stay:2};

// index.html line 3979
var JNS = null;

// index.html line 3990
/* v5.2 round, step 3 (Oct 3, 2026; ledger s82; dev/DECISIONS.md, Session 35): SAVINGS THAT KEEP UP WITH PRICES. null = off (every earlier run). When an object, each
 * year from year 1 every adult's savings (positive wealth) earn interest equal to the year's price rise plus a real rate:  W x ((P_t / P_t-1) x (1 + r) - 1),
 * where P is the model's price level (outside inflation x the price module's basket index, the one the cost of living reads) and r = SAVE.r. It applies to every
 * adult in every run that sets it, the no-programme run included; it is not design-specific. Debts (negative wealth) are left as they are unless SAVE.debt = 'same'.
 *  r  0.0097: the average real yield on 10-year Treasury Inflation-Protected Securities, 2003-2025 (FRED series DFII10, daily, 5,753 observations, mean
 *     0.972%; sources/tips_real_rate.py). Readings: 0 (savings that only keep their value) and 0.0196 (the 2025 average).
 * The interest is added to savings at the start of the year, before the year's income and costs (it revalues last year's savings into this year's prices); it is
 * reinvested, so it does not enter the year's income measures, the spending share or the labour response. Where it comes from is not modelled: it is read as paid
 * by borrowers and the economy outside the 500 adults, as in a banking system, so it does not enter the price rule as new money (a stated limit: the reading shows
 * how much of a result is the missing protection of savings, not a model of a bank). No random draw is added. SVS holds the run's state (reset at year 0). */
var SAVE = null, SAVE_DEFAULTS = {r:0.0097, debt:'none'}, SVS = null;

// index.html line 4012
/* v5.2 round, step 4 (Oct 3, 2026; ledger s83; decision A, ledger d152; dev/DECISIONS.md, Session 35): ADULTS WHO AGE, RETIRE AND ARE REPLACED. null = off (every
 * earlier run: the adults never age). When an object (testbed runs; tbRunCore sets it up with ageInit), every adult has an age, drawn at year 0 from the Census
 * distribution of the population aged 25-66 (CFG.AGE_WEIGHTS). From year 1, at the start of each year: each adult dies with the life table's probability at their age
 * (CFG.DEATH_Q) and is replaced in the same place by a new 25-year-old (so the population stays at its size; the new adult is drawn like a year-0 adult, with the
 * starting wage scaled by how far the working adults' mean wage has moved since year 0 and the starting savings by the price level, and the estate leaves the
 * model); survivors age a year; an adult who
 * reaches 67 (CFG.RETIRE_AGE) retires: no wages, and a Social Security benefit instead, in year-0 dollars moved with the price level as the SSA's COLA moves it:
 *  ss   'average' the average retired-worker benefit (CFG.SS_RETIRE_ANNUAL, $24,180 in 2025); 'pia' the benefit formula on the adult's own monthly wage at
 *       retirement in year-0 dollars (CFG.SS_BEND_POINTS; the model keeps no earnings history, so the last wage stands in for average indexed earnings).
 *  ret  what a retired participant keeps under Compassionism (decision A): 'keep' (the default) the full BU for life on top of Social Security; no paid ESP work
 *       after 67, but expired BU can still be converted through creative work (project hiring) at the rate the adult has earned; 'noconv' the BU but no
 *       conversion after retirement; 'none' no design-specific rule: a retiree leaves the programme and lives on Social Security, as with no programme.
 * The benefit is money income in every measure (and in the price module's income); it is not programme cost. Retirees keep their memberships (PTF, PTH).
 * Every random number the switch needs comes from its own stream (ageInit: mulberry32(seed + 600011): one draw per adult for the starting age, one per adult-year
 * for death, and a new adult's construction draws), so the main stream still draws 8 numbers per adult-year and every design sees the same deaths and the same
 * new adults (paired seeds hold). AGS holds the run's state. Mortality depends on age only (a stated limit: in the US the poor die younger). */
/* v5.3 B7 (Oct 7, 2026; plan item B7; dev/DECISIONS.md Session 39, "B7"): earn 'flat' (the default: a wage does not depend on age, as before) | 'cps'
 * (a calibration reading): wages follow the shape of US median earnings by age (BLS, CPS, sources/earnings_age.md; CFG.EARN_AGE, straight lines between
 * the age groups' middle ages). At the start each adult's wage is multiplied by the curve at their age over its mean across the population aged 25-66
 * (CFG.AGE_WEIGHTS), so the average wage is unchanged; each birthday moves a worker along the curve; a new 25-year-old starts at the curve's value at 25;
 * the wage index a newcomer's wage follows leaves the curve out. No draw is added. */
var AGE = null, AGE_DEFAULTS = {ret:'keep', ss:'average', earn:'flat'}, AGS = null;

// index.html line 4013
CFG.EARN_AGE = {age:[22, 29.5, 39.5, 49.5, 59.5, 67.5], w:[831, 1160, 1436, 1421, 1367, 1233]};  /* median usual weekly earnings, full-time workers, by age group's middle age (BLS CPS, Q2 2026) */

// index.html line 4028
/* v5.2 round, step 5 (Oct 3, 2026; ledger s84; dev/DECISIONS.md, Session 35): LATENT, readings that change how the adults are drawn, each closing a gap between the
 * no-programme run and US data. null = off. When an object, latentAdjust transforms each drawn adult before it is placed (year 0, and every new adult when ageing
 * is on), with no random draw added (it reuses each draw's own normal score), so every design sees the same adults. Applied in every run that sets it, no
 * programme included.
 *  wealth  rho > 0: starting savings drawn from the SCF distribution of the comparison group (CFG.SCF_NETWORTH_PCTL), linked to the adult's wage by a Gaussian
 *          copula with correlation rho (CFG.SCF_WAGE_WEALTH_RHO); the model's own draw is lognormal and independent of the wage.
 *  risk    rho < 0: the automation risk keeps its distribution (the CFG.AUTO_* mixture) but is linked to the wage with copula correlation rho (CFG.FO_RISK_WAGE_RHO).
 *  wsd     > 0: log wages spread with this standard deviation (CFG.SCF_WAGE_SIGMA) around the same median, in place of 0.5.
 *  wmed    > 0: wages centred on this annual median in 2025 dollars (CFG.SCF_WAGE_MEDIAN) in place of the model's $39,945 (log mean 3.5 in model units). */
var LATENT = null;

// index.html line 4036
/* v5.3 B7 (Oct 7, 2026; plan item B7; dev/DECISIONS.md Session 39, "B7"): INCOME-GRADED SPENDING, a calibration reading (null = off: every adult pays
 * their full cost each year, as before; applied in every run that sets it, no programme included). When an adult's income this year (wages, Social
 * Security, a cash grant) is below their cash cost, they spend cost x (income / cost)^eps rather than the whole cost: people with less income spend less,
 * at the income elasticity of spending in the Consumer Expenditure Survey 2024 (quintiles 2-5 per equivalent adult, CFG.CE_SPEND_ELAST,
 * sources/ce_spending.py), anchored where income equals the cost (a modelling assumption). The measures still compare income with the full cost (the
 * cut is hardship, not relief); the cut stays in the adult's wealth (an accounted flow, a._acGr) and counts as basket consumption that did not happen
 * in the price model's demand (as a write-off at the floor does), but not as money. A pooled couple is graded on its totals (hhPool). */
var SPEND_GRADE = null;

// index.html line 4042
/* S35 (Oct 30, 2026; research-update prereg/2026-11-study-program.md, study F): the debt reading, a sensitivity reading of the graded spending rule above
 * (null = off, as released). When the rule would have an adult (a pooled couple: the couple) spend more than the rule's own income this year, the excess is
 * paid only from savings: wealth at the start of the year, if positive, plus the borrowing limit for ordinary spending (lim, 0: no borrowing). Once that is
 * used up the adult spends its income; the rest of the cost is cut, as the rule's own cut is (it stays in wealth, a._grCut). Nothing else changes: the debt
 * floor still applies to job loss, shocks and every other flow. No random draw. Per row: c.dr ({} or true = {lim:0}). */
var DEBT_READ = null;

// index.html line 4056
/* S13 (Oct 31, 2026; outside audit of the engine, dev/reports/s13-engine-audit.md): corrections found by the audit, each its own part, all off by default
 * (null = off, as released; every released figure is unchanged). Per row: c.au (true = the three corrections {gate, sg, fbs}; or an object naming parts).
 *  gate  the BLEI gate on the wage bonus (and the PTF adoption term that reads the same BLEI) in year-0 prices, divided by the year's price level, as
 *        every reported BLEI figure is (audit E3). As released the gate compares this year's dollars with the fixed $68.33 a day.
 *  sg    income-graded spending on all of the year's cash income: as released it reads wages, Social Security, cash grants, unemployment insurance
 *        and the safety net, and leaves out conversion income (projects, business payouts, the ESP premium) and the testbed's transfers less its
 *        contribution, which are added later in the year (audit E4).
 *  fbs   the financial-stability score that drives octave advancement (framework conversion) in year-0 dollars, divided by the year's price level,
 *        since its lambda is set in year-0 dollars (audit E7).
 *  wOut  a reading, not a correction (not in c.au === true): wages also follow the environment's outside inflation (inflRate, 2% a year in Adverse
 *        and Stress), added to wage growth as the programme's own price rise is (audit E5). As released wages follow only the programme's price level.
 * No random draw in any part. */
var AUD = null;

// index.html line 4064
/* v5.3 B7 (Oct 7, 2026; plan item B7, "FBS lambda -> FBS50"; dev/DECISIONS.md Session 39, "B7"): FBS50, the advancement rule in interpretable units. The
 * chance of advancing an octave in a year is 1 - exp(-lambda x FBS) (BLEI paper, Index IV); FBS50 = ln 2 / lambda is the monthly free bandwidth surplus at
 * which that chance is even ($524 to $4,191 a month over the model's lambda range, CFG.FBS_HALF_SAT_LO/HI). null (the default) leaves the rule as it is.
 * When an object (row option fb): dist 'lambda' keeps each adult's lambda (evenly spread in lambda, as now) and 'fbs50' spreads FBS50 evenly over the same
 * range instead (the same uniform draw, read in FBS50: more adults need a larger surplus); scale multiplies every FBS50 (a sweep: how hard advancing is).
 * It also reports the share of participant-years whose FBS reaches their own FBS50 (better than even odds), for everyone and for adults in households
 * with children (FBS_KEYS). No draw is added. */
var FBS50 = null, FBSS = null, FBS_KEYS = ['fbsAbove', 'fbsAboveKids', 'fbs50Med'];

// index.html line 4066
function fbsRes(F, out){ if (!F) ⟦not run⟧ out.fbsAbove = F.n ? F.a/F.n*100 : 0; out.fbsAboveKids = F.nK ? F.aK/F.nK*100 : 0; var v = F.f.sort(function(x, y){ return x - y; }); out.fbs50Med = v.length ? v[Math.floor(v.length/2)] : 0; return out; }

// index.html line 4067
CFG.CE_SPEND_ELAST = 0.5573;  /* the income elasticity of spending (BLS CE 2024, quintiles 2-5, per equivalent adult) */

// index.html line 4068
function normCdf(z){ var x = Math.abs(z)/Math.SQRT2, t = 1/(1 + 0.5*x), r = t*Math.exp(-x*x - 1.26551223 + t*(1.00002368 + t*(0.37409196 + t*(0.09678418 + t*(-0.18628806 + t*(0.27886807 + t*(-1.13520398 + t*(1.48851587 + t*(-0.82215223 + t*0.17087277)))))))));
  return z >= 0 ? 1 - r/2 : r/2; }  /* the complementary error function of Numerical Recipes (erfcc), relative error < 1.2e-7 everywhere, so the tails stay accurate */

// index.html line 4070
function normInv(p){ var a = [-39.69683028665376, 220.9460984245205, -275.9285104469687, 138.3577518672690, -30.66479806614716, 2.506628277459239], b = [-54.47609879822406, 161.5858368580409, -155.6989798598866, 66.80131188771972, -13.28068155288572],
  c = [-0.007784894002430293, -0.3223964580411365, -2.400758277161838, -2.549732539343734, 4.374664141464968, 2.938163982698783], d = [0.007784695709041462, 0.3224671290700398, 2.445134137142996, 3.754408661907416], q, r;
  p = Math.min(1 - 1e-12, Math.max(1e-12, p));
  if (p < 0.02425){ q = Math.sqrt(-2*Math.log(p)); return (((((c[0]*q + c[1])*q + c[2])*q + c[3])*q + c[4])*q + c[5])/((((d[0]*q + d[1])*q + d[2])*q + d[3])*q + 1); }
  if (p > 1 - 0.02425){ q = Math.sqrt(-2*Math.log(1 - p)); return -(((((c[0]*q + c[1])*q + c[2])*q + c[3])*q + c[4])*q + c[5])/((((d[0]*q + d[1])*q + d[2])*q + d[3])*q + 1); }
  q = p - 0.5; r = q*q; return (((((a[0]*r + a[1])*r + a[2])*r + a[3])*r + a[4])*r + a[5])*q/(((((b[0]*r + b[1])*r + b[2])*r + b[3])*r + b[4])*r + 1); }  /* Acklam's rational approximation, relative error < 1.2e-9 */

// index.html line 4132
/* ─── v5.3 B3 (Oct 7, 2026; plan item B3; dev/DECISIONS.md Session 39, "B3, households"): HOUSEHOLDS. null (the default, and the page's) leaves every run
 * bit-identical. When an object (HH_DEFAULTS), and in the framework (Hub-spec) conversion model, the adults are grouped into households once at the start, on
 * their own random stream (seed + 500009), as fixed counts from the Census CPS ASEC 2023 tables (sources/households.py): couples with and without children
 * under 18, single parents, and single adults; partners are paired at random; children are dependants with an age each (no draws on the main stream, so
 * every adult keeps its eight draws a year and its pairing with the no-programme run).
 *  - What a household needs: MIT's budget for its family type (one or two working adults, up to three children), each component as a ratio to the
 *    one-adult budget (CFG.HH_RATIO, so a single adult is exactly the adult-only model), plus childcare for each child under 13 at MIT's own prices in MIT's
 *    order (CFG.HH_CHILDCARE: first $12,914, second $11,638, third and more $7,824 at the model's level; priced with the general price level). An adult
 *    carries an equal share of the household's budget and of the children's BU (each child childBU x the adult BU: Duke's quarter, d167).
 *  - pool 'household' (d168, the main reading): at the end of the year a couple's cash surplus is pooled before the spending rule takes its share, their
 *    wealth is shared equally, the debt floor applies to the household, and poverty status is the household's; 'individual': each adult pays their equal
 *    share from their own income and keeps their own savings.
 *  - Decisions are the household's: a partner takes the first adult's participation, PTF and PTH draws at the start and follows the first adult's later
 *    joins (open enrolment, PTF adoption).
 *  - BLEI: the daily cost of basic living (rent, food, utilities, transport: the BLEI paper's definition) is the household's, from MIT's (housing + food +
 *    transport) for its type, and each adult's BLEI uses their own resources against an equal share of it (a._hhD multiplies agentBLEI's daily cost).
 * With ageing on (AGE), households live through the run: see CHILDREN'S LIVES below (v5.3 B4, B5). Single adults (one adult, no children) take the
 * adult-only path everywhere. */
/* v5.3 B6 (Oct 7, 2026; plan item B6; dev/DECISIONS.md Session 39, "B6"): shock 0 (the default: partners' yearly income swings are independent, as before)
 * | 'shore' | a number in [-1, 1]. The model's income shock is the year's macro multiplier (the recession path, common to everyone) times each adult's own
 * swing (uniform 0.90-1.10 on the main stream). With a shock, a couple's two swings share a household part drawn once a year on its own stream
 * (seed + 500041), so their correlation is the chosen value and each adult's swing keeps its spread; 'shore' takes Shore (2010, Review of Economics and
 * Statistics 92(3)): spouses' labour-income changes correlate about +0.10 in good years and -0.10 in bad ones (CFG.HH_SHOCK_CORR; recession years are bad). */
/* v5.3 B7 (Oct 7, 2026; plan item B7; dev/DECISIONS.md Session 39, "B7"): wealth 'model' (the default: each adult's own starting draw, as before) | 'scf'
 * (a calibration reading, applied in every run that sets it, no programme included): each household's starting net worth comes from the 2022 Survey of
 * Consumer Finances for its type (families with a head aged 25-66 and wage income; sources/scf_households.py; CFG.HH_SCF_PCTL, 100 quantiles in 2025
 * dollars; single adults use CFG.SCF_NETWORTH_PCTL, the same group), linked to the household's wage income by a Gaussian copula with the survey's own
 * correlation for the type (CFG.HH_SCF_RHO), and shared equally by its adults. No draw is added: within each type, the households' wages and their
 * adults' own wealth draws are ranked, and the two normal scores are combined. Newcomers with ageing keep the model's own draw (a stated limit). */
var HOUSEHOLDS = null, HH_DEFAULTS = {pool:'household', childBU:0.25, estate:'heirs', shock:0, wealth:'model'}, HHS = null;

// index.html line 4133
CFG.HH_SCF_PCTL = {coupleKids:[-113197,-43954,-15181,-6496,-648,550,3318,5514,7686,10638,12871,16177,20793,23597,29152,33434,38624,46061,51242,62142,67200,70162,71778,79282,86766,93332,98264,103187,109809,112868,120128,125519,130909,134684,141743,146350,150805,157902,164834,172540,183823,188443,197345,205295,214361,223351,229204,235416,245171,266822,281541,295456,310843,323777,334693,349461,360614,377408,396441,412994,434695,463932,489119,510287,541255,555660,594647,612821,630061,662465,691728,723106,749286,815013,843011,880062,930555,994603,1044523,1119505,1197983,1320665,1394148,1437558,1477815,1540792,1611177,1698713,1965287,2150866,2536985,2807946,3108593,3499511,4041682,4833081,5629278,7436513,11651611,22097732],
  coupleNoKids:[-414584,-84673,-49841,-21672,550,2035,3521,6820,9571,12541,16242,19712,24227,27350,30563,32646,36701,40544,50923,61246,64426,72970,80103,88567,95604,106954,120035,128872,139820,141997,151695,168294,171997,174282,176892,188310,194809,198842,209291,224647,240939,254862,273927,286803,301411,311105,318511,324538,331350,345401,368353,379527,392917,404828,417463,424960,429845,443661,460753,474492,502081,519495,528288,556934,609464,677232,695805,724041,772885,804706,858709,886499,919297,959817,1001515,1033835,1113078,1184339,1261568,1341780,1427758,1561764,1697419,1883320,1981924,2264727,2350679,2539754,2720822,2836723,3211332,3308371,4122563,4508115,5003150,6470032,7587033,8836987,12771253,31326977],
  singleParent:[-112095,-89908,-75679,-59714,-52584,-35407,-27424,-21055,-18711,-15279,-13864,-12871,-10308,-7657,-5269,-692,0,110,286,330,880,3045,4026,4917,5433,6215,7021,7756,9030,10040,10531,11609,12816,13751,14022,15353,16146,18902,21858,22734,25319,28640,31410,34554,36527,38602,40821,42903,44113,46182,49935,53772,55829,56549,59016,60374,66126,67794,72332,78953,85470,94579,97274,105388,118390,122396,134848,147462,157395,168279,171779,181121,186234,203059,211897,220952,240508,249601,249827,252607,265636,272112,290860,297241,325623,336015,390942,399548,428076,446241,464453,495084,739215,768154,805099,915532,1109721,1140010,1697112,3699413]};  /* net worth at 0.5%, 1.5%, ..., 99.5%, 2025 dollars (SCF 2022, sources/scf_households.py) */

// index.html line 4136
CFG.HH_SCF_RHO = {coupleKids:0.6458, coupleNoKids:0.4978, singleParent:0.3347, single:0.3585};  /* normal-score correlation of wage income with net worth, by type (single = CFG.SCF_WAGE_WEALTH_RHO) */

// index.html line 4137
CFG.HH_SHOCK_CORR = [0.10, -0.10];  /* correlation of spouses' income changes: good years, recession years (Shore 2010) */

// index.html line 4138
CFG.HH_COMP = {coupleKids:0.3163, coupleNoKids:0.3291, singleParent:0.0495, single:0.3050};  /* adults 25-64 by household type (CPS ASEC 2023, tables A1, A3, UC3) */

// index.html line 4139
CFG.HH_KIDS = {couple:[0.4063, 0.3838, 0.1462, 0.0637], single:[0.5651, 0.2785, 0.1101, 0.0463]};  /* 1, 2, 3, 4 or more own children under 18, per parent (table A3) */

// index.html line 4140
CFG.HH_KID_AGES = {couple:[0.3278, 0.3308, 0.3414], single:[0.2649, 0.3433, 0.3918]};  /* children aged 0-5, 6-11, 12-17, with two parents or one (table C2) */

// index.html line 4141
CFG.HH_RATIO = {'1a0k':{food:1, housing:1, medical:1, transport:1, civic:1, internet:1, other:1, taxes:1},
  '1a1k':{food:1.46685, housing:1.357341, medical:2.842683, transport:1.157305, civic:1.688049, internet:1, other:1.818304, taxes:1.522541},
  '1a2k':{food:2.197896, housing:1.357341, medical:2.890464, transport:1.457801, civic:2.226109, internet:1, other:1.987634, taxes:2.202741},
  '1a3k':{food:2.925225, housing:1.765906, medical:2.942673, transport:1.677405, civic:2.535119, internet:1, other:2.164186, taxes:3.084082},
  '2a0k':{food:1.833247, housing:1.100935, medical:2.147724, transport:1.157305, civic:1.688049, internet:1.375771, other:1.818304, taxes:1.10112},
  '2a1k':{food:2.275206, housing:1.357341, medical:3.142813, transport:1.457801, civic:2.226109, internet:1.375771, other:2.035738, taxes:1.65003},
  '2a2k':{food:2.926551, housing:1.357341, medical:3.240001, transport:1.677405, civic:2.535119, internet:1.375771, other:2.164186, taxes:2.070551},
  '2a3k':{food:3.570563, housing:1.765906, medical:3.348802, transport:1.877961, civic:2.838304, internet:1.375771, other:2.423002, taxes:2.731563}};  /* MIT family-type components over one adult's (sources/households.py; couples: both working) */

// index.html line 4149
CFG.HH_CHILDCARE = [12913.68, 11637.65, 7823.75];  /* MIT childcare at the model's level: first child (toddler care), second (preschool), third and more (school-age) */

// index.html line 4150
CFG.HH_CARE_AGE = 13;  /* childcare for children under 13 (dev/reports/v5-3-design.md, 1.3) */

// index.html line 4151
CFG.HH_BLEI_KEYS = ['housing', 'food', 'transport'];  /* the BLEI paper's basic living cost: rent and utilities (MIT housing is HUD rent with utilities), food, transport */

// index.html line 4152
function hhNeed(H){  /* the household's needs at year-0 prices (static until children age, B4) */
  var nA = H.a.length, nK = H.kids.length, R = CFG.HH_RATIO[nA + 'a' + Math.min(3, nK) + 'k'], need = {}, tot = 0, cc = 0, nc = 0, bl = 0, bl1 = 0;
  CFG.BASKET_KEYS.forEach(function(k){ need[k] = CFG.LIVING_WAGE_ANNUAL*CFG.BASKET[k]*R[k]; tot += need[k]; });
  H.kids.slice().sort(function(x, y){ return x - y; }).forEach(function(age){ if (age < CFG.HH_CARE_AGE){ cc += CFG.HH_CHILDCARE[Math.min(nc, CFG.HH_CHILDCARE.length - 1)]; nc++; } });
  need.childcare = cc; tot += cc;
  CFG.HH_BLEI_KEYS.forEach(function(k){ bl += CFG.BASKET[k]*R[k]; bl1 += CFG.BASKET[k]; });
  H.single = nA === 1 && nK === 0; H.need = need; H.need0 = tot; H.buM = 1 + (HOUSEHOLDS.childBU ⟦not run⟧)*nK/nA; H.dM = bl/bl1/nA;
}

// index.html line 4160
function hhInit(agents, seed){
  var r = mulberry32(seed + 500009), n = agents.length, C = CFG.HH_COMP, ord = [], i, list = [], q = 0;
  for (i = 0; i < n; i++) ord.push(i);
  for (i = n - 1; i > 0; i--){ var j = Math.floor(r()*(i + 1)), t = ord[i]; ord[i] = ord[j]; ord[j] = t; }  /* the adults in a random order: consecutive adults pair up */
  var nC = Math.round(n*(C.coupleKids + C.coupleNoKids)/2), nCK = Math.round(nC*C.coupleKids/(C.coupleKids + C.coupleNoKids)), nSP = Math.round(n*C.singleParent);
  function kids(arr){ var u = r(), K = CFG.HH_KIDS[arr], k = 0, c = K[0], A = CFG.HH_KID_AGES[arr], out = [];
    while (k < K.length - 1 && u >= c){ k++; c += K[k]; }
    for (var m = 0; m <= k; m++){ var v = r(), b = v < A[0] ? 0 : v < A[0] + A[1] ? 1 : 2; out.push(b*6 + Math.floor(r()*6)); }
    return out; }
  for (i = 0; i < nC; i++){ var a1 = agents[ord[q++]], a2 = agents[ord[q++]]; list.push({a:[a1, a2], kids:i < nCK ? kids('couple') : []}); }
  for (i = 0; i < nSP && q < n; i++) list.push({a:[agents[ord[q++]]], kids:kids('single')});
  while (q < n) list.push({a:[agents[ord[q++]]], kids:[]});
  list.forEach(function(H, h){ H.id = h; H.grown = []; var hd = H.a[0]; hhNeed(H);
    H.a.forEach(function(a, j){ a._hh = H; a._hhHead = j === 0; if (!H.single) a._hhD = H.dM;
      if (j > 0){ a.inCCO = hd.inCCO; a.inPTF = hd.inPTF; a.inPTH = hd.inPTH; a.uCCO = hd.uCCO; } }); });  /* decisions are the household's */
  if (HOUSEHOLDS.wealth === 'scf') hhScfWealth(list);  /* v5.3 B7 */
  HHS = {list:list, grown:[], elig:[], nextId:list.length, rng:null, st:null, srng:mulberry32(seed + 500041)};  /* grown, elig, rng, st: children's lives (B4; read only with ageing); srng: the household part of income shocks (B6) */
}

// index.html line 4178
function hhScfQ(Q, p){ var h = p*100 - 0.5, k = Math.floor(h); if (k < 0) return Q[0]; if (k >= Q.length - 1) return Q[Q.length - 1]; return Q[k] + (Q[k + 1] - Q[k])*(h - k); }  /* as scfWealthQ, for any table */

// index.html line 4179
function hhScfWealth(list){  /* v5.3 B7: household net worth from the SCF by type, ranked on the households' own wages and wealth draws (no draw) */
  if (LATENT ⟦not run⟧) ⟦not run⟧
  var G = {coupleKids:[], coupleNoKids:[], singleParent:[], single:[]};
  list.forEach(function(H){ G[H.a.length > 1 ? (H.kids.length ? 'coupleKids' : 'coupleNoKids') : (H.kids.length ? 'singleParent' : 'single')].push(H); });
  Object.keys(G).forEach(function(t){ var L = G[t], n = L.length, Q = t === 'single' ? CFG.SCF_NETWORTH_PCTL : CFG.HH_SCF_PCTL[t], rho = CFG.HH_SCF_RHO[t]; if (!n) ⟦not run⟧
    function scores(f){ var o = L.map(function(H, i){ return [f(H), i]; }).sort(function(x, y){ return x[0] - y[0]; }), z = new Array(n); o.forEach(function(q, r){ z[q[1]] = normInv((r + 0.5)/n); }); return z; }
    var zw = scores(function(H){ return H.a.reduce(function(m, a){ return m + a.wage; }, 0); }), zq = scores(function(H){ return H.a.reduce(function(m, a){ return m + a.wealth; }, 0); });
    L.forEach(function(H, i){ var W = hhScfQ(Q, normCdf(rho*zw[i] + Math.sqrt(1 - rho*rho)*zq[i])); H.a.forEach(function(a){ a.wealth = W/H.a.length; }); }); });
}

// index.html line 4188
function hhYear(agents){  /* each household's cost factor and shares at this year's prices (no draw) */
  var bI = PRICE ? PRICE.bIdx ⟦not run⟧;
  HHS.list.forEach(function(H){ if (H.single) return;
    if (HOUSEHOLDS.shock && H.a.length > 1) H.hv = 0.90 + HHS.srng()*0.20;  /* v5.3 B6: the couple's shared part of this year's income swing */
    var N = H.need, P = 0, e = 0, f, hs, t;
    function c(k){ return PRICE ? PRICE.comp[k === 'childcare' ? 'other' : k] ⟦not run⟧; }
    Object.keys(N).forEach(function(k){ P += N[k]*c(k); });
    buEss().forEach(function(k){ e += N[k]*c(k); }); if (BU_SCOPE === 'hub') e += N.childcare*c('childcare');  /* v5.3 B3f: BU scope (childcare at PTF centres under 'hub') */
    f = N.food*c('food')/P; hs = N.housing*c('housing')/P; t = DISC_BASE === 'pretax' ? N.taxes*c('taxes')/P ⟦not run⟧;
    var pS = PTFS ? {f:f, h:hs, t:N.transport*c('transport')/P, m:N.medical*c('medical')/P, k:(N.childcare || 0)*c('childcare')/P} ⟦not run⟧;  /* v5.4 item 4: the household's sector shares */
    var q22 = 0; if (C22) ⟦not run⟧  /* S6: the household's C2.2 needs (reporting only) */
    H.a.forEach(function(a){ if (C22) ⟦not run⟧ a._hhF = P/(H.a.length*CFG.LIVING_WAGE_ANNUAL*bI); a._hhE = e/P; a._hhFd = f; a._hhH = hs; a._hhT = t; a._hhBU = H.buM; if (pS) a._hhS = pS; }); });
}

// index.html line 4201
function hhSync(what){  /* partners follow the first adult's decision */
  HHS.list.forEach(function(H){ if (H.a.length < 2) return; var hd = H.a[0];
    for (var j = 1; j < H.a.length; j++){ var a = H.a[j]; if (what === 'cco'){ a.inCCO = hd.inCCO; a._jnY = hd._jnY; } else a.inPTF = hd.inPTF; } });
}

// index.html line 4205
function hhPool(yr, tbOn){  /* pool 'household': the end-of-year step for couples (spending rule, shared wealth, floor, household poverty status, the accounting check) */
  HHS.list.forEach(function(H){ if (H.a.length < 2) return;
    var n = H.a.length, cs = 0, w = 0;
    if (SURPLUS_CONSUMPTION_SHARE > 0){ H.a.forEach(function(a){ cs += SURPLUS_CONSUMPTION_BASE === 'cash' ? a._hhCS ⟦not run⟧; });
      var sc = SURPLUS_CONSUMPTION_SHARE*Math.max(0, cs)/n; H.a.forEach(function(a){ a.wealth -= sc; if (ACCT) ⟦not run⟧ if (LEDGER) ⟦not run⟧ }); }
    if (SPEND_GRADE){ var gA = 0, gC = 0; H.a.forEach(function(a){ gA += a._grA; gC += a._grC; });  /* v5.3 B7: the couple spends less when its income is below its costs */
      var gc = gC > 0 && gA < gC ? gC - gC*Math.pow(Math.max(0, gA)/gC, SPEND_GRADE.eps) : 0;
      if (DEBT_READ ⟦not run⟧)⟦not run⟧  /* S35: the debt reading */
      H.a.forEach(function(a){ a._grCut = gc/n; a.wealth += gc/n; if (ACCT) ⟦not run⟧ }); }
    H.a.forEach(function(a){ w += a.wealth; }); w /= n;
    H.a.forEach(function(a){ if (ACCT) ⟦not run⟧ a.wealth = w; });
    if (PRICE && PRICE.acc){ var A = PRICE.acc; H.a.forEach(function(a){ var pmW = a.wealth < CFG.WEALTH_FLOOR ? CFG.WEALTH_FLOOR - a.wealth : 0, pmU = a._hhPmB > 0 ? Math.min(1, (SPEND_GRADE ? pmW + a._grCut ⟦not run⟧)/a._hhPmB) ⟦not run⟧;
      A.essD -= pmU; A.unmet += pmW; if (pmW > 0) A.unmetN++; }); }  /* the price module's unmet need, after pooling (the year loop counted none for these adults) */
    if (tbOn){ var inc = 0, mlc = 0, cost = 0, disp = 0; H.a.forEach(function(a){ inc += a._hhInc; mlc += a._hhMlc; cost += a._hhCost; disp += a._hhDisp; });
      H.a.forEach(function(a){ tbPov(a, TB.cur, a._hhIdx, inc/n, mlc/n, cost/n, disp/n); }); }
    H.a.forEach(function(a){ if (a.wealth < CFG.WEALTH_FLOOR){ if (ACCT) ⟦not run⟧
      if (LEDGER)⟦not run⟧ a.wealth = CFG.WEALTH_FLOOR; } });
    if (ACCT)⟦not run⟧  /* the scale: the transfers and the wealth pooled (rounding is relative to the wealth: v5.3 B6) */
  });
}

// index.html line 4233
/* v5.3 B6 (Oct 7, 2026; plan item B6; dev/DECISIONS.md Session 39, "B6"): THE MEASURED EDC (reporting only: no draw, nothing any rule reads; EDC_MEASURE
 * false, the default, adds nothing). The Extractive Drain Coefficient as the page's glossary defines it, the share of income captured by contracts that
 * build no household wealth (rent, interest, fees), measured from the year's flows: rent paid to a landlord (MIT's housing with utilities, the household's
 * at its own prices; a community-housing (PTH) payment counts 0, as the glossary says) plus interest paid on debt (only where the savings reading charges it;
 * the model has no fees), over gross income (wages, conversion income, Social Security, cash transfers before the contribution, and the BU allowance at
 * face value, since BU pay rent too). With households it is the household's (its adults' rent over their income), counted for every person; otherwise
 * each adult's. Keys EDC_KEYS: the mean over person-years of the ratio (capped at 1), the ratio of the totals, the mean for adults in and outside PTH,
 * and the design target proxy (agentEDC, the formula the earlier engine shows) for comparison. */
var EDC_MEASURE = false, EDCS = null;

// index.html line 4234
var EDC_KEYS = ['edcM', 'edcMagg', 'edcMPth', 'edcMOut', 'edcProxy'];

// index.html line 4235
function edcNew(){ return {s:0, n:0, r:0, y:0, sP:0, nP:0, sO:0, nO:0, px:0, pn:0}; }

// index.html line 4236
function edcYear(E, agents, p){
  function add(rent, inc, w){ var q = inc > 0 ? Math.min(1, rent/inc) : 1; E.s += q*w; E.n += w; E.r += rent; E.y += inc; return q; }
  if (HOUSEHOLDS && HHS) HHS.list.forEach(function(H){ var r = 0, y = 0; H.a.forEach(function(a){ r += (a._edcR || 0) + (a._edcInt || 0); y += a._edcY || 0; }); add(r, y, H.a.length + H.kids.length); });⟦not run, 2 lines⟧
  agents.forEach(function(a){ var r = (a._edcR || 0) + (a._edcInt || 0), y = a._edcY || 0, q = y > 0 ? Math.min(1, r/y) : 1;
    if (p.pth && a.inPTH){ E.sP += q; E.nP++; } else { E.sO += q; E.nO++; } E.px += agentEDC(a, p.ccoOn, p.pth); E.pn++; });
}

// index.html line 4243
function edcRes(E, out){ if (!E) ⟦not run⟧
  out.edcM = E.n ? E.s/E.n*100 ⟦not run⟧; out.edcMagg = E.y ? E.r/E.y*100 ⟦not run⟧; out.edcMPth = E.nP ? E.sP/E.nP*100 : 0; out.edcMOut = E.nO ? E.sO/E.nO*100 ⟦not run⟧; out.edcProxy = E.pn ? E.px/E.pn*100 ⟦not run⟧; return out; }

// index.html line 4268
/* ─── v5.3 B4 and B5 (Oct 7, 2026; plan items B4, B5; dev/DECISIONS.md Session 39, "B4"): CHILDREN'S LIVES. Read only when ageing (AGE) and households
 * are both on; either off leaves every run as before. Sources and derivations: sources/households.py, section 6; sources/births_us.md.
 *  - Ages at the start (hhAges, own stream seed + 500021, after ageInit): a mother's age given her children's ages is drawn in proportion to the population
 *    at each age (CFG.AGE_WEIGHTS) times the 2024 birth rate at the age she had each child (CFG.HH_ASFR, NCHS); a partner's age adds the spouses' age gap
 *    (CFG.HH_GAP, Census CPS 2023 Table FG3, with or without children; redrawn while outside 25-66); a childless couple's woman follows FG3's wives without
 *    children (CFG.HH_AGE_WIFE_NOKIDS); single adults follow the CPS singles by age (CFG.HH_AGE_SINGLE). Couples are a woman and a man (FG3 covers opposite-sex
 *    married couples; cohabiting couples are assumed alike); a single parent is a mother with C2's share (CFG.HH_FEMALE.singleParent), a single adult a woman
 *    with the share left by the population (CFG.HH_FEMALE.single), a new 25-year-old a woman with the 2024 population's share at 25.
 *  - Each year, at the start (ageYear; own stream seed + 500029 for every draw below): deaths as before; the place of an adult who dies goes to a grown child
 *    of a household turning 25 that year if one is waiting (drawn at random among them), otherwise to an unrelated 25-year-old, as before; the newcomer
 *    forms a household of one, drawn like every new adult (no inheritance of earnings: a stated limit). A partner who survives keeps the household and its
 *    children; when the last adult of a household dies, its children under 18 leave the model (to relatives outside it; counted). Children age a year;
 *    at 18 a child stops being a dependant and leaves the household (outside the model from 18 to 24, as people that age always have been; at 25 they can
 *    take a place, and those who find none leave the model: the population stays at its size). Then each woman aged up to 49 gives birth with the 2024
 *    rate at her age times CFG.HH_FERT_K (partner present or not; chosen so that women as a whole give birth at the national rates and 22% of births are to
 *    women without a partner, C2's share of children under 6 living with one parent, which also stands in for young families that split: the model has no
 *    separations or new partnerships, a stated limit). A household's needs, childcare and child allowance follow its children every year.
 *  - Estates (B5, Duke's decision d169; estate 'heirs', the default): an adult's estate (positive wealth and Acre Equity; debts are not inherited and BU
 *    held for later conversion lapse, as before) passes to the surviving partner, else to the children in equal shares (children under 18, whose shares
 *    leave the model with them, and grown children, whose shares reach them if they are adults in the model), else it leaves the model. Acre Equity stays
 *    Acre Equity for an heir in community housing, otherwise it is paid out at the deceased's liquid share and the rest stays with the trust (Claude's
 *    reading of the Hub's "Inheritance Rights", dev/reports/v5-3-design.md 1.5). estate 'leave': every estate leaves the model, as in the adult-only model.
 *    Estates pass at the start of the year, before the year's accounts open, so the yearly identities are unchanged. No inheritance tax (none on the Hub). */
CFG.HH_ASFR = [12.6, 55.8, 89.5, 93.7, 54.3, 12.7, 1.1];  /* births per 1,000 women a year at ages 15-19, 20-24, ..., 45-49 (NCHS, Births: Final Data for 2024, Table 2) */

// index.html line 4269
CFG.HH_FERT_K = {couple:1.2376, single:0.5975};  /* the rate's multiple for a woman with a partner present and without (sources/households.py, section 6) */

// index.html line 4270
CFG.HH_FEMALE = {single:0.4461, singleParent:0.8317, entrant:0.4910};  /* shares of women: single adults, single parents (C2), new 25-year-olds (Census 2024) */

// index.html line 4271
CFG.HH_GAP = [[20,24,357,209],[15,19,516,319],[10,14,1911,1016],[6,9,4420,2718],[4,5,4834,2960],[2,3,7810,4979],[-1,1,13892,8748],[-3,-2,2760,1717],[-5,-4,1447,689],[-9,-6,1139,437],[-14,-10,453,150],[-19,-15,170,41],[-24,-20,122,58]];  /* husband's age minus wife's: lowest, highest, couples (thousands) without and with own children under 18 (FG3; "20+" taken as 20-24) */

// index.html line 4272
CFG.HH_AGE_SINGLE = [1800.7,1797.5,1800.7,1812.4,1842.6,1878.5,1905.9,1945.4,1970.4,1972.0,1099.1,1077.8,1063.9,1063.7,1060.4,1036.6,1049.1,1044.7,1027.8,1021.3,1018.1,993.8,979.8,945.1,953.6,933.8,944.4,987.8,1044.4,1026.3,1382.9,1351.2,1353.2,1369.4,1418.7,1449.4,1446.4,1447.4,1440.3,1410.3,1379.2,1363.0];  /* single adults at ages 25..66 (CPS 2023 tables A1, UC3, A3 by ten-year band, spread by the 2024 population) */

// index.html line 4273
CFG.HH_AGE_WIFE_NOKIDS = [285.9,286.0,287.5,289.3,294.3,319.1,323.8,331.2,336.2,336.7,265.4,260.3,256.4,256.1,255.8,291.0,294.8,293.9,289.4,287.9,527.0,515.0,509.3,491.3,496.3,854.4,865.4,903.5,953.5,938.2,1139.8,1116.0,1122.6,1138.7,1185.7,1212.8,1214.5,1217.8,1215.0,1192.3,1106.9,1096.9];  /* wives in couples without children under 18 at ages 25..66 (FG3, spread by the 2024 female population) */

// index.html line 4274
CFG.HH_ADULT_AGE = 18;  /* a child stops being a dependant (the Census counts children under 18; the draft Act gives BU from 18) */

// index.html line 4331
var HH_LIFE_KEYS = ['hhBirthR', 'hhBirthSg', 'hhKid0', 'hhEntK', 'hhGrOut', 'hhOrph', 'hhEstN', 'hhEstP', 'hhEstK', 'hhEstO', 'hhMom0', 'hhGap0'];  /* v5.3 B4, B5: children's lives (households with ageing) */

// index.html line 4332
function hhLifeRes(out){ var t = HHS && HHS.st; if (!t) return out;⟦not run, 2 lines⟧ ⟦not run⟧; out.hhBirthSg = t.births ⟦not run⟧ ⟦not run⟧; out.hhKid0 = t.kid0;
  out.hhEntK = t.entK + t.entU ⟦not run⟧ ⟦not run⟧; out.hhGrOut = t.grOut; out.hhOrph = t.orph; out.hhEstN = t.estN;
  out.hhEstP = t.estV ⟦not run⟧ ⟦not run⟧; out.hhEstK = t.estV ⟦not run⟧ ⟦not run⟧; out.hhEstO = t.estV ⟦not run⟧ ⟦not run⟧;
  out.hhMom0 = t.momN ⟦not run⟧ ⟦not run⟧; out.hhGap0 = t.gapN ⟦not run⟧ ⟦not run⟧; return out; }

// index.html line 4345
/* v5.3 B3 (Oct 7, 2026): the household reading's measures (reporting only: no draw, nothing any rule reads). Every person counts, children included, with the
 * status of their household (its resources against its needs, under either pooling rule; the adult measures above keep each adult's own status under
 * 'individual'). Per year: below the cost of living (household cash income after the contribution against the household's cost after price cuts and BU), below
 * the official poverty line for the household's size and children (Census 2025 thresholds, CFG.HH_FPL, moved with prices; money income before tax: wage,
 * conversion, cash transfers, Social Security), too little wealth (household net wealth below six months of the household's own cost of living, CFG.HH_WEALTH_MONTHS:
 * the reading of the $25,000 line for one adult, $24,685), and below 30 days of basic living (the household's BLEI: the mean of its adults'). Shares of persons
 * and of children, as person-years over the run and at Year 7 and the last year; the same by household type; and the Gini and median of disposable income per
 * equivalent adult (household income over the square root of its size, the OECD's square-root scale), across persons, at the last year. Keys HH_KEYS. */
CFG.HH_FPL = {'1a0k':16749, '1a1k':22190, '1a2k':25938, '1a3k':32762, '1a4k':37833, '2a0k':21558, '2a1k':25913, '2a2k':32649, '2a3k':38421, '2a4k':43018};  /* Census, Poverty Thresholds for 2025 by Size of Family and Number of Related Children (householder under 65) */

// index.html line 4346
CFG.HH_WEALTH_MONTHS = 6;  /* too little wealth for a household: net wealth below six months of its own cost of living (one adult: $24,685, the $25,000 line's reading) */

// index.html line 4347
var HH_TYPES = ['sg', 'sp', 'cn', 'ck'];  /* single adult, single parent, couple without children, couple with children */

// index.html line 4348
var HH_KEYS = ['hhPer', 'hhKid', 'hhCostPY', 'hhCostKidPY', 'hhFplPY', 'hhFplKidPY', 'hhWlthPY', 'hhWlthKidPY', 'hhBleiPY', 'hhBleiKidPY',
  'hhFpl7', 'hhFplKid7', 'hhCost7', 'hhCostKid7', 'hhFplEnd', 'hhFplKidEnd', 'hhCostEnd', 'hhCostKidEnd', 'hhWlthEnd', 'hhWlthKidEnd', 'hhBleiEnd', 'hhBleiKidEnd',
  'hhGiniEq', 'hhMedEq'].concat(HH_TYPES.map(function(t){ return 'hhCost_' + t; }), HH_TYPES.map(function(t){ return 'hhWlth_' + t; }), HH_TYPES.map(function(t){ return 'hhShare_' + t; }));

// index.html line 4351
function hhTypeOf(H){ return H.a.length === 1 ? (H.kids.length ? 'sp' : 'sg') : (H.kids.length ? 'ck' : 'cn'); }

// index.html line 4352
function hhRepAcc(){ var R = {py:0, kpy:0, c:{}, y7:null, end:null, per:0, kid:0}; ['cost', 'fpl', 'wlth', 'blei'].forEach(function(k){ R.c[k] = 0; R.c[k + 'K'] = 0; });
  HH_TYPES.forEach(function(t){ R['t_' + t] = {py:0, cost:0, wlth:0}; }); R.ab = {a25:{py:0, c:0}, a35:{py:0, c:0}, a50:{py:0, c:0}, a67:{py:0, c:0}}; R.sp = []; return R; }  /* ab, sp: v5.3 B8 */

// index.html line 4354
function hhRepYear(R, agents, p, o, yr, T){
  var lf = o.lines === 'nominal' ⟦not run⟧ : agents[0].yrBasketUSD/CFG.LIVING_WAGE_ANNUAL/(agents[0]._hhF || 1), s = {per:0, kid:0, cost:0, costK:0, fpl:0, fplK:0, wlth:0, wlthK:0, blei:0, bleiK:0}, eq = [];
  HHS.list.forEach(function(H){ var nA = H.a.length, nK = H.kids.length, n = nA + nK, inc = 0, cost = 0, need = 0, money = 0, disp = 0, w = 0, b = 0;
    H.a.forEach(function(a){ inc += a._hhInc; cost += a._hhCost; need += a._hhMlc; disp += a._hhDisp; money += tbCashIncome(a); w += a.wealth; b += agentBLEI(a, p.bu, p.ccoOn, p.pth, p.szh, p.szhCoh, p.ptf)/lf; });
    var fC = inc < cost, fF = money < CFG.HH_FPL[nA + 'a' + Math.min(4, nK) + 'k']*lf, fW = w < need*CFG.HH_WEALTH_MONTHS/12, fB = b/nA < CFG.BLEI_PRECARIOUS_MAX, t = R['t_' + hhTypeOf(H)];
    s.per += n; s.kid += nK; if (fC){ s.cost += n; s.costK += nK; } if (fF){ s.fpl += n; s.fplK += nK; } if (fW){ s.wlth += n; s.wlthK += nK; } if (fB){ s.blei += n; s.bleiK += nK; }
    t.py += n; if (fC) t.cost += n; if (yr === T - 1){ t.n = (t.n || 0) + n; if (fW) t.w = (t.w || 0) + n; }
    if (!H._sp){ H._sp = {c:[], t:hhTypeOf(H)}; R.sp.push(H._sp); } H._sp.c.push(fC);  /* v5.3 B8: each household's years below the cost of living, for spells by its type at the start */
    H.a.forEach(function(a){ if (typeof a.age !== 'number') return;⟦not run⟧ ⟦not run⟧]; q.py++; if (fC) ⟦not run⟧ });  /* v5.3 B8: adults by age group (with ageing) */
    if (yr === T - 1){ var e = disp/Math.sqrt(n)/lf; for (var i = 0; i < n; i++) eq.push(e); } });
  R.py += s.per; R.kpy += s.kid; R.per = s.per; R.kid = s.kid;
  ['cost', 'fpl', 'wlth', 'blei'].forEach(function(k){ R.c[k] += s[k]; R.c[k + 'K'] += s[k + 'K']; });
  function snap(){ return {cost:s.cost/s.per*100, costK:s.kid ? s.costK/s.kid*100 ⟦not run⟧, fpl:s.fpl/s.per*100, fplK:s.kid ? s.fplK/s.kid*100 ⟦not run⟧, wlth:s.wlth/s.per*100, wlthK:s.kid ? s.wlthK/s.kid*100 ⟦not run⟧, blei:s.blei/s.per*100, bleiK:s.kid ? s.bleiK/s.kid*100 ⟦not run⟧}; }
  if (yr === 6) R.y7 = snap();
  if (yr === T - 1){ R.end = snap(); R.gini = giniOfArr(eq); R.med = quantileOf(eq, 0.5); }
}

// index.html line 4370
function hhRepRes(R, out){
  function pc(k, kid){ var d = kid ? R.kpy : R.py; return d ? R.c[k]/d*100 ⟦not run⟧; }
  out.hhPer = R.per; out.hhKid = R.kid;
  out.hhCostPY = pc('cost'); out.hhCostKidPY = pc('costK', 1); out.hhFplPY = pc('fpl'); out.hhFplKidPY = pc('fplK', 1); out.hhWlthPY = pc('wlth'); out.hhWlthKidPY = pc('wlthK', 1); out.hhBleiPY = pc('blei'); out.hhBleiKidPY = pc('bleiK', 1);
  var y7 = R.y7 ⟦not run⟧, e = R.end ⟦not run⟧;
  out.hhFpl7 = y7.fpl ⟦not run⟧; out.hhFplKid7 = y7.fplK ⟦not run⟧; out.hhCost7 = y7.cost ⟦not run⟧; out.hhCostKid7 = y7.costK ⟦not run⟧;
  out.hhFplEnd = e.fpl ⟦not run⟧; out.hhFplKidEnd = e.fplK ⟦not run⟧; out.hhCostEnd = e.cost ⟦not run⟧; out.hhCostKidEnd = e.costK ⟦not run⟧; out.hhWlthEnd = e.wlth ⟦not run⟧; out.hhWlthKidEnd = e.wlthK ⟦not run⟧; out.hhBleiEnd = e.blei ⟦not run⟧; out.hhBleiKidEnd = e.bleiK ⟦not run⟧;
  out.hhGiniEq = R.gini ⟦not run⟧; out.hhMedEq = R.med ⟦not run⟧;
  HH_TYPES.forEach(function(t){ var q = R['t_' + t]; out['hhCost_' + t] = q.py ? q.cost/q.py*100 ⟦not run⟧; out['hhWlth_' + t] = q.n ? (q.w ⟦not run⟧)/q.n*100 ⟦not run⟧; out['hhShare_' + t] = R.py ? q.py/R.py*100 ⟦not run⟧; });
  return out;
}

// index.html line 4385
/* v5.3 B8 (Oct 7, 2026; plan item B8; dev/DECISIONS.md Session 39, "B8"): more of the household reading's measures (reporting only). Adult-years below the
 * cost of living by age group (25-34, 35-49, 50-66, 67 and over; with ageing, else 0; children are hhCostKidPY), and poverty spells by household type:
 * each household's run of years below the cost of living (its status, as for every person in it), counted with tbRepSpells (Bane-Ellwood/Stevens, the
 * method of the US-data check), by the household's type at the start: the share of spells that end after their first year, and spells per run. */
var HH_REP_KEYS = ['hhCostA25', 'hhCostA35', 'hhCostA50', 'hhCostA67', 'hhSpEx1', 'hhSpN'].concat(HH_TYPES.map(function(t){ return 'hhSpEx1_' + t; }), HH_TYPES.map(function(t){ return 'hhSpN_' + t; }));

// index.html line 4386
function hhRepRes2(R, out){
  ['a25', 'a35', 'a50', 'a67'].forEach(function(k){ var q = R.ab[k]; out['hhCostA' + k.slice(1)] = q.py ⟦not run⟧ : 0; });
  function sp(L){ var o = {}; tbRepSpells(L, 'c', o, 'q'); return {ex:o.qN1 ? o.qX1/o.qN1 : 0, n:o.qN1}; }
  var a = sp(R.sp); out.hhSpEx1 = a.ex; out.hhSpN = a.n;
  HH_TYPES.forEach(function(t){ var q = sp(R.sp.filter(function(x){ return x.t === t; })); out['hhSpEx1_' + t] = q.ex; out['hhSpN_' + t] = q.n; });
  return out; }

// index.html line 4392
function hhRes(R, out){ return R ? hhLifeRes(hhRepRes2(R, hhRepRes(R, out))) ⟦not run⟧; }  /* v5.3 B4: + children's lives, with ageing */

// index.html line 4393
function spNewAcc(){ return {pool:0, own:0, ptf:0, rest:0, pricePool:0, cut:0, cutN:0, cutP:0, freed:0, cash:0, carry:0, profit:0, profitN:0, reinv:0, wkY:0, wkY1:0,
  d1:0, n1:0, d2:0, n2:0, non:0, yrs:0}; }

// index.html line 4399
/* PRICE (A2 issuance and price module): null = off (index.html). When an object, runYear() reprices the basket by
 * PRICE.bIdx (the endogenous index, set each year by priceRun from the previous year's flows), reads COLA off the
 * endogenous headline rate, indexes wages to P_G by PRICE.wIdx, and accumulates the year's flows into PRICE.acc.
 * No RNG is drawn; with bIdx = 1 and no accumulation a run is bit-identical (checked by `unit`). */
var PRICE = null;

// index.html line 4425
/* LABOR (A3 labor-supply module, session 4; decisions d14, d15 and d2 on the project dashboard): null = off (index.html).
 * When an object, each agent's wage earnings E0 for the year are replaced by
 *   E = max(0, E0 x raise^eps - rho x cash - rhoBU x BUspent - rhoR x BUexpired - conversion term)
 *  rho     income effect per dollar of unconditional cash (p.ubi). Source: Vivalt et al., NBER w32719 (revised Aug 2026):
 *          $1,000 a month for three years; for every dollar received, individual income excluding the transfer fell about
 *          16 cents and household income about 28 cents. The model's agents are single adults, so 0.16 is central (d15).
 *  rhoBU   income effect per BU spent on the agent's own essentials (engine: the CCO relief dollars; framework: the BU
 *          spent up to the essentials budget). These BU are inframarginal (below own essentials spending), and Hoynes &
 *          Schanzenbach (AEJ Applied 2009) find inframarginal food stamps act like cash, so rhoBU = rho by default. Hastings &
 *          Shapiro (AER 2018) reject fungibility in spending (mental accounting), the case for sweeping rhoBU below rho.
 *  rhoR    income effect per BU that expire unspent (framework: directed to projects). The holder cannot consume them, so 0
 *          by default. d2's "UBI-equivalent toggle" sets rhoBU = rhoR = rho (every BU treated as cash).
 *  eps     compensated (Hicksian) wage elasticity. Chetty (Econometrica 2012): 0.33 on the intensive margin and 0.25 on the
 *          extensive margin, pooled. The program's raises are uncompensated wage increases, so earnings scale by
 *          raise^(eps - rho) (Slutsky: e_u = e_c + eta, with eta = w dh/dI = -rho, the same rho as the income effect), where
 *          raise = wage / wage without the program's raises (octave, CIP; the N7 split) x (1 + the framework's business
 *          payout per wage dollar). One elasticity for every change in the return to work (the plan's fairness rule).
 *  delta   conversion (d14). Conversion proceeds in both models do not depend on effort; the framework says they reward
 *          project work. Last year's creator proceeds C (engine: own conversion; framework: project conversion, not the
 *          wage-linked business payout) enter as  delta x C + rho x (1 - delta) x C : delta = 0 treats C as a rent (an
 *          unconditional dollar, the engine as coded); delta = 1 as fully dissipated project time that displaces wage
 *          time one for one (a fixed BU pool bid for competitively, so a marginal project hour earns the wage).
 * No RNG is drawn. With rho = rhoBU = rhoR = eps = delta = 0 a run is bit-identical to LABOR null (checked by `unit`).
 * LABOR.acc (when an object) tallies each channel in dollars. p.ubi (harness-only): annual cash to every adult, nominal,
 * money-created; counted as cash income in the income and basket measures. Unset in every preset. */
var LABOR = null;

// index.html line 4426
var LABOR_DEFAULTS = {rho:0.16, rhoBU:0.16, rhoR:0, eps:0.33, delta:0};

// index.html line 4441
/* Session 5 restudy switches (harness-only; each off by default, so every shipped figure is bit-identical; checked by `unit`).
 *  THETA_GATE  'szh' = index.html: SZH theta (the PTF conversion bonus add-on, the PTF induction boost and the BLEI term)
 *              is read off the SZH zone-coherence slider. 'density' = the framework's gate (claims ledger C08, dashboard
 *              d12): theta is read off the population's realised PTF share at the start of each year, through the same
 *              szhTheta() curve (55% threshold, full at 90%, cap 0.25). THETA_DENS holds the latest share for agentBLEI().
 *  PTH_MODE    'basket' = index.html: PTH cuts the whole (post-PTF) basket by 35%, which is 127% of MIT's housing
 *              component. 'housing' (d4): PTH cuts the housing component by PTH_HOUSING_CUT (the same 35% rate, applied
 *              to what PTH provides). Under shipped PTF the housing component has already been cut by PTF's rate.
 *  DISC_BASE   'basket' = index.html: PTF, PTH and CCO relief discount the whole basket. 'pretax' (d5): they skip the
 *              basket's income and payroll tax share (17.97% at year-0 prices), which no price cut reduces.
 * With PTH_MODE or DISC_BASE changed, the PTH saving that funds equity routing is PTH's own cut on the agent's post-relief
 * basket (identical to index.html's cf/0.65 formula in the engine model; in the framework model BU purchases are not a
 * price cut, so the saving is PTH's cut before them). BLEI keeps its own daily-cost anchor (dual-anchor table, v4.14),
 * so PTH_MODE and DISC_BASE act on the wealth loop only. */
var THETA_GATE = 'szh', PTH_MODE = 'basket', DISC_BASE = 'basket', THETA_DENS = null, PTH_HOUSING_CUT = 0.35;

// index.html line 4442
function setRestudy(o){ var old = {THETA_GATE:THETA_GATE, PTH_MODE:PTH_MODE, DISC_BASE:DISC_BASE};
  if (o){ if (o.THETA_GATE) THETA_GATE = o.THETA_GATE; if (o.PTH_MODE) PTH_MODE = o.PTH_MODE; if (o.DISC_BASE) DISC_BASE = o.DISC_BASE; }
  return old; }

// index.html line 4463
/* ─── Session 6 (A4): the policy testbed (harness-only; dashboard s11, decisions d24–d29). TB = null (the default) or an unset
 * p.tb leaves every run bit-identical (checked by `unit`). When TB is an object AND p.tb is set, runYear() adds:
 *  - Programs (p.tb): ubi (cash to every adult, year-0 $/yr), xc {amt, delta} (X-Cents adult exchange; delta 1 = the
 *    community-work variant's hours displace wage time one for one, the d14 bracket), nit {G, t} (benefit max(0, G - t x wage
 *    earnings)), groc {cut, cover} (public grocery: a cut on the food component for covered adults), endow {amt, thresh}
 *    (one-time endowment in year 0 to adults whose year-0 wealth is below thresh). Cash amounts follow the same COLA rule as BU
 *    (the preset's cola flag; colaF).
 *  - One income effect for every unconditional dollar (the plan's fairness rule; d25): with LABOR on, earnings fall by rho per
 *    dollar of cash transfer, NIT guarantee (virtual income), endowment annuity value (amt / years), contribution virtual income,
 *    and (TB.inkindRho, default true) every price-cut dollar (PTF, PTH, public grocery) and last year's PTH liquid appreciation.
 *    Session 4's module applied rho to cash and BU only.
 *  - One elasticity for every change in the return to work: earnings scale by (1 - t)^(eps - rho) for adults in the NIT phase-out
 *    and by (1 - tau)^(eps - rho) for adults above the contribution threshold, the same exponent the module applies to raises.
 *  - Financing (TB.fin; d26): 'tax' = a contribution tau on wage earnings above TB.X, set each year to last year's program cost /
 *    last year's base (year 0 from a pre-pass of year 0), capped at tauMax, with the treasury reported; 'money' = the program's
 *    cost is created money, counted in the price module by one rule for every design (d24); 'none' = unfinanced (sessions 2-5).
 *  - A uniform cost ledger (TB.cur, per year) and basket FGT0-2 on income including transfers, less the contribution, plus the
 *    endowment's annuity value, against the agent's own cost (gross basket less in-kind cuts). */
var TB = null;

// index.html line 4469
/* Audit V5-02 (v5.1; Oct 3, 2026). In framework mode the BLEI gate on the wage-growth bonus (agentBLEI, and tbGate in the testbed) reads a._fwBUm, the BU an
 * agent spends on essentials. runYear used to call the gate before writing this year's _fwBUm, so from year 1 the gate read last year's value (the stale value
 * differed from the current one in about 73% of framework agent-years). GATE_CURRENT = true writes the same value first, with the same expression the engine
 * assigns later (checked equal in every agent-year by the unit suite), so the gate reads this year's spend. false (the default) is bit-identical to v5.0. A
 * testbed row sets it with c.gc (n1Row option gc); v5.1's release row turns it on (REL_V5). No random draw is added or moved. */
var GATE_CURRENT = false;

// index.html line 4470
var TB_DEFAULTS = {fin:'tax', aT:0, eP:0, tauMax:0.9, X:0, inkindRho:true, neutralGate:true, rep52:false, giniNN1:false};  /* v5.2 step 2: rep52 (the Year 7 and federal-poverty-line reporting) and giniNN1 (the n/(n - 1) Gini correction), reporting only, off by default */

// index.html line 4471
function tbNewAcc(){ return {pjg:0, n:0, cash:0, endow:0, bu:0, conv:0, convM:0, buIss:0, ctax:0, cutFree:0, cutPT:0, cutG:0, cap:0, pthLiq:0, tax:0, base:0, E:0, f0:0, f1:0, f2:0, idx:1, pd:0, tgt:0, emp:0, hrs:0, bR:0, bP:0,
  bz:0, es:0, n1:0, nP1:0, nN1:0, pyP:0, pyN:0, nWP1:0, esWP:0}; }  /* session 19 (s38): business premium and ESP payroll by group, years 1-19 (reporting only) */

// index.html line 4473
function tbYear(p, colaF){
  var s = p.tb;
  TB.cur = tbNewAcc();
  return {ubi:(s.ubi || 0)*colaF, xc:(s.xc ⟦not run⟧ : 0)*colaF, xd:s.xc ⟦not run⟧ : 0, G:s.nit ⟦not run⟧ : 0, t:s.nit ⟦not run⟧ : 0,
    tau:TB.tau || 0, X:(TB.X || 0)*(TB.xIdx || 1), tb:TB.tb, xi:TB.tb === 'prog' ⟦not run⟧ : (TB.xIdx || 1), cap:TB.tauMax ⟦not run⟧, W:s.endow ⟦not run⟧ : 0, T:p.years, gcap:s.groc ⟦not run⟧ : 0, gcov:s.groc ⟦not run⟧ : 0, Gp:!!(s.nit ⟦not run⟧)};
}

// index.html line 4482
/* d28: the BLEI gate on the engine's wage-growth bonus, read the same way for every design: Baseline rules (gamma 0.12, the base
 * daily cost, no SZH term) plus one month of the design's regular support, BU (the credit agentBLEI gives participants) or cash
 * (UBI, X-Cents, the NIT benefit on last year's earnings). agentBLEI itself, and every BLEI figure reported, are unchanged. */
function tbGate(a, p, buEff, y){
  var Ep = a.yrWageUSD !== undefined ? a.yrWageUSD : a.wage*12*CFG.WAGE_TO_USD, Bx = (y.G > 0 ⟦not run⟧) ⟦not run⟧ : 0;  /* the NIT benefit expected on last year's earnings; session 11: a participant-only top-up (Gp) reaches participants only */
  var m = (y.ubi + y.xc + Bx)/12;
  if (p.ccoOn && a.inCCO && buEff > 0) m += (CONVERSION_MODEL === 'framework' && a._fwBUm !== undefined) ? a._fwBUm ⟦not run⟧;
  a._tbM = m;  /* session 7: kept for the design-neutral BLEI poverty figure (d28) */
  return agentBLEI(a, 0, false, false, false, 0, false) + m/CFG.BASE_DAILY_COST;
}

// index.html line 4489
function tbNitElig(y, E0){ return y.G > 0 ⟦not run⟧; }

// index.html line 4492
/* Labor terms for one agent-year: F multiplies earnings (net-of-rate factors), V is extra unconditional dollars (x rho), D is
 * time displaced from wage work. Eligibility for the phase-out and the contribution is read on earnings before the response. */
function tbLab(a, y, E0, cutUSD){
  var ex = LABOR.eps - LABOR.rho, F = 1, el = tbNitElig(y, E0) ⟦not run⟧, tx = y.tau > 0 && E0 > y.X;
  var V = y.ubi + y.xc*(1 - y.xd) + (el ⟦not run⟧ : 0), D = y.xc*y.xd;  /* cash first, so an NIT at t = 0 is bit-identical to a UBI */
  if (a._tbEl) ⟦not run⟧
  if (y.tb === 'prog')⟦not run⟧  /* v5.2 step 7: the marginal rate, and the virtual income of the schedule linearised at E0 (for a flat rate above X this is tau x X, as below) */
  else if (y.tb === 'land')⟦not run⟧  /* v5.2 step 7: a tax on what is owned, not on work: an income effect only (one income effect per unconditional dollar, rule 7) */
  else if (tx){ F *= Math.pow(1 - y.tau, ex); V += y.tau*y.X; }
  if (el) ⟦not run⟧
  if (SNET && SNS && a._snB !== undefined){ F *= Math.pow(1 - a._snM, ex); V += a._snB + a._snM*E0; }  /* session 2b: today's safety net, its marginal rate (one elasticity) and its dollars linearised at last year's position (one income effect) */
  if (TB.inkindRho) V += cutUSD + (a._tbPthPrev || 0);
  return {F:F, V:V, D:D};
}

// index.html line 4504
function tbCashFlow(a, y, E, yr){
  var B = (y.G > 0 ⟦not run⟧) ⟦not run⟧ : 0, cash = y.ubi + y.xc + B, tax = y.tau > 0 ? (y.tb === 'prog' ⟦not run⟧ : y.tb === 'land' ⟦not run⟧ : y.tau*Math.max(0, E - y.X)) : 0;  /* v5.2 step 7: tb 'prog' | 'land' */
  if (SNET && SNS && a._snB) cash += a._snB;  /* session 2b: today's safety net, paid as cash (kept out of programme cost in tbAccount) */
  a.yrTbCash = cash; a.yrTax = tax; a._tbNit = B;
  return {net:cash - tax, endow:(yr === 0 && a._tbEl) ⟦not run⟧ : 0};
}

// index.html line 4523
/* Session 21 (s41; dashboard i10-1, decision d82): BLEI by group beside FGT2. Reporting only: no RNG, no state the model reads.
 * Three readings of an adult's BLEI (days of basic living the adult could cover), each deflated to year-0 prices like the
 * testbed's other lines (o.lines):
 *  N  design-neutral (d34): Baseline rules (gamma 0.12, the base daily cost, no SZH term) plus one month of the design's regular
 *     support (a._tbM, the d28 gate's measure). Heads the tables.
 *  O  the design's own BLEI (agentBLEI with the scenario's settings; the page's and the shipped definition).
 *  X  N with income read as this year's wage earnings net of the testbed's contribution (after any change in hours), in place of
 *     the gross monthly wage rate. agentBLEI reads the wage rate, so the contribution and the hours response reach N and O only
 *     through savings (20% of wealth); X shows what they do to the income term. Same function, same 0.1-unit wage floor.
 * Groups: all adults; participants (a._tbPart); adults who chose not to take part (!a._tbPart); the same adults in every design.
 * Measures per reading and group: person-year share below the BLEI poverty line (30 days; Crisis + Precarious) over 20 years,
 * person-year share in Crisis (below 7 days), the year-20 share below 30 days, and the year-20 median in days. The year-20 'all'
 * values of N and O equal the testbed's nbleiPov and bleiPov (checked by tbBleiUnitSuite). */
var TB_BLEI_DEFS = ['N', 'O', 'X'], TB_BLEI_GRPS = ['A', 'P', 'N'], TB_BLEI_NET = {wealth:0, wage:1};

// index.html line 4525
/* Accumulators, flat for speed: index d*3 + g (d: N, O, X; g: all, participants, non-participants). */
function tbBleiAcc(){ var r = {py:new Float64Array(9), pov:new Float64Array(9), cri:new Float64Array(9), pov20:new Float64Array(9), n20:new Float64Array(9), v20:[]};
  for (var i = 0; i < 9; i++) r.v20.push([]); return r; }

// index.html line 4527
function tbBleiNet(a){ var q = TB_BLEI_NET; q.wealth = a.wealth; q._hhD = a._hhD;  /* v5.3 B3 */ q.wage = Math.max(0, (+a.yrWageUSD || 0) - (+a.yrTax || 0))/12/CFG.WAGE_TO_USD; return q; }

// index.html line 4528
function tbBleiYear(BG, agents, p, o, last){
  var lf = o.lines === 'nominal' ⟦not run⟧ : agents[0].yrBasketUSD/CFG.LIVING_WAGE_ANNUAL/(agents[0]._hhF || 1), L30 = CFG.BLEI_PRECARIOUS_MAX, L7 = CFG.BLEI_CRISIS_MAX, v = [0, 0, 0];
  for (var i = 0; i < agents.length; i++){ var a = agents[i], m = (a._tbM || 0)/CFG.BASE_DAILY_COST, g2 = a._tbPart ? 1 : 2;
    v[0] = (agentBLEI(a, 0, false, false, false, 0, false) + m)/lf; v[1] = agentBLEI(a, p.bu, p.ccoOn, p.pth, p.szh, p.szhCoh, p.ptf)/lf;
    v[2] = (agentBLEI(tbBleiNet(a), 0, false, false, false, 0, false) + m)/lf;
    for (var d = 0; d < 3; d++){ var x = v[d], j0 = d*3, j1 = j0 + g2;
      BG.py[j0]++; BG.py[j1]++; if (x < L30){ BG.pov[j0]++; BG.pov[j1]++; } if (x < L7){ BG.cri[j0]++; BG.cri[j1]++; }
      if (last){ BG.n20[j0]++; BG.n20[j1]++; if (x < L30){ BG.pov20[j0]++; BG.pov20[j1]++; } BG.v20[j0].push(x); BG.v20[j1].push(x); } }
  }
}

// index.html line 4538
function tbBleiRes(BG, R){
  TB_BLEI_DEFS.forEach(function(d, di){ TB_BLEI_GRPS.forEach(function(g, gi){ var j = di*3 + gi, k = 'b' + d + g;
    R[k + 'Py'] = BG.py[j] ? BG.pov[j]/BG.py[j]*100 ⟦not run⟧; R[k + 'Cr'] = BG.py[j] ? BG.cri[j]/BG.py[j]*100 ⟦not run⟧; R[k + '20'] = BG.n20[j] ? BG.pov20[j]/BG.n20[j]*100 ⟦not run⟧; R[k + 'Md'] = medianOf(BG.v20[j]); }); });
  return R;
}

// index.html line 4557
/* v5.2 round, step 2 (Oct 3, 2026; Duke's answers d148 and d149; dev/DECISIONS.md, Session 35). Reporting only: no random draw and no state any rule reads. With the testbed
 * option rep52 (off by default, so every earlier figure and table is unchanged) a run also records:
 *  - the share of adults below the US official poverty line (CFG.POVERTY_THRESHOLD_ONE, one person under 65, 2025 dollars), indexed each year to the model's price level
 *    the way the Census indexes its thresholds to prices: "fpl" on the official measure's own income (money income before tax: wage earnings, conversion proceeds and
 *    cash transfers; the BU, like food stamps in the official measure, are not money income), and "fplX" on resources closer to the Census Supplemental Poverty Measure
 *    (disposable income after the contribution plus the value of the BU and the price cuts, a._tbExt), still against the official threshold;
 *  - each measure at Year 7 (year index 6, the Research Hub's date for its targets) and at the run's last year: those two poverty-line shares, the shares below the cost of
 *    living, below 30 days of basic living (BLEI, the BLEI paper's own reading and the design-neutral one) and with too little wealth, the unhoused share, and four Ginis:
 *    disposable income (giniD), income counting the value of price cuts (giniX), wealth with debts counted as zero (giniW, the convention of the income Ginis and of the
 *    BLEI paper's wealth Gini) and wealth with debts kept (giniWN, the Survey of Consumer Finances convention; it can exceed 1);
 *  - the same shares on fixed-dollar lines ("Nom": the wealth line, the 30-day BLEI line and the poverty threshold not moved with prices), to show what the price indexing
 *    of the lines does; the main readings move with the price level (decision D2, session 2);
 *  - person-year shares over the run for the poverty-line measures and the fixed-dollar BLEI readings.
 * giniNN1 multiplies every Gini of the run by n/(n - 1), which removes the sample Gini's downward bias with n adults (0.2% at 500); off, every Gini is as before. */
var TB_REP_SNAP = ['fpl', 'fplX', 'fplNom', 'f0', 'bO', 'bN', 'bONom', 'bNNom', 'pov', 'povNom', 'ep', 'giniD', 'giniX', 'giniW', 'giniWN'];

// index.html line 4564
/* v5.2 step 5: the year-0 snapshot ('y0', the calibration year, for the check against US data) and poverty spells from each adult's year-by-year history, on the
 * official line ('sf') and the cost of living ('sc'): spells that begin after an adult's first year (spells already under way when the record starts are left
 * out, as in Bane and Ellwood 1986 and Stevens 1994), N_d = spells observed at duration d (d years poor and the next year observed), X_d = those that end there
 * (the next year is above the line), d = 1..4 and 5 = 5 or more; RN = years just after an exit with the following year observed, R = those poor again then
 * (the re-entry rate after one year out). Counts are summed over the run; ratios are taken after summing over seeds. everFpl: % of adults below the official
 * line at least once. */
var TB_REP_SPELL = ['sf', 'sc'].reduce(function(r, m){ [1, 2, 3, 4, 5].forEach(function(d){ r.push(m + 'N' + d, m + 'X' + d); }); r.push(m + 'RN', m + 'R'); return r; }, []);

// index.html line 4568
/* v5.2 step 8: the year-by-year path for the page's small charts (reporting only): each year's share of adults below the cost of living (f0), with too little
 * wealth (pov), below 30 days of basic living (bO; the BLEI paper's reading), the median savings in today's dollars (medW), what a month of the BU buys in
 * today's dollars (buR; 0 with no programme), and what a month of the median wage buys in today's dollars (wageR; working adults). Keys p<measure>_<year>. */
var TB_PATH_M = ['f0', 'pov', 'bO', 'medW', 'buR', 'wageR'], TB_PATH_N = 40;

// index.html line 4573
/* S35 (Oct 30, 2026; research-update prereg/2026-11-study-program.md, before the first run, item 2): reporting only, no draw, nothing any rule reads. The
 * price level at the end of each year to year 40 (plv_<year>; the same value as pLev10 and pLev20 at years 10 and the last; 0 past the run), and the share
 * of families with net worth below zero at year 20 and year 40 (hhDebt20, hhDebt40; 0 if the run is shorter): a family is a household where households are
 * on, an adult otherwise; its net worth is its adults' wealth together. */
var TB_PLV_KEYS = Array.from({length:40}, function(_, t){ return 'plv_' + t; });

// index.html line 4574
var TB_PROG_KEYS = TB_PLV_KEYS.concat(['hhDebt20', 'hhDebt40']);

// index.html line 4575
function tbDebtShare(agents){ var n = 0, k = 0;
  if (HHS && HHS.list) HHS.list.forEach(function(H){ if (!H.a.length) ⟦not run⟧ var w = 0; H.a.forEach(function(a){ w += a.wealth; }); n++; if (w < 0) k++; });⟦not run, 2 lines⟧
  return n ? k/n*100 ⟦not run⟧; }

// index.html line 4579
var TB_PATH_KEYS = TB_PATH_M.reduce(function(r, m){ for (var t = 0; t < TB_PATH_N; t++) r.push('p' + m + '_' + t); return r; }, []);

// index.html line 4580
var TB_REP_KEYS = ['fplPY', 'fplXPY', 'fplNomPY', 'bOAPyNom', 'bNAPyNom'].concat(TB_REP_SNAP.map(function(k){ return 'y7' + k.charAt(0).toUpperCase() + k.slice(1); }), TB_REP_SNAP.map(function(k){ return 'e' + k.charAt(0).toUpperCase() + k.slice(1); }),
  TB_REP_SNAP.map(function(k){ return 'y0' + k.charAt(0).toUpperCase() + k.slice(1); }), TB_REP_SPELL, ['everFpl'], TB_PATH_KEYS);  /* v5.2 step 8: + the year-by-year path */

// index.html line 4582
function tbCashIncome(a){ var c = (+a.yrWageUSD || 0) + (+a.yrConvUSD || 0) + (+a.yrUbiUSD || 0) + (+a.yrSSUSD || 0) + (+a.yrTbCash || 0); return SNET && SNS && a._snB ? c - a._snB : c; }  /* session 2b: the official measure's money income leaves out SNAP and tax credits */

// index.html line 4584
/* A Gini that keeps negative values (debts) as they are: the sorted-rank formula equals the mean absolute difference over twice the mean for any values with a positive total. */
function giniOfArrNeg(x){ var v = x.map(function(z){ return +z ⟦not run⟧; }).sort(function(a, b){ return a - b; }), n = v.length, t = 0, w = 0;
  for (var i = 0; i < n; i++){ t += v[i]; w += (i + 1)*v[i]; } return n > 0 && t > 0 ? 2*w/(n*t) - (n + 1)/n ⟦not run⟧; }

// index.html line 4586
var REP_HOOK = null;  /* v5.2 step 5: an optional reporting hook (dev/tools/us_check.js reads the adults at Year 0, 7 and the last year); null in every run */

// index.html line 4587
function tbRepAcc(){ return {n:0, fpl:0, fplX:0, fplNom:0, bONom:0, bNNom:0, y7:null, end:null, y0:null, hist:[], path:{f0:[], pov:[], bO:[], medW:[], buR:[], wageR:[]}}; }

// index.html line 4588
function tbRepYear(R, agents, p, o, yr, T, ep){
  var n = agents.length, lf = o.lines === 'nominal' ⟦not run⟧ : agents[0].yrBasketUSD/CFG.LIVING_WAGE_ANNUAL/(agents[0]._hhF || 1), thr = CFG.POVERTY_THRESHOLD_ONE, L30 = CFG.BLEI_PRECARIOUS_MAX;
  var s = {fpl:0, fplX:0, fplNom:0, f0:0, bO:0, bN:0, bONom:0, bNNom:0, pov:0, povNom:0};
  for (var i = 0; i < n; i++){ var a = agents[i], c = tbCashIncome(a), bo = agentBLEI(a, p.bu, p.ccoOn, p.pth, p.szh, p.szhCoh, p.ptf), bn = agentBLEI(a, 0, false, false, false, 0, false) + (a._tbM || 0)/CFG.BASE_DAILY_COST;
    var th = a.age >= 65 ⟦not run⟧ : thr, pf = c < th*lf, h = a._h52;  /* v5.2 step 5: the official threshold for 65 and over where adults age (a.age is undefined otherwise) */
    if (!h){ h = a._h52 = {f:[], c:[]}; R.hist.push(h); } h.f.push(pf ? 1 : 0); h.c.push((a._tbGap || 0) > 0 ? 1 : 0);  /* each adult's year-by-year record (a new adult starts its own) */
    if (RISK_MEASURE){ if (!h.w){ h.w = []; h.b = []; h.y = []; } h.w.push(a.wealth/lf); h.b.push(bo/lf); h.y.push(c/lf); }  /* v5.4 item 1 (reporting only) */
    if (pf) s.fpl++; if (c < th) s.fplNom++; if ((a._tbExt || 0) < th*lf) s.fplX++; if ((a._tbGap || 0) > 0) s.f0++;
    if (bo/lf < L30) s.bO++; if (bn/lf < L30) s.bN++; if (bo < L30) s.bONom++; if (bn < L30) s.bNNom++;
    if (a.wealth < CFG.POVERTY_LINE*lf) s.pov++; if (a.wealth < CFG.POVERTY_LINE) s.povNom++; }
  R.n += n; R.fpl += s.fpl; R.fplX += s.fplX; R.fplNom += s.fplNom; R.bONom += s.bONom; R.bNNom += s.bNNom;
  var wk = agents.filter(function(a){ return !a._ret && a.yrWageUSD > 0; }).map(function(a){ return a.yrWageUSD/12/lf; });  /* v5.2 step 8: the year's path */
  R.path.f0[yr] = s.f0/n*100; R.path.pov[yr] = s.pov/n*100; R.path.bO[yr] = s.bO/n*100; R.path.medW[yr] = quantileOf(agents.map(function(a){ return a.wealth/lf; }), 0.5);
  R.path.buR[yr] = p.ccoOn && p.bu > 0 && PRICE && PRICE.buY ? PRICE.buY/lf : 0; R.path.wageR[yr] = wk.length ? quantileOf(wk, 0.5) ⟦not run⟧;
  if (REP_HOOK) ⟦not run⟧  /* session 7: + the year's extreme-poverty figure (explore_export.js --suite) */
  if (yr === 0 || yr === 6 || yr === T - 1){ var gc = o.giniNN1 && n > 1 ? n/(n - 1) ⟦not run⟧, q = {ep:ep};
    Object.keys(s).forEach(function(k){ q[k] = s[k]/n*100; });
    q.giniD = giniOfArr(agents.map(function(a){ return a._tbDisp || 0; }))*gc; q.giniX = giniOfArr(agents.map(function(a){ return a._tbExt || 0; }))*gc;
    q.giniW = giniOfArr(agents.map(function(a){ return a.wealth; }))*gc; q.giniWN = giniOfArrNeg(agents.map(function(a){ return a.wealth; }))*gc;
    if (yr === 0) R.y0 = q; if (yr === 6) R.y7 = q; if (yr === T - 1) R.end = q; }
}

// index.html line 4609
function tbRepSpells(hist, m, out, key){  /* spell counts on one measure (m: 'f' official line, 'c' cost of living) into out[key + ...] */
  var N = [0, 0, 0, 0, 0, 0], X = [0, 0, 0, 0, 0, 0], RN = 0, RR = 0;
  hist.forEach(function(h){ var x = h[m], L = x.length;
    for (var t = 0; t < L; t++){ if (!x[t] || (t > 0 && x[t - 1])) continue; var e = t; while (e < L && x[e]) e++; var len = e - t;
      if (t > 0) for (var d = 1; d <= len; d++){ if (t + d >= L) break; var k = Math.min(d, 5); N[k]++; if (d === len) X[k]++; }  /* observed at duration d when year t + d is in the record */
      if (e < L && e + 1 < L){ RN++; if (x[e + 1]) RR++; } t = e; } });
  for (var d = 1; d <= 5; d++){ out[key + 'N' + d] = N[d]; out[key + 'X' + d] = X[d]; } out[key + 'RN'] = RN; out[key + 'R'] = RR; }

// index.html line 4629
/* v5.4 item 1 (Oct 7, 2026; dev/reports/v5-21-v54-design.md, 1.5; dev/DECISIONS.md Session 40): RISK MEASURES beside the stability score. Reporting only:
 * false (the default) records and reports nothing new. When true (v54 row option rk), each adult's year-by-year record (tbRepYear) also keeps real wealth,
 * real BLEI days and real cash income, and the run reports (RISK_KEYS):
 *  rkDdW, rkDdW6   drawdown of wealth: the largest fall from an earlier peak, in months of the basic-living cost (CFG.LIVING_WAGE_ANNUAL/12, year-0 $);
 *                  the median over adults, and the % of adults whose fall exceeds 6 months
 *  rkDdB, rkDdB30  the same for BLEI days: median largest fall in days, % of adults whose fall exceeds 30 days
 *  rkEv            income shocks per 100 adult-years: a year whose real cash income is below 80% of the year before's (any cause)
 *  rkRec1/3/5      % of income shocks after which income is back to the year-before level within 1, 3, 5 years (each over shocks with that many years observed)
 *  rkRecM          mean years to recover, over shocks that recover
 *  rkRecB3         % of the same shocks after which BLEI days are back to the year-before level within 3 years
 *  rkReC1/3/5      re-entry: of exits from below the cost of living, % below it again within 1, 3, 5 years (Stevens 1999 reads about half within 4-5
 *                  years in the PSID, official line); rkReF5 the same at 5 years on the official line
 * Reads only what the run already computed; no draw is added and no adult's path changes. */
var RISK_MEASURE = false, RISK_KEYS = ['rkDdW', 'rkDdW6', 'rkDdB', 'rkDdB30', 'rkEv', 'rkRec1', 'rkRec3', 'rkRec5', 'rkRecM', 'rkRecB3', 'rkReC1', 'rkReC3', 'rkReC5', 'rkReF5'];

// index.html line 4630
function rkDraw(x){ var pk = x[0], d = 0; for (var t = 1; t < x.length; t++){ if (x[t] > pk) pk = x[t]; else if (pk - x[t] > d) d = pk - x[t]; } return d; }

// index.html line 4631
function rkReentry(hist, m, K){  /* exits: a year not below the line after one below it; re-entry within k years: below it in any of the next k years */
  var N = K.map(function(){ return 0; }), X = K.map(function(){ return 0; });
  hist.forEach(function(h){ var x = h[m], L = x.length; for (var e = 1; e < L; e++){ if (x[e] || !x[e - 1]) continue;
    K.forEach(function(k, i){ if (e + k >= L) return; N[i]++; for (var j = 1; j <= k; j++) if (x[e + j]){ X[i]++; break; } }); } });
  return K.map(function(k, i){ return N[i] ? X[i]/N[i]*100 ⟦not run⟧; }); }

// index.html line 4636
function tbRiskRes(hist, out){
  var mo = CFG.LIVING_WAGE_ANNUAL/12, dW = [], dB = [], ev = 0, ay = 0, R = [[0, 0], [0, 0], [0, 0]], B3 = [0, 0], rs = 0, rn = 0;
  hist.forEach(function(h){ if (!h.w || !h.w.length) ⟦not run⟧ var y = h.y, b = h.b, L = y.length; ay += L;
    dW.push(rkDraw(h.w)/mo); dB.push(rkDraw(b));
    for (var t = 1; t < L; t++){ if (!(y[t - 1] > 0) || y[t] >= 0.8*y[t - 1]) continue; ev++;
      var u = t + 1; while (u < L && y[u] < y[t - 1]) u++; var got = u < L ? u - t : Infinity; if (got < Infinity){ rs += got; rn++; }
      [1, 3, 5].forEach(function(k, i){ if (t + k < L){ R[i][0]++; if (got <= k) R[i][1]++; } });
      if (t + 3 < L){ B3[0]++; for (var v = t + 1; v <= t + 3; v++) if (b[v] >= b[t - 1]){ B3[1]++; break; } } } });
  function pc(x){ return x[0] ? x[1]/x[0]*100 ⟦not run⟧; }
  var rc = rkReentry(hist, 'c', [1, 3, 5]), rf = rkReentry(hist, 'f', [5]);
  out.rkDdW = dW.length ? medianOf(dW) ⟦not run⟧; out.rkDdW6 = dW.length ? dW.filter(function(v){ return v > 6; }).length/dW.length*100 ⟦not run⟧;
  out.rkDdB = dB.length ? medianOf(dB) ⟦not run⟧; out.rkDdB30 = dB.length ? dB.filter(function(v){ return v > 30; }).length/dB.length*100 ⟦not run⟧;
  out.rkEv = ay ? ev/ay*100 ⟦not run⟧; out.rkRec1 = pc(R[0]); out.rkRec3 = pc(R[1]); out.rkRec5 = pc(R[2]); out.rkRecM = rn ? rs/rn ⟦not run⟧; out.rkRecB3 = pc(B3);
  out.rkReC1 = rc[0]; out.rkReC3 = rc[1]; out.rkReC5 = rc[2]; out.rkReF5 = rf[0]; return out; }

// index.html line 4673
/* v5.4 item 2 (Oct 7, 2026; dev/reports/v5-21-v54-design.md, 1.1; dev/DECISIONS.md Session 40): LOSING A JOB AND FINDING ANOTHER. null = off (every
 * earlier run). When an object (v54 row option empl), every working-age adult (not retired) is employed, out of work, or back at work, year by year:
 *  - Entering unemployment: each year an adult at work can lose or leave their job into unemployment with chance CFG.EMPL_P (normal years; recession years
 *    CFG.EMPL_P_REC), from the CPS (sources/unemp_flows.py: job losers and leavers, 2015-2025 without 2020-21; 2009-10). During an automation wave
 *    (auto 'jobs', the default) the wave's existing yearly rate (popAIDisp, the same schedule as before) times the adult's automation risk is an extra chance
 *    of losing the job, and replaces the slower pay growth the wave used to cause; auto 'pay' keeps the old pay drag instead (a labelled reading).
 *  - How long: the spell's length in weeks is drawn from the share of spells lasting at least d weeks, S(d), read from the CPS's unemployed-by-duration
 *    counts (log-linear between 2.5, 9.5 and 20.5 weeks, then a constant ending rate; normal or recession figures by the year the spell starts). It starts at
 *    a point of the year drawn evenly; weeks beyond the year carry into the next (no new spell begins while one runs). Pay that year falls by the share of the
 *    year out of work (before the labour-supply response, which then applies as before).
 *  - Unemployment insurance (both runs, as in the US): with chance CFG.EMPL_UI_RECIP (CPS continued claims / unemployed) the spell is insured; it pays
 *    CFG.EMPL_UI_REPL (DOL: average weekly benefit / average weekly covered wage) of the adult's weekly pay for up to 26 weeks of the spell. It is cash income
 *    like the UBI comparator's (yrUbiUSD carries both), with no effect on hours (it is paid only while out of work).
 *  - Coming back at lower pay: a permanent job loss (chance CFG.EMPL_PERM of a spell, CPS permanent job losers / losers and leavers; every automation loss)
 *    cuts pay on return by a share drawn evenly from 0 to 2 x cut (cut 0.10: a design parameter, swept 0 and 0.20; the displaced-worker literature's
 *    long-run losses for long-tenured workers in mass layoffs run 10-25%: Jacobson, LaLonde and Sullivan 1993; von Wachter, Song and Manchester 2009). The
 *    cut also applies to the no-programme-raise wages (_lwNB, _wNB): job loss is not the programme's. After an automation loss the adult's automation risk
 *    becomes the low-risk group's mean (they move to other work).
 *  - The labour-supply response (LABOR) scales with the share of the year at work: hours already at zero while out of work cannot fall further.
 *  - Recessions (rec 'replace', the default): the recession's income cut for everyone is reduced by the extra share of the year that recession job loss takes
 *    on average ((EMPL_P_REC x EMPL_W_REC - EMPL_P x EMPL_W)/52, about 4.2 points), so the recession's loss is not counted twice; rec 'add' keeps both.
 * Six draws per adult-year from the switch's own stream (mulberry32(seed + 600031)), taken whatever the adult's state, so the two runs stay paired; the main
 * stream's eight draws per adult-year are untouched. No effect of BU on search length beyond the existing income effect (standing rule 7). */
var EMPL = null, EMPL_DEFAULTS = {auto:'jobs', cut:0.10, rec:'replace', ui:true, occ:true}, EMS = null;

// index.html line 4674
CFG.EMPL_P = 0.0851; CFG.EMPL_P_REC = 0.1423; CFG.EMPL_PERM = 0.413; CFG.EMPL_PERM_REC = 0.621; CFG.EMPL_UI_RECIP = 0.273; CFG.EMPL_UI_RECIP_REC = 0.356;

// index.html line 4675
CFG.EMPL_UI_REPL = 0.322; CFG.EMPL_UI_WEEKS = 26; CFG.EMPL_W = 15.2; CFG.EMPL_W_REC = 24.5;

// index.html line 4676
CFG.EMPL_S = {n:[0.4434, 0.1871, 24.18], r:[0.5978, 0.3618, 30.90]};  /* S(9.5), S(20.5), weeks of the constant-rate tail */

// index.html line 4684
/* Occupations (EMPL.occ, on by default with EMPL): the common cause of pay and automation risk. Each adult holds one of 700 occupations (Frey and Osborne's
 * probabilities with May 2016 BLS employment and median pay; sources/fo_occupations.py), drawn at the start on the switch's own stream (mulberry32(seed +
 * 600041), one draw per adult): the occupations are ranked by median pay, and an adult's place in that ranking follows their own pay rank with correlation
 * rho = sqrt(between-occupation variance of log pay (vb, the data) / the variance of log pay across the run's adults), so occupation explains the measured
 * share of the spread of pay and no more. Their automation risk is their occupation's probability (replacing the separate draw). Hours are not tied to
 * occupation: the model's hours enter only as each adult's change from their own starting hours, so occupation's usual hours would change nothing (a
 * stated limit). Adults who arrive later (with ageing) keep their own draw. */
CFG.EMPL_OCC = {"vb":0.2651,"cum":[0.00073,0.02701,0.02713,0.03107,0.03197,0.03581,0.03891,0.05859,0.06079,0.08796,0.09121,0.09232,0.09621,0.10084,0.1052,0.10721,0.10756,0.11409,0.11568,0.11582,0.11694,0.12404,0.12407,0.12548,0.13693,0.13837,0.14028,0.14032,0.14573,0.14643,0.1491,0.14945,0.15029,0.15059,0.15322,0.15947,0.15955,0.1943,0.19757,0.19864,0.19882,0.21429,0.21443,0.21701,0.21707,0.22641,0.243,0.2457,0.24715,0.24881,0.24887,0.25002,0.25007,0.25014,0.25329,0.25356,0.25686,0.25716,0.258,0.25938,0.26014,0.26042,0.26103,0.27073,0.27419,0.27503,0.2757,0.27584,0.27622,0.27635,0.28481,0.28515,0.30501,0.30515,0.30529,0.30541,0.30543,0.31239,0.31264,0.31284,0.31346,0.31434,0.3149,0.31542,0.31542,0.31548,0.31548,0.31548,0.3193,0.31938,0.31946,0.31963,0.31986,0.32077,0.32088,0.32098,0.32105,0.32116,0.3223,0.32996,0.33464,0.33533,0.3359,0.33607,0.33903,0.33909,0.33937,0.33976,0.34043,0.34102,0.34115,0.34131,0.34151,0.34344,0.3464,0.34697,0.34725,0.34731,0.34773,0.34873,0.34943,0.3495,0.34974,0.35029,0.3522,0.35223,0.35325,0.35337,0.36191,0.36341,0.36736,0.3677,0.36814,0.36926,0.36939,0.36958,0.37616,0.39884,0.39915,0.39937,0.39951,0.40257,0.40304,0.40312,0.40831,0.40859,0.41026,0.41049,0.41071,0.41111,0.41288,0.41985,0.42464,0.42741,0.42741,0.42743,0.42886,0.42895,0.42908,0.44985,0.45133,0.4555,0.45626,0.45681,0.45689,0.45876,0.45942,0.45989,0.46047,0.46118,0.46174,0.46199,0.46274,0.463,0.46317,0.46352,0.46487,0.47187,0.47191,0.47228,0.4723,0.47657,0.47682,0.47702,0.47704,0.47759,0.4777,0.47773,0.4781,0.47825,0.47839,0.47929,0.47952,0.47993,0.48003,0.48082,0.48094,0.48104,0.49865,0.49897,0.49903,0.49934,0.49935,0.50047,0.50135,0.50365,0.50422,0.50553,0.50576,0.50599,0.50617,0.50717,0.50718,0.5076,0.50768,0.50782,0.50793,0.50808,0.50814,0.51186,0.51193,0.51194,0.51266,0.51271,0.51281,0.51291,0.51311,0.51364,0.51418,0.51425,0.51524,0.5167,0.51671,0.52069,0.52073,0.521,0.52115,0.52143,0.52395,0.53417,0.53426,0.53462,0.53533,0.5354,0.53541,0.53543,0.53621,0.53637,0.53813,0.53852,0.53856,0.53876,0.53897,0.53913,0.53938,0.54105,0.54133,0.54193,0.54282,0.54313,0.5434,0.54348,0.5446,0.54612,0.54619,0.54772,0.54882,0.5508,0.55203,0.55224,0.55243,0.5528,0.56482,0.56512,0.56723,0.5722,0.57332,0.57358,0.57373,0.57396,0.57412,0.57584,0.57636,0.57651,0.57725,0.57742,0.57768,0.57794,0.57917,0.57956,0.58062,0.58978,0.59112,0.59405,0.59409,0.59419,0.5955,0.59563,0.59637,0.59645,0.59648,0.5965,0.59665,0.59693,0.59727,0.59749,0.5975,0.59753,0.5979,0.59803,0.59806,0.59876,0.5997,0.5998,0.60051,0.60081,0.61389,0.61444,0.61554,0.61567,0.61585,0.61885,0.61921,0.61989,0.62014,0.62056,0.6211,0.62145,0.62268,0.62269,0.62311,0.6232,0.62377,0.6238,0.62393,0.62481,0.62492,0.62823,0.62931,0.63033,0.63057,0.63286,0.6339,0.6391,0.64449,0.64565,0.64712,0.64737,0.6474,0.64792,0.64806,0.64832,0.64901,0.64932,0.64936,0.65018,0.65213,0.65214,0.65229,0.6525,0.65268,0.65284,0.65322,0.65401,0.6549,0.65528,0.65569,0.65576,0.65627,0.659,0.65905,0.66132,0.66184,0.66224,0.66224,0.66238,0.66239,0.66486,0.66494,0.66597,0.66738,0.66812,0.66818,0.66833,0.66995,0.67002,0.67059,0.67067,0.67309,0.67343,0.67352,0.67373,0.67377,0.67464,0.67469,0.67502,0.6753,0.67542,0.67549,0.67563,0.67566,0.67569,0.67597,0.6761,0.67656,0.67705,0.678,0.67806,0.68019,0.68028,0.68028,0.68037,0.68077,0.68133,0.68429,0.68685,0.68718,0.68737,0.68752,0.68819,0.68927,0.6893,0.68935,0.68952,0.68971,0.69016,0.69025,0.6918,0.69189,0.69244,0.69258,0.69574,0.69648,0.69653,0.69664,0.69717,0.69744,0.69753,0.698,0.69805,0.69849,0.70457,0.70462,0.70496,0.70527,0.70537,0.70614,0.7073,0.71196,0.7124,0.71289,0.71373,0.71381,0.71383,0.71559,0.7157,0.71693,0.71703,0.72811,0.72824,0.72833,0.72868,0.72917,0.72952,0.73152,0.73161,0.73178,0.73181,0.73198,0.732,0.73241,0.73252,0.7432,0.74805,0.7489,0.74942,0.74943,0.74955,0.7497,0.75035,0.75039,0.7552,0.75531,0.75534,0.75597,0.75629,0.75767,0.76844,0.76919,0.77074,0.77136,0.77169,0.77179,0.77209,0.77308,0.77777,0.77951,0.78721,0.78973,0.78974,0.78983,0.78992,0.79065,0.79134,0.79232,0.79238,0.79285,0.79314,0.79521,0.79532,0.79565,0.79591,0.80096,0.80198,0.80202,0.80228,0.80248,0.80347,0.80349,0.80352,0.80366,0.80399,0.80412,0.80415,0.80543,0.80577,0.80742,0.80757,0.8077,0.80781,0.80841,0.80945,0.80956,0.81017,0.81074,0.81187,0.81616,0.81761,0.8177,0.81793,0.81798,0.81813,0.81824,0.82172,0.82407,0.82617,0.82628,0.82725,0.82734,0.82749,0.82772,0.82779,0.82785,0.82788,0.83962,0.84172,0.84176,0.84193,0.84464,0.84496,0.84521,0.84535,0.84605,0.84629,0.8472,0.84729,0.85685,0.85713,0.85777,0.86513,0.86516,0.86611,0.86661,0.867,0.86756,0.86782,0.8679,0.86797,0.86801,0.8686,0.86948,0.86959,0.8698,0.87009,0.87166,0.8736,0.87443,0.87444,0.87511,0.87553,0.87665,0.87666,0.87681,0.87709,0.87753,0.87857,0.87884,0.87911,0.87928,0.87938,0.88015,0.88042,0.88072,0.88153,0.8817,0.88422,0.88427,0.88511,0.88549,0.88838,0.8884,0.89049,0.89062,0.89067,0.89092,0.89176,0.89665,0.89881,0.8989,0.89981,0.90003,0.90004,0.90225,0.90444,0.90641,0.90718,0.90758,0.90845,0.91012,0.91027,0.91228,0.91247,0.91684,0.91736,0.91823,0.92014,0.92038,0.92065,0.9227,0.92425,0.92531,0.92536,0.92548,0.92555,0.92741,0.92762,0.92768,0.92774,0.92915,0.92925,0.92939,0.93194,0.93323,0.93418,0.93443,0.93544,0.95224,0.9523,0.95287,0.95896,0.95911,0.95933,0.95948,0.96028,0.96042,0.96043,0.96353,0.96355,0.9638,0.96408,0.96722,0.96822,0.96871,0.96924,0.96979,0.96999,0.97004,0.9706,0.97073,0.97085,0.97365,0.9784,0.97882,0.98299,0.98533,0.98551,0.98559,0.98566,0.98587,0.98588,0.9865,0.98676,0.98834,0.9897,0.99241,0.99322,0.99493,0.99992,0.99996,1.0],"p":[0.96,0.92,0.79,0.81,0.96,0.96,0.97,0.94,0.72,0.97,0.91,0.67,0.77,0.77,0.084,0.86,0.81,0.87,0.71,0.43,0.87,0.69,0.98,0.94,0.74,0.82,0.94,0.97,0.38,0.95,0.37,0.83,0.83,0.41,0.87,0.39,0.91,0.92,0.98,0.89,0.83,0.64,0.25,0.006,0.52,0.96,0.66,0.11,0.89,0.99,0.94,0.94,0.99,0.13,0.83,0.37,0.66,0.91,0.7,0.89,0.95,0.72,0.86,0.56,0.97,0.064,0.51,0.98,0.61,0.8,0.84,0.047,0.85,0.39,0.75,0.95,0.97,0.95,0.13,0.99,0.6,0.48,0.49,0.47,0.96,0.87,0.77,0.83,0.98,0.97,0.94,0.73,0.96,0.79,0.64,0.94,0.72,0.1,0.7,0.96,0.01,0.96,0.94,0.84,0.98,0.27,0.61,0.86,0.93,0.97,0.81,0.91,0.97,0.92,0.007,0.95,0.92,0.72,0.57,0.97,0.94,0.93,0.21,0.74,0.98,0.18,0.93,0.92,0.97,0.99,0.89,0.29,0.92,0.95,0.87,0.83,0.69,0.96,0.9,0.97,0.93,0.92,0.043,0.98,0.98,0.92,0.95,0.1,0.93,0.95,0.013,0.63,0.3,0.13,0.3,0.057,0.94,0.61,0.95,0.55,0.78,0.93,0.029,0.93,0.95,0.049,0.91,0.86,0.95,0.99,0.66,0.39,0.92,0.94,0.92,0.97,0.98,0.88,0.035,0.37,0.83,0.81,0.93,0.97,0.87,0.91,0.73,0.96,0.021,0.88,0.55,0.91,0.97,0.78,0.21,0.009,0.79,0.67,0.96,0.99,0.91,0.77,0.97,0.61,0.93,0.95,0.71,0.83,0.42,0.83,0.88,0.83,0.95,0.89,0.72,0.37,0.45,0.37,0.54,0.96,0.87,0.048,0.63,0.86,0.94,0.59,0.83,0.099,0.99,0.88,0.46,0.076,0.99,0.98,0.87,0.71,0.93,0.97,0.51,0.64,0.84,0.61,0.67,0.97,0.98,0.97,0.74,0.91,0.13,0.68,0.76,0.65,0.79,0.97,0.72,0.75,0.97,0.41,0.9,0.11,0.75,0.79,0.86,0.96,0.84,0.91,0.87,0.085,0.94,0.95,0.87,0.88,0.98,0.62,0.98,0.59,0.5,0.84,0.91,0.74,0.025,0.92,0.81,0.66,0.49,0.84,0.97,0.85,0.47,0.83,0.9,0.28,0.94,0.94,0.005,0.89,0.67,0.98,0.54,0.59,0.54,0.62,0.77,0.75,0.53,0.83,0.96,0.88,0.94,0.88,0.97,0.033,0.4,0.16,0.79,0.82,0.79,0.98,0.91,0.76,0.94,0.65,0.73,0.99,0.83,0.69,0.55,0.78,0.97,0.92,0.96,0.9,0.3,0.65,0.36,0.003,0.94,0.6,0.005,0.1,0.65,0.028,0.7,0.72,0.058,0.86,0.98,0.77,0.9,0.82,0.85,0.04,0.86,0.074,0.9,0.34,0.73,0.82,0.57,0.64,0.007,0.89,0.008,0.57,0.61,0.015,0.99,0.84,0.57,0.95,0.61,0.65,0.61,0.38,0.98,0.003,0.91,0.88,0.66,0.82,0.42,0.037,0.066,0.9,0.082,0.28,0.76,0.39,0.17,0.27,0.8,0.31,0.004,0.35,0.93,0.93,0.055,0.25,0.71,0.62,0.18,0.97,0.014,0.25,0.98,0.82,0.4,0.008,0.94,0.84,0.99,0.1,0.022,0.75,0.92,0.67,0.79,0.2,0.015,0.25,0.54,0.91,0.76,0.28,0.36,0.19,0.042,0.083,0.006,0.84,0.5,0.35,0.52,0.08,0.41,0.83,0.004,0.54,0.9,0.59,0.93,0.65,0.48,0.9,0.59,0.93,0.49,0.15,0.15,0.045,0.03,0.29,0.007,0.5,0.36,0.13,0.004,0.89,0.014,0.53,0.23,0.38,0.68,0.63,0.008,0.86,0.88,0.82,0.6,0.44,0.23,0.81,0.004,0.86,0.79,0.41,0.37,0.91,0.83,0.018,0.067,0.17,0.01,0.49,0.95,0.97,0.81,0.85,0.055,0.029,0.009,0.83,0.26,0.96,0.65,0.016,0.18,0.008,0.68,0.93,0.87,0.48,0.63,0.016,0.066,0.008,0.004,0.028,0.014,0.91,0.38,0.89,0.098,0.008,0.06,0.85,0.81,0.71,0.061,0.91,0.3,0.025,0.7,0.01,0.9,0.038,0.57,0.016,0.68,0.24,0.47,0.84,0.021,0.31,0.24,0.004,0.61,0.21,0.88,0.31,0.008,0.045,0.98,0.003,0.98,0.98,0.077,0.007,0.86,0.021,0.015,0.9,0.004,0.047,0.032,0.08,0.57,0.012,0.016,0.71,0.027,0.78,0.99,0.037,0.097,0.48,0.94,0.23,0.033,0.23,0.091,0.33,0.35,0.89,0.98,0.13,0.003,0.041,0.2,0.17,0.022,0.75,0.9,0.27,0.68,0.075,0.005,0.49,0.1,0.94,0.012,0.25,0.13,0.02,0.004,0.006,0.85,0.015,0.38,0.003,0.018,0.04,0.55,0.34,0.39,0.25,0.85,0.035,0.17,0.03,0.059,0.48,0.34,0.014,0.22,0.004,0.13,0.23,0.64,0.004,0.027,0.012,0.019,0.011,0.029,0.004,0.018,0.03,0.021,0.037,0.22,0.028,0.006,0.038,0.59,0.071,0.63,0.023,0.73,0.58,0.01,0.95,0.64,0.67,0.005,0.021,0.01,0.14,0.1,0.004,0.43,0.007,0.03,0.014,0.017,0.025,0.16,0.021,0.004,0.042,0.21,0.039,0.43,0.14,0.07,0.041,0.25,0.047,0.006,0.14,0.13,0.006,0.015,0.017,0.03,0.015,0.039,0.22,0.1,0.96,0.013,0.035,0.018,0.069,0.012,0.11,0.005,0.009,0.4,0.055,0.18,0.16,0.014,0.017,0.035,0.004,0.015,0.004,0.023,0.004]};

// index.html line 4685
function emplOcc(agents, seed){ var O = CFG.EMPL_OCC, r = mulberry32(seed + 600041), n = agents.length; if (!n) ⟦not run⟧
  var lw = agents.map(function(a){ return Math.log(Math.max(1e-9, a.wage)); }), m = lw.reduce(function(s, x){ return s + x; }, 0)/n,
    v = lw.reduce(function(s, x){ return s + (x - m)*(x - m); }, 0)/n, rho = v > 0 ? Math.sqrt(Math.min(1, O.vb/v)) ⟦not run⟧;
  var ord = agents.map(function(a, i){ return i; }).sort(function(i, j){ return agents[i].wage - agents[j].wage ⟦not run⟧; }), rk = new Array(n);
  ord.forEach(function(i, k){ rk[i] = k; });
  agents.forEach(function(a, i){ var e = normInv(Math.min(1 - 1e-12, Math.max(1e-12, r()))), z = rho*normInv((rk[i] + 0.5)/n) + Math.sqrt(1 - rho*rho)*e, q = normCdf(z), lo = 0, hi = O.cum.length - 1;
    while (lo < hi){ var mid = (lo + hi) >> 1; if (O.cum[mid] >= q) hi = mid; else lo = mid + 1; }
    a._emOcc = lo; a.automationRisk = O.p[lo]; });
  return rho; }

// index.html line 4694
var EMPL_KEYS = ['emUrate', 'emSpells', 'emWeeks', 'emAuto', 'emUI', 'emCut', 'emLong', 'emRho'];  /* % of adult-years out of work (weeks/52); spells per 100 adult-years; weeks out per adult-year with any; automation losses per 100 adult-years; UI as % of pay lost; mean pay cut on return (%); % of spells over 26 weeks */

// index.html line 4695
function emplWeeks(u, rec){ var s = CFG.EMPL_S[rec ? 'r' : 'n'], S1 = s[0], S2 = s[1];  /* the spell length d with S(d) = u */
  if (u >= 1) ⟦not run⟧ if (u >= S1) return 2.5 + 7*Math.log(u)/Math.log(S1); if (u >= S2) return 9.5 + 11*(Math.log(u) - Math.log(S1))/(Math.log(S2) - Math.log(S1));
  return 20.5 + s[2]*Math.log(S2/u); }

// index.html line 4698
function emplInit(agents, seed){ EMS = {r:mulberry32(seed + 600031), n:0, out:0, spells:0, weeks:0, auto:0, ui:0, lost:0, cut:0, cutN:0, long:0, rho:EMPL.occ ? emplOcc(agents, seed) ⟦not run⟧}; }

// index.html line 4699
function emplYear(a, rec, aiH, u, wkPay){  /* u: six draws. Returns {out: share of the year out of work, ui: dollars}. */
  var A = EMS, w = 0, ui = 0, carry = Math.min(52, a._emW || 0); a._emW = (a._emW || 0) - carry; w = carry;
  if (carry > 0 && a._emUi){ var uw = Math.min(carry, Math.max(0, CFG.EMPL_UI_WEEKS - a._emUiW)); a._emUiW += uw; ui += uw*CFG.EMPL_UI_REPL*wkPay; }
  if (carry === 0){ var hA = EMPL.auto === 'jobs' ? Math.max(0, aiH*a.automationRisk) ⟦not run⟧, h = rec ? CFG.EMPL_P_REC : CFG.EMPL_P, pE = 1 - (1 - h)*(1 - hA);
    if (u[0] < pE){ var auto = u[0] < hA, D = emplWeeks(u[2], rec), st = u[3]*52, now = Math.min(D, 52 - st); A.spells++; if (auto) A.auto++; if (D > 26) A.long++;
      w = now; a._emW = D - now; a._emUi = EMPL.ui && u[4] < (rec ? CFG.EMPL_UI_RECIP_REC : CFG.EMPL_UI_RECIP); a._emUiW = 0;
      if (a._emUi){ var uw2 = Math.min(now, CFG.EMPL_UI_WEEKS); a._emUiW = uw2; ui += uw2*CFG.EMPL_UI_REPL*wkPay; }
      a._emCut = (auto || u[1] < (rec ? CFG.EMPL_PERM_REC : CFG.EMPL_PERM)) ? 2*EMPL.cut*u[5] : 0; a._emAuto = auto; } }
  if (a._emW <= 0 && (a._emCut || a._emAuto)){ var f = 1 - (a._emCut ⟦not run⟧); a.wage *= f; if (a._lwNB !== undefined) a._lwNB *= f; if (a._wNB !== undefined) a._wNB *= f;  /* back at work: the lower pay */
    A.cut += a._emCut ⟦not run⟧; A.cutN++; if (a._emAuto) a.automationRisk = 1/(1 + CFG.AUTO_LOW_B); a._emCut = 0; a._emAuto = false; }
  A.n++; A.weeks += w; A.ui += ui; A.lost += w*wkPay; if (w > 0) A.out++; return {out:Math.min(1, w/52), ui:ui}; }

// index.html line 4710
function emplRes(out){ var A = EMS; out.emUrate = A && A.n ? A.weeks/52/A.n*100 ⟦not run⟧; out.emSpells = A && A.n ? A.spells/A.n*100 ⟦not run⟧; out.emWeeks = A && A.out ? A.weeks/A.out ⟦not run⟧;
  out.emAuto = A && A.n ? A.auto/A.n*100 ⟦not run⟧; out.emUI = A && A.lost > 0 ? A.ui/A.lost*100 ⟦not run⟧; out.emCut = A && A.cutN ? A.cut/A.cutN*100 ⟦not run⟧; out.emLong = A && A.spells ? A.long/A.spells*100 ⟦not run⟧; out.emRho = A ? A.rho ⟦not run⟧; return out; }

// index.html line 4736
/* v5.4 item 3 (Oct 7, 2026; dev/reports/v5-21-v54-design.md, 1.2; dev/DECISIONS.md Session 40): PTH AS A HOUSING BALANCE SHEET. null = off (every earlier
 * run). When an object (v54 row option pthb), every PTH home has the trust's books beside its member's Acre Equity:
 *  - The home: bought when its first member's books open, at CFG.PTHB_PR years of the member's market housing cost (hSA x dcA: the housing share of their
 *    basket, at market prices), financed by the trust's debt less the member's starting Acre Equity, so the community's equity starts at zero. Its value moves
 *    each year with the model's price level and CFG.PTHB_G real growth (FHFA over CPI-U, 1991-2025); CFG.PTHB_LAND of it is land.
 *  - The trust's cash each year: in, the market housing cost (the member's fee plus the programme's payment for the cut, which the programme's cost already
 *    carries) and the member's equity contribution; out, interest (a real rate CFG.PTHB_RREAL on top of the year's price rise, so inflation does not shrink the
 *    debt for free), upkeep (CFG.PTHB_UPK of the structure's value: BEA's yearly wear of owner-occupied homes), property tax (CFG.PTHB_TAX of value) and the
 *    appreciation paid to the member in cash. What is left pays down the debt; a shortfall adds to it.
 *  - Acre Equity grows with the home's value but at most at the year's price rise + 2% (cap 'hub': the Democratic Governance paper's cap, Duke's question
 *    d175's default); cap 'old' keeps the 3-5% rule (plus the Social Zone bonus) as before. What the home gains beyond the credit is the community's.
 *  - Leaving: each year a member leaves the network with chance exit (0.062: renters' moves to another county, CPS ASEC 2023; 'owners' reading 0.019; one
 *    draw per adult a year on the switch's own stream mulberry32(seed + 600043); in a household the head's draw decides for its PTH members). A leaver takes
 *    cash share x of their Acre Equity (0.40: the Real Estate paper's cash value on exit; Duke's question d174) and the rest becomes the community's; the
 *    trust borrows the cash. The home passes to the next adult waiting (non-members in the order of their PTH uptake draw, fixed at the start), who starts
 *    with no Acre Equity. Moves within the county stay in the network with their equity (not modelled as moves).
 *  - Cash from appreciation (the existing liquid share, 15% rising to 85% with tenure) is paid only on the gain above the year's price rise; the part that
 *    keeps up with prices stays as Acre Equity (otherwise inflation would turn members' equity into spending).
 *  - pbCover: the share of home-years whose market rent and equity contribution cover the real cost of the debt (interest less the price rise's erosion of
 *    it), upkeep, tax and cash paid out. pbAprP is the year's nominal gain from the price rise, pbAprR the real gain, pbAprC what the community keeps beyond the
 *    members' credit (all in year-0 dollars per home-year).
 *  - The identity homes - debt = members' equity + community equity is checked for every home every year (ACCT 'pth-books'): it ties the engine's Acre Equity
 *    to the trust's flows. Insurance is not modelled (no separate source; BEA folds it into intermediate costs).
 * Only the programme run has PTH; the no-programme run is untouched. No draw on the main stream. */
var PTHB = null, PTHB_DEFAULTS = {cap:'hub', x:0.40, exit:0.062}, PBS = null;

// index.html line 4737
CFG.PTHB_PR = 18.23; CFG.PTHB_LAND = 0.377; CFG.PTHB_UPK = 0.0231; CFG.PTHB_TAX = 0.0065; CFG.PTHB_G = 0.0172; CFG.PTHB_RREAL = 0.0180; CFG.PTHB_EXIT_OWN = 0.019;

// index.html line 4738
var PTHB_KEYS = ['pbV', 'pbD', 'pbME', 'pbCE', 'pbCover', 'pbExit', 'pbCash', 'pbAprP', 'pbAprR', 'pbAprC', 'pbFill'];

// index.html line 4739
function pthbInit(agents, latent, seed){ PBS = {r:mulberry32(seed + 600043), q:[], P:1, pi:0, n:0, exits:0, cash:0, cover:0, aP:0, aR:0, aC:0, fill:0, slots:[]};
  agents.forEach(function(a, i){ a._pbU = latent[i] ? latent[i].uPTH ⟦not run⟧; if (a.inPTH){ a._pbS = {V:0, D:0, CE:0}; PBS.slots.push(a._pbS); } else PBS.q.push(a); });
  PBS.q.sort(function(x, y){ return x._pbU - y._pbU; }); }

// index.html line 4742
function pthbYear(agentSet, yr, P){  /* before the year's adults: this year's price rise, then leavers and their homes' new members */
  PBS.pi = yr > 0 && PBS.P > 0 ? P/PBS.P - 1 : 0; PBS.P = P; if (yr === 0) return;
  var x = PTHB.x, rate = PTHB.exit === 'owners' ⟦not run⟧ : PTHB.exit, u = agentSet.map(function(){ return PBS.r(); }), go = [];
  agentSet.forEach(function(a, i){ if (!a.inPTH || !a._pbS) return; var h = a._hh && !a._hh.single && a._hh.a ? a._hh.a[0] : a, j = agentSet.indexOf(h);
    if ((j >= 0 ? u[j] ⟦not run⟧) < rate) go.push(a); });
  go.forEach(function(a){ var S = a._pbS, E = Math.max(0, +a.acreEquity ⟦not run⟧), c = x*E; a.wealth += c; S.D += c; S.CE += E - c; a.acreEquity = 0; a.inPTH = false; a.pthTenure = 0; a._pbS = null; if (ACCT)⟦not run⟧  /* the exit is booked at the year's opening (the trust's side: D and CE above) */
    PBS.exits++; PBS.cash += c/P; if (LEDGER) ⟦not run⟧
    while (PBS.q.length && (PBS.q[0].inPTH || agentSet.indexOf(PBS.q[0]) < 0)) PBS.q.shift();
    if (PBS.q.length){ var b = PBS.q.shift(); b.inPTH = true; b.acreEquity = 0; b.pthTenure = 0; b._pbS = S; if (ACCT) ⟦not run⟧ PBS.fill++; } }); }

// index.html line 4751
function pthbRes(out){ var A = PBS, n = A && A.slots.length ? A.slots.length : 0, P = A ? A.P : 1; function sum(k){ return A ? A.slots.reduce(function(s, S){ return s + S[k]; }, 0) ⟦not run⟧; }
  out.pbV = n ? sum('V')/n/P : 0; out.pbD = n ? sum('D')/n/P : 0; out.pbCE = n ? sum('CE')/n/P : 0; out.pbME = n ? out.pbV - out.pbD - out.pbCE : 0;
  out.pbCover = A && A.n ? A.cover/A.n*100 : 0; out.pbExit = A && A.n ? A.exits/A.n*100 : 0; out.pbCash = A && A.exits ? A.cash/A.exits : 0;
  out.pbAprP = A && A.n ? A.aP/A.n : 0; out.pbAprR = A && A.n ? A.aR/A.n : 0; out.pbAprC = A && A.n ? A.aC/A.n : 0; out.pbFill = A && A.exits ? A.fill/A.exits*100 : 0; return out; }

// index.html line 4769
/* v5.4 item 4 (Oct 7, 2026; dev/reports/v5-21-v54-design.md, 1.3; dev/DECISIONS.md Session 40): PTF BY SECTOR, AND MEMBERS WHO LEAVE. null = off (every
 * earlier run: 12% off the whole cost of living, more with Social Zone Harmonization, and members never leave). When an object (v54 row option ptfs):
 *  - A member's cut is the sum over five sectors of the sector's share of their household's basket times the sector's PTF price cut:
 *      food        1 - 1/2.64 (the BLEI paper's food epsilon; 1 - 1/1.65 while fewer than 40% of adults are members: the paper's "below approximately 40%
 *                  PTF merchant participation ... epsilon falls toward 1.5-1.8x", its midpoint)
 *      utilities   1 - 1/1.80 (the paper's utility epsilon) on CFG.PTFS_UTIL of the housing share (BEA 2025: electricity, gas, water and sanitation over
 *                  housing plus those, 487.7 / 3,814.0)
 *      transport, health care, childcare: other (0: the Hub gives no figure, so the cautious main value is no cut; swept 0.12 and 0.25)
 *    With Social Zone Harmonization the cut is raised in the same proportion as before ((0.12 + 0.04 x cohesion)/0.12).
 *  - Leaving: each year a member household leaves with chance leave (0.032: moves to another county, CPS ASEC 2023 Table 1; one draw per adult a year on
 *    the switch's own stream mulberry32(seed + 600047), the head's draw deciding for the household). Leavers can join again through the adoption curve.
 *    No leaving for lack of value: membership has no fee in the model, so nothing weighs against the cut (a stated limit).
 *  - Capacity: the membership gate the model already has (the production side's capacity, PROD) limits how many adults can be members; the sectors share
 *    it (no sector has its own capacity data: a stated limit). */
var PTFS = null, PTFS_DEFAULTS = {other:0, leave:0.032}, PFS = null;

// index.html line 4770
CFG.PTFS_EPS_FOOD = 2.64; CFG.PTFS_EPS_FOOD_LOW = 1.65; CFG.PTFS_EPS_UTIL = 1.80; CFG.PTFS_LOW_DENS = 0.40; CFG.PTFS_UTIL = 487.685/(3326.284 + 487.685);

// index.html line 4771
var PTFS_KEYS = ['pfCut', 'pfLeave', 'pfMem'];

// index.html line 4772
function ptfsShares(a, HHA){  /* the member's basket shares: food, housing, transport, medical, childcare */
  if (HHA && a._hhS) return a._hhS; var c = function(k){ return PRICE ? PRICE.comp[k]/PRICE.bIdx ⟦not run⟧; };
  return {f:CFG.BASKET.food*c('food'), h:CFG.BASKET.housing*c('housing'), t:CFG.BASKET.transport*c('transport'), m:CFG.BASKET.medical*c('medical'), k:0}; }

// index.html line 4775
function ptfsCut(a, HHA, p, quiet){ var s = ptfsShares(a, HHA), eF = PFS && (CMS ⟦not run⟧ ⟦not run⟧ : PFS.dens) < CFG.PTFS_LOW_DENS ? CFG.PTFS_EPS_FOOD_LOW ⟦not run⟧, o = PTFS.other;
  var c = s.f*(1 - 1/eF) + s.h*CFG.PTFS_UTIL*(1 - 1/CFG.PTFS_EPS_UTIL) + (s.t + (HLS ⟦not run⟧ ⟦not run⟧ : s.m) + s.k)*o;  /* session 2b (DECISIONS, 'Nothing counted twice', item 7): under single payer (B, C) the health-sector cut lowers the plan's costs (hlSingle), not the household's */ if (p.szh) c *= (0.12 + p.szhCoh*0.04)/0.12;
  if (PFS && !quiet){ PFS.cut += c; PFS.cn++; } return Math.min(0.95, c); }

// index.html line 4778
function ptfsYear(agentSet, yr){  /* before the year's adults: leavers, then the share of adults who are members (the food epsilon's density test) */
  var u = agentSet.map(function(){ return PFS.r(); }), m = 0;
  if (yr > 0) agentSet.forEach(function(a, i){ if (!a.inPTF || (a._hh && !a._hh.single && a._hh.a && a._hh.a[0] !== a)) return; if (u[i] < PTFS.leave){ a.inPTF = false; PFS.leave++;
    if (a._hh && a._hh.a) a._hh.a.forEach(function(b){ b.inPTF = false; }); } });
  agentSet.forEach(function(a){ if (a.inPTF) m++; }); PFS.dens = m/Math.max(1, agentSet.length); PFS.mem += PFS.dens; PFS.yrs++; }

// index.html line 4783
function ptfsRes(out){ var A = PFS; out.pfCut = A && A.cn ? A.cut/A.cn*100 : 0; out.pfLeave = A && A.yrs ? A.leave/A.yrs : 0; out.pfMem = A && A.yrs ? A.mem/A.yrs*100 : 0; return out; }

// index.html line 4806
/* S37 (Oct 31, 2026; dev/reports/community-layer.md; dev/DECISIONS.md S37): THE COMMUNITY AND ZONE LAYER. null = off (every earlier run: the tests that
 * read PTF density read the share of all adults who are members). When an object (row option cl), and only in runs with PTF:
 *  - Communities. At the start of the run the households (each adult alone, without households) are dealt into round(n/k) communities of about k adults,
 *    in an order drawn on the switch's own stream mulberry32(seed + 600059), one draw per household. Households are never split. k (100) is a design
 *    parameter: how many simulated adults stand for one zone, not a zone's population (the Hub: zones "scale from neighborhood to regional"); swept 50
 *    and 250. An adult who dies is replaced in the same community (no draw).
 *  - Zones. When zones form (SZH and PTF on; with zc, CIP on too: the Hub forms zones through CIP surveys), the starting PTF members are placed together,
 *    as Social Zone Harmonization "organizes the geographic deployment of PTF businesses": communities are filled in turn with member households until
 *    members are a share f of the community, then with non-member households up to its size; the last zone takes the members left. f (0.5: the Hub's
 *    zone formation by survey majority) is a design parameter, swept 2/3 (the zone charter's supermajority) and 1. The other communities are dealt as
 *    above. Who is a member does not change (the same draws decide it), only who lives with whom. No zones form if members are already a share f of all
 *    adults.
 *  - Local density. Each year each community's member share replaces the share of all adults in the three tests that read PTF density: the food price
 *    cut (epsilon 2.64, or 1.65 below 40%: the BLEI paper, "below approximately 40% PTF merchant participation in a given zone"); the synergy
 *    coefficient theta (0 below 55%, 0.25 at 90%, the same paragraph), which sets the PTF rate bonus, the SZH induction into PTF and the design's BLEI
 *    term; and the Bass imitation term of PTF adoption (bass 'local'; 'pop' keeps it population-wide). Each share is taken at the point of the year where
 *    the population share is taken, so with one community (k at least n) every figure equals the switch off. Price damping and the PTF's capacity stay
 *    population-wide (a stated limit: capacity is not placed by zone).
 *  - Not modelled: PTH density. The Hub's one PTH quantity is a count (break-even at 30-40 households), which a sample of a zone's adults cannot show,
 *    and the "community coherence" PTH needs has no size.
 * Reported (CL_KEYS): clN communities; clZ zones formed at the start; clSd the spread of the member share across communities (standard deviation, points,
 * mean over years); clHi the share of members living where the share is at least 40% (%, mean over years); clTh the same where theta is above 0 (%). */
var COMM = null, COMM_DEFAULTS = {k:100, f:0.5, zc:false, bass:'local'}, CMS = null;

// index.html line 4807
var CL_KEYS = ['clN', 'clZ', 'clSd', 'clHi', 'clTh'];

// index.html line 4823
/* S6 (Oct 31, 2026; research-update prereg/2026-11-c22-coverage-adequacy.md; dev/reports/c22-coverage-adequacy.md): who receives the BU and whether it
 * covers basic needs (NEEC criterion C2.2: unconditional provision covering 100% of housing, food, healthcare and utilities for all residents). Off by
 * default (C22 null): nothing below runs and every figure is unchanged. Study row option c22: {u, auto, idx}.
 *  - u: the Act's status rule (section 102: "every citizen and legal resident"). A share u of households is not eligible: their adults never receive
 *    the BU (they cannot join, and emergency enrolment skips them); everything else about them is unchanged. Drawn once per household (a single adult is
 *    a household of one) on its own stream (seed + 600067), so no draw moves on any other stream. u = 0 draws nothing.
 *  - auto: the Act's "distribution shall be automatic": every eligible adult receives the BU from year 0 and nobody leaves (taking part costs nothing).
 *    Joining still means what it means in the model (BU, octaves, conversion); the BU's receipt no longer waits on a choice.
 *  - idx 'needs': the BU indexed every year to the price of the C2.2 needs (food, housing with utilities, medical care: C22_NEEDS) instead of the
 *    cost-of-living adjustment's 5% trigger. With it, a BU set at c22NeedsBU() keeps paying for those needs at the prices a non-member pays.
 * Reported (C22_KEYS; reporting only, no draw): c22PY the share of adult-years in which the BU the adult receives (12 months, the adult's share of the
 *   household's allowance) is at least the cost of the C2.2 needs at market prices (the adult's share of the household's needs; no member price cut);
 *   c22R the mean of that ratio capped at 1 (%); buPY the share of adult-years receiving the BU; elN the share of adults not eligible (%); elF0, elW,
 *   elRes those adults' share of years below the cost of living, share with too little wealth at the end, and mean real resources (as gNonF0, gNonW,
 *   gNonRes). With u > 0 on the no-programme row as well, the same adults are found there (the draw does not depend on the row). */
var C22 = null, C22_DEFAULTS = {u:0, auto:false, idx:false}, C22S = null, C22_NEEDS = ['food', 'housing', 'medical'];

// index.html line 4824
var C22_KEYS = ['c22PY', 'c22R', 'buPY', 'elN', 'elF0', 'elW', 'elRes'];

// index.html line 4845
/* S14 (Oct 31, 2026; research-update prereg/2026-11-lw-weighted-line.md; dev/reports/lw-weighted-line.md): the cost-of-living line at another level.
 * CFG.LIVING_WAGE_ANNUAL ($49,370) is the unweighted mean of MIT's 51 state one-adult living wages. Three sets of constants are fitted at that level
 * from the eight MIT state pages (sources/households.py): the basket shares CFG.BASKET, the household ratios CFG.HH_RATIO and the childcare dollars
 * CFG.HH_CHILDCARE; project pay (PROJ_DEFAULTS.pay) is the line over 2,080 hours. Every other dollar that follows the line reads it when it runs.
 * Study row option lw: a key of CFG.LW_SETS (sources/lw_line.py prints them): the line and the three sets refitted at it, by the same method. For that
 * row only, lwSet writes them in place (the objects keep their identity) and lwReset puts the values back; the no-programme reference path is keyed
 * by the line. Off by default (LW null): nothing changes and every figure is unchanged. No draw is added.
 *  ext: $51,201.28, a population-weighted mean of MIT's 51 states computed outside the project (v4.11; not re-derived: MIT licenses data for more
 *       than ten locations). bea: $51,837.76, the line x the population-weighted over unweighted ratio of a fit on BEA's price parities (sources/lw_bea.py). */
CFG.LW_SETS = {"ext":{"L":51201.28,"basket":{"food":0.0884,"housing":0.2881,"medical":0.0653,"transport":0.1892,"civic":0.0657,"internet":0.0302,"other":0.0903,"taxes":0.1828},"ratio":{"1a0k":{"food":1.0,"housing":1.0,"medical":1.0,"transport":1.0,"civic":1.0,"internet":1.0,"other":1.0,"taxes":1.0},"1a1k":{"food":1.466864,"housing":1.361395,"medical":2.867701,"transport":1.157298,"civic":1.688056,"internet":1.0,"other":1.818302,"taxes":1.551209},"1a2k":{"food":2.197915,"housing":1.361395,"medical":2.916119,"transport":1.457795,"civic":2.226143,"internet":1.0,"other":1.987649,"taxes":2.270729},"1a3k":{"food":2.925249,"housing":1.776497,"medical":2.969052,"transport":1.677398,"civic":2.535163,"internet":1.0,"other":2.164198,"taxes":3.179257},"2a0k":{"food":1.833269,"housing":1.098858,"medical":2.169752,"transport":1.157298,"civic":1.688056,"internet":1.379819,"other":1.818302,"taxes":1.091745},"2a1k":{"food":2.275222,"housing":1.361395,"medical":3.171906,"transport":1.457795,"civic":2.226143,"internet":1.379819,"other":2.03575,"taxes":1.652083},"2a2k":{"food":2.926572,"housing":1.361395,"medical":3.270417,"transport":1.677398,"civic":2.535163,"internet":1.379819,"other":2.164198,"taxes":2.101813},"2a3k":{"food":3.570596,"housing":1.776497,"medical":3.380697,"transport":1.877953,"civic":2.838346,"internet":1.379819,"other":2.423008,"taxes":2.811523}},"care":[13341.57,12099.58,7936.27]},"bea":{"L":51837.76,"basket":{"food":0.0878,"housing":0.292,"medical":0.0643,"transport":0.1871,"civic":0.0655,"internet":0.0298,"other":0.0896,"taxes":0.1839},"ratio":{"1a0k":{"food":1.0,"housing":1.0,"medical":1.0,"transport":1.0,"civic":1.0,"internet":1.0,"other":1.0,"taxes":1.0},"1a1k":{"food":1.466869,"housing":1.362664,"medical":2.87653,"transport":1.157296,"civic":1.688058,"internet":1.0,"other":1.818302,"taxes":1.56048},"1a2k":{"food":2.197922,"housing":1.362664,"medical":2.925173,"transport":1.457792,"civic":2.226154,"internet":1.0,"other":1.987654,"taxes":2.292716},"1a3k":{"food":2.925258,"housing":1.779812,"medical":2.978362,"transport":1.677396,"civic":2.535178,"internet":1.0,"other":2.164201,"taxes":3.210037},"2a0k":{"food":1.833277,"housing":1.098208,"medical":2.177526,"transport":1.157296,"civic":1.688058,"internet":1.381231,"other":1.818302,"taxes":1.088714},"2a1k":{"food":2.275228,"housing":1.362664,"medical":3.182172,"transport":1.457792,"civic":2.226154,"internet":1.381231,"other":2.035754,"taxes":1.652747},"2a2k":{"food":2.926579,"housing":1.362664,"medical":3.281151,"transport":1.677396,"civic":2.535178,"internet":1.381231,"other":2.164201,"taxes":2.111923},"2a3k":{"food":3.570608,"housing":1.779812,"medical":3.391953,"transport":1.877951,"civic":2.838361,"internet":1.381231,"other":2.423011,"taxes":2.837382}},"care":[13490.28,12260.11,7975.38]}};

// index.html line 4846
var LW = null;

// index.html line 4847
function lwSet(id){
  if (!id) return null;⟦not run, 4 lines⟧}

// index.html line 4852
function lwReset(sv){
  if (!sv) return;⟦not run, 2 lines⟧}

// index.html line 4901
/* v5.4 item 5 (Oct 7, 2026; dev/reports/v5-21-v54-design.md, 1.6; dev/DECISIONS.md Session 40): A DISASTER. null = off (every earlier run). When an object
 * (v54 row option dis), in year yr (default 6, the model's Year 7) a share of households (share 0.25: design, swept 0.10 and 0.50) is hit, the same
 * households in both runs (one draw per adult on the switch's own stream mulberry32(seed + 600053), the head's draw deciding for the household; a second
 * draw for federal aid). A hit household:
 *  - loses loss dollars of wealth (10,000 in year-0 dollars, moved with the price level: design, swept 5,000 and 25,000; the uninsured part of the damage) and
 *    weeks of pay (4: design, swept 0 and 12; work stops while the area recovers), shared equally among its adults;
 *  - receives the federal Individuals and Households Program's mean award, CFG.DIS_AID ($3,092), with chance CFG.DIS_APPR (50.6%; OpenFEMA, disasters
 *    4400 and later, sources/fema_ihp.py), in both runs;
 *  - with the programme, if taking part: an emergency distribution of emerg (0.20) times the year's BU (the Roadmap's Natural Disaster Response "preload
 *    emergency units" gives no amount; the Recession Protocol's 20% is used, a modelling assumption). Suspended expiry has no effect in the release model,
 *    where BU are allocated and used within the year; Reconstruction Collectives and "enhanced PTF support" have no size in the Hub and are not modelled.
 * Reported (DIS_KEYS): the share of adults hit, and of them the share whose real wealth is back to its level before the disaster within 3 years and by the
 * end, and the mean years it takes those who recover; the same two shares for adults not hit (dsCtl3, dsCtlEnd: real wealth back to its level at the
 * start of the disaster year), so the disaster's own effect is the difference (prices rise much faster with the programme, which slows every adult's return). */
var DIS = null, DIS_DEFAULTS = {yr:6, share:0.25, loss:10000, weeks:4, emerg:0.20}, DSS = null;

// index.html line 4902
CFG.DIS_AID = 3092; CFG.DIS_APPR = 0.506;

// index.html line 4903
var DIS_KEYS = ['dsHit', 'dsRec3', 'dsRecEnd', 'dsRecYrs', 'dsCtl3', 'dsCtlEnd'];

// index.html line 4930
/* v5.4: one entry point for the round's switches, per row (tbStudy's row option v54, an object; absent = every switch as it is). Returns the old values. */
/* ─── Session 2a (Oct 13, 2026): HEALTH COVERAGE MADE EXPLICIT, setting A (today's system) ───────────────────────────────────────────
 * Design and sources: dev/reports/v5-25-health-today.md; choices: dev/DECISIONS.md, Session 2a. HEALTH null (the default) adds nothing: no draw, no
 * state any rule reads (dev/tools/guard_test.js proves it). With HEALTH on, every person (each adult and, with households, each child) has a yearly
 * medical need in year-0 dollars: the CMS spending for the age (adults without an age take the working-age figure), times a lasting chronic state
 * (multiple chronic conditions, MEPS), a spread fitted to MEPS's concentration of spending, and an acute shock. The draws come from a counter-based
 * hash of (seed, person, year, slot), not from any stream the engine uses, so the main stream's eight draws per adult-year and every other stream are
 * untouched, and a person's draws are the same in the programme run and the no-programme run. Coverage each year: Medicare from 65 (only adults who
 * age reach it), Medicaid by the shared income test (incomeTest; expansion and non-expansion limits), employer coverage (more likely at higher pay; lost
 * in a year mostly out of work), the ACA marketplace (premium tax credit by income), or none. Out-of-pocket cost follows each plan's deductible,
 * coinsurance and limit; a household whose bills are high against its income skips part of its non-acute care; bills it cannot pay become medical
 * debt (tracked; the debt is the negative wealth the bills caused). Who pays is recorded (household, employer, government, insurer).
 * Calibration (no constant tuned to a result): the household's expected premiums and out-of-pocket cost are scaled, by household type, so that their
 * average equals the basket's medical line (6.85% of the MIT basket, by household type). Each household then pays the difference between its own bill
 * and its line, in cash, on top of the basket (which still carries the average line, so BU, PTF's sector cut and the price module see what they saw).
 * Turning it on adds spread, not cost. */
var HEALTH = null, HLS = null;

// index.html line 4931
var HEALTH_DEFAULTS = {set:'A', exp:true, skip:0.5, persist:0.9, countBU:false, cs:'central', start:1, adm:0.011, cap:0.5, induce:0.25, gap:0.04, sel:0.11, priv:0.55, gov:'fixed'};

// index.html line 4939
/* Session 2c (Oct 13, 2026; ledger decision d194; dev/DECISIONS.md, Session 2c): GOVERNMENT'S SHARE UNDER SINGLE PAYER, FIXED. Under B and C the government keeps paying
 * what it pays today (Medicaid, the premium tax credits, Medicare), and the health tax pays the rest. HEALTH.gov 'float' (session 2b's behaviour, kept as a
 * sensitivity row) reads that share from the run's own incomes, so when the programme raises incomes and fewer people would qualify for Medicaid, the government
 * pays less and the flat health tax rises for everyone: a change in bookkeeping, not in anyone's care or coverage. HEALTH.gov 'fixed' (the main runs) holds it,
 * year by year, at the no-programme run's level per person, for the same seed, health setting and safety net (HL_GOVREF, filled by tbStudy's no-programme run
 * of the row; a programme run without such a reference falls back to 'float', and hlGovFix reports the share of plan years that were fixed). Medicare's part
 * depends on age and need only, so it is the same in both runs; what the fixing holds is the income-tested part. No draw, no state outside the health block. */
var HL_GOVREF = null;

// index.html line 4956
/* Session 2c (ledger step s141; dev/reports/v5-28-safety-net-grid.md, section 4; dev/DECISIONS.md, Session 2c): THE PREVENTION LINK. PREV null (the default) adds
 * nothing: no draw, no state any rule reads. When an object (row option pv), an adult's chance of entering the lasting chronic state (two or more chronic conditions,
 * the state that raises need; persistence is unchanged) depends on last year's exposure to two things the programme, the safety net and single payer can change:
 *  - care skipped for cost (the person skipped some care last year under today's system; nobody skips in the years under B or C): risk ratio PREV.care;
 *  - food access: the chance that the household was food insecure, read from its income for food last year (money income as in the Medicaid test, plus last
 *    year's safety-net benefits and BU allowance, year-0 dollars) against the poverty guideline, by USDA ERS's 2023 rates (Household Food Security in the United
 *    States in 2023, ERR-337, Table 2: 38.7% under 1.00; 34.1% from 1.00 to 1.30 and 27.6% from 1.30 to 1.85, derived from the table's counts; 7.5% at 1.85 and
 *    over): risk ratio PREV.food, applied as the expected weight 1 + (food - 1) x P(food insecure).
 * The weights multiply. So that the chronic share stays MEPS's 25.9% in today's world, each run divides by the mean weight over adults not in the chronic state in
 * year 0, whose exposures do not depend on the programme (year 0's incomes are the pay rates; no benefit or allowance has been paid yet): the same in both runs.
 * Cases (each labelled in PREV_CASES): zero (the switch off: the Oregon Health Insurance Experiment found no detectable effect of Medicaid on blood pressure,
 * cholesterol or blood sugar control in two years; Baicker et al., NEJM 2013), central (care 1.10, food 1.10: design values, about half of the associations
 * below, because associations in observational data overstate causal effects), high (care 1.51: people who restricted medicines for cost reported a significant
 * decline in health over two to three years 32.1% of the time against 21.2%, Heisler et al., Medical Care 2004, a risk ratio of 1.51, derived; food 1.30: the
 * largest significant adjusted relative risk among food-insecure poor adults in NHANES 1999-2004, for hyperlipidemia; hypertension 1.20, Seligman et al., J Nutr 2010).
 * Diet quality beyond access, and any effect on how long the chronic state lasts, are not modelled (stated limits). */
var PREV = null;

// index.html line 4957
var PREV_CASES = {central:{care:1.10, food:1.10}, high:{care:1.51, food:1.30}};

// index.html line 4958
var PREV_DEFAULTS = PREV_CASES.central;

// index.html line 4959
CFG.PV_FI = [[1.00, 0.387], [1.30, 0.341], [1.85, 0.276], [Infinity, 0.075]];  /* food insecurity by income over the poverty guideline (upper bound, share): USDA ERS, ERR-337, 2023 */

// index.html line 4980
/* Setting C (session 2b, step 2; dev/reports/v5-27-health-financing.md): SINGLE PAYER WITH A PRIVATE LAYER. Everything in setting B holds (one public base for everyone
 * from HEALTH.start, no premiums and no out-of-pocket cost, the same care, cost per unit, waits, administrative jobs, health tax and price rule), plus:
 *  - Medicaid kept: people who would be on Medicaid today (the shared income test, take-up as in setting A) stay on Medicaid, run by states and counties and paid
 *    by government as today. Their care costs what the public base pays per unit (a modelling assumption: keeping Medicaid changes who runs it, not its unit
 *    cost), and they do not take private plans;
 *  - a private layer: the household of anyone else may take a private plan that the public programme pays per person, as Medicare Advantage is paid. Share
 *    HEALTH.priv (0.55: Medicare Advantage's share of beneficiaries with Parts A and B in 2025, MedPAC March 2026; applied at every age, a modelling assumption),
 *    one draw per household head (hash slot 94), lasting. For each enrollee the programme pays the enrollee's public-base cost times (1 + gap) x (1 + sel):
 *      gap  the payment gap from coding: plans record more diagnoses, so risk scores and payments are higher than for the same person in the public base.
 *           MedPAC (March 2026 report; press release Mar 12, 2026): about 4% in 2026 after CMS's coding adjustment (central); 0 (low: risk adjustment removes
 *           it); 8% (high: MedPAC's 2025 estimate, 20% in all less selection's 11%, before the V28 risk model was fully in place);
 *      sel  selection: healthier people choose private plans, so the payment set by risk score exceeds what the enrollees would have cost the public base
 *           (and the public base keeps the costlier people). MedPAC: about 11% in 2026 and in 2025 (central); half and one and a half times (5.5% and 16.5%,
 *           design values) as low and high.
 *    MedPAC's total for 2026 is about 14% ($76 billion); the central case's (1.04 x 1.11 = 15.4%) is close. Enrollees are drawn at random and selection enters as
 *    the payment factor, which gives the same programme cost as a pool of healthier enrollees paid at average rates; who chooses, and why, is not modelled
 *    (a stated limit). The extra payment funds plans' extra benefits and profit (MedPAC: rebates go to lower cost sharing, extra benefits, Part D and Part B
 *    premiums, and administration and profit); here it is counted as programme cost only, not as value to enrollees (a stated limit).
 * The health tax pays the larger plan cost, so the setting's question is how much of setting B's savings the private layer gives back. */
CFG.HL_HOSP = 1634.7;  /* hospital care spending, 2024, $ billion (CMS National Health Expenditure fact sheet): the base for the preprint's avoided emergency and inpatient care (CFG.HL_B.avoided) */

// index.html line 5003
/* Setting B (session 2a, step 5): SINGLE PAYER, PUBLIC PLAN ONLY (as in the Medicare for All Act). From year HEALTH.start (1; year 0 is today's system, which sets
 * the calibration and the first incomes) everyone is covered by one public plan with no premiums and no out-of-pocket cost, paid for by a flat health tax on money
 * income. Today's system keeps running in the background as the counterfactual (who would have been covered how, and what each payer would have paid), so the
 * comparison is like for like, person by person, every year:
 *  - care: everyone's full need (nothing skipped for cost), plus HEALTH.induce (25%) more for people who would have been uninsured (the Oregon Health Insurance
 *    Experiment: Medicaid coverage raised spending about 25%; Finkelstein et al., QJE 2012);
 *  - cost per unit of care: today's (all payers, after the calibration) times the case's factor, from the Yale preprint (Galvani, Pandey, Wells and Ye, medRxiv
 *    2026, doi 10.64898/2026.07.22.26358689; not peer reviewed): 2024 spending $5,278.6 billion; gross savings $1,345.2 billion (drug prices 377.5, Medicare rates
 *    for providers 295.6, administration 286.3, fraud 285.7, avoided emergency and inpatient care 100.0); added $304.0 billion (induced use 197.7, dental 54.7,
 *    care now unpaid 51.7); net 19.7%. Per unit: central 1 - 1345.2/5278.6; cautious (net savings of at least $663.3 billion, 12.6%: the preprint's lower bound
 *    with the drug and fraud savings cut) 1 - (663.3 + 304.0)/5278.6; costs run higher (providers paid near commercial rates, so the savings vanish)
 *    1 - 304.0/5278.6, so that with the added care the total is about today's. Dental and the payment for care now unpaid (54.7 + 51.7 = 2.0% of spending) are
 *    added as a share of today's spending; the model's own added care (skipped care, induced use) replaces the preprint's induced use;
 *  - financing: the government keeps paying what it pays today (Medicaid, Medicare, tax credits: financed as now, inside the basket's taxes); the rest of the
 *    public plan's cost is a new flat tax on households' money income (the same base as the Medicaid test). The employer's former premium share comes back to
 *    the household as a cost offset (it was counted as pay forgone; d-health-price rule b: health money enters costs, never total cash income);
 *  - access: today's care delivered is the system's capacity; capacity grows to meet the share HEALTH.cap (0.5, a design parameter swept 0.25-1) of the extra
 *    demand; demand beyond capacity waits (the share of needed care delayed), and the capped budget pays for the care delivered;
 *  - administrative jobs: at the start, the share HEALTH.adm (1.1%) of working adults lose their jobs (about 1.8 million insurance and billing jobs, Pollin et
 *    al., PERI 2018, as reported by secondary summaries: the report itself was not read; over about 160 million employed) and enter the job-loss path: a spell
 *    of the usual length, unemployment insurance as for anyone, and the pay cut on return that a permanent loss carries. Only with the job-loss part on;
 *  - prices: no market price response for medical care (d-health-price rule a): the public payer sets rates; a shortage shows as waits. */
CFG.HL_B = {base:5278.6, gross:{central:1345.2, cautious:663.3 + 304.0, high:304.0}, added:304.0, extra:54.7 + 51.7, avoided:100.0};

// index.html line 5004
CFG.HL_AGE = [[17, 4217], [44, 6669], [64, 12577], [84, 20503], [999, 35995]];  /* personal health care per person by age (upper age, $), 2020: CMS National Health Expenditure, Age and Sex tables (0-18, 19-44, 45-64, 65-84, 85+; the model's adults start at 18) */

// index.html line 5005
CFG.HL_AGE_NONE = 9154;  /* CMS 2020, working-age adults (19-64): for adults the model gives no age (no ageing) */

// index.html line 5006
CFG.HL_LEVEL = 15474/12530;  /* to year-0 dollars: national health spending per person, 2024 ($15,474, CMS NHE fact sheet) over 2020 ($12,530) */

// index.html line 5007
CFG.HL_MCC = {prev:0.259, share:0.57};  /* adults treated for two or more chronic conditions: 25.9% of adults, 57.0% of spending (MEPS 2012; AHRQ Statistical Brief 485) */

// index.html line 5008
CFG.HL_ACUTE = {p:0.08, share:0.30};  /* an acute event (a hospital stay) in a year and its share of mean spending: design parameters (swept), not sourced */

// index.html line 5009
CFG.HL_SIGMA = {base:1.5, acute:0.6};  /* log spreads, fitted to MEPS 2017's concentration (top 1% 21.9%, top 5% 50.1%, bottom half 2.9% of spending; Statistical Brief 528): the fit gives 22.2 / 50.4 / 3.5 */

// index.html line 5010
CFG.HL_FPL = {one:15650, add:5500};  /* HHS poverty guidelines 2025, 48 states: one person, each added person */

// index.html line 5011
CFG.HL_MCAID = {exp:1.38, parentNx:0.405, adultNx:0, kids:2.55, take:0.80, takeKids:0.90};  /* income limits, share of the poverty guideline (KFF state indicators, Jan 2026): expansion states 138%; non-expansion parents, the median of the ten states' limits (15-105%); non-expansion adults without children 0; children (Medicaid and CHIP) 255%. Take-up among the eligible: design parameters */

// index.html line 5012
CFG.HL_ESI = {premS:9325, wkS:1440, premF:26993, wkF:6850, ded:1886, coins:0.20, oopMax:9200, offer:[0.20, 0.80]};  /* KFF Employer Health Benefits Survey 2025: premiums and the worker's share (single, family), single deductible; coinsurance 20% (design); the ACA's 2025 out-of-pocket limit; offer-and-take-up rising from 20% at the lowest pay to 80% at the highest, set so about 63% of the model's adult-years have employer coverage (Census 2024, ages 19-64: private coverage 74.0%, of which about 11 points direct purchase) */

// index.html line 5013
CFG.HL_MKT = {prem:5964, kid:0.5, ded:2759, coins:0.20, oopMax:9200, oopCSR:3050, take:0.60};  /* KFF: benchmark silver premium for a 40-year-old, 2025 ($497 a month); a child's at half (design); average marketplace deductible 2025; cost-sharing reductions cap out-of-pocket cost at $3,050 under 200% of poverty (2025); take-up among those not otherwise covered, set so about 11-13% of the model's adult-years are uninsured (Census 2024: 11% at 19-64; the model has too few adults on Medicaid, see the report) */

// index.html line 5014
CFG.HL_MCARE = {partB:2220, ded:257, coins:0.20, oopMax:9350};  /* Medicare 2025: Part B premium ($185 a month) and deductible, 20% coinsurance, capped at the Medicare Advantage in-network limit (a stand-in for supplemental cover) */

// index.html line 5015
CFG.HL_UNDER = {oop:0.10, oopLow:0.05, lowFpl:2.0, ded:0.05};  /* Commonwealth Fund: insured all year with out-of-pocket cost (not premiums) of 10% of income or more, 5% under 200% of poverty, or a deductible of 5% of income or more */

// index.html line 5016
CFG.HL_DEBT_LINE = 250;  /* medical debt counted above $250 (KFF analysis of SIPP 2021: about 1 in 12 adults) */

// index.html line 5017
var HL_KEYS = ['hlEsi', 'hlMkt', 'hlMcaid', 'hlMcare', 'hlUnins', 'hlUnder', 'hlSkip', 'hlSkipD', 'hlNeed', 'hlOop', 'hlPrem', 'hlEmp', 'hlGov', 'hlIns', 'hlPaid', 'hlLine', 'hlDev', 'hlDebt', 'hlDebtM', 'hlKap', 'hlKidMcaid', 'hlKidUnins', 'hlMcaidLost', 'hlTax', 'hlRate', 'hlWait', 'hlSA', 'hlSB', 'hlAdded', 'hlAdm', 'hlBack', 'hlCliff', 'hlCliffD', 'hlCliffN', 'hlPriv', 'hlXtra', 'hlPtfP', 'hlGovB', 'hlGovFix', 'hlChron', 'hlPvX'];

// index.html line 5033
/* hlEsi..hlUnins: % of adult-years by coverage; hlUnder: % of insured adult-years underinsured; hlSkip: % of adult-years skipping some care for cost; hlSkipD: care skipped,
 * $ per adult-year; hlNeed: medical need (care used plus skipped) per person-year; hlOop, hlPrem: what households pay out of pocket and in premiums, per adult-year;
 * hlEmp: employers' premium share (pay forgone) per adult-year; hlGov: government (Medicaid, Medicare, premium tax credits) per adult-year; hlIns: insurers' claims per
 * adult-year; hlPaid and hlLine: the household's bill after calibration and its basket line, per adult-year; hlDev: the mean absolute gap between them; hlDebt: % of
 * adult-years with medical debt over $250; hlDebtM: mean medical debt per adult-year; hlKap: the calibration factor; hlKidMcaid, hlKidUnins: % of child-years;
 * hlMcaidLost: % of adult-years that had Medicaid the year before and lost it to income. Setting B: hlTax, the health tax per adult-year; hlRate, its rate (% of
 * money income, mean over the years under B); hlWait, % of needed care delayed; hlSA and hlSB, today's system's spending and the public plan's, per person-year
 * (the years under B; all payers, after the calibration); hlAdded, the added care (% of today's care delivered); hlAdm, % of adults laid off from administrative
 * jobs; hlBack, the employer share returned per adult-year. In the years under B the coverage keys read the counterfactual (today's system). Dollars: year-0.
 * Session 2b: hlCliff, the benefit cliff at the adult Medicaid limit (hlJump): the mean jump in a household's expected health bill when its tested income crosses the
 * limit, over households within a quarter of the guideline of it, in points of the household's basket medical line (every year under today's system; in the years
 * under B and C it is 0, because the bill does not depend on Medicaid, so their figure is year 0's share); hlCliffD, the same in dollars per household; hlCliffN, the share of household-years (%) near the limit; hlPriv, % of person-years in private plans (setting C); hlXtra, the programme's payments to private plans above the
 * enrollees' public-base cost, per person-year; hlPtfP, PTF's health-sector cut to the plan's costs (B and C, with PTF's rate for health care above 0), per person-year.
 * Session 2c: hlChron, % of adult-years in the chronic state; hlPvX, the prevention link's mean exposure weight over adult-years (0 with PREV off); hlGovB, government's share of the public plan's cost (Medicaid, Medicare, the tax credits) per adult-year in the years under B or C, as the health tax
 * nets it; hlGovFix, % of those years in which it was held at the no-programme run's level (100 in a programme run with HEALTH.gov 'fixed', 0 otherwise). */
function hlU(s, id, yr, j){  /* a uniform draw from the hash of (seed, person, year, slot): murmur3's finaliser over the mixed integers */
  var h = Math.imul(s ^ 0x5bd1e995, 0x85ebca6b) ^ Math.imul((id | 0) + 0x632be5ab, 0xc2b2ae35) ^ Math.imul((yr | 0) + 0x7f4a7c15, 0x27d4eb2f) ^ Math.imul((j | 0) + 0x165667b1, 0x9e3779b1);
  h ^= h >>> 16; h = Math.imul(h, 0x85ebca6b); h ^= h >>> 13; h = Math.imul(h, 0xc2b2ae35); h ^= h >>> 16; return ((h >>> 0) + 0.5)/4294967296; }

// index.html line 5043
/* The shared income test (session 2a; reused by the today's-safety-net row and session 2b's benefit-cliff check): a household's money income against the
 * poverty guideline for its size. income in year-0 dollars; returns {n: people, line: the guideline, ratio: income over the guideline}. */
function incomeTest(nAdults, nKids, income){ var n = Math.max(1, nAdults + nKids), line = CFG.HL_FPL.one + CFG.HL_FPL.add*(n - 1); return {n:n, line:line, ratio:income/line}; }

// index.html line 5068
function hlUnits(agents, HHON){ return HHON ? HHS.list.filter(function(H){ return H.a.length > 0; }).map(function(H){ return {a:H.a, kids:H.kids, H:H}; }) ⟦not run⟧; }

// index.html line 5242
/* ─── Session 2b (Oct 13, 2026; dev/reports/v5-27-health-financing.md, part 1; dev/DECISIONS.md, Session 2b): TODAY'S SAFETY NET, a comparison row ─────
 * SNET null (the default) adds nothing: no draw, no state any rule reads. When an object (row option sn), each household receives, from year 0, SNAP, the
 * earned income tax credit (EITC) and the refundable part of the Child Tax Credit (CTC). Each is set on last year's money income in year-0 dollars (the
 * tax credits are paid on the year before's return; SNAP's monthly test is read on last year's income as well, a modelling simplification) and paid at this
 * year's price level (the statutes index them to prices). Income: pay, Social Security, unemployment insurance, the UBI comparator and conversion income;
 * year 0 reads the pay rate, as the health block does. The BU allowance is not income here (like SNAP itself, an allowance for essentials).
 *  - SNAP (USDA FNS, FY2026 maximum allotments and deductions, 48 states and DC): maximum allotment by household size; net income = gross income - 20% of
 *    earnings - the standard deduction - dependent care (the household's childcare line) - excess shelter (the housing line, MIT's HUD rent with utilities,
 *    over half of income after the other deductions; capped at $744 a month unless an adult is 60 or older); benefit = allotment - 30% of net income, at
 *    least $24 for one or two people. Gross income limit 200% of the poverty guideline (broad-based categorical eligibility, used by most states, which
 *    waives the net income and asset tests; the federal 130% is swept: gross 1.3). Take-up 88% of eligible people (USDA FNS, national SNAP participation
 *    rates, FY2022). The work rule for adults without dependants (three months in three years) is SNET.abawd, off by default (session 7, below); with it
 *    off it is not modelled (a stated limit: it overstates SNAP for adults without children who are out of work long).
 *  - SNAP's work rule (session 7, Oct 14, 2026; ledger s166, d209; sources/snap_work_rule.md; dev/reports/v5-33-snap-work-rule.md). SNET.abawd false (the
 *    default) adds nothing: no state is stored and no rule reads one. When true, 7 U.S.C. 2015(o) as amended by P.L. 119-21 sec. 10102: an adult aged 18
 *    to 64 (USDA's reading of the law's "over 65"; adults without an age count as subject) in a household with no child under 14 gets SNAP for at most 3
 *    months in 36 in which they do not work 20 hours a week averaged monthly. In a yearly model: the months that count are the weeks out of work that are
 *    not on unemployment insurance (UI claimants are exempt under section 6(d)(2)(A)), or every week without UI when the adult's hours at work are under
 *    half of full time (the model's pay is for a full-time job, 2,080 hours, the hours MIT's living wage assumes; the labor response scales hours).
 *    Retirees are treated as exempt (a modelling assumption, the cautious reading: the rule's bite is not overstated). The status is last year's, as
 *    SNAP's income is. Each adult's clock holds the countable months credited in each of the last two years; this year at most 3 minus those, and only
 *    while the household receives SNAP; months beyond that are lost. In a lost month the adult is not a household member for SNAP (size one smaller, all
 *    income still counted, 7 CFR 273.11(c)); the yearly benefit falls by (lost months / 12) x the difference, summed over the adults, times 1 - abawdEx
 *    (the 8% of covered people a State may exempt each year, sec. 6(o)(6)(F), applied as an expected share: no draw). Not modelled: area waivers (now
 *    only where unemployment is over 10%, which the model's economy does not reach), the medical, pregnancy, student, treatment and caregiver
 *    exemptions (the model has no such states), and regaining eligibility by 80 hours in 30 days (a year with enough work counts no months anyway).
 *    No draw on any stream.
 *  - EITC (IRS Rev. Proc. 2024-40, sec. 3.06, tax year 2025): by qualifying children (the model's children are all under 19), the credit phases in up to
 *    the earned income amount, stays at the maximum, then phases out on the larger of earnings and income; couples file jointly (a modelling assumption:
 *    the model's couples are treated as married), single parents as heads of household; adults without children qualify at 25-64 (adults without an age
 *    count as working age). Take-up 80.8% (IRS, EITC participation rate, tax year 2022).
 *  - CTC (P.L. 119-21, sec. 70101: $2,200 per child under 17 from 2025; IRC sec. 24(d): refundable at 15% of earnings above $2,500; Rev. Proc. 2024-40,
 *    sec. 3.05: refundable part at most $1,700 per child): only the refundable part is paid, the smaller of $1,700 per child, 15% of earnings above
 *    $2,500, and the credit left after income tax before credits (2025 brackets, Rev. Proc. 2024-40 sec. 3.01; standard deductions $15,750 / $31,500 /
 *    $23,625, P.L. 119-21). The part that offsets income tax is not added: the basket's tax line is MIT's tax after credits at the living wage
 *    (PolicyEngine), so adding it would count it twice. Claimed on the same return as the EITC (the same take-up draw).
 * Financing: nothing new. These programmes are paid for by taxes the basket already charges every household (its income and payroll tax line), so they
 * are not new money in the price module, not programme cost and not in the testbed's contribution. They count as income in basket poverty, FGT and the
 * household's income-graded spending, not in the official poverty measure (money income before taxes, which leaves out SNAP and tax credits) and not in
 * the Medicaid test (federal rules disregard SNAP and tax refunds).
 * Work (guardrail 7): with the labour response on, the household's combined marginal rate m (the benefits lost per $1,000 more earnings, at last year's
 * position; negative where the EITC phases in) scales earnings by (1 - m)^(eps - rho), the one elasticity for every change in the return to work, and the
 * benefits enter as unconditional dollars linearised at last year's earnings (the adult's share of the benefits + m x the adult's earnings), the one income
 * effect. Draws: take-up is a hash of (seed, household head, slot) with the health block's hash on its own seed offset; no stream the engine uses. */
var SNET = null, SNS = null;

// index.html line 5243
var SNET_DEFAULTS = {gross:2.0, snapTake:0.88, taxTake:0.808, snap:true, eitc:true, ctc:true, abawd:false, abawdEx:0.08, slope:false};  /* abawd, abawdEx: session 7, SNAP's work rule (below); slope: session 9, the marginal rate without SNAP's income-limit cliff (below) */

// index.html line 5244
CFG.SN_SNAP = {max:[298, 546, 785, 994, 1183, 1421, 1571, 1789], add:218, std:[209, 209, 209, 223, 261, 299], shCap:744, min:24, earnDed:0.20, rate:0.30, old:60};

// index.html line 5245
CFG.SN_EITC = [{inc:8490, max:649, ps:10620, pj:17730, es:19104, ej:26214}, {inc:12730, max:4328, ps:23350, pj:30470, es:50434, ej:57554},
  {inc:17880, max:7152, ps:23350, pj:30470, es:57310, ej:64430}, {inc:17880, max:8046, ps:23350, pj:30470, es:61555, ej:68675}];  /* none, one, two, three or more children */

// index.html line 5247
CFG.SN_CTC = {per:2200, ref:1700, thr:2500, rate:0.15, age:17, po:{s:200000, h:200000, j:400000}, poR:0.05};

// index.html line 5248
CFG.SN_TAX = {std:{s:15750, j:31500, h:23625}, br:{s:[[11925, 0.10], [48475, 0.12], [103350, 0.22], [197300, 0.24], [Infinity, 0.32]],
  j:[[23850, 0.10], [96950, 0.12], [206700, 0.22], [394600, 0.24], [Infinity, 0.32]], h:[[17000, 0.10], [64850, 0.12], [103350, 0.22], [197300, 0.24], [Infinity, 0.32]]}};

// index.html line 5250
var SN_KEYS = ['snSnap', 'snEitc', 'snCtc', 'snSnapM', 'snEitcM', 'snCtcM', 'snAll', 'snMtr', 'snKids'];

// index.html line 5251
var SN_AB_KEYS = ['snAbN', 'snAbM', 'snAbLost'];  /* session 7, only with SNET.abawd: % of adult-years losing SNAP months to the work rule; SNAP dollars cut and months lost per adult-year */

// index.html line 5254
/* snSnap, snEitc, snCtc: % of adult-years in households receiving each; snSnapM, snEitcM, snCtcM, snAll: dollars per adult-year (year-0); snMtr: the mean combined
 * marginal rate (%) over adult-years in receiving households; snKids: % of child-years in households receiving any of the three. */
function snIncTax(f, agi){ var T = CFG.SN_TAX, x = Math.max(0, agi - T.std[f]), lo = 0, t = 0;  /* income tax before credits, filing status f ('s', 'h', 'j') */
  T.br[f].some(function(b){ t += Math.max(0, Math.min(x, b[0]) - lo)*b[1]; lo = b[0]; return x <= b[0]; }); return t; }

// index.html line 5256
function snBen(h, earn, keep){  /* one household's yearly benefits in year-0 dollars at earnings earn: [snap, eitc, ctc]. h: {nA, nK, k17, other, house, care, old, okAge, takeS, takeT}; keep (session 9, SNET.slope): SNAP's gross income test is passed */
  var E = SNET, Y = Math.max(0, earn + h.other), T = incomeTest(h.nA, h.nK, Y), n = T.n, f = h.nA >= 2 ? 'j' : h.nK > 0 ? 'h' : 's', snap = 0, eitc = 0, ctc = 0;
  if (E.snap && h.takeS && (keep || T.ratio <= E.gross)){ var S = CFG.SN_SNAP, ni = Math.max(0, Y - S.earnDed*earn - 12*S.std[Math.min(n, S.std.length) - 1] - h.care), sh = Math.max(0, h.house - 0.5*ni);
    if (!h.old) sh = Math.min(sh, 12*S.shCap); ni = Math.max(0, ni - sh);
    var mx = 12*(n <= S.max.length ? S.max[n - 1] ⟦not run⟧); snap = Math.max(0, mx - S.rate*ni); if (n <= 2) snap = Math.max(snap, 12*S.min); }
  if (E.eitc && h.takeT && (h.nK > 0 || h.okAge)){ var P = CFG.SN_EITC[Math.min(3, h.nK)], st = f === 'j' ? P.pj : P.ps, en = f === 'j' ? P.ej : P.es;
    eitc = Math.max(0, Math.min(P.max, P.max/P.inc*Math.max(0, earn)) - P.max/(en - st)*Math.max(0, Math.max(earn, Y) - st)); }
  if (E.ctc && h.takeT && h.k17 > 0){ var C = CFG.SN_CTC, cr = Math.max(0, C.per*h.k17 - C.poR*Math.max(0, Y - C.po[f]));
    ctc = Math.max(0, Math.min(C.ref*h.k17, C.rate*Math.max(0, earn - C.thr), cr - snIncTax(f, Y))); }
  return [snap, eitc, ctc]; }

// index.html line 5266
function snAbClock(a, subject, gets){  /* session 7: one adult's work-rule clock for this year; returns the months of SNAP lost (a._snAbC: last year's countable months) */
  var pr = a._snAb || [0, 0], c = a._snAbC || 0, cr = subject && gets ? Math.min(c, Math.max(0, 3 - pr[0] - pr[1])) : 0; a._snAb = [cr, pr[0]]; return subject && gets ? c - cr : 0; }

// index.html line 5268
function snAbCut(h, earn, snap, lost){  /* session 7: the household's yearly SNAP cut for its adults' lost months (each lost month: one member fewer, all income counted) */
  if (!lost.length || snap <= 0) return 0; var h1 = Object.assign({}, h, {nA:h.nA - 1}), w = h1.nA + h1.nK > 0 ? snBen(h1, earn)[0] : 0, f = 0;
  lost.forEach(function(l){ f += l/12; }); return Math.min(snap, f*(1 - SNET.abawdEx)*Math.max(0, snap - w)); }

// index.html line 5271
function snInit(agents, seed){ SNS = {seed:(seed | 0) + 700001, idxPrev:1, acc:{ay:0, ky:0, kN:0, snapN:0, eitcN:0, ctcN:0, snap:0, eitc:0, ctc:0, mN:0, m:0, abN:0, abM:0, abL:0}}; agents.forEach(function(a, j){ a._snId = j; a._snB = 0; a._snM = 0; }); }

// index.html line 5272
function snYear(agents, yr, HHON, inflRate){
  var S = SNS, ac = S.acc, gIdx = Math.pow(1 + inflRate, yr)*(PRICE ? PRICE.bIdx ⟦not run⟧), next = 0;
  agents.forEach(function(a){ if (a._snId === undefined) ⟦not run⟧ });  /* adults who arrive with ageing */
  hlUnits(agents, HHON).forEach(function(u){
    var nA = u.a.length, nK = u.kids.length, earn = 0, other = 0, old = false, okAge = false, k17 = 0, hd = u.a[0]._snId;
    u.a.forEach(function(a){ if (yr === 0 || a.yrWageUSD === undefined) earn += a._ret ⟦not run⟧ : a.wage*12*CFG.WAGE_TO_USD; else { earn += (a.yrWageUSD || 0)/S.idxPrev; other += ((a.yrSSUSD || 0) + (a.yrUbiUSD || 0) + (a.yrConvUSD || 0))/S.idxPrev; }
      if (yr === 0 && a._ret) ⟦not run⟧
      if (typeof a.age === 'number')⟦not run⟧ else okAge = true; });
    u.kids.forEach(function(age){ if (age < CFG.SN_CTC.age) k17++; });
    var h = {nA:nA, nK:nK, k17:k17, other:other, house:u.H ? u.H.need.housing ⟦not run⟧, care:u.H ? (u.H.need.childcare || 0) ⟦not run⟧, old:old, okAge:okAge,
      takeS:hlU(S.seed, hd, 0, 31) < SNET.snapTake, takeT:hlU(S.seed, hd, 0, 32) < SNET.taxTake};
    var b0 = snBen(h, earn), b1 = snBen(h, earn + 1000, SNET.slope && b0[0] > 0);  /* session 9: with SNET.slope a household receiving SNAP keeps passing the gross test at +$1,000 (comment above) */
    if (SNET.abawd){ var abK = u.kids.some(function(age){ return age < 14; }), abL = [];  /* session 7: SNAP's work rule (comment above) */
      u.a.forEach(function(a){ var l = snAbClock(a, !abK && !a._ret && (typeof a.age !== 'number' ⟦not run⟧), b0[0] > 0); if (l > 0){ abL.push(l); ac.abN++; ac.abL += l; } });
      var abCut = snAbCut(h, earn, b0[0], abL); b0[0] -= abCut; b1[0] -= snAbCut(h, earn + 1000, b1[0], abL); ac.abM += abCut; }
    var B = b0[0] + b0[1] + b0[2], m = Math.max(-0.5, Math.min(0.9, (B - (b1[0] + b1[1] + b1[2]))/1000));
    u.a.forEach(function(a){ a._snB = B*gIdx/nA; a._snM = B > 0 || m !== 0 ? m : 0; });
    ac.ay += nA; ac.ky += nK; if (B > 0) ac.kN += nK; if (b0[0] > 0) ac.snapN += nA; if (b0[1] > 0) ac.eitcN += nA; if (b0[2] > 0) ac.ctcN += nA;
    ac.snap += b0[0]; ac.eitc += b0[1]; ac.ctc += b0[2]; if (B > 0){ ac.mN += nA; ac.m += m*nA; } });
  S.idxPrev = gIdx; }

// index.html line 5292
function snRes(out){ var A = SNS ? SNS.acc ⟦not run⟧, ay = A && A.ay ? A.ay ⟦not run⟧, pc = function(x){ return A ? x/ay*100 ⟦not run⟧; };
  out.snSnap = pc(A ? A.snapN ⟦not run⟧); out.snEitc = pc(A ? A.eitcN ⟦not run⟧); out.snCtc = pc(A ? A.ctcN ⟦not run⟧); out.snSnapM = A ? A.snap/ay ⟦not run⟧; out.snEitcM = A ? A.eitc/ay ⟦not run⟧; out.snCtcM = A ? A.ctc/ay ⟦not run⟧;
  out.snAll = out.snSnapM + out.snEitcM + out.snCtcM; out.snMtr = A && A.mN ? A.m/A.mN*100 ⟦not run⟧; out.snKids = A && A.ky ? A.kN/A.ky*100 ⟦not run⟧;
  if (SNET && SNET.abawd){ out.snAbN = pc(A ? A.abN ⟦not run⟧); out.snAbM = A ? A.abM/ay ⟦not run⟧; out.snAbLost = A ? A.abL/ay ⟦not run⟧; } return out; }

// index.html line 5296
function tbSetV54(o){ var old = {rk:RISK_MEASURE, em:EMPL, pb:PTHB, pf:PTFS, ds:DIS}; if (o){ if (o.rk !== undefined) RISK_MEASURE = !!o.rk; if (o.empl) EMPL = Object.assign({}, EMPL_DEFAULTS, o.empl === true ⟦not run⟧ : o.empl);
  if (o.pthb) PTHB = Object.assign({}, PTHB_DEFAULTS, o.pthb === true ⟦not run⟧ : o.pthb); if (o.ptfs) PTFS = Object.assign({}, PTFS_DEFAULTS, o.ptfs === true ⟦not run⟧ : o.ptfs);
  if (o.dis) ⟦not run⟧ } return old; }

// index.html line 5299
function tbResetV54(old){ RISK_MEASURE = old.rk; EMPL = old.em; EMS = null; PTHB = old.pb; PBS = null; PTFS = old.pf; PFS = null; DIS = old.ds; DSS = null; }

// index.html line 5300
function tbRepRes(R, out){
  function pc(k){ return R && R.n ? R[k]/R.n*100 ⟦not run⟧; }
  out.fplPY = pc('fpl'); out.fplXPY = pc('fplX'); out.fplNomPY = pc('fplNom'); out.bOAPyNom = pc('bONom'); out.bNAPyNom = pc('bNNom');
  TB_REP_SNAP.forEach(function(k){ var K = k.charAt(0).toUpperCase() + k.slice(1); out['y7' + K] = R && R.y7 ? R.y7[k] ⟦not run⟧; out['e' + K] = R && R.end ? R.end[k] ⟦not run⟧; out['y0' + K] = R && R.y0 ? R.y0[k] ⟦not run⟧; });
  TB_PATH_M.forEach(function(m){ for (var t = 0; t < TB_PATH_N; t++){ var v = R && R.path[m][t]; out['p' + m + '_' + t] = typeof v === 'number' ? v : 0; } });  /* v5.2 step 8 */
  if (R && RISK_MEASURE) tbRiskRes(R.hist, out);  /* v5.4 item 1 */
  if (R){ tbRepSpells(R.hist, 'f', out, 'sf'); tbRepSpells(R.hist, 'c', out, 'sc'); out.everFpl = R.hist.length ? R.hist.filter(function(h){ return h.f.some(function(v){ return v; }); }).length/R.hist.length*100 ⟦not run⟧; }⟦not run, 2 lines⟧
  return out;
}

// index.html line 5310
function tbAccount(a, y, yr, mlc, cf, cfPreCCO, costUSD, E, tbG, tbPT){
  var C = TB.cur, idx = mlc/CFG.LIVING_WAGE_ANNUAL/(a._hhF || 1), conv = +a.yrConvUSD || 0;  /* v5.3 B3: a household member's basket is its share of the household's; the index is the price level */
  TB.xIdx = idx;  /* d26: the contribution threshold X is in year-0 dollars, indexed to the basket with a one-year lag */
  C.n++; C.idx = idx; C.E += E; C.cash += a.yrTbCash; if (SNET && SNS && a._snB) C.cash -= a._snB; C.tax += a.yrTax;  /* session 2b: the safety net is paid by the basket's taxes, not programme cost */ if (y.tb === 'prog')⟦not run⟧ C.base += y.tb === 'prog' ⟦not run⟧ : y.tb === 'land' ⟦not run⟧ : Math.max(0, E - y.X);  /* v5.2 step 7 */
  if (yr === 0 && a._tbEl) ⟦not run⟧
  var spCut = a._spCutY || 0, buR = Math.max(0, mlc*(cfPreCCO - cf) - tbG - spCut);  /* plan step 1 (d105): the split's price cut is conversion premium, not BU relief */
  if (a._csFree){ C.cutFree += a._csFree; a._csFree = 0; }  /* plan step 5 */
  C.bu += buR; C.conv += conv + spCut; if (a._pdM){ C.convM += a._pdM; a._pdM = 0; }  /* plan step 2: matched project output */ C.pjg += a.yrPjGift || 0; a.yrPjGift = 0; C.cutPT += tbPT; C.cutG += tbG; C.pthLiq += a._tbPthNow || 0;
  /* Session 7 (A5 targeting share): program dollars this agent received this year (cash, the endowment's annuity value, BU relief,
   * conversion, price-cut dollars, PTH liquid appreciation; not capital), and the part that closes the agent's shortfall before
   * transfers: the gross basket less wage earnings. Reporting only. */
  var pd = a.yrTbCash + (a._tbEl ⟦not run⟧ : 0) + buR + conv + spCut + tbPT + tbG + (a._tbPthNow || 0);
  if (SNET && SNS && a._snB) pd -= a._snB;  /* session 2b */
  C.pd += pd; C.tgt += Math.min(pd, Math.max(0, mlc - E - (a.yrSSUSD || 0)));
  if (y.gcap ⟦not run⟧) ⟦not run⟧
  var inc = E + conv + (a.yrUbiUSD || 0) + (a.yrSSUSD || 0) + a.yrTbCash - a.yrTax + (a._tbEl ⟦not run⟧ : 0);  /* v5.2 step 4: + the Social Security benefit (0 without ageing) */
  var disp = E + conv + (a.yrUbiUSD || 0) + (a.yrSSUSD || 0) + a.yrTbCash - a.yrTax;
  if (EDCS) a._edcY = E + conv + (a.yrUbiUSD || 0) + (a.yrSSUSD || 0) + a.yrTbCash + (a._edcBU || 0);  /* v5.3 B6: gross income for the measured EDC (before the contribution; BU at face) */
  /* Session 8 (A5; dashboard s18). Reporting only, no RNG. Spells: a spell starts in any year the agent is below the basket after
   * being above it (or in year 0); spells are censored at the 20-year window. Hours: this year's earnings over the same agent's
   * earnings with no labor response (a._lbE0, set in runYear's LABOR block), which is hours at a fixed wage; 1 with LABOR off.
   * Disposable income, OECD definition (the Hub's C30): wage earnings + conversion proceeds + cash transfers - the contribution;
   * no in-kind benefits, no capital transfer (the endowment), no capital gains (PTH appreciation). Extended income adds the in-kind
   * cuts to the agent's basket (BU relief and PTF, PTH and grocery price cuts). */
  if (a._hh){ a._hhInc = inc; a._hhDisp = disp; a._hhMlc = mlc; a._hhCost = costUSD; a._hhIdx = idx; }  /* v5.3 B3: kept for the household's measures (hhRepYear) and a pooled couple's status */
  if (!a._hhPool) tbPov(a, C, idx, inc, mlc, costUSD, disp);  /* v5.3 B3: a pooled couple's status is set at the end of the year (hhPool) */
  C.emp += E > 0 ? 1 : 0; C.hrs += a._lbE0 > 0 ? (a._pjHW ? E + a._pjHW : E)/a._lbE0 : 1;  /* N1 (session 15): + project hours at the worker's own wage */
  C.bR += a._bleiR || 0; C.bP += a._bleiP || 0;  /* session 9 (i3-2): BLEI raises, and those the program's support carried over the gate */
  /* Session 19 (s38): the framework model's business premium as received, the ESP's own payout and ESP payroll, by group, over the years it
   * is paid (1 to 19; year 0 pays none). Reporting only, no RNG; zero in the engine model. */
  if (yr > 0){ var bzY = a._fwPayY || 0, esY = a._esPrY || 0; C.n1++; C.bz += bzY; C.es += esY;
    if (a.inCCO){ C.nP1++; C.pyP += bzY + esY; if (a._esWk){ C.nWP1++; C.esWP += esY; } } else { C.nN1++; C.pyN += bzY; } }
  a._tbPthPrev = a._tbPthNow || 0; a._tbPthNow = 0;
}

// index.html line 5346
/* The poverty part of tbAccount: this year's shortfall against the adult's own cost (FGT), resources, spells, disposable and extended income. v5.3 B3: split out
 * so a pooled couple's members get the household's status (hhPool calls it with the household's totals per adult); unchanged for everyone else. */
function tbPov(a, C, idx, inc, mlc, costUSD, disp){
  var g = Math.max(0, costUSD - inc)/mlc;
  C.f0 += g > 0 ? 1 : 0; C.f1 += g; C.f2 += g*g;
  a._tbGap = g; a._tbF0 = (a._tbF0 || 0) + (g > 0 ? 1 : 0); a._tbF2 = (a._tbF2 || 0) + g*g;  /* session 21 (s41): FGT2 by group */
  a._tbRes = (a._tbRes || 0) + (inc + mlc - costUSD)/idx; a._tbYrs = (a._tbYrs || 0) + 1;
  if (g > 0){ if (!a._tbInSp) a._tbSp = (a._tbSp || 0) + 1; a._tbInSp = true; } else a._tbInSp = false;
  a._tbDisp = disp; a._tbExt = a._tbDisp + Math.max(0, mlc - costUSD);
}

// index.html line 5354
function runYear(agentSet,yr,p,recSt){
  var totalBU=0,totalConversion=0;recSt=recSt⟦not run⟧;
  if(AGE⟦not run⟧)⟦not run⟧  // v5.2 step 4: deaths, new adults, a year older (own random stream)
  if(ACCT)⟦not run⟧  // v5.3 B2: the accounting check (off by default; no RNG, nothing any rule reads)
  var HHON=!!HOUSEHOLDS&&!!HHS&&(CONVERSION_MODEL==='framework'||!p.ccoOn),HHPOOL=HHON&&HOUSEHOLDS.pool!=='individual';if(HHON)hhYear(agentSet);  // v5.3 B3: households (no RNG)
  var pthApprBonus=p.szh?p.szhCoh*0.01:0;
  var szhThetaVal=p.szh?szhTheta(p.szhCoh):0;
  if(THETA_GATE==='density'){var tdN=0;if(p.ptf)agentSet.forEach(function(a){if(a.inPTF)tdN++;});THETA_DENS=tdN/Math.max(1,agentSet.length);szhThetaVal=p.szh?szhTheta(THETA_DENS):0;}  // session 5 (C08/d12): harness-only
  var ptfConvBonus=1.30+((p.szh&&p.ptf)?szhThetaVal:0);
  var szhPartBoost=(p.szh&&p.ccoOn)?szhThetaVal*0.16:0;
  if(CMS)⟦not run⟧var clTh=CMS⟦not run⟧:null;  // S37: theta by community (CMS null: the population's, as before)
  function clPCB(a){return clTh⟦not run⟧:ptfConvBonus;}function clPB(a){return clTh⟦not run⟧:szhPartBoost;}
  /* v4.14 parity fix — ported from index.html: PTF's inflation-damping term used to read
   * the static initial-share slider (p.ptfShare) rather than the population's actual
   * current PTF membership, which this same function already computes a few lines later
   * (for the Bass-diffusion adoption term) but never reused here. ptfAdoptFrac is moved up
   * and reused for both purposes — it draws no RNG, so this reordering shifts no draw
   * anywhere in the function. Verified inert on the documented seed-42/Full Integration
   * regression (inflRate=0 there, so the guard never fires); see CONTRIBUTING.md's v4.14
   * Release Notes for the full trail and measured effect size on configs it does touch. */
  var ptfAdoptFrac=0;
  if(PTFS&&PFS&&p.ptf)ptfsYear(agentSet,yr);  // v5.4 item 4: PTF leavers and this year's member share
  if(p.ptf&&p.ptfShare>0){var ptfCount0=0;agentSet.forEach(function(a){if(a.inPTF)ptfCount0++;});ptfAdoptFrac=ptfCount0/Math.max(1,agentSet.length);}
  if(CMS)⟦not run⟧  // S37: each community's member share, where the population's is taken (after the leavers)
  /* v4.15 parity fix — ported from index.html: PTH's inflation damping used to be the flat,
   * toggle-triggered `inflRate*=0.90` below — the same defect class the v4.14 PTF fix closed
   * one line above it, in a coarser form (it referenced no adoption-scale quantity at all,
   * so 5% PTH uptake got the identical 10% population-wide reduction as 50%). Unlike PTF,
   * PTH membership is drawn once at construction and never changes during a run, so
   * pthMemberFrac is simply the population's fixed realised PTH share — counted the same
   * no-RNG way as ptfAdoptFrac (existing a.inPTH flags only), so no draw shifts anywhere.
   * Verified inert on the documented seed-42/Full Integration regression (inflRate=0 there)
   * and on Baseline (pth=false); see CONTRIBUTING.md's v4.15 Release Notes. */
  var pthMemberFrac=0;
  if(p.pth){var pthCount0=0;agentSet.forEach(function(a){if(a.inPTH)pthCount0++;});pthMemberFrac=pthCount0/Math.max(1,agentSet.length);}
  var inflRate=p.inflRate||0;
  if(p.ptf&&inflRate>0&&!(PRICE&&PRICE.noDamp))⟦not run⟧  // session 2: PRICE.noDamp (price module only)
  /* v4.15: (1-pthMemberFrac*0.10) replaces the flat *0.90. The 0.10 coefficient (=1-0.90) is
   * unchanged from the historical value and is now the ceiling reached at 100% membership. */
  if(p.pth&&inflRate>0&&!(PRICE&&PRICE.noDamp))⟦not run⟧
  var dollarCost=CFG.BASE_DAILY_COST*365*Math.pow(1+inflRate,yr);
  if(HEALTH⟦not run⟧)⟦not run⟧  // session 2a: health coverage (setting A); off by default; its own hashed draws, none from any stream
  if(PRICE)dollarCost*=PRICE.bIdx;  // session 2: endogenous basket index (price module only)
  var popShock=recSt.active?recSt.incomeMultiplier:1.0;
  if(EMPL&&EMPL.rec==='replace'&&recSt.active)popShock=1-Math.max(0,(1-popShock)-(CFG.EMPL_P_REC*CFG.EMPL_W_REC-CFG.EMPL_P*CFG.EMPL_W)/52);  // v5.4 item 2: the recession's job loss is not counted twice
  var mlNT=0;  // v5.2 step 6: the share added to every worker's wage by spending that fills idle labour in a year without a recession
  var hcM=0;if(HCAP)⟦not run⟧  // v5.2 step 7: this year's rent mark-up outside PTH, from last year's flows
  if(MULT&&TB&&p.tb){if(yr===0||!MLS)MLS={push:0,y:[]};var mlFill=0,mlLoss=0,mlRest=0;  // plan step 16: the spending layer (testbed only; no RNG)
    if(recSt.active&&popShock<1&&MLS.push>0){var mlW=0;agentSet.forEach(function(a){if(!isNaN(a.wage)&&a.wage>0)mlW+=a.wage*12*CFG.WAGE_TO_USD;});mlLoss=(1-popShock)*mlW;
      if(mlLoss>0){mlRest=Math.min(mlLoss,MULT_LS*MULT.m*MLS.push);mlFill=mlRest/mlLoss;popShock+=(1-popShock)*mlFill;}}
    else if(MULT.nt⟦not run⟧)⟦not run, 2 lines⟧
    MLS.y[yr]={fill:mlFill,loss:mlLoss,rest:mlRest,push:MLS.push};if(MULT.nt)⟦not run⟧}
  var ptfLiveCount=0,ptfLiveTotal=agentSet.length;
  if(p.ptf&&p.ptfCap)⟦not run⟧
  var PDON=!!PROD&&CONVERSION_MODEL==='framework'&&!!p.ptf&&PROD.cap==='ptf',pdCap=1,pdLive=0;  /* plan step 2: PTF capacity (no RNG) */
  if(PDON){if(yr===0||!PDS){var pdN0=0;agentSet.forEach(function(a){if(a.inPTF)pdN0++;});PDS={c0:pdN0/Math.max(1,agentSet.length),y:[]};}
    var pdK=SURP?SURP.K⟦not run⟧,pdA=(yr>0&&SURP&&SPS)?SPS.capPA:0;pdCap=pdK<=0⟦not run⟧:Math.min(1,PDS.c0+pdA/pdK);
    agentSet.forEach(function(a){if(a.inPTF)pdLive++;});
    var pdOwn=pdCap,pdBor=0;if(PROD.speed==='oneyear'){if(yr>0&&pdK<Infinity&&pdK>0){pdCap=Math.min(1,Math.max(pdOwn,(pdLive+(PDS.blk||0))/Math.max(1,agentSet.length)));pdBor=Math.max(0,pdCap-pdOwn)*pdK;}PDS.blk=0;PDS.borPA=pdBor;}  // plan step 15 (d137): last year's unmet demand is served this year; the capacity reinvestment has not paid for is borrowed (year-0 $ per adult)
    PDS.y[yr]={cap:pdCap,mem:pdLive/Math.max(1,agentSet.length),own:pdOwn,bor:pdBor};}
  function ptfCapAllows(){return (!p.ptfCap⟦not run⟧)&&(!PDON||pdLive<ptfLiveTotal*pdCap);}
  var popAIDisp=0;
  if(p.automation){
    if(yr>=CFG.AI_DISPLACEMENT_YEAR_2)popAIDisp=CFG.AI_DISPLACEMENT_RATE_1*(CFG.AI_DISPLACEMENT_YEAR_2-CFG.AI_DISPLACEMENT_YEAR_1)+CFG.AI_DISPLACEMENT_RATE_2*(yr-CFG.AI_DISPLACEMENT_YEAR_2+1);
    else if(yr>=CFG.AI_DISPLACEMENT_YEAR_1)popAIDisp=CFG.AI_DISPLACEMENT_RATE_1*(yr-CFG.AI_DISPLACEMENT_YEAR_1+1);
    popAIDisp=Math.min(0.10,popAIDisp);
  }
  /* v4.19: automatic stabilizers (Research Hub Integrated Implementation Roadmap, Appendix G).
   * All off by default: with p.stab and p.cola unset, buEff===p.bu exactly (a multiply by 1),
   * emergLine is -1 and decay is untouched, so every documented figure is bit-identical.
   *  - Recession trigger: the year's recession is active and its population income loss
   *    (1 - incomeMultiplier) is at least p.stabThresh. The engine has no GDP or unemployment
   *    rate, so the hub's ">2% GDP decline" is read as a >=2% income loss; every engine
   *    recession (5-30%) clears it. The trigger reads the CURRENT year's shock (a timely
   *    trigger); harness.js measures what a one-year data lag costs.
   *  - Increase: fixed multiplier p.stabMult, or scaled 1 + p.stabK x loss (p.stabSev).
   *  - COLA: BU indexed by the same cost index mainLoopCostUSD uses, (1+inflRate)^yr, when the
   *    headline rate p.inflRate is above p.colaThresh (Inflation Surge Protocol: 5%).
   *    Inflation is a constant input rate here, so the threshold acts for the whole run.
   *  - buEff replaces p.bu at every read below: allocation, the 3x cap, FBS, and the BLEI
   *    check that gates the wage-growth bonus.
   *  - Suspended expiry (p.stabSusp, hub Natural Disaster Response): unspent BU carries over
   *    while triggered, up to the 3x cap.
   *  - Emergency enrollment (p.emerg, hub "relax requirements"): while triggered, a
   *    non-participant whose latent CCO uniform lies in [partRate, partRate + take-up x
   *    (1 - partRate)) gets the CCO cost relief for that year only. Deterministic: it reads
   *    a.uCCO, drawn at construction, so no RNG draw is added and CRN pairing holds.
   *    Enrollees do not enter octave advancement or conversion.
   * No RNG is drawn here. */
  var stabLoss=recSt.active?Math.max(0,1-recSt.incomeMultiplier):0;
  var stabOn=!!(p.stab⟦not run⟧);
  var stabM=stabOn⟦not run⟧:1;
  var colaF=(p.cola&&(p.inflRate||0)>(p.colaThresh⟦not run⟧))⟦not run⟧:1;
  /* Session 2, price module only: COLA reads the headline rate, exogenous plus endogenous, year by year, and ratchets BU
   * up to the full price index in any year that rate exceeds p.colaThresh (Inflation Surge Protocol, 5% in D6). */
  if(PRICE){var pmFull=Math.pow(1+inflRate,yr)*PRICE.bIdx;if(p.cola&&pmFull/PRICE.lastFull-1>(p.colaThresh⟦not run⟧))PRICE.colaLevel=pmFull;PRICE.lastFull=pmFull;colaF=p.cola?PRICE.colaLevel:1;}
  if(C22⟦not run⟧)⟦not run⟧  // S6: the BU indexed every year to the price of the C2.2 needs
  var buEff=p.bu*stabM*colaF;if(PRICE)PRICE.buY=buEff;  // v5.2 step 8: this year's BU a month, for the purchasing-power path (reporting only)
  var agP=Math.pow(1+inflRate,yr)*(PRICE?PRICE.bIdx⟦not run⟧);  // v5.2 step 4: the price level the benefit moves with (read only when AGE is on)
  var svF=0;if(SAVE)⟦not run⟧  // v5.2 step 3: savings that keep up with prices (no RNG)
  var tbY=(TB&&p.tb)?tbYear(p,colaF):null;  // session 6 (A4 testbed): null unless TB and p.tb are both set (harness-only; no RNG)
  if(SNET&&SNS&&tbY)snYear(agentSet,yr,HHON,inflRate);  // session 2b: today's safety net (SNAP, EITC, the refundable CTC), set on last year's income; off by default; no stream drawn
  if(DIS⟦not run⟧)⟦not run⟧  // v5.4 item 5: who the disaster hits (and, later, who has recovered)
  if(PTHB&&PBS&&p.pth)pthbYear(agentSet,yr,agP);  // v5.4 item 3: the year's price rise, PTH leavers and their homes' new members
  if(JOIN&&CONVERSION_MODEL==='framework'&&p.ccoOn){  /* plan step 4: open enrolment (no RNG) */
    if(yr===0||!JNS){JNS={y:[],join:0,leave:0};agentSet.forEach(function(a){a._jnY=0;});}
    var jnN=0,jnJ=0,jnL=0;
    if(yr>0){var jnIdx=Math.pow(1+inflRate,yr)*(PRICE?PRICE.bIdx⟦not run⟧),jnM=CFG.LIVING_WAGE_ANNUAL*jnIdx,jnE=0,jnTx=DISC_BASE==='pretax';
      buEss().forEach(function(k){jnE+=CFG.BASKET[k]*(PRICE?PRICE.comp[k]⟦not run⟧);});if(PRICE)jnE/=PRICE.bIdx;  // v5.3 B3f: what BU can buy
      var jnF=CFG.BASKET.food*(PRICE?PRICE.comp.food/PRICE.bIdx⟦not run⟧),jnH=CFG.BASKET.housing*(PRICE?PRICE.comp.housing/PRICE.bIdx⟦not run⟧),jnRs=PTH_MODE!=='basket'⟦not run⟧;
      agentSet.forEach(function(a){var jHH=HHON&&a._hh&&!a._hh.single,ef=jHH?a._hhE:jnE,u=1,jF=jHH?a._hhFd:jnF,jH=jHH?a._hhH:jnH,jM=jHH?jnM*a._hhF:jnM,jB=jHH?buEff*a._hhBU:buEff;if(a._inel)⟦not run⟧if(a._ret⟦not run⟧)⟦not run⟧/* S6: not eligible (C22.u) */ /* v5.2 step 4: under 'none' a retiree is outside the programme */  /* v5.3 B3: a household member's share of the household's essentials and BU */
        if(p.ptf&&a.inPTF){if(PTFS){var jnC=1-ptfsCut(a,jHH,p,true);ef=ef*jnC;if(jnRs)u=jnC;}⟦not run⟧}
        if(p.pth&&a.inPTH&&!PATHWAY_OFF.pthCost){if(PTH_MODE==='housing')ef-=PTH_HOUSING_CUT*jH*u;⟦not run⟧}
        var use=Math.min(12*jB,jM*ef),cost=(JOIN.cost==='none'||(C22⟦not run⟧))⟦not run⟧:12*p.bu*(typeof a.uCCO==='number'?a.uCCO⟦not run⟧)/Math.max(1e-9,p.partRate)*(JOIN.cost==='nominal'⟦not run⟧:jnIdx),want=p.bu>0&&use>=cost;
        if(a.inCCO&&!want⟦not run⟧)⟦not run⟧
        else if(!a.inCCO&&want){a.inCCO=true;a._jnY=yr;jnJ++;}});if(HHON)hhSync('cco');}  // v5.3 B3: partners follow the first adult
    agentSet.forEach(function(a){if(a.inCCO)jnN++;});JNS.join+=jnJ;JNS.leave+=jnL;JNS.y[yr]={part:jnN/Math.max(1,agentSet.length),join:jnJ,leave:jnL};
  }
  var emergLine=(stabOn⟦not run⟧)⟦not run⟧:-1;
  var emergN=0;
  /* v4.19, Duke's decision (Option B): CCO's cost relief scales with the effective BU. Through
   * v4.18 it was a flat 0.80 whenever BU > 0, so the BU amount reached a household only through
   * conversion proceeds, credited once a year. BU is "redeemable at PTF businesses for essential
   * goods" (Research Hub glossary), so the amount now moves the relief directly: 20% of the
   * basket at the $1,200 reference, in proportion above and below it, capped at 50%. At $1,200
   * this is exactly 0.80, so every $1,200 preset and the seed-42 regression are bit-identical;
   * Stress Test ($900) and any run at another BU amount move. The 50% cap is a placeholder. */
  /* v4.21 units fix, ported from index.html (see its comment): the relief share reads BU in
   * year-0 dollars, buEff / priceIdx. RELIEF_PRICE_LEGACY (harness-only) restores v4.19-v4.20. */
  var priceIdx=RELIEF_PRICE_LEGACY⟦not run⟧:Math.pow(1+inflRate,yr);
  if(PRICE&&!RELIEF_PRICE_LEGACY)priceIdx*=PRICE.bIdx;  // session 2: BU erodes with the endogenous index too
  var ccoReliefF=CCO_RELIEF_FLAT⟦not run⟧:1-Math.min(CFG.CCO_RELIEF_CAP,CFG.CCO_RELIEF_AT_REF*buEff/(CFG.CCO_RELIEF_REF_BU*priceIdx));
  if(LEDGER)⟦not run⟧  // A1 ledger (reporting only): this year's price index, the one mainLoopCostUSD uses
  /* Session 2: framework conversion state (N1-N4) and the basket's current essentials and food shares (price module). */
  var FWON=CONVERSION_MODEL==='framework';
  if(FWON){if(yr===0||!FWS)FWS={prev:null};FWS.next={bizBU:0,projBU:0,expiredBU:0,destroyedBU:0,wSum:0,pwSum:0,projAlloc:0,projGross:0,projTax:0,projNet:0,projLost:0,bizPaid:0};}
  var PJON=!!PROJ,pjPay=0,pjIdx=1,pjCipB=1,pjFg=0;  /* N1 (session 15): project hiring; see PROJ. No RNG is drawn in any PROJ step. */
  if(PJON){
    if(yr===0||!PJS)PJS={prev:null,acc:pjNewAcc()};PJS.next={pool:0,gpool:0};  // gpool: the launch gift's share, tracked for financing (d66)
    pjIdx=Math.pow(1+inflRate,yr)*(PRICE?PRICE.bIdx⟦not run⟧);pjPay=PROJ.pay*pjIdx;pjCipB=p.cip?(1+p.cipDemo*0.12)⟦not run⟧;
    var pjP=[],pjWt=0,pjWR=0,pjIn=PJS.prev?PJS.prev.pool+PJS.prev.gpool:0,pjCarry=0;pjFg=pjIn>0?PJS.prev.gpool/pjIn:0;
    if(REVIEW⟦not run⟧)⟦not run⟧  // v5.2 step 7: one number per adult a year from the review stream
    if(p.ccoOn)agentSet.forEach(function(a){if(!a.inCCO)return;if(a._ret⟦not run⟧)⟦not run⟧/* v5.2 step 4: no conversion after retirement under 'noconv' */var r=pjOwnRate(a,p,clPCB(a)),cap=12*FW.octaveCapBase*Math.pow(2,a.octave),w=cap*Math.max(0,a.quality);
      a._pjR=r;a._pjCap=cap;a._pjW=w;a._pjBU=0;pjWt+=w;pjWR+=w*r;pjP.push(a);});
    var pjRc=pjWt>0?pjWR/pjWt⟦not run⟧,pjSet=[];PJS.acc.rc+=pjRc;PJS.acc.rcN++;
    pjP.forEach(function(a){var ru=PROJ.rate==='max'?Math.max(a._pjR,pjRc)⟦not run⟧,v=pjPay*ru*(1-pjTax(p,ru))*pjCipB,h=a.wage*12*CFG.WAGE_TO_USD/PROJ.hrsYr;
      a._pjRu=ru;a._pjWill=v>(a._ret⟦not run⟧:h);/* v5.2 step 4: a retiree gives up no wage for project hours */if(PROJ.alloc==='capqAll'||a._pjWill)pjSet.push(a);});
    if(pjIn>0&&pjSet.length){
      if(PROJ.alloc==='low')⟦not run⟧
      else if(PROJ.alloc==='equal')⟦not run⟧
      else{var pjS=0;pjSet.forEach(function(a){pjS+=a._pjW;});if(pjS>0)pjSet.forEach(function(a){a._pjBU=pjIn*a._pjW/pjS;});⟦not run⟧}
    } else pjCarry=pjIn;
    pjP.forEach(function(a){if(a._pjBU>0){PJS.acc.alloc+=a._pjBU/pjIdx;PJS.acc.work++;if(!a._pjWill)⟦not run⟧}});
    PJS.acc.carry=pjCarry/pjIdx;PJS.next.pool+=pjCarry*(1-pjFg);PJS.next.gpool+=pjCarry*pjFg;PJS.acc.partY+=pjP.length;
    if(yr===0&&PROJ.giftMode==='forward'&&PROJ.gift>0){PJS.next.gpool+=PROJ.gift*pjP.length;if(ACCT)⟦not run⟧PJS.acc.gift+=PROJ.gift*pjP.length;PJS.acc.pool+=PROJ.gift*pjP.length;}
    if(yr===1&&PROJ.giftMode==='holder'⟦not run⟧)⟦not run⟧
  }
  var ESON=FWON&&!!ESP,esIdx=1,esCipB=1;  /* N1 (session 19, s38): ESP payroll. Framework model only; no RNG is drawn in any ESP step. */
  if(ESON){
    if(yr===0||!ESS)ESS={prev:null,acc:esNewAcc(),y:[]};
    esIdx=Math.pow(1+inflRate,yr)*(PRICE?PRICE.bIdx⟦not run⟧);esCipB=p.cip?(1+p.cipDemo*0.12)⟦not run⟧;
    var esA=ESS.acc,esPool=ESS.prev?ESS.prev.pool:0,esW=0,esRet=0,esSv=0,esY=ESS.y[yr]={pool:esPool,conv:0,ret:0,sv:0};
    agentSet.forEach(function(a,i){
      if(a._esU===undefined)a._esU=((i+1)*ESP_GOLD)%1;  // d72: fixed by agent index
      a._esWk=(ESP.work==='all'⟦not run⟧:ESP.work==='ptf'⟦not run⟧:a._esU<ESP.work)&&!a._ret;  // v5.2 step 4: no paid ESP work after 67
      a._esBU=0;a._esC=0;a._esX=0;a._esR=0;
      if(a._esWk)esW+=Math.max(0,a._fwW||0);
    });
    ESS.wW=esW;esA.poolPaid+=esPool/esIdx;
    agentSet.forEach(function(a){
      if(!a._esWk&&!(a._esSv>0))return;
      var w=Math.max(0,a._fwW||0),sh=0,bu=0;
      if(a._esWk){esA.wkY++;if(yr>0){esA.wkY1++;esA.wage+=w/esIdx;}
        if(esPool>0&&esW>0){sh=esPool*w/esW;bu=Math.min(sh,w);if(sh>bu)⟦not run⟧if(w>0)esA.maxShare=Math.max(esA.maxShare,bu/w);}
        a._esBU=bu;esA.alloc+=bu/esIdx;}
      if(!(p.ccoOn&&a.inCCO)){esRet+=bu;esA.retNon+=bu/esIdx;return;}  // d73: non-participants have no earned rate; paid in dollars
      if(a._esWk)esA.partWkY++;
      var r=pjOwnRate(a,p,clPCB(a)),tx=pjTax(p,r),ok=ESP.take==='biz'⟦not run⟧:r*(1-tx)*esCipB>1;
      if(!ok){esRet+=bu;esA.retPar+=bu/esIdx;return;}  // below par (or below the ESP's rate, 'biz'): paid in dollars
      var have=bu+(ESP.cap==='save'⟦not run⟧:0);
      var cap=ESP.cap==='none'⟦not run⟧:Math.max(0,12*FW.octaveCapBase*Math.pow(2,a.octave)-(PJON?(a._pjBU||0)+(a._pjSaved||0)⟦not run⟧));  // d74: net of project BU
      var c=Math.min(have,cap);a._esK=cap;  // _esK: reporting only (the capacity test)
      if(have>c+1e-9){esA.capBind++;if(ESP.cap==='save')⟦not run⟧else{esRet+=have-c;esA.retCap+=(have-c)/esIdx;}}
      else if(ESP.cap==='save')⟦not run⟧
      if(c>0){a._esC=c;a._esR=r;if(ACCT)⟦not run⟧a._esX=w>0?c*(r*(1-tx)*esCipB-1)/w⟦not run⟧;esA.tk++;}  // the payroll raise for the labor module (before the income shock)
    });
    if(ESP.cap==='save')⟦not run⟧
    esY.ret=esRet;esY.sv=esSv;esA.ret+=esRet/esIdx;esA.sv=esSv/esIdx;
    agentSet.forEach(function(a){esY.conv+=a._esC;});
    if(esRet>0&&FWS.prev){  // d73-d75: the BU returned to the ESP convert at FW.bizRate this year, paid with the rest of last year's premium
      var esBT=p.cip?p.tax*(1-p.cipDemo*0.18)⟦not run⟧,esTR=Math.min(CFG.PROG_TAX_MAX,esBT+Math.max(0,(FW.bizRate-CFG.PROG_PIVOT)*CFG.PROG_RATE)),esTP=Math.min(CFG.PROG_TAX_MAX,esBT);
      var esRG=esRet*(FW.bizCap*FW.bizRate+(1-FW.bizCap)),esRT=esRet*(FW.bizCap*FW.bizRate*esTR+(1-FW.bizCap)*esTP),esRN=PATHWAY_OFF.conversion⟦not run⟧:esRG-esRT-esRet;
      FWS.prev.bizNet+=esRN;esA.retNet+=esRN/esIdx;if(tbY)TB.cur.ctax+=esRT;if(ACCT)⟦not run⟧
      if(LEDGER)⟦not run⟧
    }
    if(LEDGER)⟦not run⟧
  }
  var c22Cur=C22S⟦not run⟧:0;  // S6: the C2.2 needs' share of the basket (reporting only)
  var eShareCur=0,fShareCur=CFG.BASKET.food;buEss().forEach(function(k){eShareCur+=CFG.BASKET[k]*(PRICE?PRICE.comp[k]⟦not run⟧);});  // v5.3 B3f: the share of the basket BU can buy (BU_SCOPE)
  if(PRICE){eShareCur/=PRICE.bIdx;fShareCur=CFG.BASKET.food*PRICE.comp.food/PRICE.bIdx;}
  var rsAlt=PTH_MODE!=='basket'⟦not run⟧;  // session 5 (d4/d5): harness-only
  var tShareCur=DISC_BASE==='pretax'?CFG.BASKET.taxes*(PRICE?PRICE.comp.taxes/PRICE.bIdx⟦not run⟧)⟦not run⟧,hShareCur=CFG.BASKET.housing*(PRICE?PRICE.comp.housing/PRICE.bIdx⟦not run⟧);
  var tShA=tShareCur;function discMul(c,m){return DISC_BASE==='pretax'?tShA+(c-tShA)*m⟦not run⟧;}  // v5.3 B3: tShA = a household member's own tax share (set per adult below)
  if(ACCT⟦not run⟧)⟦not run⟧  // v5.3 B2: the premium to be paid out this year (with the returned BU's)
  var SPON=FWON&&!!SURP,spDelta=0,spProfW=0,spRestW=0,spOwnW=0;  /* plan step 1 (Oct 1, 2026): the ESP surplus split; see SURP. No RNG is drawn in any SURP step. */
  if(SPON){
    if(yr===0||!SPS)SPS={capPA:0,cap:0,carry:0,carryP:0,sw:-1,acc:spNewAcc(),y:[]};
    var spIdx=Math.pow(1+inflRate,yr)*(PRICE?PRICE.bIdx⟦not run⟧),spA=SPS.acc,spN=agentSet.length;
    var spPool=FWS.prev?FWS.prev.bizNet:0,spS=(SURP.priv==='owners'||SURP.priv==='prices')?((FWS.prev&&FWS.prev.bizBU>0)?(FWS.prev.bizBUptf⟦not run⟧)/FWS.prev.bizBU:0)⟦not run⟧;  // the PTFs' share: BU PTF members spent last year / all BU accepted
    var spPh=yr===0?1:SURP.swYear!=null⟦not run⟧:((PDON?(SURP.K<=0||PDS.c0+SPS.capPA/SURP.K>=1)⟦not run⟧)?2:1);if(spPh===2&&SPS.sw<0)SPS.sw=yr;  // plan step 2: with PTF capacity on, when c reaches 1  // year 0 has no pool  // d101: phase 2 the year after the capital account reaches K
    var spSh=spPh===1?SURP.p1:SURP.p2,spPtf=spPool*spS,spOwn=spPool-spPtf,spChD=0,spChI=0;
    if(PDON&&PROD.speed==='oneyear'){var spChDue=(PDS.borPA||0)*(PROD_CAP_DEP+PROD_CAP_INT)*spN*spIdx+(PDS.debt||0)*spIdx,spChPd=Math.min(spPtf,spChDue);PDS.debt=(spChDue-spChPd)/spIdx;spPtf-=spChPd;  // plan step 15: depreciation plus real interest on borrowed PTF capital, paid from the PTFs' premium first; any shortfall carries
      spChD=spChPd*PROD_CAP_DEP/(PROD_CAP_DEP+PROD_CAP_INT);spChI=spChPd-spChD;if(tbY){TB.cur.conv+=spChPd;TB.cur.convM+=spChD;}if(PRICE&&PRICE.acc)PRICE.acc.conv+=spChPd;SPS.acc.chD=(SPS.acc.chD||0)+spChD/spIdx;SPS.acc.chI=(SPS.acc.chI||0)+spChI/spIdx;}
    var spRest=spPtf*Math.max(0,1-spSh[0]-spSh[1]-spSh[2]),spCarryIn=SPS.carry;
    var spPP=spPtf*spSh[0]+(SURP.rv==='price'⟦not run⟧:0)+SPS.carry,spRv=SURP.rv==='price'⟦not run⟧:spPtf*spSh[1],spPr=spPtf*spSh[2]+SPS.carryP;SPS.carryP=0;
    var spCust=SURP.cust==='auto'?((SURP.priv==='owners'||SURP.priv==='prices')?'ptf'⟦not run⟧)⟦not run⟧;
    var spVOn=SURP.priv==='prices',spVW=0,spVP=0,spVSum=0,spVUsed=0;  /* plan step 14 (Oct 2, 2026; d140): private ESPs pass their premium to BU customers as lower prices; workers matched */
    if(spVOn){if(SPS.carryV===undefined)SPS.carryV=0;spVW=SURP.privWk==='none'⟦not run⟧:spOwn*spSh[2];spVP=spOwn-spVW+SPS.carryV;spPr+=spVW;spOwn=0;}
    var spMlc=CFG.LIVING_WAGE_ANNUAL*Math.pow(1+inflRate,yr);if(PRICE)spMlc*=PRICE.bIdx;
    var spSum=0,spWW=0,spWO=0;
    if(!ESON)⟦not run⟧  // ESP payroll off: the same workforce (d72)
    agentSet.forEach(function(a){  // each customer's essentials at own prices, exactly as the agent loop computes them (start-of-year memberships)
      var bp=p.ccoOn&&a.inCCO&&p.bu>0&&!PATHWAY_OFF.relief,isC=spCust==='all'||(spCust==='pp'⟦not run⟧)||(spCust==='ptf'&&p.ptf&&a.inPTF)||(spCust==='part'⟦not run⟧),e=0;
      var sHH=HHON&&a._hh&&!a._hh.single,sE=sHH?a._hhE:eShareCur,sF=sHH?a._hhFd:fShareCur,sH=sHH?a._hhH:hShareCur,sM=sHH?spMlc*a._hhF:spMlc;  // v5.3 B3: a household member's share of the household's essentials
      if(isC){var ef=sE,u=1;
        if(p.ptf&&a.inPTF){if(PTFS){var spC=1-ptfsCut(a,sHH,p,true);ef=ef*spC;if(rsAlt)u=spC;}⟦not run⟧}
        if(p.pth&&a.inPTH&&!PATHWAY_OFF.pthCost){if(PTH_MODE==='housing')ef-=PTH_HOUSING_CUT*sH*u;⟦not run⟧}
        if(SURP_CUT_MARKUP&&bp&&HCAP⟦not run⟧)⟦not run⟧  // v5.3 B2: the bill the cut is applied to (the agent loop adds hcX to a BU customer's essentials)
        e=sM*ef;if(SURP.bu==='cash'⟦not run⟧)⟦not run⟧}
      if(spVOn){var vBu=(bp&&!(p.ptf&&a.inPTF))?Math.max(0,a._spBU||0):0,vE=0;if(vBu>0){vE=sE;if(p.pth&&a.inPTH&&!PATHWAY_OFF.pthCost){if(PTH_MODE==='housing')vE-=PTH_HOUSING_CUT*sH;⟦not run⟧}vE*=sM;}a._spVw=vBu;a._spVE=vE;spVSum+=vBu;}
      a._spE=e;a._spCutY=0;a._spPay=0;a._spOwn=0;a._spBU=0;a._spWk=!!a._esWk&&(SURP.wk!=='espPart'||!!(p.ccoOn&&a.inCCO));
      spSum+=e;if(a._spWk)spWW+=Math.max(0,a._fwW||0);spWO+=Math.max(0,a.wealth);
    });
    spDelta=spSum>0?Math.min(1,spPP/spSum)⟦not run⟧;var spUsed=spDelta*spSum;SPS.carry=spPP-spUsed;  // d98: one uniform cut, capped at 1; the rest carries
    if(spVOn){agentSet.forEach(function(a){a._spV=(spVSum>0&&a._spVw>0)?Math.min(spVP*a._spVw/spVSum,a._spVE):0;spVUsed+=a._spV;});SPS.carryV=spVP-spVUsed;}  // plan step 14: shared by last year's BU spent at private ESPs, capped at own essentials; the rest carries
    if(spWW>0)spProfW=spPr/spWW;else{SPS.carryP=spPr;spPr=0;}
    var spRestOn=spRest>0&&FWS.prev&&FWS.prev.wSum>0;spRestW=spRestOn?Math.max(0,spRest)/FWS.prev.wSum:0;
    if(spWO>0)spOwnW=spOwn/spWO;⟦not run⟧
    agentSet.forEach(function(a){var w=a._fwW||0;a._spOwn=spOwnW*Math.max(0,a.wealth);a._spRest=spRestOn?spRest*w/FWS.prev.wSum:0;a._spPay=(a._spWk&&spWW>0?spPr*Math.max(0,w)/spWW:0)+a._spRest+a._spOwn;});  // shares all 0 under 'same': exactly today's payout (unit)
    SPS.cap+=spRv;SPS.capPA+=spRv/spIdx/spN;  // d100: the ESP capital account (year-0 dollars per adult for the trigger)
    if(tbY){TB.cur.conv+=spRv;if(PROD)TB.cur.convM+=spRv;}if(PRICE&&PRICE.acc)PRICE.acc.conv+=spRv;  // plan step 2: reinvestment buys capital goods (output at face)  // d105: reinvestment is part of the conversion premium
    spA.pool+=spPool/spIdx;spA.own+=spOwn/spIdx;if(spVOn){spA.privW=(spA.privW||0)+spVW/spIdx;spA.privP=(spA.privP||0)+(spVP-SPS.carryV)/spIdx;}spA.ptf+=spPtf/spIdx;spA.rest+=spRest/spIdx;spA.pricePool+=(spPP-spCarryIn)/spIdx;spA.reinv+=spRv/spIdx;spA.carry=SPS.carry/spIdx;
    if(yr>0){if(spPh===1){spA.d1+=spDelta;spA.n1++;}else{spA.d2+=spDelta;spA.n2++;}spA.yrs++;}
    SPS.y[yr]={pool:spPool,s:spS,own:spOwn,ptf:spPtf,rest:spRest,carryIn:spCarryIn,pp:spPP,sum:spSum,delta:spDelta,used:spUsed,carryOut:SPS.carry,profit:spPr,reinv:spRv,cap:SPS.cap,capPA:SPS.capPA,phase:spPh,cut:0,freed:0,paid:0,pjFreed:0,privW:spVW,privPool:spVP,privUsed:spVUsed,cutV:0,ch:spChD+spChI,chDue:(typeof spChDue==='number'?spChDue⟦not run⟧)};
    if(LEDGER)⟦not run⟧
  }
  agentSet.forEach(function(a){
    if(isNaN(a.wealth))⟦not run⟧if(isNaN(a.wage)||a.wage<=0)⟦not run⟧
    var HHA=HHON&&a._hh&&!a._hh.single,eSA=HHA?a._hhE:eShareCur,fSA=HHA?a._hhFd:fShareCur,hSA=HHA?a._hhH:hShareCur,buA=HHA?buEff*a._hhBU:buEff,dcA=HHA?dollarCost*a._hhD:dollarCost,HHP=HHPOOL&&HHA&&a._hh.a.length>1;tShA=HHA?a._hhT:tShareCur;if(HHON)a._hhPool=HHP;  // v5.3 B3: a household member's shares, BU and BLEI cost; HHP: a pooled couple (finished in hhPool)
    var dsOn=!!(DIS⟦not run⟧);if(dsOn⟦not run⟧)⟦not run⟧  // v5.4 item 5: the emergency distribution
    if(svF!==0⟦not run⟧)⟦not run⟧  // v5.2 step 3
    a.yrWealthStartUSD=a.wealth;  /* v4.18 parity: start-of-year wealth for housingDistressOf() (no RNG) */
    var agentVar=0.90+RNG()*0.20,incomeShock=popShock*agentVar;
    if(HHON&&HOUSEHOLDS.shock&&a._hh&&a._hh.a.length>1){var hsR=HOUSEHOLDS.shock==='shore'?CFG.HH_SHOCK_CORR[recSt.active?1:0]⟦not run⟧,hsA=Math.min(1,Math.abs(hsR)),hsS=hsR<0&&a._hh.a[1]===a?-1:1;agentVar=1+Math.sqrt(hsA)*hsS*(a._hh.hv-1)+Math.sqrt(1-hsA)*(agentVar-1);incomeShock=popShock*agentVar;a._shkV=agentVar;a._shkR=!!recSt.active;}  // v5.3 B6: a couple's swings share a household part (off by default)
    if(EDCS){a._edcInt=0;a._edcBU=0;}  // v5.3 B6: the measured EDC's inputs (reporting only)
    var uSpendFrac=0.60+RNG()*0.30;
    var uCipQuality=RNG();
    var uAdvance=RNG();
    var uSzhInduce=RNG();
    var uSzhPtfShare=RNG();
    var uPthAppr=RNG();
    var uPtfAdopt=RNG();
    if(AGE⟦not run⟧)⟦not run⟧  // v5.2 step 4: a retiree's benefit, moved with prices; BLEI and the stability score read it as the monthly income
    if(GATE_CURRENT&&FWON&&p.ccoOn&&a.inCCO&&p.bu>0&&!PATHWAY_OFF.relief){  // audit V5-02: the framework BLEI gate reads THIS year's BU spend, not last year's (same expression as fwB0 below)
      var gEss=eSA;
      if(p.ptf&&a.inPTF)gEss=PTFS?gEss*(1-ptfsCut(a,HHA,p,true))⟦not run⟧;
      if(p.pth&&a.inPTH&&!PATHWAY_OFF.pthCost){if(PTH_MODE==='housing')gEss-=PTH_HOUSING_CUT*hSA*(rsAlt&&p.ptf&&a.inPTF&&(PTFS⟦not run⟧)?(PTFS?1-ptfsCut(a,HHA,p,true)⟦not run⟧):1);⟦not run⟧}
      var gCost=CFG.LIVING_WAGE_ANNUAL*Math.pow(1+inflRate,yr);if(PRICE)gCost*=PRICE.bIdx;if(HHA)gCost*=a._hhF;
      a._fwBUm=Math.min(12*buA,gCost*gEss)/12;
    }
    var bleiCheck=agentBLEI(a,buA,p.ccoOn,p.pth,p.szh,p.szhCoh,p.ptf);
    var tbNB=tbY?tbGate(a,p,buA,tbY):0,wg=CFG.WAGE_BASE_GROWTH,bleiGate=(tbY&&TB.neutralGate)?tbNB:bleiCheck;if(AUD⟦not run⟧)⟦not run⟧  // S13 gate: year-0 prices  // session 6 (d28): design-neutral gate for the wage bonus (testbed only)
    var bleiProg=0;a._bleiR=0;a._bleiP=0;  // session 9 (i3-2): harness-only attribution of the BLEI raise (no RNG)
    if(bleiGate>CFG.BLEI_PRECARIOUS_MAX&&!PATHWAY_OFF.bleiWage){  // v4.21: harness-only pathway switch
      var drFactor=1/(1+0.5*Math.max(0,a.wage/CFG.WAGE_MEDIAN_SIU-1));
      wg+=CFG.WAGE_BLEI_BONUS*Math.max(0.1,drFactor);
      a._bleiR=1;if(!(agentBLEI(a,0,false,false,false,0,false)/(AUD⟦not run⟧:1)>CFG.BLEI_PRECARIOUS_MAX)){a._bleiP=1;if(N7_BLEI)bleiProg=CFG.WAGE_BLEI_BONUS*Math.max(0.1,drFactor);}
    }
    if(!PATHWAY_OFF.octaveWage)wg+=a.octave*CFG.WAGE_OCTAVE_BONUS;  // v4.21: harness-only pathway switch
    if(p.cip)wg+=p.cipDemo*0.005;
    if(LABOR&&a._lwNB===undefined)a._lwNB=a.wage;  // session 4 (A3): the wage without program-induced raises
    if(PRICE){if(a._wNB===undefined)a._wNB=a.wage;if(PRICE.wIdx)wg+=PRICE.wIdx*PRICE.piG;}if(AUD⟦not run⟧)⟦not run⟧  // S13 wOut (a reading)  // session 2: wage indexation to P_G (price module; 0 = nominal drift)
    if(!(EMPL&&EMPL.auto==='jobs'))wg-=popAIDisp*((typeof a.automationRisk==='number'&&!isNaN(a.automationRisk))?a.automationRisk⟦not run⟧);  /* v4.17 parity: `||0.5` read a draw of exactly 0 as 0.5 */
    a.wage=Math.max(a.wage*0.80,a.wage*(1+wg));
    if(isNaN(a.wage))⟦not run⟧
    if(a._ret)⟦not run⟧  // v5.2 step 4: a retiree's income is the benefit (no wage growth)
    if(a._ret)⟦not run⟧  // v5.2 step 4: no programme raise on a benefit
    if(LABOR){var lbProg=(PATHWAY_OFF.octaveWage?0:a.octave*CFG.WAGE_OCTAVE_BONUS)+(p.cip?p.cipDemo*0.005:0)+bleiProg;a._lwNB=Math.max(a._lwNB*0.80,a._lwNB*(1+wg-lbProg));}
    if(PRICE){var pmProg=(PATHWAY_OFF.octaveWage?0:a.octave*CFG.WAGE_OCTAVE_BONUS)+(p.cip?p.cipDemo*0.005:0)+bleiProg;a._wNB=Math.max(a._wNB*0.80,a._wNB*(1+wg-pmProg));}  // N7: the wage without program-induced raises
    var cf=1.0,rsPtfU=1,rsRel=1;
    if(!rsAlt)⟦not run, 8 lines⟧ else {  // session 5 (d4/d5): the same chain with PTH_MODE and DISC_BASE (harness-only)
    if(p.ptf&&a.inPTF){if(PTFS){rsPtfU=1-ptfsCut(a,HHA,p);cf=discMul(cf,rsPtfU);}⟦not run⟧}
    var cfPTF=cf;
    if(p.pth&&a.inPTH&&!PATHWAY_OFF.pthCost){if(PTH_MODE==='housing')cf-=PTH_HOUSING_CUT*hSA*rsPtfU;⟦not run⟧}
    var cfPreCCO=cf;
    if(p.ccoOn&&a.inCCO&&p.bu>0){if(!PATHWAY_OFF.relief&&!FWON)⟦not run⟧}
    else if(emergLine>=0⟦not run⟧)⟦not run⟧
    }
    var hcOn=!!(HCAP⟦not run⟧),hcX=hcOn⟦not run⟧:0,hcDone=false;  // v5.2 step 7: whose rent is marked up, and by how much (a share of the basket)
    var mainLoopCostUSD=CFG.LIVING_WAGE_ANNUAL*Math.pow(1+inflRate,yr);
    if(PRICE)mainLoopCostUSD*=PRICE.bIdx;  // session 2: endogenous basket index
    if(HHA)mainLoopCostUSD*=a._hhF;  // v5.3 B3: this adult's share of the household's needs at the household's own prices
    if(C22S⟦not run⟧)⟦not run⟧  // S6: C2.2 coverage (reporting only); amendment 1: covered within a relative 1e-9, so a BU equal to the needs is not lost to rounding
    if(hcOn)⟦not run⟧  // v5.2 step 7: the rent bill of the adults the mark-up falls on
    if(EDCS){a._edcR=(p.pth&&a.inPTH)?0:mainLoopCostUSD*(hSA+hcX);a._edcInt=a._edcIntP||0;a._edcIntP=0;}  // v5.3 B6: rent to a landlord (housing with utilities, MIT; PTH payments are not extractive: the glossary's EDC = 0) and interest on debt
    if(FWON&&p.ccoOn&&a.inCCO&&p.bu>0&&!PATHWAY_OFF.relief){  // session 2, N3/N4: BU buy essentials at the agent's own prices, up to 12 x BU a year
      var essF=eSA;
      if(p.ptf&&a.inPTF)essF=PTFS?essF*(1-ptfsCut(a,HHA,p,true))⟦not run⟧;
      if(p.pth&&a.inPTH&&!PATHWAY_OFF.pthCost){if(PTH_MODE==='housing')essF-=PTH_HOUSING_CUT*hSA*rsPtfU;⟦not run⟧}  // session 5 (d4)
      if(hcX>0)⟦not run⟧  // v5.2 step 7: BU pay the marked-up rent
      var fwBudget=12*buA,fwB=Math.min(fwBudget,mainLoopCostUSD*essF),spC=0,fwB0=fwB;if(tbY)TB.cur.buIss+=fwBudget;if(EDCS)a._edcBU=fwBudget;if(HEALTH)⟦not run⟧  // plan step 3: BU the Source issues (reporting)
      if(SPON&&a._spE>0&&spDelta>0){var spE=mainLoopCostUSD*essF;  // plan step 1 (d99): the cut lowers essentials; BU buy the discounted essentials first
        if(SURP.bu==='cash')⟦not run⟧else{spC=spDelta*spE;fwB=Math.min(fwBudget,spE-spC);}
        a._spCutY=spC;var spY=SPS.y[yr];spY.cut+=spC;spY.freed+=fwB0-fwB;SPS.acc.cut+=spC/spIdx;SPS.acc.cutP+=spC/spIdx;SPS.acc.freed+=(fwB0-fwB)/spIdx;SPS.acc.cash+=(spC-(fwB0-fwB))/spIdx;}
      if(SPON&&a._spV>0){var vSpE=mainLoopCostUSD*essF,vC=Math.min(a._spV,Math.max(0,vSpE-spC)),vB=fwB;  // plan step 14 (d140): a private ESP's lower BU price; BU buy the discounted essentials first, the BU it frees expire
        if(vC>0){spC+=vC;fwB=Math.min(fwBudget,vSpE-spC);a._spCutY=spC;var vY=SPS.y[yr];vY.cut+=vC;vY.cutV+=vC;vY.freed+=vB-fwB;SPS.acc.cut+=vC/spIdx;SPS.acc.cutP+=vC/spIdx;SPS.acc.cutV=(SPS.acc.cutV||0)+vC/spIdx;SPS.acc.freed+=(vB-fwB)/spIdx;SPS.acc.cash+=(vC-(vB-fwB))/spIdx;}}
      var fwLeft=fwBudget-fwB;
      if(HCAP⟦not run⟧)⟦not run⟧  // v5.2 step 7: BU spent on rent outside PTH (at shares of the essentials they buy)
      cf=cfPreCCO+hcX-fwB/mainLoopCostUSD;hcDone=true;if(spC)cf-=spC/mainLoopCostUSD;a._fwBUm=fwB0/12;  // the neutral BLEI gate counts the BU that would be spent without the cut (no price cut enters it)
      if(SPON){a._spBU=fwB;if(p.ptf&&a.inPTF)FWS.next.bizBUptf=(FWS.next.bizBUptf||0)+fwB;}  // plan step 1: BU accepted by PTFs (PTF members' purchases)
      if(SPON&&PJON)SPS.y[yr].pjFreed+=(fwB0-fwB)*PROJ.share;
      FWS.next.bizBU+=fwB;FWS.next.expiredBU+=fwLeft;FWS.next.projBU+=fwLeft*FW.directedShare;FWS.next.destroyedBU+=fwLeft*(1-FW.directedShare);
      if(PJON){PJS.next.pool+=fwLeft*PROJ.share;PJS.acc.exp+=fwLeft/pjIdx;PJS.acc.pool+=fwLeft*PROJ.share/pjIdx;}  // N1 (session 15): the same pool, paid as project hiring
      if(LEDGER)⟦not run⟧
      if(ACCT)⟦not run⟧  // v5.3 B2: issued, spent, and the expired BU not directed (destroyed)
    } else if(SPON&&a._spE>0&&spDelta>0){var spC2=spDelta*a._spE;cf-=spC2/mainLoopCostUSD;a._spCutY=spC2;SPS.y[yr].cut+=spC2;SPS.acc.cut+=spC2/spIdx;SPS.acc.cash+=spC2/spIdx;if(!a.inCCO)SPS.acc.cutN+=spC2/spIdx;⟦not run⟧}  // plan step 1: a customer without BU saves the cut in cash
    if(hcX>0⟦not run⟧)⟦not run⟧  // v5.2 step 7: without BU the higher rent is paid in cash
    var emQ=null,emWk=0;if(EMPL&&EMS){var emU=[EMS.r(),EMS.r(),EMS.r(),EMS.r(),EMS.r(),EMS.r()];emWk=a.wage*12*CFG.WAGE_TO_USD*incomeShock/52;if(!a._ret)emQ=emplYear(a,recSt.active,popAIDisp,emU,emWk);}  // v5.4 item 2: job loss (own stream, six draws whatever the state)
    var annualWageUSD=a._ret⟦not run⟧:a.wage*12*CFG.WAGE_TO_USD*incomeShock*(1+mlNT);
    if(emQ)annualWageUSD*=1-emQ.out;
    if(HEALTH)⟦not run⟧  // session 2a: a year mostly out of work loses employer coverage next year
    if(dsOn)⟦not run⟧  // v5.4 item 5: weeks of work lost to the disaster  // v5.2 step 4: a retiree earns no wage  // v5.2 step 6: mlNT = 0 unless the spending layer fills normal-times slack
    var tbG=0,tbPT=0;if(tbY&&COST&&p.ptf&&a.inPTF){a._csFree=Math.min(mainLoopCostUSD*(1-cfPTF),mainLoopCostUSD*(fSA*COST.food+hSA*COST.util));a._csFreeY=a._csFree;}  // plan step 5: the PTF discount a PTF funds from forgone profit (accounting only)
    if(tbY){tbPT=mainLoopCostUSD*(1-cfPreCCO);if(p.tb.groc⟦not run⟧)⟦not run⟧}  // session 11: X-Cents Power of 1 on housing too (groc.housing)  // session 6: PTF/PTH price-cut dollars; public-grocery cut on the food component
    if(LABOR){  // session 4 (A3): the labor-supply response replaces this year's wage earnings (no RNG)
      var lbE0=annualWageUSD,lbBU=0,lbR=0,lbC=a._labC||0,lbU=p.ubi||0;
      if(p.ccoOn&&a.inCCO&&p.bu>0&&!PATHWAY_OFF.relief){if(FWON){lbBU=fwB;lbR=fwLeft;}⟦not run⟧}
      var lbBiz=(FWON&&FWS.prev&&FWS.prev.wSum>0)?Math.max(0,FWS.prev.bizNet)/FWS.prev.wSum:0;
      if(ESON&&ESP.rest==='esp')⟦not run⟧  // d75 alternative: the ESP's premium reaches its own workers only
      if(SPON)lbBiz=(a._spWk?spProfW:0)+spRestW;  // plan step 1 (d104): the profit share is a raise for ESP workers only; a remainder paid as today stays a raise for all
      var lbRaise=Math.pow(Math.max(1,a.wage/a._lwNB)*(1+lbBiz)*(ESON?1+a._esX:1),LABOR.eps-LABOR.rho);  // uncompensated: Slutsky e_u = e_c + eta, eta = -rho. Session 19: x the ESP payroll raise (earned: one elasticity, no income effect)
      var tbQ=tbY?tbLab(a,tbY,lbE0,tbPT+tbG+(SPON?a._spCutY:0))⟦not run⟧;if(tbQ)lbRaise*=tbQ.F;  // session 6: phase-out and contribution rates (one elasticity), extra unconditional dollars (one income effect)
      var lbInc=LABOR.rho*lbU+LABOR.rhoBU*lbBU+LABOR.rhoR*lbR+LABOR.rho*(1-LABOR.delta)*lbC+(tbQ?LABOR.rho*tbQ.V⟦not run⟧),lbDisp=LABOR.delta*lbC+(tbQ?tbQ.D⟦not run⟧);
      if(SPON&&a._spOwn>0)⟦not run⟧  // plan step 1: owners' dollars are unconditional (one income effect)
      if(emQ){lbInc*=1-emQ.out;lbDisp*=1-emQ.out;}  // v5.4 item 2: the hours response applies to the part of the year at work
      annualWageUSD=Math.max(0,lbE0*lbRaise-lbInc-lbDisp);a._lbE0=lbE0;  // session 8 (A5): earnings with no response, for the hours measure
      if(tbQ&&LABOR.acc)LABOR.acc.cash+=LABOR.rho*tbQ.V;
      if(LABOR.acc){var LA=LABOR.acc;LA.n++;if(a.inCCO)LA.nP++;LA.E0+=lbE0;LA.E+=annualWageUSD;LA.raise+=lbE0*(lbRaise-1);LA.cash+=LABOR.rho*lbU;LA.bu+=LABOR.rhoBU*lbBU;LA.buR+=LABOR.rhoR*lbR;
        LA.rent+=LABOR.rho*(1-LABOR.delta)*lbC;LA.disp+=lbDisp;LA.C+=lbC;LA.U+=lbU+lbBU;LA.projH+=lbE0>0?lbDisp/lbE0:0;if(annualWageUSD===0&&lbE0>0)LA.zero++;}
    }
    if(PJON){a._pjHW=0;if(a._pjBU>0){var pjH=a._pjBU/pjPay,pjHw=a.wage*12*CFG.WAGE_TO_USD*incomeShock/PROJ.hrsYr,pjD=pjH*pjHw;  // N1 (session 15): project hours
      if(PROJ.hours==='displace')⟦not run⟧
      a._pjHW=pjD;PJS.acc.hrs+=pjH;PJS.acc.disp+=(PROJ.hours==='displace'⟦not run⟧:0)/pjIdx;}}
    if(SNET&&SNET.abawd){var abW=emQ?emQ.out*52:0,abUi=emQ&&emWk>0?Math.min(abW,emQ.ui/(CFG.EMPL_UI_REPL*emWk)):0,abB=LABOR?(a._lbE0||0):annualWageUSD,abR=abB>0?(LABOR?annualWageUSD/abB:1):0;a._snAbC=a._ret⟦not run⟧:12*Math.max(0,(abR<0.5?52:abW)-abUi)/52;}  // session 7: SNAP's work rule, this year's months not meeting it (read next year)
    if(tbG)⟦not run⟧  // session 6: public grocery (applied after the labor block reads the CCO relief)
    var costUSD=mainLoopCostUSD*cf;
    if(HEALTH⟦not run⟧)⟦not run⟧  // session 2a: the household's medical bill above (or below) its basket line, in cash, at medical prices
    a.wealth+=annualWageUSD-costUSD;
    if(SPEND_GRADE&&!(AUD⟦not run⟧)){var grA=annualWageUSD+(a._ret⟦not run⟧:0)+(p.ubi>0⟦not run⟧:0)+(emQ?emQ.ui:0);if(SNET&&SNS&&a._snB)grA+=a._snB;a._grCut=0;if(HHP){a._grA=grA;a._grC=costUSD;}else if(costUSD>0&&grA<costUSD){a._grCut=costUSD-costUSD*Math.pow(Math.max(0,grA)/costUSD,SPEND_GRADE.eps);if(DEBT_READ)⟦not run⟧a.wealth+=a._grCut;if(ACCT)⟦not run⟧}}  // v5.3 B7: less income, less spending (off by default)
    a.yrSSUSD=a._ret⟦not run⟧:0;if(a._ret)⟦not run⟧  // v5.2 step 4: the Social Security benefit (money income)
    if(SURPLUS_CONSUMPTION_SHARE>0&&SURPLUS_CONSUMPTION_BASE==='wage'⟦not run⟧)⟦not run⟧  // v4.21: harness-only (saving mode)
    if(ACCT⟦not run⟧)⟦not run⟧  // v5.3 B2
    if(HHP)a._hhWS=annualWageUSD-costUSD;  // v5.3 B3: a pooled couple's spending rule is applied to the couple (hhPool)
    if(p.ubi>0)⟦not run⟧
    if(EMPL){var emUI=emQ?emQ.ui:0;a.yrUbiUSD=(p.ubi>0⟦not run⟧:0)+emUI;if(emUI>0){a.wealth+=emUI;if(ACCT)⟦not run⟧}}  // v5.4 item 2: unemployment insurance (cash, like the UBI comparator's)
    if(dsOn)⟦not run⟧  // v5.4 item 5: the damage and federal aid (both runs)  // session 4: UBI comparator (harness-only; unset in every preset)
    var yrCashSurplus=annualWageUSD-costUSD+(p.ubi>0⟦not run⟧:0)+(a._ret⟦not run⟧:0);
    if(emQ&&emQ.ui>0)yrCashSurplus+=emQ.ui;  // v5.4 item 2  // v5.2 step 4: + the benefit  // session 1: for SURPLUS_CONSUMPTION_BASE 'cash' (harness-only; no RNG)
    if(tbY){var tbK=tbCashFlow(a,tbY,annualWageUSD,yr);a.wealth+=tbK.net+tbK.endow;yrCashSurplus+=tbK.net;if(HEALTH)⟦not run⟧if(ACCT)⟦not run⟧}  // session 6: cash transfers less the contribution; an endowment is wealth, not consumable surplus
    if(LEDGER)⟦not run, 7 lines⟧
    a.yrWageUSD=annualWageUSD;a.yrCostUSD=costUSD;a.yrBasketUSD=mainLoopCostUSD;a.yrConvUSD=0;  /* v4.17: income/basket poverty inputs (no RNG) */
    if(FWON){  // session 2, N1: last year's business conversion premium, paid to every agent in proportion to last year's wage income
      a._fwPayY=0;  // session 19: reporting only (the testbed's premium-by-group columns)
      if(FWS.prev&&FWS.prev.wSum>0){var fwPay=FWS.prev.bizNet*(a._fwW||0)/FWS.prev.wSum;
        if(ESON&&ESP.rest==='esp')⟦not run⟧  // d75 alternative (session 19): a worker cooperative
        if(SPON){fwPay=a._spPay;SPS.y[yr].paid+=fwPay;SPS.acc.profit+=(fwPay-a._spOwn-a._spRest)/spIdx;if(!a.inCCO)SPS.acc.non+=fwPay/spIdx;if(a._spWk&&yr>0){SPS.acc.wkY1++;SPS.acc.profitN+=(fwPay-a._spOwn-a._spRest)/spIdx;}}  // plan step 1: profit share, owners' dollars and any remainder paid as today
        a.wealth+=fwPay;a.yrConvUSD+=fwPay;yrCashSurplus+=fwPay;FWS.next.bizPaid+=fwPay;a._fwPayY=fwPay;
        if(PRICE)PRICE.acc.conv+=fwPay;if(LEDGER)⟦not run⟧}
      if(ESON){a._esPrY=0;if(a._esC>0){  // session 19 (s38, d73): ESP payroll BU converted at the worker's own rate; the premium over face value is conversion income
        var esTx=pjTax(p,a._esR),esG=PATHWAY_OFF.conversion⟦not run⟧:a._esC*a._esR*esCipB*incomeShock,esPr=PATHWAY_OFF.conversion⟦not run⟧:esG*(1-esTx)-a._esC;
        a.wealth+=esPr;a.yrConvUSD+=esPr;yrCashSurplus+=esPr;a._esPrY=esPr;a._esShk=incomeShock;
        if(tbY)TB.cur.ctax+=esG*esTx;var esAc=ESS.acc;esAc.conv+=a._esC/esIdx;esAc.gross+=esG/esIdx;esAc.tax+=esG*esTx/esIdx;esAc.prem+=esPr/esIdx;esAc.rateXbu+=a._esR*a._esC/esIdx;
        if(PRICE)PRICE.acc.conv+=esPr;if(LEDGER)⟦not run⟧}}
      a._fwW=annualWageUSD;FWS.next.wSum+=annualWageUSD;
    }
    if(isNaN(a.wealth))⟦not run⟧
    if(p.ccoOn&&a.inCCO&&FWON){
      /* Session 2, CONVERSION_MODEL 'framework' (N1-N4). No personal BU balance and no conversion of one's own spending:
       * the participant converts the BU directed to projects last year (N2), allocated in proportion to octave capacity
       * x quality, capped at their octave capacity, at their own engine rate and under the engine's progressive tax.
       * The draws above are made exactly as in the engine branch, so the two models stay CRN-paired. */
      if(p.cip&&uCipQuality<p.cipDemo*0.15)a.quality=Math.min(p.maxMult,a.quality+0.1);
      var octCeilF=1+(a.octave/Math.max(1,p.maxOct))*(Math.max(1,p.maxMult)-1),qfF=Math.min(1,a.quality/Math.max(1,p.maxMult));
      var phiF=(p.phi&&a.quality>p.maxMult*CFG.PHI_QUALITY_THRESH)?CFG.PHI_RATIO:1.0,ptfBF=(p.ptf&&a.inPTF)?clPCB(a):1.0;
      var rateF=Math.min((1+qfF*(octCeilF-1))*phiF*ptfBF,p.maxMult*(p.phi?CFG.PHI_RATIO⟦not run⟧));
      var bTaxF=p.cip?p.tax*(1-p.cipDemo*0.18)⟦not run⟧,taxF=Math.min(CFG.PROG_TAX_MAX,bTaxF+Math.max(0,(rateF-CFG.PROG_PIVOT)*CFG.PROG_RATE));
      var cipBF=p.cip?(1+p.cipDemo*0.12)⟦not run⟧,capBU=12*FW.octaveCapBase*Math.pow(2,a.octave);
      if(FWS.prev&&FWS.prev.pwSum>0&&!PJON)⟦not run, 9 lines⟧
      a._fwPW=capBU*Math.max(0,a.quality);FWS.next.pwSum+=a._fwPW;
      if(a.octave<p.maxOct){  // as in the engine branch, except that the monthly basic cost is read before the BU purchase, since BU is added as income here
        var YusdF=a.wage*CFG.WAGE_TO_USD,cBasicF=(dcA*cfPreCCO)/12,edcF=(p.pth&&a.inPTH)?CFG.FBS_EDC_RESIDUAL_PTH:CFG.FBS_EDC_RESIDUAL_BASE;
        var fbsF=Math.max(0,YusdF+buA-cBasicF-edcF*YusdF)/(AUD⟦not run⟧:1),lamF=(typeof a.lambda==='number'&&!isNaN(a.lambda))?a.lambda⟦not run⟧;
        if(p.cip)lamF*=(1+p.cipDemo*CFG.FBS_CIP_LAMBDA_BOOST);
        if(FBS50){if(FBS50.dist!=='lambda'||(FBS50.scale⟦not run⟧)!==1)⟦not run⟧if(FBSS&&tbY){var fbK=!!(a._hh&&a._hh.kids.length);FBSS.n++;if(lamF*fbsF>=Math.LN2)FBSS.a++;if(fbK){FBSS.nK++;if(lamF*fbsF>=Math.LN2)FBSS.aK++;}if(yr===0)FBSS.f.push(Math.LN2/lamF);}}  // v5.3 B7: FBS50 (off by default)
        if(uAdvance<1-Math.exp(-lamF*fbsF)&&!PATHWAY_OFF.octave&&!(OCT⟦not run⟧)){a.octave++;if(OCT)⟦not run⟧}  // plan step 6: OCT gap (sensitivity)
      }
      if(uSzhInduce<clPB(a)⟦not run⟧)⟦not run⟧else if(PDON&&PROD.speed==='oneyear'&&uSzhInduce<clPB(a)⟦not run⟧)⟦not run⟧  // plan step 15: turned away for lack of PTF capacity
    } else if(p.ccoOn&&a.inCCO)⟦not run, 44 lines⟧
    if(PJON&&p.ccoOn&&a.inCCO){  // N1 (session 15): convert project BU (and a holder's own gift) within octave capacity; the rest is saved
      var pjA=PJS.acc,pjCapR=PROJ.cap⟦not run⟧:Infinity,pjE=(a._pjSaved||0)+(a._pjBU||0),pjC1=Math.min(pjE,pjCapR);a._pjSaved=pjE-pjC1;pjCapR-=pjC1;
      var pjGh=a._pjGiftH||0,pjC2=Math.min(pjGh,pjCapR);a._pjGiftH=pjGh-pjC2;if(ACCT)⟦not run⟧
      if(PROJ.cap⟦not run⟧)⟦not run⟧  // project BU fill the capacity the engine's own-spending conversion leaves (that conversion is not capped; at $1,200 BU it never reaches 12,000)
      var rvR=a._pjRu,rvU=false,rvE=0;if(REVIEW⟦not run⟧)⟦not run⟧  // v5.2 step 7: an unearned high rate, caught (paid at 1x) or not
      var pjTx=pjTax(p,rvR),pjG1=PATHWAY_OFF.conversion⟦not run⟧:pjC1*rvR*pjCipB*incomeShock,pjN1=pjG1*(1-pjTx);
      if(REVIEW⟦not run⟧)⟦not run⟧
      var pjTg=pjTax(p,a._pjR),pjG2=PATHWAY_OFF.conversion⟦not run⟧:pjC2*a._pjR*pjCipB*incomeShock,pjN2=pjG2*(1-pjTg);
      if(PROD&&FWON){var pdH=pjC1/pjPay,pdV=pdH*(PROD.match==='face'⟦not run⟧:a.wage*12*CFG.WAGE_TO_USD*incomeShock/PROJ.hrsYr)*(1+(PROD.mat||0));a._pdM=PROD.match==='market'?Math.max(0,rvU⟦not run⟧:pjN1)⟦not run⟧;a._pdMy=a._pdM;a._pdNy=pjN1;a._pdVy=pdV;}  // plan step 2: project output at the cost of the hours (_pd*y: reporting only)
      if(tbY)TB.cur.ctax+=pjG1*pjTx+pjG2*pjTg;a.wealth+=pjN1+pjN2;a.yrConvUSD+=pjN1+pjN2;yrCashSurplus+=pjN1+pjN2;totalConversion+=pjN1+pjN2;totalBU+=pjC1+pjC2;
      if(LABOR&&pjN2)⟦not run⟧  // the holder's gift is an unconditional dollar: the rent channel
      a.yrPjGift=pjN1*pjFg+pjN2;  // d66: gift-funded proceeds, tallied so the testbed can finance them as you go or over the run (the carried share is approximate)
      if(PRICE)PRICE.acc.conv+=pjN1+pjN2;
      pjA.conv+=pjC1/pjIdx;pjA.giftConv+=pjC2/pjIdx;pjA.gross+=(pjG1+pjG2)/pjIdx;pjA.net+=pjN1/pjIdx;pjA.giftNet+=pjN2/pjIdx;
      if(LEDGER)⟦not run⟧
      if(isNaN(a.wealth))⟦not run⟧
    }
    if(p.pth&&a.inPTH&&!PATHWAY_OFF.pthEquity&&!PATHWAY_OFF.pthCost){  // v4.21: pathway switches (off: no routing, no appreciation)
      if(typeof a.pthTenure!=='number'||isNaN(a.pthTenure))⟦not run⟧
      a.pthTenure+=1;
      var cfWithoutPTH=cf/0.65;
      var pthSaving=Math.max(0,dcA*cfWithoutPTH*(1-0.65));
      if(rsAlt)pthSaving=Math.max(0,dcA*(cfPTF-cfPreCCO)*rsRel);  // session 5 (d4/d5): PTH's own cut on the post-relief basket
      var equityContrib=pthSaving*CFG.PTH_EQUITY_CONTRIB_SHARE;
      a.acreEquity+=equityContrib;a.wealth-=equityContrib;yrCashSurplus-=equityContrib;  // session 1: equity routing is not discretionary cash
      var ar=0.030+uPthAppr*0.020+pthApprBonus;var pbS=PTHB&&PBS?a._pbS⟦not run⟧,pbV0=0,pbVn=0;if(pbS){if(!pbS.V){pbS.V=CFG.PTHB_PR*hSA*dcA;pbS.D=pbS.V-(a.acreEquity-equityContrib);}pbV0=pbS.V;pbVn=pbV0*(1+PBS.pi)*(1+CFG.PTHB_G);if(PTHB.cap==='hub')ar=Math.min(pbVn/pbV0-1,PBS.pi+0.02);}  // v5.4 item 3: Acre Equity grows with the home, at most at the price rise + 2%
      var appr=a.acreEquity*ar,lqs=pthLiquidShare(a.pthTenure);
      if(pbS)lqs*=appr>0?Math.max(0,appr-PBS.pi*a.acreEquity)/appr⟦not run⟧;  // v5.4 item 3: only the gain above the price rise is paid out in cash; what keeps up with prices stays as equity
      a.acreEquity+=PTH_APPR_CONSERVE?appr*(1-lqs)⟦not run⟧;a.wealth+=appr*lqs;yrCashSurplus+=appr*lqs;  /* v4.16: PTH_APPR_CONSERVE=false is bit-identical to index.html */
      if(tbY)a._tbPthNow=appr*lqs;  // session 6
      if(LEDGER)⟦not run⟧  // A1 ledger
      if(ACCT)⟦not run⟧  // v5.3 B2
      if(pbS){var pbR=hSA*dcA,pbI=((1+CFG.PTHB_RREAL)*(1+PBS.pi)-1)*pbS.D,pbU=CFG.PTHB_UPK*(1-CFG.PTHB_LAND)*pbV0,pbT=CFG.PTHB_TAX*pbV0,pbL=appr*lqs;  // v5.4 item 3: the trust's books for this home
        pbS.D-=pbR+equityContrib-pbI-pbU-pbT-pbL;pbS.CE+=(pbVn-pbV0)+pbR-pbI-pbU-pbT-appr;pbS.V=pbVn;
        PBS.n++;if(pbR+equityContrib>=pbI-PBS.pi*(pbS.D+pbR+equityContrib-pbI-pbU-pbT-pbL)+pbU+pbT+pbL)PBS.cover++;PBS.aP+=pbV0*PBS.pi/PBS.P;PBS.aR+=pbV0*(1+PBS.pi)*CFG.PTHB_G/PBS.P;PBS.aC+=(pbVn-pbV0-appr)/PBS.P;
        if(ACCT)⟦not run⟧}
      if(PRICE)PRICE.acc.pthLiq+=appr*lqs;  // session 2: price module
    } else if(a.pthTenure)⟦not run, 3 lines⟧
    if(p.ptf&&!a.inPTF&&p.ptfShare>0&&yr>0&&!(HHA&&!a._hhHead)&&ptfCapAllows()){var ap=0.005+CFG.PTF_BASS_Q*(CMS⟦not run⟧:ptfAdoptFrac);if(bleiCheck/(AUD⟦not run⟧:1)<CFG.BLEI_PRECARIOUS_MAX)ap+=0.015;if(uPtfAdopt<ap){a.inPTF=true;if(p.ptfCap)⟦not run⟧if(PDON)pdLive++;}}
    else if(PDON&&PROD.speed==='oneyear'&&p.ptf&&!a.inPTF&&p.ptfShare>0&&yr>0&&!(HHA&&!a._hhHead)&&(!p.ptfCap⟦not run⟧)){var apB=0.005+CFG.PTF_BASS_Q*(CMS⟦not run⟧:ptfAdoptFrac);if(bleiCheck/(AUD⟦not run⟧:1)<CFG.BLEI_PRECARIOUS_MAX)apB+=0.015;if(uPtfAdopt<apB)PDS.blk++;}  // plan step 15: turned away for lack of PTF capacity
    if(SPEND_GRADE&&AUD⟦not run⟧)⟦not run, 2 lines⟧
    if(HHP)a._hhCS=yrCashSurplus;  // v5.3 B3: pooled in hhPool
    if(SURPLUS_CONSUMPTION_SHARE>0&&SURPLUS_CONSUMPTION_BASE==='cash'&&!HHP){var scC=SURPLUS_CONSUMPTION_SHARE*Math.max(0,yrCashSurplus);a.wealth-=scC;if(ACCT)⟦not run⟧if(LEDGER)⟦not run⟧}  // session 1: harness-only
    if(PRICE){  // session 2 (D1/N5): a write-off at the floor is basket consumption that did not happen (unmet need), not spending
      var pmW=(!HHP&&a.wealth<CFG.WEALTH_FLOOR)?CFG.WEALTH_FLOOR-a.wealth:0,pmB=mainLoopCostUSD*cfPreCCO,pmU=pmB>0?Math.min(1,(SPEND_GRADE&&!HHP?pmW+a._grCut:pmW)/pmB)⟦not run⟧,A=PRICE.acc;  /* v5.3 B7: + the spending cut */
      A.n++;A.essD+=1-pmU;A.unmet+=pmW;A.basketOwn+=pmB;if(pmW>0)A.unmetN++;A.Y+=annualWageUSD+a.yrConvUSD+(a.yrSSUSD||0);A.Yw+=annualWageUSD+(a.yrSSUSD||0);if(p.ptf&&a.inPTF)A.ptfN++;
      if(HHP)a._hhPmB=pmB;  // v5.3 B3: a pooled couple's unmet need is counted after pooling (hhPool)
      A.wageBonus+=Math.max(0,a.wage-a._wNB)*12*CFG.WAGE_TO_USD*incomeShock;A.wageBonusNS+=Math.max(0,a.wage-a._wNB)*12*CFG.WAGE_TO_USD;  // session 3: the premium before the income shock, for aw's increment reading
    }
    if(LABOR){a._labC=a._labCn||0;a._labCn=0;if(LABOR.acc){LABOR.acc.conv+=a.yrConvUSD||0;if(a.inCCO)LABOR.acc.convP+=a.yrConvUSD||0;}}  // session 4: creator proceeds carried to next year's labor response
    if(tbY)tbAccount(a,tbY,yr,mainLoopCostUSD,cf,cfPreCCO+hcX,costUSD,annualWageUSD,tbG,tbPT);  // v5.2 step 7: + hcX, so BU spent on the higher rent count as BU relief  // session 6: uniform cost ledger and basket FGT (reporting; no RNG)
    if(ACCT⟦not run⟧)⟦not run⟧  // v5.3 B2: debt written off at the floor
    if(!HHP&&a.wealth<CFG.WEALTH_FLOOR){if(LEDGER)⟦not run⟧a.wealth=CFG.WEALTH_FLOOR;}  // A1 ledger inside the clamp
    if(ACCT⟦not run⟧)⟦not run⟧  // v5.3 B2: this adult's identities for the year
  });
  if(HHON){if(HHPOOL)hhPool(yr,!!tbY);hhSync('ptf');}  // v5.3 B3: couples' end of year (pooling), then partners follow the first adult's PTF decision
  if(FWON){  // session 2, N1: businesses convert this year's accepted BU; the premium over a cash sale is paid out next year
    var nx=FWS.next,bTaxB=p.cip?p.tax*(1-p.cipDemo*0.18)⟦not run⟧;
    var taxR=Math.min(CFG.PROG_TAX_MAX,bTaxB+Math.max(0,(FW.bizRate-CFG.PROG_PIVOT)*CFG.PROG_RATE)),taxP=Math.min(CFG.PROG_TAX_MAX,bTaxB);
    var bzB=ESON?nx.bizBU*(1-ESP.lam)⟦not run⟧;if(ACCT)⟦not run⟧  // session 19 (d71): with ESP payroll the ESP converts the share it keeps; lam of what it accepted is next year's payroll
    nx.bizGross=bzB*(FW.bizCap*FW.bizRate+(1-FW.bizCap));nx.bizTax=bzB*(FW.bizCap*FW.bizRate*taxR+(1-FW.bizCap)*taxP);
    nx.bizNet=PATHWAY_OFF.conversion⟦not run⟧:nx.bizGross-nx.bizTax-bzB;if(tbY)TB.cur.ctax+=nx.bizTax;  // plan step 3: conversion tax kept by the Source (reporting)  // session 7: the conversion switch also covers business-side conversion (harness-only)
    if(LEDGER)⟦not run⟧
    if(ESON){ESS.next={pool:nx.bizBU*ESP.lam};ESS.acc.accBU+=nx.bizBU/esIdx;ESS.acc.ownBU+=bzB/esIdx;ESS.y[yr].acc=nx.bizBU;ESS.y[yr].own=bzB;ESS.y[yr].poolNext=ESS.next.pool;
      if(LEDGER)⟦not run⟧}
    FWS.prev=nx;
  }
  if(ESON)ESS.prev=ESS.next;  // N1 (session 19)
  if(PJON)PJS.prev=PJS.next;  // N1 (session 15)
  if(ACCT)⟦not run⟧  // v5.3 B2: the year's BU stock, the premium paid out and the Source's books
  return{bu:totalBU,conversion:totalConversion,stabOn:stabOn,stabM:stabM,colaF:colaF,buEff:buEff,emergN:emergN};  // v4.19
}


// index.html line 5903
var FULL_INTEGRATION = {
  bu:1200, maxOct:6, expiry:1, tax:0.12, maxMult:9,
  nAgents:500, partRate:0.78, years:20,
  ptfShare:0.18, pthUptake:0.20, szhCoh:0.72, cipDemo:0.65,
  phi:true, ptf:true, pth:true, szh:true, cip:true,
  shock:false, automation:false, inflRate:0, ccoOn:true, ptfCap:false
};

// index.html line 5910
var BASELINE = {
  bu:0, maxOct:1, expiry:1, tax:0, maxMult:1,
  nAgents:500, partRate:0, years:20,
  ptfShare:0, pthUptake:0, szhCoh:0, cipDemo:0,
  phi:false, ptf:false, pth:false, szh:false, cip:false,
  shock:false, automation:false, inflRate:0.03, ccoOn:false, ptfCap:false
};


// index.html line 5947
/* v4.18: CCO Only exactly as simulate() builds pCCO for a given scenario — every CCO setting kept,
 * PTF/PTH/SZH/CIP off. */
function ccoOnlyFor(p){ return Object.assign({}, p, {ptfShare:0, pthUptake:0, szhCoh:0, cipDemo:0, ptf:false, pth:false, szh:false, cip:false}); }

// index.html line 5950
/* The Baseline as simulate() builds it for a given scenario's comparison: shocks and
 * automation follow the scenario, inflation stays at BASELINE_CPI_RATE unless matched. */
function baselineFor(p, matchInfl){ return Object.assign({}, BASELINE, {shock:!!p.shock, automation:!!p.automation, inflRate: matchInfl ? p.inflRate ⟦not run⟧}); }


// index.html line 5958
/* ─── Session 2: the next round's default rule (D1) and the A2 issuance and price module ───────────────
 * NEXT_ROUND: D1, adopted Sep 26 (session-1-handoff.md): consume 0.9 of ALL cash surplus; basket consumption is financed
 * only down to the floor, and a write-off at the floor is reported as unmet need. It is a profile, not a new default for the
 * global switches, so validate/unit/domtest keep testing index.html; the next round's modes apply it (`price`, and
 * `ledger --next`). Setting the share back to 0 restores v4.21. nextRoundPreset(): D6, the hub's 5% COLA trigger, for any
 * preset with CCO on. */
var NEXT_ROUND = {SURPLUS_CONSUMPTION_SHARE:0.9, SURPLUS_CONSUMPTION_BASE:'cash'};

// index.html line 5959
function applyRule(r){ var old = {SURPLUS_CONSUMPTION_SHARE:SURPLUS_CONSUMPTION_SHARE, SURPLUS_CONSUMPTION_BASE:SURPLUS_CONSUMPTION_BASE};
  SURPLUS_CONSUMPTION_SHARE = r.SURPLUS_CONSUMPTION_SHARE; SURPLUS_CONSUMPTION_BASE = r.SURPLUS_CONSUMPTION_BASE; return old; }

// index.html line 5961
function nextRoundPreset(p){ return p.ccoOn ? Object.assign({}, p, {cola:true, colaThresh:CFG.COLA_HUB_THRESH}) ⟦not run⟧; }

// index.html line 5988
/* A2 defaults. Sources and status in session-2-handoff.md; nothing here is tuned to a target.
 *  a        additionality share: the part of conversion-created primary currency matched by new output. Swept [0,1].
 *  lamG     P_G pass-through of unmatched new money, as a share of that year's aggregate cash income: 1 = the quantity-
 *           theory benchmark (velocity 1, matched output permanent). A logged placeholder, swept 0.25-1.
 *  theta    P_E: each essentials price rises by theta x the % gap between effective essentials demand and supply.
 *           housing 0.6: sourced range 0 (Eriksen & Ross 2015, no overall rent effect) to 0.78 (Fack 2006), with Gibbons &
 *           Manning 2006 at 0.60-0.67. food 0: Cunha, De Giorgi & Jayachandran 2019 find cash transfers raise food prices
 *           negligibly where villages are tied to outside markets. medical 0.5: an unsourced, logged placeholder.
 *  ptfCap   the share of PTF's cost reduction that is added real capacity rather than a transferred margin (supply side of
 *           P_E). No evidence yet, so 0 (the plan's rule); swept.
 *  pthUnmatched  PTH appreciation credited to liquid wealth has no counterparty: counted as unmatched new money (a = 0).
 *  floorUnmatched  N5: false = a floor write-off is unmet need, not money; true = the plan's original treatment.
 *  aw       N7: share of program-induced raises (octave, CIP) matched by output. 1 by default. Session 3 (S3-1): the unmatched
 *           part enters U as the year's CHANGE in the aggregate premium (measured before the income shock): a raise paid from
 *           revenue with no added output passes through to prices once, as a level shift. awLevel: true restores session 2's
 *           reading, which counts the whole premium as new money every year (the raise re-created as currency each year).
 *  wIdx     wage indexation to P_G (0 = the engine's nominal drift).
 *  pgOnE    general (monetary) inflation raises essentials prices too. The plan's text reprices essentials by P_E only;
 *           applying P_G to them as well is the conservative reading (flagged in the hand-off).
 *  lines    D2: 'deflate' (both poverty lines move with the price index) or 'nominal'.
 *  supply   essentials supply (N11, new in session 2). 'capacity' (default; the plan's "baseline growth"): capacity is the
 *           matched Baseline's first-year effective demand, growing at gS a year (0: the model has a fixed population and a
 *           fixed real basket), and prices move only with the demand the program adds ABOVE that capacity, net of any
 *           excess the Baseline itself has. 'baseline': capacity is the matched Baseline's demand in the same year. That
 *           reading shrinks capacity whenever the Baseline impoverishes (Adverse: to about half by year 19) and is kept
 *           as an upper bound. */
var PM_DEFAULTS = {a:0, lamG:1, theta:{food:0, housing:0.6, medical:0.5}, ptfCap:0, pthUnmatched:true, floorUnmatched:false,
  aw:1, awLevel:false, wIdx:0, pgOnE:true, noDamp:false, essMatched:false, lines:'deflate', supply:'capacity', gS:0};

// index.html line 5990
function pmOpts(o){ o = o ⟦not run⟧; var r = Object.assign({}, PM_DEFAULTS, o); r.theta = Object.assign({}, PM_DEFAULTS.theta, o.theta || {}); return r; }

// index.html line 5992
/* Pure price rules (tested by priceUnitSuite). */
function pmEssLevel(D, S, cap, theta){ var s = S*(1 + cap); return s > 0 ? Math.max(0, 1 + theta*(D - s)/s) ⟦not run⟧; }

// index.html line 5993
function pmGenStep(PG, U, Y, lam){ return Y > 0 ? PG*(1 + lam*U/Y) ⟦not run⟧; }

// index.html line 5994
function pmBasketIdx(comp){ var b = 1; CFG.BASKET_KEYS.forEach(function(k){ b += CFG.BASKET[k]*(comp[k] - 1); }); return b; }  /* 1 + weighted deviations: exactly 1 when no price moved */

// index.html line 5995
function newPMAcc(){ return {n:0, essD:0, unmet:0, basketOwn:0, unmetN:0, Y:0, Yw:0, ptfN:0, conv:0, pthLiq:0, wageBonus:0, wageBonusNS:0}; }  /* v5.2 step 6: Yw, earned income (wages and Social Security) */

// index.html line 5999
/* One run with the price module. S: the supply path for effective essentials demand (per-agent share of basket consumed,
 * by year), normally the matched Baseline's own path under the same rule; null holds P_E at 1. Draws exactly as
 * runScenario() does. Returns the demand path D (for use as S), the price path, and end-of-run metrics under D2. */
function priceRun(p, seed, o, S){
  o = pmOpts(o);
  var CALM0 = {active:false, incomeMultiplier:1.0, yearsLeft:0};
  RNG = mulberry32(seed + 700003);
  var agents = makeLatentPopulation(p.nAgents).map(function(l){ return instantiateAgent(l, p); });
  if (HOUSEHOLDS) hhInit(agents, seed);  /* v5.3 B3: the same households as the testbed run of this seed */
  var recPath = p.shock ? (REC_SCRIPT ⟦not run⟧ : buildRecessionPath(p.years, seed)) : null;  /* session 9: REC_SCRIPT (comment above tbOpts), so the supply path sees the same scripted path */
  RNG = mulberry32(seed);
  var comp = {}; CFG.BASKET_KEYS.forEach(function(k){ comp[k] = 1; });
  PRICE = {bIdx:1, comp:comp, piG:0, colaLevel:1, lastFull:1, wIdx:o.wIdx, noDamp:o.noDamp, acc:null};
  var PG = 1, D = [], path = [], tot = newPMAcc(), wbPrev = 0, labAcc = null;
  THETA_DENS = null;
  if (o.labor)⟦not run⟧  /* session 5: the joint price and labor run */
  try {
    for (var yr = 0; yr < p.years; yr++){
      PRICE.acc = newPMAcc();
      runYear(agents, yr, p, recPath ? recPath[yr] : CALM0);
      var A = PRICE.acc, d = A.n ? A.essD/A.n ⟦not run⟧; D.push(d);
      Object.keys(tot).forEach(function(k){ tot[k] += A[k]; });
      var wbInc = A.wageBonusNS - wbPrev; wbPrev = A.wageBonusNS;  /* session 3 (S3-1): an unmatched raise is a cost-push level shift, so only the year's change in the premium is new */
      var U = (1 - o.a)*A.conv + (o.pthUnmatched ? A.pthLiq ⟦not run⟧) + (o.floorUnmatched ⟦not run⟧ : 0) + (1 - o.aw)*(o.awLevel ⟦not run⟧ : wbInc);
      var PGn = pmGenStep(PG, U, A.Y, o.lamG), capShare = o.ptfCap*(A.n ? A.ptfN/A.n ⟦not run⟧), PE = {};
      CFG.ESSENTIALS.forEach(function(k){
        var cut = !p.ptf ? 0 ⟦not run⟧;
        if (!S ⟦not run⟧){ PE[k] = 1; return; }⟦not run, 2 lines⟧ ⟦not run⟧;
        var dEff = o.supply === 'baseline' ⟦not run⟧ ⟦not run⟧;
        PE[k] = pmEssLevel(dEff, sRef, capShare*cut, o.theta[k]);
      });
      path.push({bIdx:PRICE.bIdx, PG:PG, PEh:PRICE.comp.housing/(o.pgOnE ? PG ⟦not run⟧), d:d, U:U, Y:A.Y, conv:A.conv, unmet:A.unmet, basketOwn:A.basketOwn, unmetN:A.unmetN/A.n, colaLevel:PRICE.colaLevel});
      PRICE.piG = PGn/PG - 1; PG = PGn;
      CFG.BASKET_KEYS.forEach(function(k){ comp[k] = CFG.ESSENTIALS.indexOf(k) >= 0 ? PE[k]*(o.pgOnE ? PG ⟦not run⟧) : PG; });
      PRICE.bIdx = pmBasketIdx(comp);
    }
  } finally { PRICE = null; if (labAcc) ⟦not run⟧ }
  var T = p.years, full = agents[0].yrBasketUSD/CFG.LIVING_WAGE_ANNUAL/(agents[0]._hhF || 1), lineF = o.lines === 'nominal' ⟦not run⟧ : full, n = agents.length;
  var ws = agents.map(function(a){ return a.wealth; }), pov = 0, bpov = 0;
  ws.forEach(function(w){ if (w < CFG.POVERTY_LINE*lineF) pov++; });
  agents.forEach(function(a){ if (agentBLEI(a, p.bu, p.ccoOn, p.pth, p.szh, p.szhCoh, p.ptf)/lineF < CFG.BLEI_PRECARIOUS_MAX) bpov++; });
  var ib = incomeBasketMetrics(agents), bI = path[T-1].bIdx, mx = 0;
  for (var t = 1; t < T; t++) mx = Math.max(mx, path[t].bIdx/path[t-1].bIdx - 1);
  var colaLast = path[T-1].colaLevel;
  return {D:D, path:path, agents:agents, tot:tot, res:{
    endoAnn: Math.pow(bI, 1/(T - 1)) - 1, endoMax: mx, endoIdx: bI, PG: path[T-1].PG, PEh: path[T-1].PEh, fullIdx: full,
    pov: pov/n*100, bleiPov: bpov/n*100, basketPov: ib.basketPov, medWealthReal: medianOf(ws)/full,
    unmetShare: tot.basketOwn > 0 ? tot.unmet/tot.basketOwn ⟦not run⟧, unmetYears: tot.unmetN/tot.n, convShare: tot.Y > 0 ? tot.conv/tot.Y ⟦not run⟧,
    buReal: p.bu*(p.cola ⟦not run⟧ : 1)/full,
    dE: labAcc ⟦not run⟧ ⟦not run⟧ : 0, labE: labAcc ⟦not run⟧ : 0}};
}

// index.html line 6061
/* ─── Session 3 (Sep 26 2026; Duke assigns the version): A2 sweeps and the breakeven report ─────────────────
 * Harness-only, and nothing here changes a run: these functions only drive priceRun(). CRN makes the mean over a fixed
 * set of seeds a deterministic function of every input, so each point below is an exact mean, not a noisy estimate,
 * and breakeven additionality can be found by a bracketed secant search instead of a coarse grid.
 *  s3BaseS    the matched Baseline's effective-demand path for P_E (the supply side). The Baseline has no conversion,
 *             no PTH and no floor money under the adopted rules, so its prices never move and the path depends only on
 *             the seed, the environment and the consumption rule: cached.
 *  s3Point    per-seed results at one a (kept, for a bootstrap over seeds and the share of seeds above tolerance).
 *  s3Breakeven  the smallest a at which mean endogenous inflation is at or below tol: anchors at a = 1, 0 and 0.9,
 *             then secant steps inside the tightest bracket until it is 0.002 wide or an end is within 0.01 point of
 *             tol; the estimate interpolates the final bracket. 95% interval: 2,000 bootstrap resamples of the seeds at
 *             the two bracket points (linear inside the bracket, which is narrow).
 *  s3Config   one scenario under one sweep row (switches, preset overrides and module options), both tolerances. */
var S3_CACHE = {};

// index.html line 6062
function s3BaseS(p, seed){
  var bp = baselineFor(p, true);
  if (p.years > bp.years) ⟦not run⟧  /* session 33: the supply path covers runs longer than the Baseline's 20 years (unchanged for 20) */
  var k = JSON.stringify(bp) + '|' + SURPLUS_CONSUMPTION_SHARE + '|' + SURPLUS_CONSUMPTION_BASE + '|' + seed + '|' + JSON.stringify(HOUSEHOLDS) + '|' + JSON.stringify(SPEND_GRADE) + (DEBT_READ ⟦not run⟧ : '') + (LW ⟦not run⟧ : '') + (AUD ⟦not run⟧ : '');  /* S14: + the line (key unchanged when off) */  /* S35: + the debt reading (key unchanged when off). v5.3 B3: + households (the reference path of an economy of households); B7: + income-graded spending */
  if (!S3_CACHE[k]) S3_CACHE[k] = priceRun(bp, seed, {}, null).D;
  return S3_CACHE[k];
}

// index.html line 6075
/* ─── Session 4 (Sep 27 2026; Duke assigns the version): A3 labor supply ─────────────────────────────────────────────
 * laborRun   one run with LABOR set to L (null = off). Draws exactly as runScenario() does, so runs are CRN-paired
 *            across every L and preset. Returns end-of-run poverty (wealth, BLEI, basket) and, per agent-year, the
 *            earnings response by channel, the program's gross cost (BU spent on own essentials + conversion + UBI) and,
 *            with wantBound, the BU that expired unconverted (the most extra conversion could draw on).
 * laborStudy the mean over seeds 1..N of laborRun, under the D1 consumption rule (NEXT_ROUND) and D6 COLA. */
function newLabAcc(){ return {n:0, nP:0, E0:0, E:0, raise:0, cash:0, bu:0, buR:0, rent:0, disp:0, C:0, U:0, projH:0, zero:0, conv:0, convP:0}; }

// index.html line 6081
/* ─── Session 6 (A4): testbed runs, presets, matching and tests (harness-only). ─────────────────────────────────────────────
 * NR6, the next-round accounting profile Duke confirmed on Sep 27 (dashboard d22, d23): the D1 consumption rule, plus the three
 * text-versus-engine corrections (theta on realised PTF density, PTH cuts housing only, discounts skip the tax share). TB_RUN adds
 * wage indexation to P_G (d23; applied to every preset, since wage indexation is a property of the economy, not of a program)
 * and the A3 labor response at its central values. The globals keep their v4.21 defaults, so the checks still test index.html. */
var NR6 = {rule:NEXT_ROUND, rs:{THETA_GATE:'density', PTH_MODE:'housing', DISC_BASE:'pretax'}};

// index.html line 6082
function applyNR6(){ return {rule:applyRule(NR6.rule), rs:setRestudy(NR6.rs)}; }

// index.html line 6083
function resetNR6(sv){ applyRule(sv.rule); setRestudy(sv.rs); }

// index.html line 6084
var TB_RUN = {wIdx:1, labor:LABOR_DEFAULTS};

// index.html line 6095
/* Session 9 (Oct 14, 2026; ledger s146; dev/plans/s146-history-check.md; dev/reports/v5-34-history-check.md): A SCRIPTED RECESSION PATH for the history check.
 * REC_SCRIPT null (the default) adds nothing: the testbed draws its recessions as before (buildRecessionPath, its own stream). When an array of
 * {active, incomeMultiplier}, a testbed run with p.shock (and the price run that gives its supply path) uses it, year by year, for every seed and both
 * arms (years past its end are calm); the random path is not built, and since buildRecessionPath draws only from its own stream and restores the main one, no other draw moves. No draw is added. */
var REC_SCRIPT = null;

// index.html line 6097
function tbOpts(o){ o = o ⟦not run⟧; var r = Object.assign({}, PM_DEFAULTS, TB_DEFAULTS, TB_RUN, o); r.theta = Object.assign({}, PM_DEFAULTS.theta, o.theta || {}); return r; }

// index.html line 6099
/* Session 8 (A5): Gini coefficient of a list of incomes (negatives count as 0), the standard sorted-rank formula. */
function giniOfArr(x){ var v = x.map(function(z){ return Math.max(0, +z || 0); }).sort(function(a, b){ return a - b; }), n = v.length, t = 0, w = 0;
  for (var i = 0; i < n; i++){ t += v[i]; w += (i + 1)*v[i]; } return n > 0 && t > 0 ? 2*w/(n*t) - (n + 1)/n ⟦not run⟧; }

// index.html line 6102
/* One testbed run: priceRun()'s loop (same draws, same price rules) with TB set. Returns the run's metrics; see tbStudy for keys. */
function tbRunCore(p, seed, o, S, tau0, yMax){
  var CALM0 = {active:false, incomeMultiplier:1.0, yearsLeft:0};
  RNG = mulberry32(seed + 700003);
  var latent = makeLatentPopulation(p.nAgents); if (LATENT) ⟦not run⟧  /* v5.2 step 5: the readings that close known gaps with US data (no draw added) */
  var agents = latent.map(function(l){ return instantiateAgent(l, p); });
  var recPath = p.shock ? (REC_SCRIPT ⟦not run⟧ : buildRecessionPath(p.years, seed)) : null;  /* session 9: REC_SCRIPT, a fixed recession path (comment above tbOpts) */
  var spec = p.tb ⟦not run⟧, gR = mulberry32(seed + 900001), grp = o.grp ⟦not run⟧;
  var wq = latent.map(function(l){ return l.wage; }).sort(function(x, y){ return x - y; }), w1 = wq[Math.floor(wq.length/3)], w2 = wq[Math.floor(2*wq.length/3)];
  agents.forEach(function(a, i){ var l = latent[i]; a._tbU = gR(); a._tbEl = !!(spec.endow ⟦not run⟧); a._tbPart = l.uCCO < grp.part; a._tbPTH = l.uPTH < grp.pth; a._tbLow = l.wage < w1; a._tbTop = l.wage >= w2; });
  if (EMPL) emplInit(agents, seed);⟦not run⟧
  if (HEALTH)⟦not run⟧ else HLS = null;  /* session 2a: health coverage (no draw on any stream); session 2c: the no-programme run records government's share (d194) */
  if (SNET) snInit(agents, seed);⟦not run⟧  /* session 2b: today's safety net (no draw on any stream) */
  if (PTHB && p.pth) pthbInit(agents, latent, seed); else PBS = null;
  if (DIS) ⟦not run⟧ else DSS = null;  /* v5.4 item 5 */
  if (PTFS && p.ptf) PFS = {r:mulberry32(seed + 600047), cut:0, cn:0, leave:0, mem:0, yrs:0, dens:1}; else PFS = null;  /* v5.4 item 4 */  /* v5.4 item 3: the PTH trust's books */  /* v5.4 item 2: job loss, on its own stream */
  if (HOUSEHOLDS) hhInit(agents, seed);⟦not run⟧  /* v5.3 B3: households drawn once, on their own stream (no draw on the main or construction streams) */
  if (COMM ⟦not run⟧) ⟦not run⟧ else CMS = null;
  if (C22) ⟦not run⟧ else C22S = null;  /* S6: eligibility and automatic distribution (own stream); coverage tallies */  /* S37: the community layer (its own stream; nothing to do without PTF) */
  if (HOUSEHOLDS && HOUSEHOLDS.wealth === 'scf' && spec.endow) ⟦not run⟧  /* v5.3 B7: an endowment's test reads the household's starting wealth */
  var RHH = HOUSEHOLDS && HHS ? hhRepAcc() ⟦not run⟧;  /* v5.3 B3: the household reading's measures (reporting only) */
  EDCS = EDC_MEASURE ? edcNew() ⟦not run⟧;  /* v5.3 B6: the measured EDC (reporting only) */
  FBSS = FBS50 ? {n:0, a:0, nK:0, aK:0, f:[]} ⟦not run⟧;  /* v5.3 B7: FBS50 tallies (reporting only) */
  if (AGE) ⟦not run⟧  /* v5.2 step 4: ages; a new adult gets the same group tests from its own draws */
  else AGS = null;
  if (AGE ⟦not run⟧) ⟦not run⟧  /* v5.3 B4: ages, sexes and the family stream for households with ageing */
  if (AGE ⟦not run⟧) ⟦not run⟧  /* v5.3 B7: wages by age, after every age is set */
  REVS = REVIEW ⟦not run⟧ : null; HCS = null;  /* v5.2 step 7: the review stream and the rent state, per run */
  RNG = mulberry32(seed);
  var comp = {}; CFG.BASKET_KEYS.forEach(function(k){ comp[k] = 1; });
  PRICE = {bIdx:1, comp:comp, piG:0, colaLevel:1, lastFull:1, wIdx:o.wIdx, noDamp:o.noDamp, acc:null};
  TB = {fin:o.fin, tau:tau0, X:o.X, inkindRho:o.inkindRho, neutralGate:o.neutralGate, cur:null, tb:o.taxBase, tauMax:o.tauMax};  /* v5.2 step 7: taxBase 'prog' | 'land' (undefined = the flat contribution) */
  var PG = 1, path = [], wbPrev = 0, labAcc = null, T = p.years;
  var L = {pjg:0, cost:0, cash:0, endow:0, bu:0, conv:0, cutPT:0, cutG:0, cap:0, pth:0, tax:0, need:0, treas:0, f0:0, f1:0, f2:0, n:0, endowTot:0, need0:0, base0:0, pd:0, tgt:0, emp:0, hrs:0, Er:0, bR:0, bP:0,
    bz:0, es:0, n1:0, nP1:0, nN1:0, pyP:0, pyN:0, nWP1:0, esWP:0, convM:0, buIss:0, ctax:0, cutFree:0, bkP:0, bkU:0, bkY:0, ntR:0};  /* session 19 (s38); convM: plan step 2; buIss, ctax: plan step 3; bk*, ntR: v5.2 step 6 */
  THETA_DENS = null;
  var epD0 = housingDistressYear0(agents), epSum = 0;  /* plan step 9: unhoused person-years (reporting only) */
  var BG = tbBleiAcc();  /* session 21 (s41; i10-1): BLEI by group, every year (reporting only, no RNG) */
  var dbt20 = 0, dbt40 = 0;  /* S35: families in debt (reporting only) */
  var R52 = o.rep52 ? tbRepAcc() ⟦not run⟧;  /* v5.2 step 2: Year 7, the poverty line, fixed-dollar lines, the wealth Gini (reporting only, no RNG) */
  if (o.labor){ labAcc = newLabAcc(); LABOR = Object.assign({}, o.labor, {acc:labAcc}); }
  try {
    for (var yr = 0; yr < yMax; yr++){
      PRICE.acc = newPMAcc();
      runYear(agents, yr, p, recPath ? recPath[yr] : CALM0);
      tbBleiYear(BG, agents, p, o, yr === T - 1);
      if (!o.noEP){ var epY = extremePovertyOf(housingDistressOf(agents), epD0, p); epSum += epY ? epY.total/100 ⟦not run⟧; }  /* plan step 9 */  /* session 21 (s41): year-end state, before this year's price step (which moves no agent) */
      if (R52) tbRepYear(R52, agents, p, o, yr, T, (!o.noEP && epY) ? epY.total ⟦not run⟧);  /* v5.2 step 2 */
      if (RHH) hhRepYear(RHH, agents, p, o, yr, T);  /* v5.3 B3 */
      if (yr === 19) dbt20 = tbDebtShare(agents); else if (yr === 39) ⟦not run⟧  /* S35 (reporting only) */
      if (EDCS) edcYear(EDCS, agents, p);  /* v5.3 B6 */
      var A = PRICE.acc, C = TB.cur ⟦not run⟧, d = A.n ? A.essD/A.n ⟦not run⟧, tauUsed = TB.tau;
      var wbInc = A.wageBonusNS - wbPrev; wbPrev = A.wageBonusNS;
      var extra = (o.floorUnmatched ⟦not run⟧ : 0) + (1 - o.aw)*(o.awLevel ⟦not run⟧ : wbInc);
      if (yr === 0) L.endowTot = C.endow;
      /* d26: what the treasury must fund this year: every program dollar at face value (the endowment amortized over the run),
       * less the efficiency share eP of price cuts (added capacity, not a transfer; 0 by the plan's rule). */
      /* d66 (sessions 15-16; issue i7): the launch gift's proceeds are one-time spending. 'payg' (Duke's pick) finances them in the
       * year they are paid, like every other conversion; 'run' spreads them over the remaining years, like the endowment (d26). */
      L.pjg += C.pjg; var gRun = !!(PROJ && PROJ.giftFin === 'run');
      var need = C.cash + L.endowTot/T + (o.fin === 'source' ? 0 : C.bu) + (o.fin === 'hybrid' || o.fin === 'source' ? 0 : gRun ⟦not run⟧ : C.conv) + C.cap + (1 - o.eP)*(C.cutPT - C.cutFree + C.cutG) + C.pthLiq, U;  /* plan step 3: the Source pays every conversion (BU face value included) */  /* session 7 (d26): hybrid leaves conversion rewards to money creation */
      /* d24: created money counted by one rule for every design. aT: output matched to transfer dollars (cash, BU spent at face
       * value, the endowment, capital spending); a: output matched to conversion rewards (H1); eP: price-cut efficiency. */
      /* Session 7 (d24 option b, o.buAtA): output matched at a to a converted BU's face value as well as its reward. */
      if (o.fin === 'money') ⟦not run⟧
      else if (o.fin === 'tax') U = extra + (o.taxBase ⟦not run⟧ : 0);  /* v5.2 step 7: the progressive and land taxes pay what they can (marginal rates capped at tauMax); the Source pays the rest as new money */
      else if (o.fin === 'source'){ var cvS = gRun ⟦not run⟧ : C.conv, bkP = (o.faceM ⟦not run⟧ : C.bu) + cvS - C.convM, bkU = (1 - o.a)*bkP;  /* v5.2 step 7: with the gift over the run, the Source's new money for the launch gift is spread over the run (d66's 'run', as for the contribution) */  /* plan step 3 (S1-S6): the Source's net payout is new money, less output that backs it; faceM: essentials bought with BU count as backed */
        if (o.aK) ⟦not run⟧  /* v5.2 step 6 (decision B): the middle reading; output backs the payout up to aK of the year's earned income (CFG.KENYA_ABSORB_*) */
        U = bkU + extra; L.bkP += bkP/C.idx; L.bkU += bkU/C.idx; L.bkY += A.Yw/C.idx;
        if (ACCT ⟦not run⟧)⟦not run⟧ }⟦not run, 3 lines⟧  /* 'none': the session 2-5 rule (transfers and price cuts unfinanced) */
      if (yr === 0){ L.need0 = need; L.base0 = C.base; if (C.Es)⟦not run⟧ }  /* v5.2 step 7: year 0's earnings for the progressive schedule (its brackets are in year-0 terms) */
      if (MULT && MLS && MLS.y[yr] && MLS.y[yr].ntR) ⟦not run⟧  /* v5.2 step 6: wages added by filling normal-times slack (year-0 $) */
      if (MULT && MLS) MLS.push = o.fin === 'source' ? Math.max(0, C.bu + C.conv - C.ctax) ⟦not run⟧;  /* plan step 16: next year's push, the net Source payout */
      L.cost += (C.cash + C.endow + C.bu + C.conv + C.cap + C.cutPT - C.cutFree + C.cutG + C.pthLiq)/C.idx; L.cutFree += C.cutFree/C.idx;  /* plan step 5: the PTF discount funded by forgone profit is not programme cost */
      L.cash += C.cash/C.idx; L.endow += C.endow/C.idx; L.bu += C.bu/C.idx; L.conv += C.conv/C.idx; L.cutPT += C.cutPT/C.idx; L.cutG += C.cutG/C.idx; L.cap += C.cap/C.idx; L.pth += C.pthLiq/C.idx;
      L.pd += C.pd/C.idx; L.tgt += C.tgt/C.idx; L.tax += C.tax/C.idx; L.need += need/C.idx; L.treas += (C.tax - need)/C.idx; L.f0 += C.f0; L.f1 += C.f1; L.f2 += C.f2; L.n += C.n;
      L.emp += C.emp; L.hrs += C.hrs; L.Er += C.E/C.idx; L.bR += C.bR; L.bP += C.bP;  /* session 8 (A5): employment, hours, real wage earnings */
      L.convM += C.convM/C.idx; L.buIss += C.buIss/C.idx; L.ctax += C.ctax/C.idx;  /* plan steps 2-3 */
      L.bz += C.bz/C.idx; L.es += C.es/C.idx; L.pyP += C.pyP/C.idx; L.pyN += C.pyN/C.idx; L.esWP += C.esWP/C.idx; L.n1 += C.n1; L.nP1 += C.nP1; L.nN1 += C.nN1; L.nWP1 += C.nWP1;  /* session 19 */
      if (o.fin === 'tax' || o.fin === 'hybrid' || o.fin === 'source'){
        if (o.taxBase === 'prog' ⟦not run⟧ ⟦not run⟧)⟦not run⟧  /* v5.2 step 7: the brackets move with mean earnings (as the Social Security wage base does), not with prices */
        TB.tau = C.base > 0 ? (o.taxBase === 'prog' ⟦not run⟧ : Math.min(o.tauMax, need/C.base)) ⟦not run⟧; }  /* v5.2 step 7: for the progressive tax, the multiplier on the schedule that raises need (its marginal rates are capped instead) */
      var PGn = pmGenStep(PG, U, A.Y, o.lamG), capShare = o.ptfCap*(A.n ? A.ptfN/A.n ⟦not run⟧), PE = {};
      CFG.ESSENTIALS.forEach(function(k){
        var cut = !p.ptf ? 0 : PTF_MODE === 'shipped' ? (p.szh ? 0.12 + p.szhCoh*0.04 ⟦not run⟧) ⟦not run⟧;
        if (!S || o.essMatched)⟦not run⟧
        var sRef = o.supply === 'baseline' ⟦not run⟧ : S[0]*Math.pow(1 + o.gS, yr);
        var dEff = o.supply === 'baseline' ⟦not run⟧ : sRef + Math.max(0, d - sRef) - Math.max(0, S[yr] - sRef);
        PE[k] = pmEssLevel(dEff, sRef, capShare*cut, k === 'medical' && HEALTH ⟦not run⟧ ⟦not run⟧ ⟦not run⟧ : o.theta[k]);  /* session 2a, d-health-price rule a: under single payer the public payer sets rates (a shortage shows as waits); this step sets next year's prices */
      });
      path.push({bIdx:PRICE.bIdx, PG:PG, U:U, Y:A.Y, tau:tauUsed, colaLevel:PRICE.colaLevel, full:C.idx});  /* session 8: full price level (exogenous x endogenous) */
      PRICE.piG = PGn/PG - 1; PG = PGn;
      CFG.BASKET_KEYS.forEach(function(k){ comp[k] = CFG.ESSENTIALS.indexOf(k) >= 0 ? PE[k]*(o.pgOnE ? PG ⟦not run⟧) : PG; });
      PRICE.bIdx = pmBasketIdx(comp);
    }
  } finally { PRICE = null; TB = null; if (labAcc) LABOR = null; }
  if (yMax < T) return {tau0: L.base0 > 0 ? (o.taxBase === 'prog' ⟦not run⟧ : Math.min(o.tauMax, L.need0/L.base0)) ⟦not run⟧};
  var n = agents.length, NY = n*T, full = agents[0].yrBasketUSD/CFG.LIVING_WAGE_ANNUAL/(agents[0]._hhF || 1), lineF = o.lines === 'nominal' ⟦not run⟧ : full, pov = 0, bpov = 0, g0 = 0, g1 = 0, g2 = 0;
  var nbpov = 0;  /* session 7 (d28): design-neutral BLEI, Baseline rules plus one month of the design's regular support (the d28 gate's measure) */
  agents.forEach(function(a){ if (a.wealth < CFG.POVERTY_LINE*lineF) pov++; if (agentBLEI(a, p.bu, p.ccoOn, p.pth, p.szh, p.szhCoh, p.ptf)/lineF < CFG.BLEI_PRECARIOUS_MAX) bpov++;
    if ((agentBLEI(a, 0, false, false, false, 0, false) + (a._tbM || 0)/CFG.BASE_DAILY_COST)/lineF < CFG.BLEI_PRECARIOUS_MAX) nbpov++;
    var g = a._tbGap || 0; if (g > 0) g0++; g1 += g; g2 += g*g; });
  /* Groups: mean real resources per year, person-year basket FGT0, and wealth poverty at year 20 (the inflation tax on nominal wealth
   * shows only here: income terms are indexed, wealth is not). */
  function grpOf(f){ var m = 0, k = 0, f0 = 0, f2 = 0, wp = 0; agents.forEach(function(a){ if (f(a)){ k++; m += a._tbRes/a._tbYrs; f0 += a._tbF0/a._tbYrs; f2 += (a._tbF2 || 0)/a._tbYrs; if (a.wealth < CFG.POVERTY_LINE*lineF) wp++; } });
    return k ? {res:m/k, f0:f0/k*100, f2:f2/k*100, wp:wp/k*100, k:k} ⟦not run⟧; }  /* session 21 (s41): + person-year FGT2 (f2) */
  var gP = grpOf(function(a){ return a._tbPart; }), gN = grpOf(function(a){ return !a._tbPart; }), gH = grpOf(function(a){ return a._tbPTH; }), gL = grpOf(function(a){ return a._tbLow; }), gT = grpOf(function(a){ return a._tbTop; });
  /* Session 8 (A5): spells, persistence, and the year-20 income distribution (reporting only). */
  var sp = 0, spY = 0, ever = 0, chron = 0; agents.forEach(function(a){ sp += a._tbSp || 0; spY += a._tbF0 || 0; if (a._tbF0 > 0) ever++; if ((a._tbF0 || 0) >= T/2) chron++; });
  var gcF = o.giniNN1 && n > 1 ? n/(n - 1) ⟦not run⟧;  /* v5.2 step 2: the n/(n - 1) correction (x 1 exactly when off) */
  var giniD = giniOfArr(agents.map(function(a){ return a._tbDisp || 0; }))*gcF, giniX = giniOfArr(agents.map(function(a){ return a._tbExt || 0; }))*gcF;
  var pT = path[T-1], p10 = path[Math.min(T-1, 9)], realT = (p.cola ? pT.colaLevel ⟦not run⟧)/pT.full;
  function pjQ(k){ return (PROJ && PJS && PJS.acc.partY > 0) ? PJS.acc[k]/PJS.acc.partY : 0; }  /* N1 (session 15) */
  var pjSv = 0; if (PROJ && PJS && PJS.acc.partY > 0){ agents.forEach(function(a){ pjSv += (a._pjSaved || 0) + (a._pjGiftH || 0); }); pjSv /= Math.max(1, PJS.acc.partY/T); }
  var esOn = !!(ESP && ESS && CONVERSION_MODEL === 'framework'), eA = esOn ? ESS.acc : null;  /* session 19 (s38) */
  var spOn = !!(SURP && SPS && CONVERSION_MODEL === 'framework'), sA = spOn ? SPS.acc : null;  /* plan step 1 */
  function spQ(k){ return spOn && L.n1 ? sA[k]/L.n1 : 0; }
  var jnOn = !!(JOIN && JNS && CONVERSION_MODEL === 'framework' && p.ccoOn); function jnQ(y){ return jnOn && JNS.y[y] ? JNS.y[y].part*100 : 0; }  /* plan step 4 */
  function pdQ(y, k){ return (PROD && PDS && PDS.y[y] && CONVERSION_MODEL === 'framework') ? PDS.y[y][k]*100 : 0; }  /* plan step 2 */
  var bI = path[T-1].bIdx, mx = 0, tauS = 0;
  for (var t = 1; t < T; t++) mx = Math.max(mx, path[t].bIdx/path[t-1].bIdx - 1);
  path.forEach(function(q){ tauS += q.tau; });
  var emR = EMPL && EMS ? emplRes({}) ⟦not run⟧;  /* v5.4 item 2 */
  if (PTHB) emR = pthbRes(emR ⟦not run⟧);
  if (PTFS) emR = ptfsRes(emR ⟦not run⟧);  /* v5.4 item 4 */
  if (COMM) ⟦not run⟧  /* S37 */
  if (C22) ⟦not run⟧  /* S6 */
  if (HEALTH ⟦not run⟧) ⟦not run⟧  /* session 2a */
  if (SNET && SNS) emR = snRes(emR ⟦not run⟧);  /* session 2b */
  if (DIS) ⟦not run⟧  /* v5.4 item 5 */
  var plv = {}; TB_PLV_KEYS.forEach(function(k, t){ plv[k] = t < path.length ? path[t].full : 0; });  /* S35 (reporting only) */  /* v5.4 item 3 (zeros in the no-programme run) */
  return {path:path, res:Object.assign(fbsRes(FBSS, edcRes(EDCS, hhRes(RHH, tbRepRes(R52, tbBleiRes(BG, {
    endoAnn:Math.pow(bI, 1/(T - 1)) - 1, endoMax:mx, pov:pov/n*100, bleiPov:bpov/n*100, nbleiPov:nbpov/n*100, tgt:L.pd > 0 ? L.tgt/L.pd : 0, medWealthReal:medianOf(agents.map(function(a){ return a.wealth; }))/full,
    fgt0:g0/n*100, fgt1:g1/n*100, fgt2:g2/n*100, fgt0PY:L.f0/L.n*100, fgt1PY:L.f1/L.n*100, fgt2PY:L.f2/L.n*100,
    cost:L.cost/NY, cCash:L.cash/NY, cEndow:L.endow/NY, cBU:L.bu/NY, cConv:L.conv/NY, cCut:(L.cutPT + L.cutG)/NY, cCap:L.cap/NY, cPth:L.pth/NY,
    tax:L.tax/NY, need:L.need/NY, treas:L.treas/NY, tauMean:tauS/T, tauLast:path[T-1].tau,
    dE:labAcc && labAcc.E0 > 0 ? (labAcc.E - labAcc.E0)/labAcc.E0 ⟦not run⟧, E:labAcc ? labAcc.E/Math.max(1, labAcc.n) ⟦not run⟧, E0:labAcc ? labAcc.E0/Math.max(1, labAcc.n) ⟦not run⟧, zero:labAcc ? labAcc.zero/Math.max(1, labAcc.n) ⟦not run⟧,
    gPartRes:gP.res, gPartF0:gP.f0, gNonRes:gN.res, gNonF0:gN.f0, gPthRes:gH.res, gPthF0:gH.f0, gLowRes:gL.res, gLowF0:gL.f0, gTopRes:gT.res, gTopF0:gT.f0,
    gPartW:gP.wp, gNonW:gN.wp, gPthW:gH.wp, gLowW:gL.wp, gTopW:gT.wp,
    pyPoor:spY/n, everPoor:ever/n*100, spellMean:sp > 0 ? spY/sp ⟦not run⟧, chronic:chron/n*100, emp:L.emp/L.n*100, hrs:L.hrs/L.n - 1, Er:L.Er/NY,
    giniD:giniD, giniX:giniX, pLev10:p10.full, pLev20:pT.full, realT:realT, bleiR:L.bR/L.n*100, bleiP:L.bP/L.n*100,
    /* N1 (session 15): project hiring, per participant-year, year-0 dollars (0 when PROJ is off) */
    pjNet:pjQ('net'), pjGift:pjQ('giftNet'), pjBU:pjQ('alloc'), pjExp:pjQ('exp'), pjHrs:pjQ('hrs'), pjDisp:pjQ('disp'), pjWork:pjQ('work')*100,
    pjRc:(PROJ && PJS && PJS.acc.rcN) ? PJS.acc.rc/PJS.acc.rcN : 0, pjSaved:pjSv,
    /* Session 19 (s38): the business premium and ESP payroll, years 1-19, year-0 dollars. bzPay: the ESP's own premium as paid out
     * (today's whole premium when ESP is off); esPrem: payroll premium; per adult-year, participant-year, non-participant-year and
     * participating ESP worker-year. From ESS (0 when ESP is off): payroll BU per ESP worker-year, BU share of ESP pay (%), mean rate
     * on payroll BU, the share of participating ESP worker-years where the octave cap binds (%), and BU converted or returned per
     * adult-year. */
    bzPay:L.n1 ? L.bz/L.n1 ⟦not run⟧, esPrem:L.n1 ? L.es/L.n1 ⟦not run⟧, payPart:L.nP1 ? L.pyP/L.nP1 : 0, payNon:L.nN1 ? L.pyN/L.nN1 ⟦not run⟧, esPremW:L.nWP1 ? L.esWP/L.nWP1 : 0,
    esBUW:eA && eA.wkY1 ? eA.alloc/eA.wkY1 : 0, esShare:eA && eA.wage > 0 ? eA.alloc/eA.wage*100 : 0, esRate:eA && eA.conv > 0 ? eA.rateXbu/eA.conv : 0,
    esCapB:eA && eA.partWkY ? eA.capBind/eA.partWkY*100 : 0, esConv:eA && L.n1 ? eA.conv/L.n1 : 0, esRet:eA && L.n1 ? eA.ret/L.n1 : 0,
    /* Session 21 (s41): person-year FGT2 (x100) and size by group; BLEI by group (tbBleiRes adds the b* keys) */
    gPartF2:gP.f2, gNonF2:gN.f2, gPartK:gP.k, gNonK:gN.k,
    /* Plan step 1 (Oct 1, 2026): the ESP surplus split, years 1-19, year-0 dollars per adult-year unless stated (0 when SURP is off). spSw: the
     * first year of phase 2 (99 = never); spCap: the capital account per adult at the end (year-0 $); spD1/spD2: mean cut by phase (%); spNon: share
     * of the pool reaching non-participants (%, cuts and dollars); spPtfS: the PTFs' share of the pool (%). */
    spPool:spQ('pool'), spOwn:spQ('own'), spPtfS:spOn && sA.pool > 0 ? sA.ptf/sA.pool*100 : 0, spCut:spQ('cut'), spCutN:spQ('cutN'), spFreed:spQ('freed'), spCash:spQ('cash'),
    spProfit:spQ('profit'), spProfW:spOn && sA.wkY1 ? sA.profitN/sA.wkY1 : 0, spReinv:spQ('reinv'), spRest:spQ('rest'), spCap:spOn ? SPS.capPA : 0, spSw:spOn ? (SPS.sw < 0 ? 99 : SPS.sw) : 0,
    spD1:spOn && sA.n1 ? sA.d1/sA.n1*100 : 0, spD2:spOn && sA.n2 ? sA.d2/sA.n2*100 : 0, spNon:spOn && sA.pool > 0 ? (sA.non + sA.cutN)/sA.pool*100 : 0, spCarry:spOn ? sA.carry/n : 0,
    /* Plan step 2: PTF capacity share at the start of years 5, 10 and 19 and PTF members' share in year 19 (%); matched output as a share of conversion (%) */
    pdC5:pdQ(5, 'cap'), pdC10:pdQ(10, 'cap'), pdC19:pdQ(T - 1, 'cap'), pdMem19:pdQ(T - 1, 'mem'), pdMatch:L.conv > 0 ? L.convM/L.conv*100 : 0,
    /* Plan step 3: the Source's ledger, year-0 dollars per adult-year: BU issued, dollars paid at conversion (BU face value spent + conversion
     * proceeds), conversion tax kept, output backing (matched), and the tax kept as a share of the BU issued (%). */
    srcIss:L.buIss/NY, srcPay:(L.bu + L.conv)/NY, srcTax:L.ctax/NY, srcM:L.convM/NY, srcCover:L.buIss > 0 ? L.ctax/L.buIss*100 : 0,
    /* Plan step 4: participation share at years 5, 10 and 19 (%), and joins and leaves over the run per 100 adults */
    jnP5:jnQ(5), jnP10:jnQ(10), jnP19:jnQ(T - 1), jnJoin:jnOn ? JNS.join/n*100 : 0, jnLeave:jnOn ? JNS.leave/n*100 : 0,
    csFree:L.cutFree/NY, epPY:epSum/T*100,
    /* v5.2 step 4: ageing (0 when AGE is off): retired share at the end (%), mean age at the start and the end, deaths per 1,000 adult-years, new adults over the run (% of the population) */
    agRet:AGE ⟦not run⟧ ⟦not run⟧ : 0, agAge0:AGE ⟦not run⟧ ⟦not run⟧ : 0, agAge:AGE ⟦not run⟧ ⟦not run⟧ : 0,
    agDeaths:AGE ⟦not run⟧ ⟦not run⟧ : 0, agBorn:AGE ⟦not run⟧ ⟦not run⟧ : 0, svInt:SAVE ⟦not run⟧ ⟦not run⟧ : 0, svIntR:SAVE ⟦not run⟧ ⟦not run⟧ : 0,
    bkA:L.bkP > 0 ? (1 - L.bkU/L.bkP)*100 : 0, bkPY:L.bkY > 0 ? L.bkP/L.bkY*100 : 0, mlNT:L.ntR/NY,
    hcM:HCAP ⟦not run⟧ ⟦not run⟧ : 0, rvX:REVS ⟦not run⟧ : 0, rvC:REVS ⟦not run⟧ : 0, taxAvg:L.Er > 0 ? L.tax/L.Er*100 ⟦not run⟧,  /* v5.2 step 7: mean rent mark-up outside PTH (%), unearned pay not caught and pay clawed back by audits (year-0 $ per adult-year), the contribution as a share of wages (%) */  /* v5.2 step 6: the share of the Source's net payout backed by output (%), that payout as a share of earned income (%), and wages added by filling normal-times slack (year-0 $ per adult-year) */
    hhDebt20:dbt20, hhDebt40:dbt40,  /* S35 */
    octMean:agents.reduce(function(m, a){ return m + (a.inCCO ? a.octave : 0); }, 0)/Math.max(1, agents.filter(function(a){ return a.inCCO; }).length)}))))), emR ⟦not run⟧, plv)};  /* plan step 6: mean octave of participants at year 20 */  /* plan step 5: PTF discount funded by forgone profit, year-0 $ per adult-year */
}

// index.html line 6279
function tbRun(p, seed, o, S){
  o = tbOpts(o);
  var tau0 = ((o.fin === 'tax' || o.fin === 'hybrid' || o.fin === 'source') && p.tb) ? tbRunCore(p, seed, o, S, 0, 1).tau0 ⟦not run⟧;
  return tbRunCore(p, seed, o, S, tau0, p.years);
}

// index.html line 6284
var TB_KEYS = ['endoAnn','endoMax','pov','bleiPov','nbleiPov','tgt','medWealthReal','fgt0','fgt1','fgt2','fgt0PY','fgt1PY','fgt2PY','cost','cCash','cEndow','cBU','cConv','cCut','cCap','cPth',
  'tax','need','treas','tauMean','tauLast','dE','E','E0','zero','gPartRes','gPartF0','gNonRes','gNonF0','gPthRes','gPthF0','gLowRes','gLowF0','gTopRes','gTopF0',
  'gPartW','gNonW','gPthW','gLowW','gTopW','pyPoor','everPoor','spellMean','chronic','emp','hrs','Er','giniD','giniX','pLev10','pLev20','realT','bleiR','bleiP',
  'pjNet','pjGift','pjBU','pjExp','pjHrs','pjDisp','pjWork','pjRc','pjSaved',  /* N1 (session 15) */
  'bzPay','esPrem','payPart','payNon','esPremW','esBUW','esShare','esRate','esCapB','esConv','esRet',  /* N1 (session 19, s38) */
  'gPartF2','gNonF2','gPartK','gNonK',
  'spPool','spOwn','spPtfS','spCut','spCutN','spFreed','spCash','spProfit','spProfW','spReinv','spRest','spCap','spSw','spD1','spD2','spNon','spCarry',
  'pdC5','pdC10','pdC19','pdMem19','pdMatch','srcIss','srcPay','srcTax','srcM','srcCover','jnP5','jnP10','jnP19','jnJoin','jnLeave','csFree','octMean','epPY','svInt','svIntR','agRet','agAge0','agAge','agDeaths','agBorn','bkA','bkPY','mlNT','hcM','rvX','rvC','taxAvg'].concat(TB_PROG_KEYS, TB_REP_KEYS, TB_BLEI_DEFS.reduce(function(r, d){ TB_BLEI_GRPS.forEach(function(g){ ['Py','Cr','20','Md'].forEach(function(m){ r.push('b' + d + g + m); }); }); return r; }, []));  /* session 21 (s41) */

// index.html line 6296
/* Paired study over seeds 1..N (optionally lo..hi). envP: the Compassionism scenario that defines the environment, the essentials
 * supply path (its matched Baseline, as in sessions 2-5) and the groups (participants: latent uCCO < its partRate; PTH members:
 * latent uPTH < its pthUptake, the same agents in every design). cfgs: [{p, o, cm, pw}]; pw switches PATHWAY_OFF entries for that
 * row only (d19). Returns means and per-seed arrays. */
function tbStudy(cfgs, N, envP, o0, lo){
  if (o0 && typeof o0.sc === 'number'){ var scS = SURPLUS_CONSUMPTION_SHARE; SURPLUS_CONSUMPTION_SHARE = o0.sc;  /* plan step 7: a study-level spending rule (the supply path and every row) */
    try { var oS = Object.assign({}, o0); delete oS.sc; return tbStudy(cfgs, N, envP, oS, lo); } finally { SURPLUS_CONSUMPTION_SHARE = scS; } }
  lo = lo ⟦not run⟧; var M = N - lo + 1, grp = {part:envP.partRate, pth:envP.pthUptake};
  var out = cfgs.map(function(){ var r = {_s:{}}; TB_KEYS.forEach(function(k){ r[k] = 0; r._s[k] = new Float64Array(M); }); return r; });
  for (var sd = lo; sd <= N; sd++){
    var S = s3BaseS(envP, sd); HL_GOVREF = {};  /* session 2c (d194): each seed's no-programme health runs record government's share for its programme runs */
    cfgs.forEach(function(c, i){ var lw0 = lwSet(c.lw);  /* S14: the cost-of-living line for this row (first, so project pay follows it) */
      var cm0 = CONVERSION_MODEL, pw0 = Object.assign({}, PATHWAY_OFF); if (c.cm) CONVERSION_MODEL = c.cm;
      if (c.pw) Object.assign(PATHWAY_OFF, c.pw);  /* d19: e.g. {octaveWage:true}, the octave wage bonus off for this row only */
      var g0 = tbSetG(c.g);  /* session 7: per-row engine-question switches (i3), restored below */
      var pj0 = PROJ; if (c.pj) PROJ = Object.assign({}, PROJ_DEFAULTS, c.pj === true ⟦not run⟧ : c.pj);  /* N1 (session 15): project hiring for this row only */
      var es0 = ESP; if (c.es) ESP = Object.assign({}, ESP_DEFAULTS, c.es === true ⟦not run⟧ : c.es);  /* N1 (session 19): ESP payroll for this row only */
      var sp0 = SURP; if (c.sp) SURP = Object.assign({}, SURP_DEFAULTS, c.sp === true ⟦not run⟧ : c.sp);  /* plan step 1: the ESP surplus split for this row only */
      var pd0 = PROD; if (c.pd) PROD = Object.assign({}, PROD_DEFAULTS, c.pd === true ⟦not run⟧ : c.pd);  /* plan step 2: the production side for this row only */
      var sc0 = SURPLUS_CONSUMPTION_SHARE; if (typeof c.sc === 'number') SURPLUS_CONSUMPTION_SHARE = c.sc;  /* plan step 7: the spending rule for this row only */
      var oc0 = OCT; if (c.oc) ⟦not run⟧  /* plan step 6 */
      var cs0 = COST; if (c.cs) COST = Object.assign({}, COST_DEFAULTS, c.cs === true ⟦not run⟧ : c.cs);  /* plan step 5 */
      var jn0 = JOIN; if (c.jn) JOIN = Object.assign({}, JOIN_DEFAULTS, c.jn === true ⟦not run⟧ : c.jn);  /* plan step 4: joining and leaving for this row only */
      var ml0 = MULT; if (c.ml) MULT = Object.assign({}, MULT_DEFAULTS, c.ml === true ⟦not run⟧ : c.ml);  /* plan step 16: the spending layer for this row only */
      var gc0 = GATE_CURRENT; if (typeof c.gc === 'boolean') GATE_CURRENT = c.gc;  /* audit V5-02: the framework BLEI gate reads this year's BU, for this row only */
      var sv0 = SAVE; if (c.sv) ⟦not run⟧  /* v5.2 step 3: savings that keep up with prices, for this row only (no programme rows too) */
      var ag0 = AGE; if (c.ag) ⟦not run⟧  /* v5.2 step 4: ageing, for this row only (no programme rows too) */
      var hc0 = HCAP; if (c.hc) ⟦not run⟧  /* v5.2 step 7: housing capture for this row ({c, all}) */
      var rv0 = REVIEW; if (c.rv) ⟦not run⟧  /* v5.2 step 7: review errors and collusion for this row */
      var bs0 = BU_SCOPE; if (c.bs) BU_SCOPE = c.bs;  /* v5.3 B3f: what BU can buy, for this row ('core' | 'hub') */
      var em0 = EDC_MEASURE; if (c.em) EDC_MEASURE = true;  /* v5.3 B6: the measured EDC for this row (reporting only) */
      var au0 = AUD; if (c.au) ⟦not run⟧  /* S13: the audit's corrections for this row (no programme rows too) */
      var dr0 = DEBT_READ; if (c.dr) ⟦not run⟧  /* S35: the debt reading for this row (no programme rows too) */
      var cl0 = COMM; if (c.cl) ⟦not run⟧  /* S37: the community layer for this row */
      var c220 = C22; if (c.c22) ⟦not run⟧  /* S6: coverage and adequacy for this row */
      var sg0 = SPEND_GRADE; if (c.sg) SPEND_GRADE = {eps:typeof c.sg === 'number' ⟦not run⟧ : CFG.CE_SPEND_ELAST};  /* v5.3 B7: income-graded spending for this row (no programme rows too) */
      var fb0 = FBS50; if (c.fb) FBS50 = Object.assign({dist:'lambda', scale:1}, c.fb === true ? {} ⟦not run⟧);  /* v5.3 B7: FBS50 for this row */
      var hh0 = HOUSEHOLDS; if (c.hh) HOUSEHOLDS = Object.assign({}, HH_DEFAULTS, c.hh === true ⟦not run⟧ : c.hh);  /* v5.3 B3: households for this row ({} = the defaults) */
      var v540 = tbSetV54(c.v54);  /* v5.4: the round's switches for this row */
      var hl0 = HEALTH; if (c.hl) ⟦not run⟧  /* session 2a: the health setting for this row (no programme rows too) */
      var sn0 = SNET; if (c.sn) SNET = Object.assign({}, SNET_DEFAULTS, c.sn === true ⟦not run⟧ : c.sn);  /* session 2b: today's safety net for this row */
      var pv0 = PREV; if (c.pv) ⟦not run⟧  /* session 2c: the prevention link for this row */
      var lt0 = LATENT; if (c.lt) ⟦not run⟧  /* v5.2 step 5: {w, r, s, m} flags; S34: s, m 'all' or 'ft' read the CPS's earnings (CFG.CPS_EARN) */
      try { var r = tbRun(c.p, sd, Object.assign({grp:grp}, o0 ⟦not run⟧, c.o || {}), HOUSEHOLDS ⟦not run⟧ ⟦not run⟧ ? s3BaseS(envP, sd) ⟦not run⟧).res;  /* v5.3 B3: a household row's supply reference is the no-programme economy of households (B7: likewise with income-graded spending) */
        TB_KEYS.forEach(function(k){ out[i][k] += r[k]/M; out[i]._s[k][sd - lo] = r[k]; });
        if (r.fbsAbove !== undefined) FBS_KEYS.forEach(function(k){ if (!out[i]._s[k]){ out[i][k] = 0; out[i]._s[k] = new Float64Array(M); } out[i][k] += r[k]/M; out[i]._s[k][sd - lo] = r[k]; });  /* v5.3 B7 */
        if (r.dsHit !== undefined) ⟦not run⟧  /* v5.4 item 5 */
        if (r.pfCut !== undefined) PTFS_KEYS.forEach(function(k){ if (!out[i]._s[k]){ out[i][k] = 0; out[i]._s[k] = new Float64Array(M); } out[i][k] += r[k]/M; out[i]._s[k][sd - lo] = r[k]; });  /* v5.4 item 4 */
        if (r.c22PY !== undefined) ⟦not run⟧  /* S6 */
        if (r.clN !== undefined) ⟦not run⟧  /* S37 */
        if (r.pbV !== undefined) PTHB_KEYS.forEach(function(k){ if (!out[i]._s[k]){ out[i][k] = 0; out[i]._s[k] = new Float64Array(M); } out[i][k] += r[k]/M; out[i]._s[k][sd - lo] = r[k]; });  /* v5.4 item 3 */
        if (r.snAbN !== undefined) SN_AB_KEYS.forEach(function(k){ if (!out[i]._s[k]){ out[i][k] = 0; out[i]._s[k] = new Float64Array(M); } out[i][k] += r[k]/M; out[i]._s[k][sd - lo] = r[k]; });  /* session 7 */
        if (r.snSnap !== undefined) SN_KEYS.forEach(function(k){ if (!out[i]._s[k]){ out[i][k] = 0; out[i]._s[k] = new Float64Array(M); } out[i][k] += r[k]/M; out[i]._s[k][sd - lo] = r[k]; });  /* session 2b */
        if (r.hlEsi !== undefined) ⟦not run⟧  /* session 2a */
        if (r.emUrate !== undefined) EMPL_KEYS.forEach(function(k){ if (!out[i]._s[k]){ out[i][k] = 0; out[i]._s[k] = new Float64Array(M); } out[i][k] += r[k]/M; out[i]._s[k][sd - lo] = r[k]; });  /* v5.4 item 2 */
        if (r.rkEv !== undefined) RISK_KEYS.forEach(function(k){ if (!out[i]._s[k]){ out[i][k] = 0; out[i]._s[k] = new Float64Array(M); } out[i][k] += r[k]/M; out[i]._s[k][sd - lo] = r[k]; });  /* v5.4 item 1 */
        if (r.edcM !== undefined) EDC_KEYS.forEach(function(k){ if (!out[i]._s[k]){ out[i][k] = 0; out[i]._s[k] = new Float64Array(M); } out[i][k] += r[k]/M; out[i]._s[k][sd - lo] = r[k]; });  /* v5.3 B6 */
        if (r.hhPer !== undefined) HH_KEYS.concat(HH_REP_KEYS, r.hhBirthR !== undefined ⟦not run⟧ : []).forEach(function(k){ if (!out[i]._s[k]){ out[i][k] = 0; out[i]._s[k] = new Float64Array(M); } out[i][k] += r[k]/M; out[i]._s[k][sd - lo] = r[k]; }); }  /* v5.3 B3: the household reading's measures, where the row has households (B4: and children's lives, with ageing) */
      finally { tbResetV54(v540); HEALTH = hl0; HLS = null; SNET = sn0; SNS = null; PREV = pv0; CONVERSION_MODEL = cm0; Object.assign(PATHWAY_OFF, pw0); tbSetG(g0); PROJ = pj0; ESP = es0; SURP = sp0; PROD = pd0; JOIN = jn0; COST = cs0; OCT = oc0; SURPLUS_CONSUMPTION_SHARE = sc0; MULT = ml0; GATE_CURRENT = gc0; SAVE = sv0; AGE = ag0; AGS = null; LATENT = lt0; HCAP = hc0; HCS = null; REVIEW = rv0; REVS = null; HOUSEHOLDS = hh0; HHS = null; BU_SCOPE = bs0; EDC_MEASURE = em0; EDCS = null; SPEND_GRADE = sg0; DEBT_READ = dr0; AUD = au0; COMM = cl0; CMS = null; C22 = c220; C22S = null; FBS50 = fb0; FBSS = null; lwReset(lw0); } });
  }
  HL_GOVREF = null;  /* session 2c */
  return out;
}

// index.html line 6356
/* Session 7: set the i3 engine-question switches for one row; returns the previous values. */
function tbSetG(g){ var old = {FBS_BU_ONCE:FBS_BU_ONCE, PTH_APPR_CONSERVE:PTH_APPR_CONSERVE, N7_BLEI:N7_BLEI, SURP_CUT_MARKUP:SURP_CUT_MARKUP};
  if (g){ if ('FBS_BU_ONCE' in g) FBS_BU_ONCE = !!g.FBS_BU_ONCE; if ('PTH_APPR_CONSERVE' in g) PTH_APPR_CONSERVE = !!g.PTH_APPR_CONSERVE; if ('N7_BLEI' in g) N7_BLEI = !!g.N7_BLEI; if ('SURP_CUT_MARKUP' in g) SURP_CUT_MARKUP = !!g.SURP_CUT_MARKUP; }  /* v5.3 B2: + SURP_CUT_MARKUP */
  return old; }

// index.html line 6364
/* Presets. The environment (shocks, automation, exogenous inflation, years, population) comes from the Compassionism scenario P.
 * Every comparator gets the same COLA rule as BU (the Inflation Surge Protocol, 5%; D6). */
var TB_XC_AMT = 9.90*365;          /* X-Cents adult daily exchange (d17): a dime for $10 a day, net $9.90: derived, $3,613.50 a year */

// index.html line 6365
var TB_GROC = {cut:0.15, cap:140}; /* d27. cut: nyc.gov (Jul 27, 2026): 30% off a core basket, projected to cut the average grocery bill 15%; a promise,
                                    * not an observed result. cap: the $70M capital budget for five stores over 20 years, per covered adult-year, at an
                                    * assumed 5,000 regular adult shoppers per store: a logged placeholder (the shopper count is unsourced), swept. */

// index.html line 6368
var TB_ENDOW_THRESH = 25000;       /* d27: year-0 wealth below the model's wealth-poverty line (CFG.POVERTY_LINE) */

// index.html line 6369
var TB_NIT_T = 0.5;                /* d27: central phase-out rate; 0.3 and 0.7 swept */

// index.html line 6387
/* Session 11 (Duke's notes on the v4.22 page; dashboard d44-d47).
 * TB_GROC_PILOT  the NYC plan's five stores serve a small share of the city's shoppers: the Mayor puts the existing count at
 *                "more than the thousand existing grocery stores" (nyc.gov transcript, Jul 27, 2026), so five equal-sized stores
 *                would serve 5/1,005 = 0.5%; the first sites are 9,000 sq ft, smaller than a typical supermarket, so this is if
 *                anything high. Derived. The full-cover row (cover 1) is the network at a scale that serves every adult.
 * TB_XC_P1       X-Cents "Power of 1" (the CurrentSea X-Change paper, s3.2): at designated times every coin is worth $1 for
 *                necessities, so food bought with pennies costs 1 cent per dollar (a 99% cut). One designated day a week
 *                (Duke, Sep 28): the share of food bought that day, f, is 1 if adults do their weekly food shopping on it (central)
 *                and 1/7 if they do not shift any (swept). Food only: rent and utilities need the paper's phase-2 service-provider
 *                integration, which the model does not assume centrally; the X-Cents site names food and housing, so a row with
 *                housing (rent and utilities, HUD FMR incl. tenant-paid utilities) paid the same way is shown beside it (d48).
 * TB_UBI_PROP, TB_NIT_PROP, TB_ENDOW_PROP  each comparator at its proposers' size (d45): $1,000 a month (the amount paid in
 *                Vivalt et al.'s study); the guarantee at the 2026 HHS poverty guideline for one person ($15,960, aspe.hhs.gov),
 *                50% phase-out, inside the range the 1968-82 NIT experiments tested; the stakeholder grant's $80,000 of 1999
 *                (Ackerman and Alstott) in 2025 dollars, x 321.943/166.6 (BLS CPI-U annual averages) = $154,594.
 * TB_TOPUP_S     d39/N3: the share of the flat BU moved to the needs-based top-up at equal cost in `topup` (0.1, 0.25 and 0.5 swept).
 *                TB_TOPUP_S_A5 = 0.1 in a5 and on the page (d44): the only share tested that deepens the FGT2 cut in all four cells. */
var TB_GROC_PILOT = 0.005, TB_XC_P1 = 0.99, TB_UBI_PROP = 12000, TB_NIT_PROP = 15960, TB_ENDOW_PROP = 154594, TB_TOPUP_S = 0.25, TB_TOPUP_S_A5 = 0.1;

// index.html line 6388
function tbComp(P, spec){ return Object.assign({}, baselineFor(P, true), {nAgents:P.nAgents, years:P.years, cola:true, colaThresh:CFG.COLA_HUB_THRESH, tb:spec}); }

// index.html line 6389
function tbCCO(P, bu){ var q = nextRoundPreset(Object.assign({}, P, bu !== undefined ⟦not run⟧ : {})); q.tb = {}; return q; }

// index.html line 6390
function tbPresets(P){
  return {
    baseline: function(){ return tbComp(P, {}); },
    ubi: ⟦not run⟧,
    nit: ⟦not run⟧,
    groc: ⟦not run⟧,
    endow: ⟦not run⟧,
    xc: ⟦not run⟧,
    cco: function(bu){ return tbCCO(P, bu); },
    ccoAlone: ⟦not run⟧,
    /* session 11 */
    grocPilot: ⟦not run⟧,
    xcFull: ⟦not run⟧,
    ccoTop: ⟦not run⟧
  };
}

// index.html line 6414
/* Session 23 (s34; d86-d90; N1-design-damping-theta.md): the N1 Compassionism rows, built one way for the testbed's projcore, esp
 * and match sections (unit s34-4: match's tax-financed rows equal projcore's and esp's). The main row: project hiring with Duke's
 * d58-d66 picks, the octave wage raise off (d46), the launch gift paid as you go (d66), the PTF/PTH inflation damping off (d86,
 * under d53), the price module's capacity term at 0 (d87); in the Hub-spec (framework) model, ESP payroll at the defaults (d76).
 * v: {gift:'run'} the gift financed over the run (d67); {raise:true} the octave wage raise kept on; {damp:true} the damping kept on;
 * {cap:x} the capacity term (PM ptfCap, not the engine presets' membership cap) at x; {esp:false} the Hub-spec model's business
 * rule before ESP payroll; {es:{...}} an ESP setting (d71-d75); {fin, a} the financing. The damping is set on the row itself, so
 * the comparators and every other testbed section are untouched. */
function n1Row(PR, cm, v){
  v = v ⟦not run⟧; var c = {p:PR.cco(), cm:cm, pj:v.gift === 'run' ⟦not run⟧ : {}, o:{noDamp:!v.damp}};
  if (!v.raise) c.pw = {octaveWage:true};
  if (cm === 'framework' && v.esp !== false) c.es = v.es || {};
  if (cm === 'framework' && v.sp) c.sp = v.sp;  /* plan step 1: the ESP surplus split ({} = the defaults) */
  if (cm === 'framework' && v.pd) c.pd = v.pd;  /* plan step 2: the production side ({} = the defaults) */
  if (typeof v.sc === 'number') c.sc = v.sc;  /* plan step 7: the spending rule (share of cash surplus consumed) */
  if (cm === 'framework' && v.oc) ⟦not run⟧  /* plan step 6: slower octave advancement */
  if (cm === 'framework' && v.cs) c.cs = v.cs;  /* plan step 5: PTF running costs ({} = the defaults) */
  if (cm === 'framework' && v.jn) c.jn = v.jn;  /* plan step 4: joining and leaving ({} = the defaults) */
  if (v.ml) c.ml = v.ml;  /* plan step 16: the spending layer ({} = the defaults) */
  if (typeof v.gc === 'boolean') c.gc = v.gc;  /* audit V5-02: the BLEI gate reads this year's BU (framework only) */
  if (v.sv) ⟦not run⟧  /* v5.2 step 3: savings that keep up with prices ({} = the defaults) */
  if (v.ag) ⟦not run⟧  /* v5.2 step 4: ageing ({} = the defaults; ret and ss as in AGE_DEFAULTS) */
  if (v.lt) ⟦not run⟧  /* v5.2 step 5: the readings that close known gaps with US data ({w, r, s}) */
  if (v.ci) ⟦not run⟧  /* v5.2 step 3 (Duke's answer d147): the BU indexed to prices every year, not only in a year prices rise faster than 5% (the Hub's rule, the main reading) */
  if (v.cap) ⟦not run⟧
  if (v.fin){ c.o.fin = v.fin; c.o.a = v.a || 0; }
  if (v.aK) ⟦not run⟧  /* v5.2 step 6 (decision B): the middle backing reading */
  if (v.hc) ⟦not run⟧  /* v5.2 step 7: housing capture ({c: dollars of higher rent per BU dollar spent on rent outside PTH, all: the rise reaches every renter outside PTH}) */
  if (v.rv) ⟦not run⟧  /* v5.2 step 7: review errors and collusion ({u, q}) */
  if (v.hh) c.hh = v.hh;  /* v5.3 B3: households ({pool, childBU}) */
  if (v.bs) c.bs = v.bs;  /* v5.3 B3f: what BU can buy ('hub': the Hub's list) */
  if (v.sg) c.sg = v.sg;  /* v5.3 B7: income-graded spending */
  if (v.em) c.em = v.em;  /* v5.3 B6: the measured EDC (reporting only) */
  if (v.fb) c.fb = v.fb;  /* v5.3 B7: FBS50 */
  if (v.g) c.g = Object.assign({}, c.g || {}, v.g);  /* v5.3 B2: engine-question switches for the row (the accounting corrections) */
  if (v.drop) ⟦not run⟧  /* v5.3 B9: a part of the design removed (a module's row option: pj, es, sp, pd, jn, ml, cs) */
  if (v.pset) ⟦not run⟧  /* v5.3 B9: a part of the preset switched off (ptf, pth, szh, cip) */
  if (v.pwOff) ⟦not run⟧  /* v5.3 B9: a pathway closed (relief, conversion, octave) */
  if (v.v54) c.v54 = v.v54;  /* v5.4 step 9: the round's switches (REL_V54) */
  return c;
}

// index.html line 6449
/* Audit F3 (v5.1): the q-quantile (0 <= q <= 1) of an array of numbers by linear interpolation between order statistics (the default of numpy.percentile). The input is
 * not changed. Reporting only: no engine code calls it. */
function quantileOf(arr, q){ var v = Array.prototype.slice.call(arr).sort(function(x, y){ return x - y; }), h = (v.length - 1)*q, lo = Math.floor(h), hi = Math.ceil(h); return v[lo] + (v[hi] - v[lo])*(h - lo); }


// index.html line 6479
function medianOf(arr){var s=arr.slice().sort(function(a,b){return a-b;}),n=s.length;return n?(n%2===0?(s[n/2-1]+s[n/2])/2:s[Math.floor(n/2)])⟦not run⟧;}

// index.html line 6480
function incomeBasketMetrics(agents){
  if(!agents||!agents.length||agents[0].yrBasketUSD===undefined)⟦not run⟧
  var inc=agents.map(function(a){var w=+a.yrWageUSD,c=+a.yrConvUSD;return (isNaN(w)⟦not run⟧:w)+(isNaN(c)⟦not run⟧:c)+(a.yrUbiUSD||0);});  /* v5.3 (B1): + the UBI comparators' cash (harness.js's studies; 0 on the page, which never sets it) */
  var ext=agents.map(function(a,i){return inc[i]+Math.max(0,(+a.yrBasketUSD⟦not run⟧)-(+a.yrCostUSD⟦not run⟧));});
  var n=inc.length,med=medianOf(inc),medX=medianOf(ext),rel=0,relX=0,net=0,gross=0;
  agents.forEach(function(a,i){if(inc[i]<0.6*med)rel++;if(ext[i]<0.6*medX)relX++;if(inc[i]<a.yrCostUSD)net++;if(inc[i]<a.yrBasketUSD)gross++;});
  return{medianIncome:med,incPov:rel/n*100,incPovExt:relX/n*100,basketPov:net/n*100,basketPovGross:gross/n*100};
}

// index.html line 6521
function housingDistressOf(agents){
  if(!agents||!agents.length||agents[0].yrWealthStartUSD===undefined)⟦not run⟧
  var n=0;
  agents.forEach(function(a){var inc=(+a.yrWageUSD||0)+(+a.yrConvUSD||0)+(+a.yrSSUSD||0),w=+a.yrWealthStartUSD⟦not run⟧;if(inc+Math.max(0,w)<(+a.yrCostUSD⟦not run⟧))n++;});  /* v5.2 step 4: + the Social Security benefit (0 without ageing) */
  return n/agents.length;
}

// index.html line 6527
function housingDistressYear0(agents){
  if(!agents||!agents.length)⟦not run⟧
  var n=0;
  agents.forEach(function(a){var inc=Math.max(isNaN(a.wage)⟦not run⟧:a.wage,0)*12*CFG.WAGE_TO_USD,w=isNaN(a.wealth)⟦not run⟧:a.wealth;if(inc+Math.max(0,w)<CFG.LIVING_WAGE_ANNUAL)n++;});
  return n/agents.length;
}

// index.html line 6533
function wellnessZoneReach(p){return(p&&p.pth&&p.szh)?CFG.EP_WZ_EFFECT*Math.max(0,Math.min(1,+p.szhCoh⟦not run⟧)):0;}

// index.html line 6535
function extremePovertyOf(d,d0,p){
  if(d===null||d===undefined||isNaN(d)||!(d0>0))⟦not run⟧
  var R=CFG.EP_Y0_RATE,s=CFG.EP_SMI_SHARE,v=CFG.EP_VOL_SHARE,wz=p==='year0'⟦not run⟧:wellnessZoneReach(p);
  var econ=R*(1-s-v)*d/d0,smi=R*s*(1-wz),vol=R*v;
  return{total:(econ+smi+vol)*100,econ:econ*100,smi:smi*100,vol:vol*100,distress:d*100,wz:wz};
}


// index.html line 8037
function lognormal(mu,sigma){var u=Math.max(1e-14,1-RNG()),v=RNG();return Math.exp(mu+sigma*Math.sqrt(-2*Math.log(u))*Math.cos(2*Math.PI*v));}

// index.html line 8038
function beta(a,b){var x=gamma(a);return x/(x+gamma(b));}

// index.html line 8052
function gamma(a){if(a===1)⟦not run⟧if(a<1)⟦not run⟧for(var i=0;i<5000;i++){var u=RNG(),v=RNG(),y=Math.tan(Math.PI*u),x=Math.sqrt(2*a-1)*y+a-1;if(x>0&&v<=(1+y*y)*Math.exp((a-1)*Math.log(x/(a-1))-Math.sqrt(2*a-1)*y))return x;}⟦not run⟧}


// harness.js line 1749
/* v5.3 B10 (Oct 7, 2026; dev/DECISIONS.md Session 39, "B10"): the v5.3 release panel. The main row and its no-programme run are made of the parts recorded before
 * the restudy: the two accounting corrections (ACCT_V53), households (pooled, the child allowance at a quarter, partners' income swings at Shore's correlations,
 * household wealth from the SCF), the Hub's list of what BU can buy, and income-graded spending; the measured EDC and FBS50 are reported (they change no
 * result). The readings are the v5.2 panel's (applied on top of the new main row) and v5.3's, each with its own no-programme pair where it changes the
 * population; the attribution rows (k 'a', plan item B9) remove one part of the design at a time. `node harness.js testbed 500 release ENV --v53 --json=...` */
var HH_V53 = REL_V53.hh;  /* the engine's v5.3 main-row households (index.html, REL_V53) */

// harness.js line 1789
function releaseRowsV53(SC){
  var ALL = Object.assign({fin:'source', a:0, jn:{}, cs:{}, sc:SC}, REL_V5, REL_V53, {em:true, fb:true}), W = function(x){ return Object.assign({}, ALL, x); }, H = function(x){ return Object.assign({}, HH_V53, x); };
  return [
    {l:'TODAY (v4.22, Hub spec): the s34 main row (wage contribution)', v:{sc:SC, gc:true, hh:HH_V53, sg:true, g:ACCT_V53}, k:'today', j:'v422'},
    {l:'RELEASE (v5.3): Compassionism with every mechanism, paid for by the Source; households and children', v:ALL, k:'main', vs:'today', j:'release'},
    /* the v5.0-v5.2 readings, on the v5.3 main row */
    {l:'  H1: every dollar the Source pays backed by new output', v:W({a:1}), k:'s', vs:'main', j:'h1'},
    {l:'  essentials bought with BU counted as backed by output', v:W({o:{faceM:true}}), k:'s', vs:'main', j:'face'},
    {l:'  paid for by a flat contribution on wages instead of the Source', v:W({fin:'tax'}), k:'s', vs:'main', j:'tax'},
    {l:'  creative projects counted at the cost of their hours, not at market value (the cautious reading)', v:W({pd:{match:'face', speed:'oneyear'}}), k:'s', vs:'main', j:'cost'},
    {l:'  community-business capacity growing only as reinvestment pays for it (the 5-year rule)', v:W({pd:{match:'market', speed:'reinvest'}}), k:'s', vs:'main', j:'cap5'},
    {l:'  taking part costs nothing (every adult joins)', v:W({jn:{cost:'none'}}), k:'s', vs:'main', j:'all'},
    {l:'  price cuts free (PTF and PTH cuts counted as capacity, not a transfer)', v:W({o:{eP:1}}), k:'s', vs:'main', j:'free'},
    {l:'  the two former stand-ins on (octave wage raise and inflation damping; theoretical, off by default)', v:W({raise:true, damp:true}), k:'s', vs:'main', j:'standins'},
    {l:'  savings that keep up with prices (interest = inflation + 0.97% a year, in both runs)', v:W({sv:{}}), k:'s', vs:'main', j:'sav', bk:'sv'},
    {l:'  savings that only keep their value (interest = inflation, in both runs)', v:W({sv:{r:0}}), k:'s', vs:'main', j:'sav0', bk:'sv0'},
    {l:'  the BU indexed to prices every year (the Hub indexes it only in a year prices rise faster than 5%)', v:W({ci:true}), k:'s', vs:'main', j:'idx'},
    {l:'  H1 with the BU indexed every year', v:W({a:1, ci:true}), k:'s', vs:'main', j:'h1idx'},
    {l:'  middle backing reading: new output backs the Source\'s payout up to 12% of earned income a year (the Kenya study\'s two-year rollout)', v:W({aK:CFG.KENYA_ABSORB_ROLLOUT}), k:'s', vs:'main', j:'mid'},
    {l:'  middle band, low end: up to 8% a year (all of the US\'s underused labour, BLS U-6, 2025)', v:W({aK:CFG.US_UNDERUSE}), k:'s', vs:'main', j:'midlo'},
    {l:'  middle band, high end: up to 16% a year (the Kenya study\'s peak year)', v:W({aK:CFG.KENYA_ABSORB_PEAK}), k:'s', vs:'main', j:'midhi'},
    {l:'  the spending layer in normal years too: idle labour (U-6 above its lowest level, 1.1% of wages) filled at the normal-times multiplier 0.6', v:W({ml:{nt:{m:CFG.MULT_NORMAL, s:CFG.US_UNDERUSE - CFG.US_UNDERUSE_LOW}}}), k:'s', vs:'main', j:'slack'},
    {l:'  landlords raise the rent of tenants paying with BU by $0.50 per BU dollar spent on rent, outside PTH (housing-voucher evidence: Collinson and Ganong 2018)', v:W({hc:{c:CFG.HOUSING_CAPTURE}}), k:'s', vs:'main', j:'hcap'},
    {l:'  rents outside PTH rise $1.41 per BU dollar spent on rent, for every renter outside PTH (Susin 2002: other renters paid more than the subsidy)', v:W({hc:{c:CFG.HOUSING_CAPTURE_HIGH, all:true}}), k:'s', vs:'main', j:'hcaphi'},
    {l:'  10% of high conversion rates unearned, audits catch half', v:W({rv:{u:0.10}}), k:'s', vs:'main', j:'rev10'},
    {l:'  20% of high conversion rates unearned, no audits', v:W({rv:{u:0.20, q:0}}), k:'s', vs:'main', j:'rev20n'},
    {l:'  the launch gift paid for over the run (the Source spreads the new money for the gift over the run)', v:W({gift:'run'}), k:'s', vs:'main', j:'giftrun'},
    {l:'  paid for by a progressive income tax instead of the Source (the 2025 federal brackets, scaled up; not specified by the Hub)', v:W({fin:'tax', o:{taxBase:'prog'}}), k:'s', vs:'main', j:'progtax'},
    {l:'  paid for by a land-value tax instead of the Source (falling on adults in proportion to their savings; not specified by the Hub)', v:W({fin:'tax', o:{taxBase:'land'}}), k:'s', vs:'main', j:'landtax'},
    {l:'  households with ageing: children grow up, are born and leave home; estates pass to partners and children (a population that drifts: couples are fixed)', v:W({ag:{}}), k:'s', vs:'main', j:'age', bk:'ag'},
    {l:'  ageing, retirees leave the programme and live on Social Security alone', v:W({ag:{ret:'none'}}), k:'s', vs:'main', j:'agenone', bk:'ag'},
    {l:'  ageing, with a Social Security benefit linked to the adult\'s own wage', v:W({ag:{ss:'pia'}}), k:'s', vs:'main', j:'agepia', bk:'agpia'},
    {l:'  ageing, every estate leaving the model (no heirs)', v:W({ag:{}, hh:H({estate:'leave'})}), k:'s', vs:'main', j:'ageleave', bk:'agleave'},
    {l:'  ageing, with wages following US earnings by age (BLS CPS)', v:W({ag:{earn:'cps'}}), k:'s', vs:'main', j:'agecps', bk:'agcps'},
    {l:'  automation risk linked to wages (lower-paid jobs at higher risk, as in the occupation data)', v:W({lt:{r:1}}), k:'s', vs:'main', j:'fixr', bk:'ltr'},
    {l:'  wages spread as widely as in the US wealth survey', v:W({lt:{s:1}}), k:'s', vs:'main', j:'fixs', bk:'lts'},
    {l:'  wages centred on the US survey\'s median ($54,698 instead of $39,945)', v:W({lt:{m:1}}), k:'s', vs:'main', j:'fixm', bk:'ltm'},
    {l:'  the three wage and risk readings together', v:W({lt:{r:1, s:1, m:1}}), k:'s', vs:'main', j:'fixall', bk:'lta'},
    /* v5.3's own readings */
    {l:'  v5.2\'s main row: adults living alone, BU buying food, housing and medical care, their own starting savings, everyone paying the full basket', v:Object.assign({fin:'source', a:0, jn:{}, cs:{}, sc:SC}, REL_V5, {g:ACCT_V53, em:true, fb:true}), k:'s', vs:'main', j:'v52', bk:'b52'},
    {l:'  adults living alone (no households), otherwise the main row', v:W({hh:null}), k:'s', vs:'main', j:'adults', bk:'badults'},
    {l:'  BU buying only food, housing and medical care (v5.2\'s list)', v:W({bs:'core'}), k:'s', vs:'main', j:'core'},
    {l:'  each adult keeping their own money (no pooling)', v:W({hh:H({pool:'individual'})}), k:'s', vs:'main', j:'indiv', bk:'bindiv'},
    {l:'  no child allowance', v:W({hh:H({childBU:0})}), k:'s', vs:'main', j:'cb0'},
    {l:'  a child allowance of half the adult BU', v:W({hh:H({childBU:0.5})}), k:'s', vs:'main', j:'cb50'},
    {l:'  households\' starting savings from the model\'s own draw (not the SCF)', v:W({hh:H({wealth:'model'})}), k:'s', vs:'main', j:'wmodel', bk:'bwmodel'},
    {l:'  everyone paying their full cost each year whatever their income (no income-graded spending)', v:W({sg:null}), k:'s', vs:'main', j:'nosg', bk:'bnosg'},
    {l:'  partners\' income swings moving together strongly (0.5)', v:W({hh:H({shock:0.5})}), k:'s', vs:'main', j:'shock50', bk:'bshock50'},
    {l:'  FBS50 spread evenly over its range (more adults need a larger surplus to advance)', v:W({fb:{dist:'fbs50'}}), k:'s', vs:'main', j:'fbs50'},
    /* plan item B9: each part of the design removed in turn */
    {l:'  without the BU allowance (no BU are issued, so none buy essentials, expire or convert)', v:W({pwOff:{relief:true}}), k:'a', vs:'main', j:'xRelief'},
    {l:'  without conversion (BU never become dollars)', v:W({pwOff:{conversion:true}}), k:'a', vs:'main', j:'xConv'},
    {l:'  without project hiring (expired BU fund projects by the earlier allocation rule instead)', v:W({drop:['pj']}), k:'a', vs:'main', j:'xProj'},
    {l:'  without the essential businesses\' payroll (ESP)', v:W({esp:false}), k:'a', vs:'main', j:'xEsp'},
    {l:'  without the premium split (the premium is paid to every adult in proportion to wages, the earlier rule)', v:W({drop:['sp']}), k:'a', vs:'main', j:'xSplit'},
    {l:'  without community businesses (PTF)', v:W({pset:{ptf:false}}), k:'a', vs:'main', j:'xPtf'},
    {l:'  without community housing (PTH)', v:W({pset:{pth:false}}), k:'a', vs:'main', j:'xPth'},
    {l:'  without zone coordination and the civic portal (SZH, CIP)', v:W({pset:{szh:false, cip:false}}), k:'a', vs:'main', j:'xZone'},
    {l:'  without joining and leaving (participation fixed as drawn)', v:W({jn:null}), k:'a', vs:'main', j:'xJoin'},
    {l:'  without the spending layer (no jobs from programme spending in recessions)', v:W({ml:null}), k:'a', vs:'main', j:'xMult'},
    {l:'  without the production side (no new capacity or creative output counted as backing)', v:W({pd:null}), k:'a', vs:'main', j:'xProd'},
    {l:'  without octave advancement', v:W({pwOff:{octave:true}}), k:'a', vs:'main', j:'xOct'}];
}

// harness.js line 1858
/* v5.4 step 9 (Oct 7, 2026; dev/DECISIONS.md Session 41): the v5.4 release panel. The main row and its no-programme run are v5.3's with the round's parts
 * (REL_V54: risk measures, job loss and re-employment with UI in both runs, PTH's books, PTF by sector with leaving), as recorded before the 500-run restudy
 * (dev/reports/v5-22-v54-report.md). Every v5.3 reading (and every no-programme pair) carries them too; beside them, v5.3's main row exactly (paired with v5.3's
 * own no-programme run) and the round's main alternatives: no pay cut on return, a 20% cut, automation as a pay drag, the earlier Acre Equity rule, PTF's other
 * sectors at 25%, and the disaster (each with its own no-programme run where it changes that run: job loss and the disaster do, PTH and PTF do not).
 * `node harness.js testbed 500 release ENV --v54 --json=...` */
var V54_MAIN = REL_V54.v54;

// harness.js line 1859
function v54With(x){ return {rk:true, empl:Object.assign({}, x.empl || {}), pthb:Object.assign({}, x.pthb || {}), ptfs:Object.assign({}, x.ptfs || {}), dis:x.dis}; }

// harness.js line 1869
function releaseRowsV54(SC){
  var R = releaseRowsV53(SC).map(function(r){ var o = Object.assign({}, r, {v:Object.assign({}, r.v, {v54:V54_MAIN})}); if (r.j === 'release') o.l = 'RELEASE (v5.4): Compassionism with every mechanism, paid for by the Source; households and children; job loss and re-employment, PTH\'s books, PTF by sector'; return o; }),
    main = R.filter(function(r){ return r.j === 'release'; })[0].v, W = function(x){ return Object.assign({}, main, x); }, at = 0;
  R.forEach(function(r, i){ if (r.j === 'release') at = i + 1; });
  return R.slice(0, at).concat([
    /* v5.4's own readings (first after the main row) */
    {l:'  v5.3\'s main row: no job loss and re-employment, PTH and PTF as in v5.3 (the risk measures still reported)', v:W({v54:{rk:true}}), k:'s', vs:'main', j:'v53', bk:'b53'},
    {l:'  no pay cut on return to work (people find work at their old pay)', v:W({v54:v54With({empl:{cut:0}})}), k:'s', vs:'main', j:'cut0', bk:'bcut0'},
    {l:'  a 20% pay cut on return to work (the design value is 10%)', v:W({v54:v54With({empl:{cut:0.20}})}), k:'s', vs:'main', j:'cut20', bk:'bcut20'},
    {l:'  automation as a lasting pay drag instead of job loss (the earlier rule)', v:W({v54:v54With({empl:{auto:'pay'}})}), k:'s', vs:'main', j:'autopay', bk:'bautopay'},
    {l:'  Acre Equity growing by the earlier 3-5% rule instead of the price rise + 2%', v:W({v54:v54With({pthb:{cap:'old'}})}), k:'s', vs:'main', j:'pthbold'},
    {l:'  PTF cutting prices 25% in transport, health care and childcare (no Hub figure; the main row assumes no cut there)', v:W({v54:v54With({ptfs:{other:0.25}})}), k:'s', vs:'main', j:'ptfs25'},
    {l:'  a disaster in Year 7: a quarter of households lose $10,000 of property and four weeks of work (FEMA data; a scenario, not a model part)', v:W({v54:v54With({dis:{}})}), k:'s', vs:'main', j:'dis', bk:'bdis'}], R.slice(at));
}

// harness.js line 2091
var ACCT_V53 = {PTH_APPR_CONSERVE:true, SURP_CUT_MARKUP:true};  /* v5.3 B2: the two engine corrections the accounting check called for (dev/DECISIONS.md Session 39) */
