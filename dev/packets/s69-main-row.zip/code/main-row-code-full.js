// The Compassionism Simulation engine: the code that the candidate main row of round 2 and its no-programme run (Reference, Adverse and Stress), in source order.
// Cut by dev/packets/make_s69_reference.js from the script harness.js builds (index.html's engine first, then harness.js's own code), under V8 block coverage over seeds 1-20 of all six rows.
// Included: every top-level function that ran, and every top-level value such code names. Each piece is headed by the file and line it comes from.
// The whole text of each included piece (main-row-code.js has the same pieces with the parts that never ran folded).

// index.html line 2072
var CFG = {
  /* v4.13: POVERTY_LINE carries no citation anywhere in this codebase — flagged as an open
   * `calibration:` item in CONTRIBUTING.md's Calibration Validation table since v4.10, but
   * with nothing at the constant itself to warn a reader who only ever looks at the code.
   * Noted here so the gap is visible where the number lives. It is a pure post-hoc
   * reporting threshold with exactly one read site (calcMetrics()), never touching RNG or
   * dynamics — which is why the v4.10 Threshold Sensitivity charts can sweep across it
   * freely, and why an uncited value here is a reporting-clarity problem rather than a
   * mechanics one. For reference, the 2026 HHS one-person federal guideline is $15,960
   * (FED_POVERTY_LINE_1P, below); $25,000 is noticeably higher and its basis is unknown.
   * v5.3 (B3, Oct 7, 2026; DECISIONS Session 39): settled as a design threshold with a stated reading. Where $25,000 came from is still
   * undocumented, but it is within 1.3% of six months of one adult's cost of living (half of LIVING_WAGE_ANNUAL, $24,685), which is how the
   * model reads it from v5.3: the household reading uses six months of each household's own costs (CFG.HH_WEALTH_MONTHS). Stricter than the
   * asset-poverty literature's line (net worth below three months of the poverty line: Haveman and Wolff 2004). Kept at $25,000 here so the
   * adult-only figures stay comparable across releases. */
  POVERTY_LINE:25000, BLEI_CRISIS_MAX:7, BLEI_PRECARIOUS_MAX:30,
  BLEI_THRESHOLD_MAX:120, BLEI_STABLE_MAX:365, BLEI_SECURE_MAX:730,
  BASE_DAILY_COST:68.33, CCO_PTH_DAILY_COST:31.67,
  /* v4.7: previously an anonymous lognormal(10.5,1.2) literal inline in
   * makeLatentAgent() — promoted to named constants purely for discoverability
   * (identical values, so zero change to RNG consumption or any simulation
   * output). Comment doubles as an open calibration flag: median wealth =
   * e^WEALTH_INIT_MU ≈ $36,316, matching this constant's own long-standing
   * "Fed SCF 2022" citation elsewhere in this file and in the ODD panel below
   * — but the actual 2022 Survey of Consumer Finances reports median
   * household net worth at ≈$193,000 (Kuhn & Ríos-Rull, NBER working paper,
   * 2025, using 2022 SCF microdata), roughly 5.3x higher. Gini of a lognormal
   * is 2Φ(σ/√2)−1 — a function of WEALTH_INIT_SIGMA alone, no μ term — so this
   * is independent of the wealth-init distribution's separately-documented
   * inherent Gini ≈0.60 (see the Empirical Calibration panel); correcting the
   * median here would shift absolute wealth-poverty rates, especially in
   * early simulated years against the fixed-dollar POVERTY_LINE, without
   * moving Gini at all. Not changed this pass — every downstream wealth/Gini/
   * BLEI/poverty figure the model produces starts from this draw, so revising
   * it needs the same mechanics-audit-plus-large-N-restudy treatment as
   * v4.0/v4.3/v4.4, not a value swap in a hygiene release. Logged as an open
   * calibration: item in CONTRIBUTING.md's Model Architecture Feedback. */
  WEALTH_INIT_MU:10.5, WEALTH_INIT_SIGMA:1.2,
  SZH_ALL_RESIDENTS:0.06, SZH_PTF_BONUS:0.05,
  /* v4.0: network-density-gated synergy coefficient θ (BLEI paper Table 6: "Synergy
   * coefficient θ ... Network-density-gated: 0 below 55% PTF density; scales to 0.25
   * at 90%"). Previously applied as a plain linear function of szhCoh with no
   * threshold — see szhTheta().
   * v4.17 correction: the threshold is applied to szhCoh, the SZH zone-coherence SLIDER, as a
   * stand-in for PTF merchant density. Realised PTF density never enters θ — the reference
   * run's θ is 0.121 whether realised PTF membership is 18% or 53%. Logged as a decision. */
  SZH_THETA_THRESHOLD:0.55, SZH_THETA_MAX_COH:0.90, SZH_THETA_MAX:0.25,
  EDC_BASELINE_LO:0.62, EDC_BASELINE_HI:0.72, EDC_PTH_CAP:0.10,
  PROG_PIVOT:3.0, PROG_RATE:0.040, PROG_TAX_MAX:0.75,
  /* v4.13: corrected comment. This previously read "retained for CCO/PTF/PTH cost-factor
   * calc only" — not true: the cost factor (cf) in runYear() is a product of dimensionless
   * multipliers (0.88 / 0.65 / 0.80) and never touches this constant. Grep confirms
   * CFG.SIM_COST_SCALE has ZERO read sites in the live code today; it appears only here and
   * in prose. Kept rather than deleted so pre-v4.3 exported CSV/JSON files and this file's
   * own historical worked examples (which quote a wage×12/SIM_COST_SCALE ratio) stay
   * interpretable — that is now its entire remaining purpose. */
  SIM_COST_SCALE:1500,     // historical constant only — read by no function in this file (v4.3 wealth loop uses WAGE_TO_USD/LIVING_WAGE_ANNUAL; v4.4 retired SIU_TO_USD, its last consumer)
  WAGE_MEDIAN_SIU:35,      // reference for diminishing-returns calculation
  WEALTH_FLOOR:-10000,     // v4.8: N=500-seed sweep across 4 candidate values run and validated — see CONTRIBUTING.md; default unchanged, this is data for a decision not a decision itself
  WAGE_BASE_GROWTH:0.010, WAGE_BLEI_BONUS:0.008, WAGE_OCTAVE_BONUS:0.003,
  AI_DISPLACEMENT_YEAR_1:5, AI_DISPLACEMENT_YEAR_2:15,
  AI_DISPLACEMENT_RATE_1:0.012, AI_DISPLACEMENT_RATE_2:0.022,
  TARGET_WEALTH:82000, TARGET_STABILITY:0.90, TARGET_POVERTY:0.05,
  TARGET_FLOURISHING:0.50, TARGET_GINI:0.25, TARGET_EDC:0.10,
  NORDIC_GINI:0.28, CCO_OPTIMAL_BU:1200,
  /* v4.17: the papers' "minimum viable" CCO participation. Used ONLY for a run warning — no
   * line of runYear() reads aggregate CCO participation, so nothing in the dynamics changes
   * at 55% (sweep in CONTRIBUTING.md v4.17; NEEC maintainers' note 7). Whether to build a
   * participation-dependent network effect is logged as a decision for Duke. */
  CCO_MIN_PARTICIPATION:0.55,
  PTF_OPTIMAL_SHARE:0.18, PTF_DISTORTION:0.30,
  PHI_RATIO:1.618, PHI_QUALITY_THRESH:0.70,
  /* v4.0 additions — see BLEI paper (basic-living-economic-index.html) §8 Table 6
   * and Index IV (FBS) for the specification these implement. */
  FBS_LAMBDA_LO:0.0001654, FBS_LAMBDA_HI:0.0013233,   // per-agent capability coefficient λ ~ U(lo,hi), units 1/USD — v4.4: rescaled ÷(WAGE_TO_USD/legacy SIU_TO_USD ≈6.0456) from the pre-v4.4 0.001/0.008. The FBS gate's wage-derived income term (Yusd, below) was redefined from the legacy SIU_TO_USD anchor to the empirically-grounded WAGE_TO_USD anchor as part of the v4.4 wage-scale unification, ~6.05× larger at any given wage — but FBS also includes fixed-dollar terms (BU face value, basic cost) that did NOT rescale, so FBS as a whole does not scale by a single clean factor, and this rescale is a CHOSEN behavioral recalibration to restore useful advancement-probability variation across the population, not a dimensionally-forced conversion (an earlier version of this comment overstated that). Left unscaled, λ×fbs saturates pAdvance (→1) for nearly all agents regardless of BU level, which measurably weakened the BU-monotonicity VAL_TEST (4/5→ties at n=200, one seed) AND, more fundamentally, leaves little of λ's intended role as an "individual capability coefficient": even the BLEI paper's own published range (0.001-0.008) already produces 89.8-100% advancement probability at the paper's own $2,281/month worked example. Rescaling preserves the HI/LO=8× heterogeneity shape and restores 5/5 on VAL_TESTS — that demonstrates internal behavioral consistency, not empirical correctness of these specific values; λ's empirical grounding remains open, same as before v4.4 (see the BLEI paper's own Index IV note and CONTRIBUTING.md's "λ Calibration Status — Open" for the full account, including a recommended future reparameterization by half-saturation point FBS₅₀=ln(2)/λ rather than a raw 1/USD coefficient).
  FBS_EDC_RESIDUAL_BASE:0.12, FBS_EDC_RESIDUAL_PTH:0.025, // EDC_residual (consumer-debt-only), Table 1b worked values
  FBS_CIP_LAMBDA_BOOST:0.20,   // CIP support raises effective λ by up to +20% at cipDemo=1 (replaces old flat advancement-probability bump)
  BASELINE_CPI_RATE:0.03,      // US Welfare Baseline anchors to documented 3% CPI, not the user's inflation slider
  PTH_EQUITY_CONTRIB_SHARE:0.25, // share of PTH's annual housing-cost saving that routes to Acre Equity (payment→equity), vs. staying as direct liquid relief
  /* v4.5: tenure-cohort-varying liquidity haircut, replacing the flat 50% share of
   * annual Acre Equity appreciation that counted as immediately-liquid wealth (see
   * pthLiquidShare() and the runYear() PTH block). BLEI paper Table 1a describes this
   * schedule qualitatively as "~10-20% at 6 months rising to ~80-90% at 5+ years" —
   * we don't have a closed-form curve from the paper, only these two anchor points, so
   * this is a linear interpolation between them, a documented interpretation choice
   * pending a fuller citation, same honesty standard as PTH_EQUITY_CONTRIB_SHARE above.
   * Anchors use the midpoint of each cited range (15%/85%) rather than either endpoint.
   * pthTenure is incremented to 1 on an agent's first year in PTH (see runYear()), so
   * tenure=1 is the point in the schedule closest to the paper's "6 months" anchor;
   * tenure>=5 holds flat at the "5+ years" anchor rather than continuing to rise. */
  PTH_LIQUID_SHARE_YEAR1:0.15, PTH_LIQUID_SHARE_YEAR5PLUS:0.85, PTH_LIQUID_SHARE_MATURE_YR:5,
  PTF_BASS_Q:0.05,      // Bass (1969) imitation coefficient for PTF adoption — see runYear
  /* v4.3: main wealth-accumulation loop unit fix (highest-priority open item as of
   * v4.2 — see CONTRIBUTING.md Model Architecture Feedback). Two new constants:
   * WAGE_TO_USD converts the wage side; LIVING_WAGE_ANNUAL anchors the cost side.
   * WAGE_TO_USD ≈ 100.52 = $42,220 median personal income (Census/BLS CPS ASEC 2023,
   * all workers 15+) ÷ (35 SIU × 12). LIVING_WAGE_ANNUAL = $49,370/yr — a national
   * living-wage figure for a single adult, no children ($23.735/hr average across
   * 50 states + DC × 2,080 hrs/yr; World Population Review's MIT-sourced table; an
   * *unweighted* average across jurisdictions, not population-weighted like MIT's
   * own Living Wage Calculator product, which is paid and requests no scraping —
   * see CONTRIBUTING.md for that caveat). Replaces netting WAGE_TO_USD-converted wage
   * against BASE_DAILY_COST (a bare-subsistence floor, correct for BLEI's poverty-line
   * use, wrong for a 20-year compounding loop netted against real wage): that anchor
   * produced an ~11x wealth explosion and broke BU-monotonicity (2/5 seeds). All six
   * VAL_TESTS pass under the LIVING_WAGE_ANNUAL anchor, including BU-monotonicity
   * (5/5) — the strongest evidence this anchor is structurally right, not just
   * numerically smaller. dollarCost/BASE_DAILY_COST — the COST side — is unchanged
   * everywhere else (BLEI, FBS, Gini) — only the main loop's cost side changes here.
   * (v4.4 note: this is about the cost side specifically. BLEI/FBS/Gini's WAGE-side
   * conversion, separately, moved off the legacy SIU_TO_USD approximation onto this
   * same WAGE_TO_USD constant in v4.4 — see Cumulative Bug Fixes. The two changes
   * are independent; this comment's claim about the cost side is still accurate.)
   * This is NOT a clean win: correcting the units also redistributes, not just grows
   * — see the redistribution note under CONTRIBUTING.md Model Architecture Feedback
   * and the Known Limitations entry below before reading the headline wealth figure
   * alone. */
  WAGE_TO_USD:100.52,
  LIVING_WAGE_ANNUAL:49370,
  /* v4.3: Social Security-anchored income-comparison figures — reference points only,
   * not a simulated cohort mechanism (see the fixed-income cohort study, Known
   * Limitations, and CONTRIBUTING.md). SSA 2026 COLA Fact Sheet
   * (ssa.gov/news/en/cola/factsheets/2026.html): SSI federal payment standard,
   * individual, $994/mo; SSDI average, all disabled workers, $1,630/mo; average
   * retired-worker benefit, $2,071/mo. */
  SS_ANCHOR_SSI_ANNUAL:11928, SS_ANCHOR_SSDI_ANNUAL:19560, SS_ANCHOR_RETIRE_ANNUAL:24852,
  /* v4.10: external reference only — NOT a simulation parameter, same category as
   * NORDIC_GINI above (never read by runYear()/calcMetrics()/agentBLEI() or any other
   * mechanics function; used only as a labeled comparison point in
   * renderThresholdSensitivity's callout text, below). 2026 HHS ASPE federal poverty
   * guideline, one-person household, 48 contiguous states + DC: $15,960/yr. Verified this
   * session directly against aspe.hhs.gov/poverty-guidelines's cited methodology plus an
   * independently-dated primary-source PDF (a Lifeline Safe Connections Act eligibility
   * table, citing HHS directly and dated January 15, 2026, showing 200% of this same
   * guideline as $31,920 for one person — i.e. the underlying guideline is exactly
   * $15,960); a first fetch attempt against the live ASPE page returned a stale cached
   * 2017 snapshot, caught and cross-checked rather than used — see CONTRIBUTING.md's v4.10
   * Release Notes for the full verification trail. Published annually, ~mid-to-late
   * January; update this figure — and its year label in the callout text — when a fresher
   * guideline is published, the same discipline CONTRIBUTING.md already applies to
   * SS_ANCHOR_* above. */
  FED_POVERTY_LINE_1P:15960, FED_POVERTY_LINE_YEAR:2026,
  /* v4.18: EXTREME POVERTY OVERLAY — homeless, with necessities provided by charity if at all.
   * The engine has no housing market, mental-health state or vocation, so this measure is an
   * overlay on engine state, not an engine output (see extremePovertyOf()). Draws no RNG. */
  EP_Y0_RATE:0.0022,     // year-0 rate: HUD 2025 AHAR Part 1 PIT count, 745,652 people on one night in Jan 2025, ~22 per 10,000
  EP_SMI_SHARE:0.25,     // share of that total unhoused because of serious mental illness: Gutwinski et al. 2021 (PLoS Med 18(8)) meta-analysis, schizophrenia spectrum 12.4% + major depression 12.6%
  EP_VOL_SHARE:0.02,     // share living this way by choice (ascetics, itinerant monastics, renunciants). Set by Duke (v4.18); no US source located. The true share may vary and should be updated as data sources become available
  EP_WZ_EFFECT:0.50,     // relative reduction in SMI homelessness from PTH+SZH wellness zones at full zone coherence: At Home/Chez Soi RCT, last 6 months housed none of the time 16% (Housing First) vs 46% (usual care); housed all of the time 62% vs 31%
  /* v4.19: AUTOMATIC STABILIZERS. Every lever is off by default (ST.stab, ST.cola), so no
   * documented figure moves. Reference values are the Research Hub's own crisis protocols
   * (Integrated Implementation Roadmap, Appendix G) and this engine's calibration of them —
   * `node harness.js stabilizer` reproduces every figure. See CONTRIBUTING.md v4.19. */
  /* v4.19, Option B: CCO cost relief = min(CCO_RELIEF_CAP, CCO_RELIEF_AT_REF x effective BU / CCO_RELIEF_REF_BU).
   * v4.21: effective BU is read in year-0 dollars (divided by the basket's price index), because
   * CCO_RELIEF_REF_BU is a year-0 amount and the relief multiplies the nominal basket. See runYear(). */
  CCO_RELIEF_AT_REF:0.20, // the historical flat relief, now its value at the reference BU
  CCO_RELIEF_REF_BU:1200, // the reference BU ($/month) at which relief is 20% of the basket
  CCO_RELIEF_CAP:0.50,    // ceiling on the relief share. PLACEHOLDER set in v4.19 (binds from $3,000 of effective BU); no source located
  STAB_HUB_MULT:1.20,    // Recession Protocol: "increase basic units 20%"
  STAB_HUB_THRESH:0.02,  // ...when "GDP decline >2% for 2 quarters". No GDP in the engine: read as a >=2% population income loss. Every engine recession (5-30% loss) clears it
  STAB_NEUTRAL_MULT:1.35,// shock-neutral multiplier for CCO participants at the reference settings, with cost relief scaling with BU (harness.js stabilizer 300: x1.36 unrounded; x1.35 in Adverse Environment and CCO Only)
  STAB_NEUTRAL_K:2.8,    // the scaled rule's equivalent: BU increase = k x income-loss share (k ~ 2.8 at the reference settings)
  STAB_MULT_MAX:4,       // slider maximum; the in-page shock-neutral search stops here
  STAB_EMERG_TAKEUP:0.50,// share of non-participants taking up emergency enrollment when triggered. PLACEHOLDER set in v4.19: no source located
  COLA_HUB_THRESH:0.05,  // Inflation Surge Protocol: "CPI >5%" -> COLA adjustments to basic units
  STAB_STUDY_SEEDS:30,   // paired seeds for the in-page shock-response study
  /* v4.20: automationRisk mixture, pi x Beta(AUTO_HIGH_A,1) + (1-pi) x Beta(1,AUTO_LOW_B).
   * Source: Frey & Osborne (2013), appendix (pp. 57-72), 702 SOC-2010 occupations, weighted by
   * May-2016 BLS OES employment (plotly/datasets job-automation-probability.csv, numbEmployed;
   * every row checked against the paper's appendix in v4.20 and matching on SOC code, rank
   * and probability). Employment-weighted mean probability 0.592; share at or above 0.5,
   * 0.660; share above 0.7, 0.501. v4.3-v4.19 used 0.47 — F&O's headline share of 2010 US
   * employment above 0.7 — as the mixture weight, which gives a mean of 0.479. 0.63 matches
   * the data's mean, and automationRisk enters runYear() linearly (wage drag = displacement
   * rate x risk), so the mean sets the population's aggregate drag; it is also the closest of
   * the candidates to the data's distribution (harness.js automation fit). Shapes are kept
   * from v4.3; the within-group means they imply (0.857/0.143) are close to the data's
   * (0.835/0.120). Drawn INDEPENDENTLY of wage, although across occupations log median wage
   * and probability correlate at -0.65 (employment-weighted): see CONTRIBUTING.md v4.20. */
  AUTO_HIGH_SHARE:0.63,
  AUTO_HIGH_A:6,
  AUTO_LOW_B:6
};

// index.html line 2312
var RNG=Math.random;

// index.html line 2313
function mulberry32(seed){var s=seed>>>0;return function(){s=(s+0x6D2B79F5)>>>0;var t=Math.imul(s^(s>>>15),1|s);t=(t+Math.imul(t^(t>>>7),61|t))^t;return((t^(t>>>14))>>>0)/4294967296;};}

// index.html line 2715
function szhTheta(coh){
  coh=isNaN(coh)?0:coh;
  if(coh<CFG.SZH_THETA_THRESHOLD)return 0;
  return Math.min(CFG.SZH_THETA_MAX,(coh-CFG.SZH_THETA_THRESHOLD)/(CFG.SZH_THETA_MAX_COH-CFG.SZH_THETA_THRESHOLD)*CFG.SZH_THETA_MAX);
}


// index.html line 2727
function pthLiquidShare(tenure){
  var t=Math.max(1,Math.min(CFG.PTH_LIQUID_SHARE_MATURE_YR,isNaN(tenure)?1:tenure));
  var span=CFG.PTH_LIQUID_SHARE_MATURE_YR-1;
  return span>0?CFG.PTH_LIQUID_SHARE_YEAR1+(t-1)/span*(CFG.PTH_LIQUID_SHARE_YEAR5PLUS-CFG.PTH_LIQUID_SHARE_YEAR1):CFG.PTH_LIQUID_SHARE_YEAR1;
}


// index.html line 2748
function agentBLEI(a,buAlloc,ccoOn,pthOn,szhOn,szhCoh,ptfOn){
  var liquid=Math.max(0,(isNaN(a.wealth)?0:a.wealth)*0.20);
  var gammaV=(ccoOn&&a.inCCO)?0.20:0.12;
  var mInc=Math.max(isNaN(a.wage)?1:a.wage,0.1)*CFG.WAGE_TO_USD;
  var buFood=(ccoOn&&a.inCCO&&buAlloc>0)?((CONVERSION_MODEL==='framework'&&a._fwBUm!==undefined)?a._fwBUm:buAlloc*(990/1200)):0;  // session 2, N3: framework credits one month of the BU the agent spends on essentials (fwB0 in runYear: the budget capped at essentials, before any price cut; audit V5-02: this year's with GATE_CURRENT)
  var szhD=szhOn?szhCoh*CFG.SZH_ALL_RESIDENTS:0;
  if(szhOn&&ptfOn&&(a.inPTF||PAS))szhD+=PAS?paW(a)*szhTheta(THETA_GATE==='density'&&THETA_DENS!==null?(CMS&&a._cm!==undefined?CMS.th[a._cm]:THETA_DENS):szhCoh)*0.20:szhTheta(THETA_GATE==='density'&&THETA_DENS!==null?(CMS&&a._cm!==undefined?CMS.th[a._cm]:THETA_DENS):szhCoh)*0.20;  // session 5 (C08): harness-only gate  // S55: under open access every adult, on the zone's PTF share of sales
  var baseCost=(ccoOn&&a.inCCO&&pthOn&&a.inPTH)?CFG.CCO_PTH_DAILY_COST:CFG.BASE_DAILY_COST;
  var dc=Math.max(baseCost*(1-szhD),0.1)*(a._hhD||1);  // v5.3 B3: an adult's share of the household's daily cost of basic living (households only)
  var r=(liquid+gammaV*mInc+buFood)/dc;
  return(isNaN(r)||!isFinite(r))?0:Math.max(0,r);
}


// index.html line 2823
function updateRecession(recSt){
  if(recSt.active){recSt.yearsLeft--;if(recSt.yearsLeft<=0){recSt.active=false;recSt.incomeMultiplier=1.0;}}
  else if(RNG()<0.10){recSt.active=true;recSt.yearsLeft=1+Math.floor(RNG()*3);recSt.incomeMultiplier=0.70+beta(5,2)*0.25;}
}

// index.html line 2835
function buildRecessionPath(years,seed){
  var path=[],saved=RNG;
  RNG=(seed===null||seed===undefined||isNaN(seed))?saved:mulberry32(seed+700000);
  var st={active:false,incomeMultiplier:1.0,yearsLeft:0};
  for(var y=0;y<years;y++){
    if(y>0)updateRecession(st);
    path.push({active:st.active,incomeMultiplier:st.incomeMultiplier});
  }
  RNG=saved;
  return path;
}

// index.html line 2871
function standardNormal(){var u=Math.max(1e-14,1-RNG()),v=RNG();return Math.sqrt(-2*Math.log(u))*Math.cos(2*Math.PI*v);}

// index.html line 2889
var AUTOMATION_SAMPLER_LEGACY = false;

// index.html line 2890
function drawAutomationRisk(){
  if(AUTOMATION_SAMPLER_LEGACY){
    if(RNG()<CFG.AUTO_HIGH_SHARE)return beta(6,1);
    return beta(1,6);
  }
  var c=RNG(),v=RNG();
  return c<CFG.AUTO_HIGH_SHARE?Math.pow(v,1/CFG.AUTO_HIGH_A):1-Math.pow(1-v,1/CFG.AUTO_LOW_B);
}

// index.html line 2898
function makeLatentAgent(){
  var uCCO=RNG(),uPTF=RNG(),uPTH=RNG();  // unconditional — see comment above
  return{uCCO:uCCO,uPTF:uPTF,uPTH:uPTH,
    wealth:lognormal(CFG.WEALTH_INIT_MU,CFG.WEALTH_INIT_SIGMA),wage:lognormal(3.5,0.5),
    octaveShape:beta(2,5),qualityZ:standardNormal(),
    automationRisk:drawAutomationRisk(),lambda:CFG.FBS_LAMBDA_LO+RNG()*(CFG.FBS_LAMBDA_HI-CFG.FBS_LAMBDA_LO)};
}

// index.html line 2905
function makeLatentPopulation(n){var pop=[];for(var i=0;i<n;i++)pop.push(makeLatentAgent());return pop;}

// index.html line 2906
function instantiateAgent(latent,cfgP){
  var qN=cfgP.cip?(1-cfgP.cipDemo*0.5):1.0;
  var maxOct=cfgP.maxOct||1,maxMult=cfgP.maxMult||1;
  var inPTH=!!(cfgP.pth&&latent.uPTH<cfgP.pthUptake);
  return{wealth:latent.wealth,wage:latent.wage,
    /* v4.5: snapshot of year-0 wage, kept alongside the mutable a.wage (which grows
     * every runYear() call). Needed to tag agents into the Social Security-anchored
     * cohorts by their INITIAL wage, matching CONTRIBUTING.md's documented methodology
     * ("agents tagged by initial wage at or below each anchor's SIU-equivalent") — see
     * ssAnchorCohorts(). Purely additive; nothing existing reads this field. */
    initialWage:latent.wage,
    octave:Math.floor(latent.octaveShape*maxOct),
    quality:Math.min(maxMult,Math.max(0,Math.exp(Math.log(maxMult*0.5)+0.4*latent.qualityZ)*qN)),
    automationRisk:latent.automationRisk,lambda:latent.lambda,
    uCCO:latent.uCCO,  // v4.19: kept for deterministic emergency take-up (no RNG)
    inCCO:!!(cfgP.ccoOn&&latent.uCCO<cfgP.partRate),inPTF:!!(cfgP.ptf&&latent.uPTF<cfgP.ptfShare),inPTH:inPTH,
    buBalance:0,acreEquity:inPTH?5000:0,
    /* v4.3: per-agent PTH tenure in years (first step toward tenure-cohort liquidity
     * haircut per BLEI paper Table 1a / CONTRIBUTING.md). Incremented each year the
     * agent remains in PTH; reset to 0 on exit. Variable haircut formula itself is a
     * follow-up PR — this only gets the tracking data flowing and exported. */
    pthTenure:0};
}

// index.html line 3418
/* ==== RELEASE ENGINE: ported verbatim from harness.js by dev/tools/port_engine.py (plan step 10). Do not edit here. ==== */
CFG.FBS_HALF_SAT_LO = Math.log(2) / CFG.FBS_LAMBDA_HI;

// index.html line 3419
CFG.FBS_HALF_SAT_HI = Math.log(2) / CFG.FBS_LAMBDA_LO;

// index.html line 3423
/* v5.2 round, step 2 (Oct 3, 2026; Duke's answer d148). The US official poverty threshold for one person under 65 in 2025 (the model's year 0 is in 2025 dollars):
 * $16,749 (US Census Bureau, Poverty Thresholds for 2025 by Size of Family and Number of Related Children Under 18 Years, "one person (unrelated individual), under 65
 * years"; quoted in Congressional Research Service, Poverty in 2025, IN12737, Sept 16, 2026). Read only by the v5.2 reporting option (tbRepYear); no engine rule reads it. */
CFG.POVERTY_THRESHOLD_ONE = 16749;

// index.html line 3424
CFG.POVERTY_THRESHOLD_SENIOR = 15440;  /* v5.2 step 5: the same table's threshold for one person aged 65 and over (Census P60-290, Appendix A), used where adults age */

// index.html line 3437
/* v5.2 round, step 5 (Oct 3, 2026): the readings that close known gaps between the no-programme run and US data (LATENT; sources/scf_singles.py derives the figures).
 * The comparison group in the 2022 Survey of Consumer Finances (Federal Reserve; summary extract, five implicates pooled, weighted): single heads with no children,
 * aged 25-66, with wage income (2,700 records, 16.8 million families), dollars taken to 2025 with CPI-U.
 *  SCF_NETWORTH_PCTL     their net worth at the 0.5th, 1.5th, ..., 99.5th percentiles, 2025 dollars (median $74,422; 12.6% in debt).
 *  SCF_WAGE_WEALTH_RHO   the normal-score (Gaussian-copula) correlation of their wage income with their net worth: 0.3585.
 *  SCF_WAGE_SIGMA        the lognormal spread that gives their wage-income Gini (0.4577): 0.8617 (the model draws log wages with 0.5, a Gini of 0.276). The
 *                        standard deviation of their log wage income is 1.049, but a lognormal with that spread would have a Gini of 0.54, far above theirs,
 *                        because the very low annual wages of part-year workers dominate the log scale; the Gini is the figure the comparison is about.
 *  FO_RISK_WAGE_RHO      the employment-weighted normal-score correlation of log median wage with automation probability across Frey and Osborne's
 *                        occupations (700 with a wage; May 2016 BLS employment), -0.5313: the Gaussian copula's own parameter (sources/fo_risk_wage.py). The
 *                        figure quoted since v4.20, -0.65, is the plain correlation of log wage with the probability, which mixes the link with the two
 *                        distributions' shapes. Both are across occupations' median wages, so they overstate the link for one person (a stated limit). */
CFG.SCF_NETWORTH_PCTL = [-168690,-110095,-78374,-59977,-43453,-42243,-28987,-21813,-17491,-11419,-8325,-4888,-703,22,330,550,1100,2599,4205,4581,4972,6903,7371,8441,9736,10451,11001,12046,12740,13751,14403,15198,16309,18501,20956,23112,25216,27108,29372,33002,36017,39041,43937,46562,48496,53517,57230,60515,67699,70933,76235,78436,83848,87842,92114,101129,108326,111257,121660,132149,137340,145550,153350,157613,166338,173027,183992,194788,211641,228658,238387,248898,262005,277769,289925,300109,320343,342047,376904,422591,454553,463540,486421,503640,524757,568960,631369,740681,798477,839114,907348,979719,1048972,1164655,1385996,1688747,1826853,2170113,2675192,10801768];

// index.html line 3438
CFG.SCF_WAGE_WEALTH_RHO = 0.3585;

// index.html line 3439
CFG.SCF_WAGE_SIGMA = 0.8617;

// index.html line 3440
CFG.SCF_WAGE_MEDIAN = 54698;  /* v5.2 step 5: the comparison group's median wage income, 2025 dollars (the model's year-0 median is 35 x 12 x 100.52 = $39,945 at log mean 3.5) */

// index.html line 3441
CFG.FO_RISK_WAGE_RHO = -0.5313;

// index.html line 3446
/* S34 (Oct 30, 2026; dev/reports/baseline-realism.md): the earnings of US adults aged 25-64, Census CPS ASEC 2026 (income year 2025; sources/baseline_realism_us.py),
 * for the LATENT wage readings lt.s and lt.m set to 'all' (adults with earnings) or 'ft' (full-time, year-round workers) in place of the SCF's (lt.s, lt.m = 1).
 * median: the weighted median of earnings (PEARNVAL); sigma: the spread of log earnings read from the quartiles, (ln p75 - ln p25)/(2 x 0.6745).
 * The model's own wage scale (WAGE_TO_USD) was set from the median personal income of everyone aged 15 and over, earners or not. Labelled readings, off by default. */
CFG.CPS_EARN = {all:{median:60000, sigma:0.7370}, ft:{median:70000, sigma:0.6258}};

// index.html line 3462
/* v5.2 round, step 6 (Oct 5, 2026; ledger s85; decision B): the middle backing reading and normal-times slack (dev/DECISIONS.md, Session 35, step 6).
 *  KENYA_ABSORB_PEAK     0.16: cash transfers equal to about 16% of a year's local GDP in the peak 12 months of disbursement were met by local output with
 *                        prices up 0.1% on average (under 1% even where transfers were largest) and a local multiplier of 2.5: Egger, Haushofer, Miguel,
 *                        Niehaus and Walker (2022), "General Equilibrium Effects of Cash Transfers: Experimental Evidence from Kenya", Econometrica 90(6),
 *                        2603-2643, Section 2.2 and abstract.
 *  KENYA_ABSORB_ROLLOUT  0.12: the same study's whole rollout, 24% of a year's GDP over 24 months, as a share a year.
 *  US_UNDERUSE           0.080: BLS U-6 (unemployed, marginally attached and part-time for economic reasons, as a share of the labour force plus the
 *                        marginally attached), 2025 average (11 months; October 2025 was not collected): BLS, Alternative Measures of Labor Underutilization
 *                        for States, 2025 11-month Averages (national total).
 *  US_UNDERUSE_LOW       0.069: U-6's lowest annual average since the series began in 1994 (6.9% in 2022 and in 2023; monthly, seasonally adjusted,
 *                        BLS series LNS13327709, via the DBnomics mirror of the BLS database). U-6 above this level is the part that has come and gone with demand.
 *  MULT_NORMAL           0.6: output per dollar of spending in normal times, the low end of Ramey and Zubairy's estimates ("most estimates of the multiplier
 *                        are between 0.6 and 1", with no evidence that they differ with slack): Ramey and Zubairy (2018), "Government Spending Multipliers in
 *                        Good Times and in Bad", Journal of Political Economy 126(2), 850-901 (NBER WP 20719). Auerbach and Gorodnichenko (2012, AEJ: Economic
 *                        Policy 4(2)) find about zero in expansions, which is the layer switched off. */
CFG.KENYA_ABSORB_PEAK = 0.16;

// index.html line 3463
CFG.KENYA_ABSORB_ROLLOUT = 0.12;

// index.html line 3464
CFG.US_UNDERUSE = 0.080;

// index.html line 3465
CFG.US_UNDERUSE_LOW = 0.069;

// index.html line 3466
CFG.MULT_NORMAL = 0.6;

// index.html line 3481
/* v5.2 round, step 7 (Oct 5, 2026; ledger s86; decision C): the robustness readings (dev/DECISIONS.md, Session 35, step 7).
 *  HOUSING_CAPTURE       0.5: landlords' share of each extra dollar of rent subsidy, taken as higher rent: every $1 increase in the voucher rent ceiling
 *                        raised rents by about $0.50, with little or no gain in unit or neighbourhood quality (Collinson and Ganong 2018, "How Do Changes in
 *                        Housing Voucher Design Affect Rent and Neighborhood Quality?", American Economic Journal: Economic Policy 10(2), 62-89).
 *  HOUSING_CAPTURE_HIGH  1.41: vouchers raised the rent paid by low-income non-recipients by $8.2 billion while giving recipients $5.8 billion (rents of
 *                        low-income housing up 16% in the 90 largest metropolitan areas): Susin (2002), "Rent vouchers and the price of low-income housing",
 *                        Journal of Public Economics 83(1), 109-152; 8.2 / 5.8 = 1.41 dollars of higher rent per subsidy dollar.
 *  REVIEW_AUDIT          0.5: the share of unearned high conversion rates that the Collectives' audits catch. Not specified by the Hub (its papers describe
 *                        graduated scrutiny, multi-stakeholder review and auditable scoring, with no detection rate): a labelled design parameter, read
 *                        with 0 (no audit catches anything) beside it.
 *  FED_STD_DED, FED_BRACKETS  the 2025 federal income tax for a single filer: standard deduction $15,750 (raised from $15,000 by Public Law 119-21, July 4,
 *                        2025) and the brackets of IRS Revenue Procedure 2024-40 (10% from $0, 12% from $11,925, 22% from $48,475, 24% from $103,350,
 *                        32% from $197,300, 35% from $250,525, 37% from $626,350 of taxable income); used for the shape of the progressive income tax
 *                        reading, not its level, which is set to pay for the programme. */
CFG.HOUSING_CAPTURE = 0.5;

// index.html line 3482
CFG.HOUSING_CAPTURE_HIGH = 1.41;

// index.html line 3483
CFG.REVIEW_AUDIT = 0.5;

// index.html line 3484
CFG.FED_STD_DED = 15750;

// index.html line 3485
CFG.FED_BRACKETS = [[0, 0.10], [11925, 0.12], [48475, 0.22], [103350, 0.24], [197300, 0.32], [250525, 0.35], [626350, 0.37]];

// index.html line 3497
/* v5.2 round, step 4 (Oct 3, 2026; ledger s83): the ageing switch's inputs (read only when AGE is on; sources/demography.py derives the two arrays).
 *  AGE_WEIGHTS  US resident population at each age 25..66, thousands, July 1, 2024 (Census Bureau, Vintage 2024 national estimates by single year of age,
 *               nc-est2024-agesex-res.csv): the starting ages of the model's working-age adults are drawn in these proportions.
 *  DEATH_Q      probability of dying between ages x and x + 1, x = 25..100, the 2022 US period life table for the total population (Arias, Xu and Kochanek,
 *               United States Life Tables, 2022, NVSR 74(2), April 2025, Table 1; 100 and over: 1). Stands in for the SSA's period life table for 2022 (2025
 *               Trustees Report), which ssa.gov would not serve to this environment; at age 67 the two agree within 0.3%.
 *  SS_RETIRE_ANNUAL  the average retired-worker benefit in 2025 dollars: $2,015 a month before the 2026 cost-of-living adjustment (SSA, 2026 COLA Fact Sheet;
 *               the same sheet as SS_ANCHOR_RETIRE_ANNUAL, $2,071 after it) x 12 = $24,180 a year.
 *  SS_BEND_POINTS  2025 primary-insurance-amount bend points, $1,226 and $7,391 a month (SSA, Benefit formula bend points), for the earnings-linked reading:
 *               90% of average monthly earnings up to the first, 32% up to the second, 15% above.
 *  RETIRE_AGE 67 (full retirement age for everyone born in 1960 or later; SSA); ENTRY_AGE 25 (new adults join at 25). */
CFG.AGE_WEIGHTS = [4467,4459,4467,4496,4571,4660,4728,4826,4888,4892,4747,4655,4595,4594,4580,4477,4531,4512,4439,4411,4225,4124,4066,3922,3957,3875,3919,4099,4334,4259,4095,4001,4007,4055,4201,4292,4283,4286,4265,4176,4084,4036];

// index.html line 3498
CFG.DEATH_Q = [0.001231,0.001316,0.001406,0.001499,0.001591,0.001682,0.001769,0.001851,0.001927,0.002002,0.00208,0.002164,0.002257,0.002359,0.002469,0.002593,0.002725,0.002854,0.00298,0.003113,0.003271,0.003466,0.003695,0.00395,0.004226,0.004515,0.004833,0.005204,0.005647,0.006162,0.006709,0.007285,0.00793,0.008641,0.009392,0.010173,0.01096,0.011741,0.012524,0.01334,0.014218,0.01528,0.016329,0.017524,0.018824,0.020179,0.021711,0.023521,0.025618,0.028122,0.030467,0.034339,0.03738,0.0415,0.045247,0.050833,0.056254,0.062471,0.069526,0.076869,0.086054,0.094545,0.106195,0.118983,0.132946,0.148104,0.164457,0.181983,0.20063,0.22032,0.240942,0.262361,0.284411,0.306908,0.32965,1.0];

// index.html line 3499
CFG.SS_RETIRE_ANNUAL = 2015*12;

// index.html line 3500
CFG.SS_BEND_POINTS = [1226, 7391];

// index.html line 3501
CFG.RETIRE_AGE = 67;

// index.html line 3502
CFG.ENTRY_AGE = 25;


// index.html line 3509
/* v4.16: counterfactual switch for the PTH appreciation-accounting question logged in
 * CONTRIBUTING.md's v4.16 notes. false (the default, and the only value any validated mode
 * uses) reproduces index.html exactly: the FULL appreciation is added to acreEquity AND the
 * tenure-based liquid share is credited to wealth. true is the value-conserving alternative
 * (acreEquity keeps only the non-liquid remainder). Read only by the `pth-accounting` mode. */
var PTH_APPR_CONSERVE = false;

// index.html line 3514
/* v5.3 B2 (Oct 6, 2026; dev/DECISIONS.md Session 39): the accounting check found that, in the two readings where landlords raise the rent of tenants paying with
 * BU (HCAP), the ESP surplus split sizes its uniform price cut on each customer's essentials before the mark-up but applies it to the essentials after it, so it
 * hands out up to 4% more than the pool holds in a year (dollars from nowhere). SURP_CUT_MARKUP = true sizes the cut on the same bill it is applied to (the
 * mark-up included for the BU customers it falls on); false (the default) is v5.2 exactly. It changes nothing without HCAP. No random draw. */
var SURP_CUT_MARKUP = false;

// index.html line 3524
/* v4.19: two harness-only switches recording the decision on how the BU amount reaches a
 * household (CONTRIBUTING.md v4.19; Duke chose Option B, which index.html now ships). Both
 * default to index.html's behaviour, bit-identically.
 *  BU_ALLOCATIONS_PER_YEAR — BU allocations credited per simulated year (index.html: 1). 12
 *    approximates monthly tranches at expiry=1: each month's allocation is spent at the year's
 *    spend fraction and the remainder expires. The 3x cap scales with it.
 *    (Option A, not adopted.)
 *  CCO_RELIEF_FLAT — true restores v4.18's flat 0.80 CCO cost relief (index.html: false, i.e.
 *    Option B: relief scales with the effective BU). For before/after comparisons only. */
var BU_ALLOCATIONS_PER_YEAR = 1;

// index.html line 3525
var CCO_RELIEF_FLAT = false;

// index.html line 3529
/* v4.21: harness-only switch. true restores v4.19-v4.20's CCO relief share, read off NOMINAL
 * effective BU against the year-0 $1,200 reference (an unindexed BU kept its real relief under
 * inflation, and COLA counted inflation twice). Inert at 0% inflation. index.html: false. */
var RELIEF_PRICE_LEGACY = false;

// index.html line 3540
/* v4.21: harness-only switches for the `pathways` and `saving` modes (CONTRIBUTING.md v4.21). Both
 * default to the shipped engine, bit-identically (checked by `validate`).
 *  PATHWAY_OFF — switch off one channel through which CCO or PTH reaches wealth, CRN-paired:
 *    relief (CCO cost relief), conversion (conversion proceeds), octave (octave advancement),
 *    octaveWage (the octave wage-growth bonus), bleiWage (the BLEI-gated wage-growth bonus),
 *    pthCost (PTH's 35% cost reduction, and with it the equity routing it funds),
 *    pthEquity (equity routing and liquid appreciation; the saving stays in wealth).
 *    The v4.14 pathway-decomposition item (Good First Issues, v4.14 (b)).
 *  SURPLUS_CONSUMPTION_SHARE — the share of income above the agent's own basket cost that the
 *    agent consumes. The engine consumes exactly the basket (0), so every dollar above it is saved. */
var PATHWAY_OFF = {relief:false, conversion:false, octave:false, octaveWage:false, bleiWage:false, pthCost:false, pthEquity:false};

// index.html line 3541
var SURPLUS_CONSUMPTION_SHARE = 0;

// index.html line 3545
/* Session 7 (dashboard i3-1, s23): harness-only switch. The engine's FBS gate on octave advancement reads the monthly basic cost
 * AFTER the CCO relief discount and then adds effective BU on top, so BU enters FBS twice (the framework branch already reads the
 * cost before the relief). true: the engine branch reads the pre-relief cost, as the framework branch does. index.html: false. */
var FBS_BU_ONCE = false;

// index.html line 3554
/* Session 9 (dashboard i3-2): N7 attribution of the BLEI-gated wage raise. The N7 split counts the octave and CIP raises as
 * program-induced and the BLEI-gated raise as not, since the Baseline has it too. But in a design the raise can fire only
 * because the design's own support lifts the adult over the gate. N7_BLEI true counts the BLEI raise as program-induced in
 * exactly those adult-years: the gate passes as the run reads it (the shipped or the design-neutral gate) and fails on Baseline
 * rules with no program support (agentBLEI(a, 0, false, ...)). Direct, same-year attribution only: a raise that passes on
 * Baseline rules is not attributed, even where program-built wealth put the adult there. The same rule applies to every
 * design. It moves the labor module's raise (uncompensated response) and, where aw < 1, the price module's unmatched
 * premium; the raise itself is unchanged. Default false (the attribution through session 8). No RNG. */
var N7_BLEI = false;

// index.html line 3561
/* Session 1 of the Sep 26 plan: which income SURPLUS_CONSUMPTION_SHARE applies to. 'wage' (the v4.21
 * behaviour): the share of wage income above the agent's basket, taken right after the wage step, so
 * conversion proceeds and PTH liquid appreciation are always saved in full. 'cash': the share of ALL cash
 * surplus that year (wage + net conversion + liquid PTH appreciation − basket − PTH equity routing), taken at the end of the
 * agent's year, before the floor clamp; conversion proceeds first offset any wage deficit. Inert when the
 * share is 0 (the default), so every shipped figure is bit-identical. For the consumption-rule decision. */
var SURPLUS_CONSUMPTION_BASE = 'wage';

// index.html line 3568
/* A1 issuance ledger (Next Round Plan, Sep 26 2026): harness-only and reporting-only. When LEDGER is
 * an object, runYear() adds each money flow it already computes to it, by year. It draws no random
 * number and writes nothing any dynamic reads (the one per-agent field, _ledFloor, is read only by the
 * `ledger` mode), so a run is bit-identical with it on or off; `ledger` checks this on every scenario.
 * null (the default, and index.html's behaviour) skips every ledger line. Flows are nominal dollars;
 * each year also records its price index so the report can deflate to year-0 dollars. */
var LEDGER = null;

// index.html line 3569
var LEDGER_RATE_TIERS = [1.5, 3, 6, 9];  /* conversion-rate tier upper bounds: <1.5, 1.5-3, 3-6, 6-9, >=9 (3 = PROG_PIVOT, 9 = maxMult) */

// index.html line 3590
/* v5.3 B2 (Oct 6, 2026; plan item B2, dev/DECISIONS.md Session 39): THE ACCOUNTING IDENTITIES, AS AN OPTIONAL RUNTIME CHECK. ACCT = null (the default, and
 * the page's) skips every ACCT line, so a run is bit-identical with or without it (the unit suite checks this on the release rows). When ACCT is an object
 * (acctNew()), runYear records each flow where it happens (per adult, fields _ac*; no random draw; nothing any rule reads) and checks, every year:
 *  money     each adult's ending money wealth = beginning + interest + wage earnings - living costs + Social Security + cash transfers less the contribution
 *            + conversion income - PTH equity contribution + PTH appreciation paid out in cash - surplus consumed + debt written off at the floor; every
 *            term but the PTH and interest ones is the adult's own yearly record that the income and poverty measures read (yrWageUSD, yrConvUSD, ...);
 *  equity    each PTH member's ending Acre Equity = beginning + equity contribution + appreciation not paid out (the cash part leaves the equity);
 *  bu        each adult's BU balance (engine model) = beginning + issued - expired - spent; and in the framework model the year's BU stock (the ESP payroll
 *            pool, the project pool, BU adults hold for later conversion, BU directed but not yet allocated) = the stock at the start + BU issued
 *            (allowances and the launch gift) - BU converted (by adults, by the ESP) - BU destroyed (expired BU not directed, BU beyond a cap);
 *  premium   the ESP's conversion premium paid out this year (with last year's carries) = price cuts delivered + dollars paid to adults + reinvestment
 *            + capital charges + what carries to next year (without the surplus split: the premium = the dollars paid out);
 *  books     the Source's ledger (testbed rows) = the households' books: BU face value paid = BU spent by adults; conversion paid = adults' conversion
 *            income + the split's price cuts + reinvestment + capital charges; BU issued = allowances; and the price module's injection = the same less
 *            the price cuts;
 *  source    (tbRunCore, Source financing) what the Source pays = new money + the output that backs it.
 * The tolerance is relative: a gap passes when |gap| <= ACCT.tol x max(1, gross size of the flows in dollars or BU), tol = 1e-9. A failure is recorded in
 * ACCT (count, the first ACCT.keep cases with their size; the gaps' sum by identity in ACCT.sum), never thrown, so a study can count them; a NaN fails. BU that
 * adults held for later conversion when they died are tallied in ACCT.lostDeath (they lapse, as unspent BU do). No figure depends on ACCT. */
var ACCT = null;

// index.html line 3639
/* ─── Next-round session 2 (Sep 26 2026; Duke assigns the version). Harness-only switches, every one inert by
 * default, so index.html and every shipped figure are unchanged (`validate` and domtest's parity checks).
 *
 * CFG.BASKET (decision N10): components of LIVING_WAGE_ANNUAL as shares of the pre-tax budget. Source: MIT Living
 * Wage Calculator (data of Feb 15, 2026), 1 adult, 0 children, "Typical Expenses". LIVING_WAGE_ANNUAL is the
 * unweighted mean of the 51 state living wages x 2,080 (checked in-session: $49,369.82). The site asks not to be
 * scraped, so the components come from 8 state pages read by hand (AL, CA, CT, HI, ID, IN, ME, WV; about one per
 * sixth of the 2026 ranking): each component's dollars regressed on the state's pre-tax total, evaluated at $49,370.
 * Housing is HUD Fair Market Rent, which includes tenant-paid utilities. `taxes` is income and payroll tax, which no
 * discount can reduce. See session-2-handoff.md for the sample and the fit.
 * ESSENTIALS: the components BU can buy and P_E prices (food, housing incl. utilities, medical: 43.5% of the basket). */
CFG.BASKET = {food:0.0901, housing:0.2761, medical:0.0685, transport:0.1955, civic:0.0663, internet:0.0314, other:0.0924, taxes:0.1797};

// index.html line 3640
CFG.BASKET_KEYS = ['food','housing','medical','transport','civic','internet','other','taxes'];

// index.html line 3641
CFG.ESSENTIALS = ['food','housing','medical'];

// index.html line 3649
/* v5.3 B3f (Oct 7, 2026; Duke's answer d173 on the dashboard, Oct 6: "the full list is the design; v5.3 adds it first as a labelled reading"): what BU can
 * buy. BU_SCOPE 'core' (the default; the model since September, decision N10): food, housing (with utilities) and medical care, CFG.ESSENTIALS. 'hub': the
 * Hub's list (glossary, "Basic Units": housing, food, healthcare, education and transportation; draft Act section 103: "Housing, Food, Transportation
 * (non-luxury), Healthcare, Education, PTF services"), so transport too (CFG.ESSENTIALS_HUB) and, for households, childcare (PTF childcare centres;
 * schooling has no fee in the model, so education reaches BU through childcare). Only what BU can buy changes: the price module's essentials keep their
 * sourced responses (food, housing, medical), and transport and childcare keep the general price level, which already rises with the Source's unbacked
 * payout (no source gives their own response to demand: a stated limit). buEss() is the list BU purchases, open enrolment and the split read. */
var BU_SCOPE = 'core';

// index.html line 3650
CFG.ESSENTIALS_HUB = ['food','housing','medical','transport'];

// index.html line 3651
function buEss(){ return BU_SCOPE === 'hub' ? CFG.ESSENTIALS_HUB : CFG.ESSENTIALS; }

// index.html line 3655
/* PTF_MODE (decision D4): 'shipped' = PTF cuts the whole basket by 12% (+4% x SZH coherence), as index.html does;
 * 'food30' = 30% off the food component only (the NYC public-grocery pilot's PROMISED cut, not an observed one);
 * 'food62' = 62% off food only (the hub's eps_food = 2.64: 1 - 1/2.64). Food modes ignore the SZH add-on. */
var PTF_MODE = 'shipped';

// index.html line 3656
var PTF_FOOD_CUT = {food30:0.30, food62:0.62};

// index.html line 3669
/* CONVERSION_MODEL (decisions N1-N4). 'engine' = index.html: each participant converts one allocation of their own
 * spent balance; CCO relief is 20% of the basket. 'framework' = the Research Hub's description:
 *  N3: one BU budget, 12 x effective BU a year per participant.
 *  N4: BU buy essentials at the agent's own (PTF/PTH-discounted) prices, up to the budget; a BU is worth $1 to all.
 *  N1: businesses convert the BU they accept at FW.bizRate (placeholder; hub cafe example 2-4x) on FW.bizCap of it
 *      (operational cap, placeholder; the rest converts at par), under the engine's progressive tax. The premium over
 *      a cash sale (net proceeds - BU accepted) is paid out the next year to ALL agents in proportion to wage income,
 *      standing in for business revenue paid out as wages and profit (the model has no firms: an assumption).
 *  N2: unspent BU expire; FW.directedShare of them go to projects and are converted the next year by participants
 *      in proportion to octave capacity x quality, at each one's own engine rate, within octave capacity
 *      (FW.octaveCapBase x 2^octave BU a month; engine octave k = hub octave k+1). The rest are destroyed.
 * Year-0 pools are empty and the last year's pools are never paid out (the run ends). */
var CONVERSION_MODEL = 'engine';

// index.html line 3670
var FW = {bizRate:3, bizCap:1, directedShare:1, octaveCapBase:1000};

// index.html line 3671
var FWS = null;  /* per-run framework state (pools carried from one year to the next); reset by runYear at yr 0 */

// index.html line 3699
/* N1, session 15 (dashboard s33; decisions d58-d65; N1-design-project-hiring.md): PROJECT HIRING PAID IN EXPIRED BU, the design's
 * mechanism in place of the octave wage raise (d46). PROJ = null (the default) leaves every run bit-identical (checked by `unit`).
 * When an object, in both conversion models:
 *  pool   last year's expired BU x share (engine: the unspent balance that expires, A0 flow 3, destroyed when PROJ is off; framework:
 *         the BU budget left unspent, N2's pool), plus the launch gift (rollout plan: 1,000 expired BU per participant) collected
 *         in year 0 and paid in year 1 when giftMode is 'forward'. Pool that finds no worker carries to the next year.
 *  pay    contract pay, BU per project hour in year-0 dollars, indexed to the basket price level (default: the model's living wage,
 *         $49,370 / 2,080 hours, at par; d63).
 *  alloc  'capq': participants for whom a project hour pays more, after conversion and tax, than an hour of their own wage, weighted
 *         by octave capacity x quality (d61); 'capqAll': the same weights, no willingness test (the framework model's N2 rule);
 *         'low': the willing, lowest wage first, each up to capacity; 'equal': equal shares among the willing.
 *  rate   'max': the higher of the worker's own rate and the contract rate, the capacity x quality-weighted mean own rate of
 *         participants (R4, R5; d62); 'own': own rate only. Progressive conversion tax, CIP bonus and income shock as in the engine.
 *  cap    false (d64, Duke's pick): no conversion cap. true: each participant converts at most 12 x FW.octaveCapBase x 2^octave BU a year: project BU fill what the engine's own
 *         spent-balance conversion leaves (that conversion is left uncapped; it never reaches the smallest capacity at $1,200 BU);
 *         BU above it are saved and converted in later years (d64).
 *  hours  'side' (d63, Duke's pick): project hours are added on top of wage work; 'displace': each project hour replaces an hour
 *         of wage work at the worker's own wage. 'low' allocation always fills each worker up to octave capacity. Project
 *         pay is earned, so it carries no income effect. The testbed's hours measure counts wage plus project hours.
 *  giftMode 'forward' | 'holder' (each participant converts their own gift at their own rate from year 1, with no hours: an
 *         unconditional dollar, so it enters the labor module's rent channel) | 'none'.
 *  giftFin how the testbed's flat contribution pays for the gift's proceeds (d66; issue i7, session 16): 'payg' (Duke's pick) in
 *         the year they are paid, so the year-2 contribution rises; 'run' spread over the remaining years of the run, the rule
 *         the testbed applies to the asset endowment (d26). The cost counted is the same; only its timing, and so the work
 *         response to the contribution, differs. Read only by the testbed's tax and hybrid financing.
 * Allocation is deterministic: no RNG draw is added (CRN holds). With PROJ on, the framework model's N2 allocation is replaced.
 * PJS: per-run state, reset by runYear at yr 0; PJS.acc tallies the flows in year-0 dollars for the testbed and the unit tests. */
var PROJ = null;

// index.html line 3700
var PROJ_DEFAULTS = {share:1, gift:1000, giftMode:'forward', giftFin:'payg', pay:CFG.LIVING_WAGE_ANNUAL/2080, alloc:'capq', rate:'max', hours:'side', cap:false, hrsYr:2080};  /* Duke's picks (Sep 30): d63 side hours, d64 no cap, d66 pay as you go */

// index.html line 3701
var PJS = null;

// index.html line 3702
function pjOwnRate(a, p, pcb){ var oc = 1 + (a.octave/Math.max(1, p.maxOct))*(Math.max(1, p.maxMult) - 1), qf = Math.min(1, a.quality/Math.max(1, p.maxMult));
  var ph = (p.phi && a.quality > p.maxMult*CFG.PHI_QUALITY_THRESH) ? CFG.PHI_RATIO : 1.0, pb = POS ? poBonus(a, p, pcb) : (p.ptf && a.inPTF) ? pcb : 1.0;
  var r = Math.min((1 + qf*(oc - 1))*ph*pb, p.maxMult*(p.phi ? CFG.PHI_RATIO : 1.0)); return LVS && LVS.m !== 1 ? 1 + LVS.m*(r - 1) : r; }  /* S54: o.lv's phase-in and issuance cap (LVS.m) */

// index.html line 3705
function pjTax(p, r){ var bT = p.cip ? p.tax*(1 - p.cipDemo*0.18) : p.tax; return LVS ? Math.min(LVS.pc, bT + Math.max(0, (r - CFG.PROG_PIVOT)*LVS.pr)) : Math.min(CFG.PROG_TAX_MAX, bT + Math.max(0, (r - CFG.PROG_PIVOT)*CFG.PROG_RATE)); }  /* S54: o.lv's progression (pr) and cap (pc) */

// index.html line 3706
function pjNewAcc(){ return {pool:0, gift:0, exp:0, alloc:0, carry:0, conv:0, giftConv:0, gross:0, net:0, giftNet:0, hrs:0, disp:0, work:0, partY:0, rc:0, rcN:0, overCap:0, unwilling:0}; }

// index.html line 3736
/* N1, session 19 (s38; decisions d70-d76; N1-design-esp-payroll.md): ESP PAYROLL IN EXPIRED BU AT WORKERS' OWN RATES, the design's
 * mechanism (Duke's R7, Sep 29) for the wage part of the Hub-spec model's business conversion (N1 above). Framework model only: the
 * engine model has no business conversion and ignores ESP (d70). ESP = null (the default) leaves every run bit-identical (session 19
 * diffed full outputs against b1bc475; `unit` checks lam 0 against ESP off). When an object:
 *  lam   payroll share (d71): of the BU essential service providers accept in year t, lam are paid out as wages in year t + 1 (the
 *        premium's timing today) and the rest convert at FW.bizRate as now. 0.20 = compensation / gross output in the essential
 *        industries, weighted by CFG.BASKET's essentials (BEA GDP-by-industry, 2024 values: 0.20 on both the Jun 25 and the Sep 30, 2026 releases; range 0.15-0.26,
 *        leaning high because BEA measures a grocer's output as its margin; sources/esp_payroll_share.py).
 *  work  who the ESP workers are (d72): a share of adults (0.230 = BLS CES Table B-1, Aug 2026: grocers, food services, utilities,
 *        real estate and health care / total nonfarm; 0.152 without food services), assigned by agent index (the fractional part of
 *        (i + 1) x 0.618... below the share: no RNG, the same adults in every design and seed); 'ptf' = this year's PTF members (the
 *        Hub's "PTF workers"); 'all' = every adult (today's payout population).
 *        The pool is shared among ESP workers in proportion to last year's wage income, each share capped at that wage; any excess
 *        returns to the ESP.
 *  take  'par' (d73): a participating ESP worker whose own rate (octave, quality, Phi, PTF bonus; the rate project hiring reads) after
 *        the progressive tax, times the CIP bonus, beats par takes their share as expired notes and converts it; 'biz': only where the
 *        own rate beats FW.bizRate (a revenue-maximizing ESP). Everyone else is paid in dollars, and the ESP converts those BU itself.
 *  cap   'dollars' (d74): payroll conversion is capped at 12 x FW.octaveCapBase x 2^octave BU a year, net of this year's project BU;
 *        BU above it are paid in dollars (the ESP converts them). 'save': the excess is saved and converted first in later years (R6).
 *        'none': no cap.
 *  rest  'all' (d75): the ESP's own premium, on the share it keeps and on the BU returned to it, is paid as today: next year (the
 *        returned BU: this year, with the rest of last year's premium) to every adult by last year's wage, the stand-in for the ESP's
 *        other costs and surplus. 'esp': to its own workers by last year's wage (a worker cooperative).
 * Income: wages are unchanged, so BU pay counts at face value in wages and the contribution base; the premium over face value,
 * BU x (rate x (1 - tax) x CIP bonus x income shock - 1), is conversion income: program cost, and P_G under money or hybrid financing.
 * Labor: the premium is earned by working at an ESP, so it enters the wage elasticity as a raise, 1 + premium before the income shock /
 * last year's wage, inside the same uncompensated factor as every other raise, with no income effect (the fairness rule). The ESP's
 * own premium keeps today's treatment. No RNG is drawn in any ESP step.
 * ESS: per-run state, reset by runYear at yr 0; ESS.acc tallies the flows in year-0 dollars for the testbed and the unit tests. */
var ESP = null;

// index.html line 3737
var ESP_DEFAULTS = {lam:0.20, work:0.230, take:'par', cap:'dollars', rest:'all'};

// index.html line 3738
var ESP_GOLD = (Math.sqrt(5) - 1)/2;

// index.html line 3739
var ESS = null;

// index.html line 3740
function esNewAcc(){ return {accBU:0, ownBU:0, poolPaid:0, alloc:0, conv:0, ret:0, retNon:0, retPar:0, retCap:0, retWage:0, retNet:0, gross:0, tax:0, prem:0, rateXbu:0,
  wkY:0, wkY1:0, wage:0, partWkY:0, tk:0, capBind:0, maxShare:0, sv:0}; }

// index.html line 3782
/* Plan step 1 (Oct 1, 2026; s40; dev/background/N1-design-esp-surplus.md, decisions d97-d106 and dev/DECISIONS.md): THE ESP SURPLUS
 * SPLIT, in place of today's stand-in (the ESP's own premium paid next year to every adult by wage). Hub-spec (framework) model only;
 * SURP = null (the default) leaves every run bit-identical (full-output diffs of projcore, esp, match and a5; `unit` checks it). When an
 * object, each year the ESP's own premium from last year (FWS.prev.bizNet: the BU it kept and the payroll BU returned to it, converted
 * at FW.bizRate under the progressive tax, less face value; d97) is split:
 *  priv  'owners' (default; Duke, Oct 1: owners keep all of a private business's earnings): the premium earned on BU that PTF members
 *        spent last year is the PTFs' and is split as below; the rest is private ESPs' and is paid in dollars to owners, every adult
 *        in proportion to positive start-of-year wealth (the model has no firms or shares; wealth stands in for ownership). An
 *        unconditional dollar: one income effect (rho). 'same' (d102): one split for every ESP.
 *        'prices' (plan step 14, Oct 2, 2026; Duke's correction d140, dev/reports/v5-1-private-esp-correction.md): a private ESP
 *        passes its premium to the customers who paid it in BU as a lower BU price and stays revenue neutral (Duke: a $9/$12/$15
 *        menu becomes $3/$4/$5 in BU at 3x); nothing goes to owners. Owners compete for workers, so participating private-ESP
 *        workers are paid what a profit-share worker earns: the private premium's profit-share fraction (the PTFs' this phase) joins
 *        the profit share (the model has no firms, so the match is funded from the premium itself; every dollar stays accounted),
 *        and the rest is the private price pool. It is shared among participants who are not PTF members (the BU spent at private
 *        ESPs, by the same proxy that sizes the PTFs' share) in proportion to the BU each spent last year, capped at their own
 *        essentials; the rest carries to next year. BU buy the discounted essentials first; the BU the cut frees expire as usual.
 *  privWk 'match' (default) as above; 'none': the whole private premium becomes lower prices (sensitivity row).
 *  p1,p2 shares [price cuts, reinvestment, profit share] in phase 1 (until PTF capacity is reached) and phase 2 (S2, S3). Shares that
 *        sum below 1 leave a remainder paid as today's stand-in (by wage to every adult), for the "each part alone" rows.
 *  K     capacity: phase 2 starts the year after cumulative reinvestment per adult, in year-0 dollars, reaches K (d101: $18,862, BEA
 *        Fixed Assets Table 3.1ESI 2025 net stock of food and beverage stores, food services and utilities / Census adults 18+, 2025).
 *        Infinity = never. swYear (a number): phase 2 from that year on, whatever the capital account (the fixed-year rows).
 *  cust  who gets the price cuts: 'auto' (default) = 'ptf' under priv 'owners' (the PTFs' cuts reach the PTFs' customers, read as PTF
 *        members, the same proxy that sizes the PTFs' share) and 'all' under 'same' (d98); 'all' every adult; 'pp' participants and
 *        PTF members; 'ptf' PTF members; 'part' participants. Shared in proportion to each customer's essentials at own prices
 *        (basket x essentials share x the PTF and PTH factors), one uniform cut delta = price pool / that sum, capped at 1; the rest
 *        carries to next year's price pool.
 *  bu    'one' (d99): one price for BU and cash; a participant's BU buy the discounted essentials first, and the BU a cut frees expire
 *        and go to project hiring like every expired BU. 'cash': the cut applies to cash purchases only (no BU freed).
 *  rv    'capital' (d100): reinvestment goes to an ESP capital account no household receives (its effect on supply is plan step 2).
 *        'price': the reinvestment share is spent as price cuts (no capital is built, so phase 1 lasts the run).
 *  wk    'espPart' (default from the step-11 restudy; Duke's answer recorded in the project ledger, s40): the profit share is paid in
 *        dollars to ESP workers who take part (ESP payroll's workforce, d72), by last year's wage; it is earned, so it enters the wage
 *        elasticity as a raise (1 + share / last year's wage) with no income effect. 'esp' (d104's earlier default, used in steps 1-9):
 *        every ESP worker.
 * Accounting (d105): price cuts used, the profit share, reinvestment and the owners' dollars are parts of the ESP's conversion premium,
 * counted as conversion in the testbed (financed by the contribution under tax financing; created at a under money and hybrid). The
 * design-neutral BLEI gate keeps counting the BU a participant would have spent without the cut (price cuts enter no design's neutral
 * BLEI). No RNG is drawn in any SURP step (CRN holds). SPS: per-run state, reset at yr 0; SPS.acc tallies flows in year-0 dollars. */
var SURP = null;

// index.html line 3783
function spBase(a){ return SURP.own === 'eq' && a._rt ? Math.max(0, a._rt.r[2] + a._rt.r[3]) : Math.max(0, a.wealth); }  /* S59 part 2: what the owners' dollars are shared by: positive wealth (default; the model had no shares), or under own 'eq' with rt the shares and private-business equity held */

// index.html line 3784
var SURP_DEFAULTS = {p1:[1/3, 1/3, 1/3], p2:[0.6, 0, 0.4], K:18862, swYear:null, cust:'auto', bu:'one', rv:'capital', priv:'owners', wk:'espPart', privWk:'match'};  /* wk 'espPart': Duke's answer (ledger, s40): only participating ESP workers share; applied from the step-11 restudy on (steps 1-9 ran 'esp', d104's earlier default) */

// index.html line 3785
var SPS = null;

// index.html line 3801
/* Plan step 2 (Oct 1, 2026; design default 1; dev/reports/02-production-side.md): THE PRODUCTION SIDE, the new output that backs the BU.
 * Hub-spec (framework) model only; PROD = null (the default) leaves every run bit-identical (full-output diffs; `unit`). When an object:
 *  cap   'ptf' (default): PTF capacity. The PTFs can serve a share c of the population: c = c0 + the ESP capital account per adult / K
 *        (SURP.K, d101), capped at 1, where c0 is the PTF members' share at the start of year 0 (the PTFs that already exist). An adult
 *        joins PTF (Bass adoption or SZH induction, with the draws the engine already makes) only while PTF members are fewer than
 *        c x adults; no member is ever removed. Reinvestment in year t serves customers from year t + 1. With the split on, phase 2
 *        starts when c reaches 1 (enough PTFs to serve demand, S3). 'none': PTF reach is unlimited, as before.
 *  match 'face' (default): project work is output valued at the cost of the hours it pays for, the contract pay (the BU's face
 *        value; hours = project BU converted / the contract pay); the conversion paid above that is a reward, not output. 'own': the
 *        hours valued at the worker's own market wage (more output for the many project workers paid above the contract rate, so
 *        the less cautious reading). The ESP split's reinvestment is output at face value (capital
 *        goods). Neither adds essentials supply. Both enter the price module only where conversion is created money (money and
 *        hybrid financing): unmatched money = (1 - a) x (conversion - matched output), so H1 (a = 1) stays a sensitivity row.
 *  mat   materials bought per dollar of project labour (0: the model has no materials; a stated limit).
 * No RNG is drawn in any PROD step (adoption reads the draws the engine makes for every agent-year). PDS: per-run state. */
var PROD = null;

// index.html line 3802
var PROD_DEFAULTS = {cap:'ptf', match:'face', mat:0, speed:'reinvest'};

// index.html line 3841
/* Plan step 15 (Oct 2, 2026; Duke's answers d137-d139; dev/reports/v5-2-creative-output-reading.md). Two more PROD options:
 *  match 'market' (Duke's reading, d138): a creative project offers its output to members far below the market price and converts the
 *        BU it receives at its earned rate, so its dollar income is about what the market would pay (revenue neutral). The whole project
 *        payout (the elevated part included) counts as output, beyond essentials. The model's project hours are the work shown: no hours,
 *        no payout. 'face' (session 30's rule) stays the cautious other reading; a = 1 (H1) the optimistic row.
 *  speed 'oneyear' (Duke's answer d137, the main run): PTF capacity grows within a year: the adults the capacity limit turned away last
 *        year (draws the engine already makes) are served this year. Capacity reinvestment has not paid for is borrowed and charged every
 *        year at depreciation plus real interest, paid from the PTFs' premium before the split (any shortfall carries). 'reinvest'
 *        (session 30): capacity grows only as reinvestment pays for it (the 5-year rule; the labelled other reading).
 * The charge (real, on capital in year-0 dollars revalued with the price level):
 *  PROD_CAP_DEP 4.528%: BEA Fixed Assets Table 3.4ESI, current-cost depreciation 2025 (utilities $166,748m, food and beverage stores
 *        $24,478m, food services and drinking places $33,202m; lines 9, 45, 95) over the mean of Table 3.1ESI net stock, yearend 2024 and
 *        2025 ($4,823,935m and $5,088,349m) (Section3All_xls.xlsx, file created Sep 28, 2026).
 *  PROD_CAP_INT 3.668%: a real corporate borrowing rate, 2025 annual means from FRED: Moody's Baa yield 5.998% (BAA) less the 10-year
 *        Treasury 4.293% (DGS10) plus the 10-year TIPS yield 1.963% (DFII10). The depreciation part buys replacement capital (output,
 *        like reinvestment); the interest part goes to lenders the model does not have (counted as conversion, unmatched; a stated limit).
 * ESP octave caps (d139): BU can only buy essentials adults already consume, which ESPs already supply, so the BU an ESP converts never
 * exceed its throughput; the cap holds by construction (v5ProdUnitSuite checks it). Individuals and Collectives have no cap (PROJ.cap
 * false, d64), and every expired BU already pays project work (PROJ.share 1), the route Duke's "6 expired BUs" describes. */
/* Plan step 16 (Oct 2, 2026; dev/reports/v5-3-spending-layer.md): THE SPENDING LAYER. Spending at businesses raises output and jobs where
 * there is idle capacity. MULT = null (the default) leaves every run bit-identical. When an object (testbed, Source financing only):
 *  push  the programme's new spending: last year's net Source payout (BU spent plus conversion paid, less the conversion tax kept), in
 *        current dollars (one-year lag; it is known at the start of the year). The multiplier is per dollar of transfer, so it already
 *        includes how much of a transfer is spent (Parker et al. 2013: 50-90% within a quarter, for context).
 *  m     output per dollar of push in a recession year: 1.5 (main; the middle of CBO's 0.8-2.2 for transfers to individuals, Estimated
 *        Impact of the American Recovery and Reinvestment Act, output multipliers table; the low end of Auerbach and Gorodnichenko 2012,
 *        AEJ: Economic Policy 4(2), 1.5-2 in recessions); 0.8 (low; CBO's low end, in line with Ramey and Zubairy 2018, JPE 126(2),
 *        multipliers below 1 with or without slack); 2.2 (high; CBO's high end).
 *  Idle capacity: only the income a recession takes away (the model's recession path). Outside recessions the model has no slack (no
 *        unemployment beyond what workers choose), so the layer adds nothing there and the published normal-times multipliers (0-0.5)
 *        never apply; spending above capacity goes to prices exactly as before. Automation's wage losses are structural, not idle demand,
 *        and are not counted (a stated limit).
 *  The wages restored = min(labour share x m x push, the recession's wage loss); they reach every adult in proportion to what the
 *        recession took from them (in the model everyone loses the same share), by raising the year's income multiplier. Labour share
 *        0.5079: compensation of employees over gross domestic income, 2025 (BEA NIPA via FRED COE and GDI, sums of the four quarters).
 *        The non-labour part of the added output is not paid to anyone (the model has no firms; a stated limit). The restored wages raise
 *        the output the price rule divides by, so they slow the created-money price rise; nothing else changes.
 * No RNG is drawn. MLS: per-run state (push, and per year the fill and wages restored). */
var MULT = null, MULT_DEFAULTS = {m:1.5}, MLS = null, MULT_LS = 62784.912/123630.857;

// index.html line 3850
/* v5.2 step 7 (ledger s86): HOUSING CAPTURE. HCAP = null (the default) leaves every run bit-identical. When {c, all} (testbed row option hc), rents
 * rise by c dollars per BU dollar spent on rent outside PTH: each year the mark-up is c x last year's BU spent on rent outside PTH / last year's rent bill
 * of the adults it falls on, who are the BU holders outside PTH (all false: landlords raise the rent of tenants who pay with BU, as voucher holders'
 * rents rose in Collinson and Ganong 2018) or every adult outside PTH (all true: the rise spreads to other renters, as in Susin 2002; with his figures,
 * $5.8 billion of subsidy and $8.2 billion of higher rent for non-recipients, this formula gives his 16%). BU pay the higher rent where they suffice and
 * count as programme cost; without BU it is paid in cash. PTH members' housing is community-owned and is not marked up (the design's answer to capture).
 * The extra rent leaves the 500 adults (the model has no landlords; a stated limit). The mark-up is a level set from last year's flows, so it does not
 * compound. No RNG is drawn. HCS: per-run state. */
var HCAP = null, HCS = null;

// index.html line 3857
/* v5.2 step 7 (ledger s86): REVIEW ERRORS AND COLLUSION in the Collectives' review of project work. REVIEW = null (the default) leaves every run
 * bit-identical. When {u, q} (testbed row option rv): each year a share u of project conversions at a rate above 1x are unearned (the work delivered is
 * worth 1x: errors and collusion together), and audits catch a share q of those (a caught conversion is paid at 1x). An unearned conversion that is not
 * caught is paid at its rate, but only the 1x value counts as new output backing it. Which conversions are unearned comes from a stream of its own
 * (seed + 800023; one number per adult a year, for every adult, so every reading sees the same draws and the shares nest: 5% within 10% within 20%), so
 * the main stream's 8 draws per adult-year are untouched. REVS: per-run state (the stream; unearned pay not caught, and pay clawed back, year-0 $). */
var REVIEW = null, REVS = null;

// index.html line 3869
var PROD_CAP_DEP = 224428/((4823935 + 5088349)/2), PROD_CAP_INT = (5.998 - 4.293 + 1.963)/100;

// index.html line 3870
var PDS = null;

// index.html line 3915
/* Plan step 4 (Oct 1, 2026; design default 3; dev/reports/04-joining.md): JOINING AND LEAVING. Hub-spec (framework) model only; JOIN =
 * null (the default) leaves every run bit-identical. When an object, from year 1 each adult faces open enrolment at the start of the year
 * (before any participant list is read): an adult joins when the BU they would use this year, min(12 x effective BU, their essentials at
 * own prices), is at least what taking part costs them, and a participant leaves when it is less, after a minimum stay (stay years since
 * they last joined); rejoining is allowed and there is no fee.
 *  cost  'revealed' (default; a modelling assumption): the cost of taking part (time, obligations) is read off the year-0 choice. Adult i's
 *        cost is 12 x BU x uCCO_i / partRate in year-0 dollars, moved with the basket price level: at year 0 this reproduces the model's
 *        participation rule exactly (an adult whose BU cover 12 months of essentials takes part iff uCCO < partRate), and later choices move
 *        only as the BU's use value moves (inflation, COLA, price cuts, membership). 'none': taking part costs nothing (every adult joins).
 *        'nominal': the same cost fixed in dollars, so inflation does not raise it.
 *  stay  the minimum stay in years (2; 1 and 5 swept).
 * Emergency enrolment on shocks is unchanged. The testbed's groups stay the adults who took part at year 0 (the same adults in every row).
 * No RNG is drawn. JNS: per-run state. */
/* Plan step 5 (Oct 1, 2026; design default 5; dev/reports/05-ptf-pth-costs.md): THE RUNNING COSTS OF COMMUNITY BUSINESSES (PTF) AND THE
 * CAPITAL OF COMMUNITY HOUSING (PTH), from sourced figures. Testbed accounting only (no agent's resources change); COST = null (the default)
 * leaves every run bit-identical. When an object:
 *  PTF  PTF capital comes from the ESP split's reinvestment account (steps 1-2), so a PTF need not earn a return on capital and can price at
 *       running cost: conventional price less net operating surplus (gross operating surplus less depreciation; it still pays wages, inputs,
 *       taxes and depreciation). Net operating surplus per dollar of sales, 2025 (BEA GDP by industry, Components of Value Added TVA113-A
 *       and Gross Output TGO105-A, released Sep 30, 2026; BEA Fixed Assets Table 3.4ESI depreciation): food and beverage stores 9.29% of
 *       gross output x 28.8% gross margin on sales (Census Annual Retail Trade Survey, gross margin as a percentage of sales, 2022) = 2.68%;
 *       food services 7.60%; utilities 20.32%. Weighted by 2025 personal consumption (BEA NIPA Table 2.4.5: food off premises $1,524.0bn,
 *       food services $1,294.2bn; housing $3,326.3bn, household utilities $487.7bn): 4.94% of the food component (food) and 20.32% x 12.79%
 *       = 2.60% of the housing component (util). That much of each PTF member's discount is not a transfer: it is not counted as programme
 *       cost or financed. The rest of the discount (the model's 12% of the basket, more with SZH) is a running subsidy and is counted as now.
 *  PTH  community housing capital: BEA Fixed Assets Table 5.1, tenant-occupied residential net stock 2025 $7,197.7bn / 46.14 million renter
 *       households (Census Housing Vacancy Survey, Table 7, 2025) = $156,000 per rented home (structures; land excluded). Net operating
 *       surplus of the housing industry is 54.7% of its output (BEA 2025: gross operating surplus $2,655.4bn less residential depreciation
 *       $824.9bn, over output $3,345.1bn), so PTH's 35% cut fits inside the return on capital a PTH need not pay: residents' rent still
 *       covers running costs, taxes and depreciation. The cost of PTH is the return forgone on its capital, which is the cut itself, as the
 *       testbed already counts it (counting the capital outlay as well would count the same cost twice). Reported, not changed.
 * "Price cuts free" (every PTF and PTH cut treated as added capacity, not a transfer) is the testbed's eP = 1, a sensitivity row. */
/* Plan step 6 (Oct 1, 2026; design default 4; dev/reports/06-octave-rule.md): THE OCTAVE RULE. Today's rule stays the default: each year a
 * participant below the top octave advances with probability 1 - exp(-lambda x FBS), where FBS is their monthly financial bandwidth (income
 * plus BU less the basic cost of living and extractive costs), i.e. advancement gated by financial stability. OCT = null (the default) leaves
 * every run bit-identical. OCT {gap:N}: the slower-advancement sensitivity, at most one octave per N years (an advance needs N years since the
 * participant's last advance, or since year 0). Hub-spec (framework) model only. The advancement draw is made every year as before (CRN). */
/* Plan step 7 (Oct 1, 2026; dev/reports/07-spending-rule.md): THE SPENDING RULE. The page's engine saves every dollar above the cost of living;
 * the testbed's profile (D1, Sep 26) consumes 0.9 of all cash surplus, a placeholder. SPEND_SOURCED is the share of cash surplus consumed that
 * makes the no-programme Baseline's saving rate (wages less outlays, where outlays are the basket actually consumed plus surplus consumed, over
 * wages; reference settings, testbed profile, seeds 1-100) equal the US personal saving rate in 2025, 5.4% of disposable personal income (BEA
 * NIPA Table 2.1, line 35, released Sep 30, 2026). Derived by bisection (harness `spend` section prints the check); 0.554 matches 2024's
 * 6.3%. It is derived once from a primary source on the no-programme run, not tuned to any programme result. A testbed row uses it when its
 * options carry sc (a number: the share); a study-level sc (tbStudy's options) applies to the supply path and every row, Baseline included. */
var SPEND_SOURCED = 0.593, SPEND_2024 = 0.554;

// index.html line 3918
/* Plan step 18 (Oct 2, 2026): the v5.0 release row's switches beyond session 30's: private ESPs pass their premium to BU customers (step 14),
 * creative output at market value and capacity within a year (step 15), the spending layer (step 16). Read by the testbed's release section and the page. */
var REL_V5 = {sp:{priv:'prices'}, pd:{match:'market', speed:'oneyear'}, ml:{}, gc:true};  /* v5.1 (audit V5-02): gc:true = the framework BLEI gate reads this year's BU; every release-panel row carries it */

// index.html line 3922
/* v5.3 B10 (Oct 7, 2026; dev/DECISIONS.md Session 39, "B10"): what v5.3's main result adds to REL_V5, recorded before the restudy: households (pooled, the child
 * allowance at a quarter, partners' income swings at Shore's correlations, starting wealth from the SCF), the Hub's list of what BU can buy, income-graded
 * spending, and the two accounting corrections. relMainCfgs(PR) gives the no-programme and main rows the page's live run and the panel share. */
var REL_V53 = {hh:{pool:'household', childBU:0.25, shock:'shore', wealth:'scf'}, bs:'hub', sg:true, g:{PTH_APPR_CONSERVE:true, SURP_CUT_MARKUP:true}};

// index.html line 3927
/* v5.4 step 9 (Oct 7, 2026; dev/DECISIONS.md Session 41; dev/reports/v5-22-v54-report.md): what v5.4's main result adds to v5.3's, recorded before the 500-run
 * restudy (no modelling error found, so every part joins): the risk measures (reporting only), job loss and re-employment with unemployment insurance (in both
 * runs), PTH's books, PTF by sector with members who leave. The disaster is a scenario, shown as a reading. relMainCfgs(PR) carries them in both rows (the page's
 * live run and the panel); relMainCfgs(PR, true) gives v5.3's main row and its no-programme run exactly. */
var REL_V54 = {v54:{rk:true, empl:{}, pthb:{}, ptfs:{}}};

// index.html line 3928
function relMainCfgs(PR, v53){ var X = v53 ? {} : REL_V54; return [Object.assign({p:PR.baseline(), hh:REL_V53.hh, sg:REL_V53.sg, g:REL_V53.g}, X), n1Row(PR, 'framework', Object.assign({fin:'source', a:0, jn:{}, cs:{}}, REL_V5, REL_V53, X))]; }

// index.html line 3961
/* Plan step 9 (Oct 1, 2026; dev/reports/09-avoided-costs.md): PUBLIC COSTS OF POVERTY AVOIDED, reported beside the programme's cost (no feedback
 * into the model). Homelessness (with the health care and justice costs that come with it): the model's extreme-poverty overlay (v4.18: HUD
 * 2025 AHAR point-in-time rate, scaled by housing distress against year 0) gives unhoused person-years; each is costed at two sourced ends:
 *  low   emergency-shelter cost only: $581 a month for an individual (Des Moines; Spellman et al., Costs Associated with First-Time
 *        Homelessness for Families and Individuals, HUD/Abt Associates, 2010; 2009 dollars) x 12 x CPI-U 321.943/214.537 = $10,462 (2025 $).
 *  high  every public cost of homeless residents: $520 million a year (Santa Clara County, 2007-2012; health care 53%, justice 34%; Flaming,
 *        Toros and Burns, Home Not Found, Economic Roundtable, 2015) / 7,631 homeless people counted in January 2013 (Santa Clara County
 *        Homeless Census) x CPI-U 321.943/218.056 (2010) = $100,608 (2025 $) per homeless person-year. High because it counts the costs of
 *        everyone homeless at any time in the year against a one-night count, and the costliest users dominate.
 * Health care and crime among adults who are poor but housed are not costed: no primary source in hand gives a causal public cost per poor
 * adult-year (stated in the report as a limit, with the direction of the omission: it understates avoided costs). */
/* Plan step 17 (Oct 2, 2026; dev/reports/v5-4-public-costs.md): WIDER PUBLIC COSTS OF POVERTY AVOIDED, reported beside the programme's cost
 * (no feedback into the model; it changes no adult's resources). Counted only where a causal estimate of income's effect exists; zero main
 * where none does; low / main / high. All in 2025 dollars per adult-year, from two paired measures against no programme: the poverty-gap
 * dollars closed (person-year FGT1 x the cost-of-living line, year-0 = 2025 dollars) and the person-years lifted above the cost of living.
 *  justice  Deshpande and Mueller-Smith (2022, QJE 137(4)): each youth removed from SSI saved the government $37,700 in SSI over two
 *           decades and created $30,200 in incarceration and $10,800 in police and court costs, i.e. $0.80 and $0.29 per dollar of
 *           income withdrawn (both in the same dollars). Their sample's annual incarceration rate is 4.7% (control mean, ages 18-38);
 *           US adults' is 0.70% (BJS, Correctional Populations in the United States, 2022: 1,827,600 in prisons and jails at yearend /
 *           261.5 million adults, Census 2022), so the main figure scales incarceration by 0.70/4.7 and leaves police and courts out
 *           (mostly fixed salaries); high: the study's own $1.09 per dollar; low: 0 (the effect may not carry to other adults). Applied to
 *           poverty-gap dollars closed (the study's income changes were up to about $10,000 a year; larger gaps are a stated limit).
 *  hospital Forget (2011, Canadian Public Policy 37(3)): a guaranteed income cut hospitalisation by 8.5%. Applied to person-years lifted
 *           above the cost of living: 8.5% x stays per person-year (35.8m / 325.1m, HCUP Statistical Brief 261, 2017) x cost per stay
 *           ($434.2bn / 35.8m) x CPI-U 2025/2017 (321.943/245.120) x the public share of hospital costs (Medicare 46.9% + Medicaid 19.4%,
 *           same brief). Low: 0 (one study, another country and decade); high: the same as main.
 *  psych    state psychiatric hospitals, outside HCUP's community hospitals: $14.8bn of state mental health agency spending, FY2024 (NRI),
 *           over 340.1m residents (Census 2024), x Forget's 8.5%, per person-year lifted. Low 0.
 *  er       emergency visits: no causal estimate for adults' income, so 0 main; high: Forget's 8.5% x treat-and-release visits per person
 *           (107.4m / 332.0m, HCUP Statistical Brief 311, 2021) x $750 a visit x CPI-U 2025/2021 (321.943/270.970) x the public share.
 *  Not costed: child welfare (the model has no children yet), ambulances (no separate source), and the Alaska dividend's short-run rise in
 *  substance-related incidents (Watson, Guettabi and Reimer 2020), which would offset some savings. */
var AVOID_WIDE = (function(){ var pub = 0.469 + 0.194, rate = 0.0070/0.047;
  return {jMain:rate*30200/37700, jHigh:(30200 + 10800)/37700, hosp:0.085*(35.8/325.1)*(434.2e9/35.8e6)*321.943/245.120*pub, psych:0.085*14.8e9/340.1e6,
    erHigh:0.085*(107.4/332.0)*750*321.943/270.970*pub}; })();

// index.html line 3974
var OCT = null;

// index.html line 3975
var OCT_DEFAULTS = {gap:3};

// index.html line 3976
var COST = null;

// index.html line 3977
var COST_DEFAULTS = {food:0.0494, util:0.0260};

// index.html line 3978
var JOIN = null;

// index.html line 3979
var JOIN_DEFAULTS = {cost:'revealed', stay:2};

// index.html line 3980
var JNS = null;

// index.html line 3991
/* v5.2 round, step 3 (Oct 3, 2026; ledger s82; dev/DECISIONS.md, Session 35): SAVINGS THAT KEEP UP WITH PRICES. null = off (every earlier run). When an object, each
 * year from year 1 every adult's savings (positive wealth) earn interest equal to the year's price rise plus a real rate:  W x ((P_t / P_t-1) x (1 + r) - 1),
 * where P is the model's price level (outside inflation x the price module's basket index, the one the cost of living reads) and r = SAVE.r. It applies to every
 * adult in every run that sets it, the no-programme run included; it is not design-specific. Debts (negative wealth) are left as they are unless SAVE.debt = 'same'.
 *  r  0.0097: the average real yield on 10-year Treasury Inflation-Protected Securities, 2003-2025 (FRED series DFII10, daily, 5,753 observations, mean
 *     0.972%; sources/tips_real_rate.py). Readings: 0 (savings that only keep their value) and 0.0196 (the 2025 average).
 * The interest is added to savings at the start of the year, before the year's income and costs (it revalues last year's savings into this year's prices); it is
 * reinvested, so it does not enter the year's income measures, the spending share or the labour response. Where it comes from is not modelled: it is read as paid
 * by borrowers and the economy outside the 500 adults, as in a banking system, so it does not enter the price rule as new money (a stated limit: the reading shows
 * how much of a result is the missing protection of savings, not a model of a bank). No random draw is added. SVS holds the run's state (reset at year 0). */
var SAVE = null, SAVE_DEFAULTS = {r:0.0097, debt:'none'}, SVS = null;

// index.html line 4013
/* v5.2 round, step 4 (Oct 3, 2026; ledger s83; decision A, ledger d152; dev/DECISIONS.md, Session 35): ADULTS WHO AGE, RETIRE AND ARE REPLACED. null = off (every
 * earlier run: the adults never age). When an object (testbed runs; tbRunCore sets it up with ageInit), every adult has an age, drawn at year 0 from the Census
 * distribution of the population aged 25-66 (CFG.AGE_WEIGHTS). From year 1, at the start of each year: each adult dies with the life table's probability at their age
 * (CFG.DEATH_Q) and is replaced in the same place by a new 25-year-old (so the population stays at its size; the new adult is drawn like a year-0 adult, with the
 * starting wage scaled by how far the working adults' mean wage has moved since year 0 and the starting savings by the price level, and the estate leaves the
 * model); survivors age a year; an adult who
 * reaches 67 (CFG.RETIRE_AGE) retires: no wages, and a Social Security benefit instead, in year-0 dollars moved with the price level as the SSA's COLA moves it:
 *  ss   'average' the average retired-worker benefit (CFG.SS_RETIRE_ANNUAL, $24,180 in 2025); 'pia' the benefit formula on the adult's own monthly wage at
 *       retirement in year-0 dollars (CFG.SS_BEND_POINTS; the model keeps no earnings history, so the last wage stands in for average indexed earnings).
 *  ret  what a retired participant keeps under Compassionism (decision A): 'keep' (the default) the full BU for life on top of Social Security; no paid ESP work
 *       after 67, but expired BU can still be converted through creative work (project hiring) at the rate the adult has earned; 'noconv' the BU but no
 *       conversion after retirement; 'none' no design-specific rule: a retiree leaves the programme and lives on Social Security, as with no programme.
 * The benefit is money income in every measure (and in the price module's income); it is not programme cost. Retirees keep their memberships (PTF, PTH).
 * Every random number the switch needs comes from its own stream (ageInit: mulberry32(seed + 600011): one draw per adult for the starting age, one per adult-year
 * for death, and a new adult's construction draws), so the main stream still draws 8 numbers per adult-year and every design sees the same deaths and the same
 * new adults (paired seeds hold). AGS holds the run's state. Mortality depends on age only (a stated limit: in the US the poor die younger). */
/* v5.3 B7 (Oct 7, 2026; plan item B7; dev/DECISIONS.md Session 39, "B7"): earn 'flat' (the default: a wage does not depend on age, as before) | 'cps'
 * (a calibration reading): wages follow the shape of US median earnings by age (BLS, CPS, sources/earnings_age.md; CFG.EARN_AGE, straight lines between
 * the age groups' middle ages). At the start each adult's wage is multiplied by the curve at their age over its mean across the population aged 25-66
 * (CFG.AGE_WEIGHTS), so the average wage is unchanged; each birthday moves a worker along the curve; a new 25-year-old starts at the curve's value at 25;
 * the wage index a newcomer's wage follows leaves the curve out. No draw is added. */
var AGE = null, AGE_DEFAULTS = {ret:'keep', ss:'average', earn:'flat'}, AGS = null;

// index.html line 4014
CFG.EARN_AGE = {age:[22, 29.5, 39.5, 49.5, 59.5, 67.5], w:[831, 1160, 1436, 1421, 1367, 1233]};  /* median usual weekly earnings, full-time workers, by age group's middle age (BLS CPS, Q2 2026) */

// index.html line 4029
/* v5.2 round, step 5 (Oct 3, 2026; ledger s84; dev/DECISIONS.md, Session 35): LATENT, readings that change how the adults are drawn, each closing a gap between the
 * no-programme run and US data. null = off. When an object, latentAdjust transforms each drawn adult before it is placed (year 0, and every new adult when ageing
 * is on), with no random draw added (it reuses each draw's own normal score), so every design sees the same adults. Applied in every run that sets it, no
 * programme included.
 *  wealth  rho > 0: starting savings drawn from the SCF distribution of the comparison group (CFG.SCF_NETWORTH_PCTL), linked to the adult's wage by a Gaussian
 *          copula with correlation rho (CFG.SCF_WAGE_WEALTH_RHO); the model's own draw is lognormal and independent of the wage.
 *  risk    rho < 0: the automation risk keeps its distribution (the CFG.AUTO_* mixture) but is linked to the wage with copula correlation rho (CFG.FO_RISK_WAGE_RHO).
 *  wsd     > 0: log wages spread with this standard deviation (CFG.SCF_WAGE_SIGMA) around the same median, in place of 0.5.
 *  wmed    > 0: wages centred on this annual median in 2025 dollars (CFG.SCF_WAGE_MEDIAN) in place of the model's $39,945 (log mean 3.5 in model units). */
var LATENT = null;

// index.html line 4037
/* v5.3 B7 (Oct 7, 2026; plan item B7; dev/DECISIONS.md Session 39, "B7"): INCOME-GRADED SPENDING, a calibration reading (null = off: every adult pays
 * their full cost each year, as before; applied in every run that sets it, no programme included). When an adult's income this year (wages, Social
 * Security, a cash grant) is below their cash cost, they spend cost x (income / cost)^eps rather than the whole cost: people with less income spend less,
 * at the income elasticity of spending in the Consumer Expenditure Survey 2024 (quintiles 2-5 per equivalent adult, CFG.CE_SPEND_ELAST,
 * sources/ce_spending.py), anchored where income equals the cost (a modelling assumption). The measures still compare income with the full cost (the
 * cut is hardship, not relief); the cut stays in the adult's wealth (an accounted flow, a._acGr) and counts as basket consumption that did not happen
 * in the price model's demand (as a write-off at the floor does), but not as money. A pooled couple is graded on its totals (hhPool). */
var SPEND_GRADE = null;

// index.html line 4043
/* S35 (Oct 30, 2026; research-update prereg/2026-11-study-program.md, study F): the debt reading, a sensitivity reading of the graded spending rule above
 * (null = off, as released). When the rule would have an adult (a pooled couple: the couple) spend more than the rule's own income this year, the excess is
 * paid only from savings: wealth at the start of the year, if positive, plus the borrowing limit for ordinary spending (lim, 0: no borrowing). Once that is
 * used up the adult spends its income; the rest of the cost is cut, as the rule's own cut is (it stays in wealth, a._grCut). Nothing else changes: the debt
 * floor still applies to job loss, shocks and every other flow. No random draw. Per row: c.dr ({} or true = {lim:0}). */
var DEBT_READ = null;

// index.html line 4061
/* S59 (Nov 10, 2026; research-update prereg/2026-11-s59-asset-classes.md; dev/reports/s59-asset-classes.md): RETURNS, wealth held by asset class.
 * Off (null) unless a study row sets rt (true, or an object over RT_DEFAULTS); off, nothing is read and no figure moves (guard test). No random draw.
 * At an adult's first year the adult's net worth is split by the household's wealth group (RT_EDGES: below zero, then the SCF population's P25, P50, P75,
 * P90, P99 of net worth, 2025 dollars; RT_GROUPS, per group: debts over assets, the asset shares home, other real estate, shares, private business, other
 * goods (the rest is nominal assets), and the fixed-rate share of debts; SCF 2022, sources/s59_portfolio.py): gross assets G = W/(1 - lev), debts lev*G.
 * Each later year, before anything else reads the adult's wealth: last year's saving (every other change in the adult's wealth) repays floating debt, then
 * goes to nominal assets (ns 'nom'; 'port': by the group's asset shares), and a shortfall draws nominal assets to zero, then adds floating debt; then with
 * pi the change in the price level (the one SAVE uses) a real asset of class c grows by (1 + ix*pi)(1 + rho[c]) - 1, nominal assets by phi*pi, floating
 * debt by psi*pi, and fixed-rate debt by chi*pi (main 0: it keeps its dollar value; 1: it reprices like floating debt, the reading with no debt relief). rho: Shiller's real price gains 1953-2022 (sources/s59_real_gains.py; other real estate as
 * homes, private business as shares, other goods 0: modelling assumptions); phi 0.46: Drechsler, Savov and Schnabl, QJE 2017 (deposit rates rise 46 basis
 * points per 100 of the policy rate). all: 'nom' or 'real' holds every asset in one class with no fixed debt (unit tests). Real assets are never sold and
 * fixed debt is never repaid; there is no creditor side and no capital income (limits, in the report).
 * Reporting (RT_KEYS, with rt only; Year-0 dollars per adult, weighted by a._w): the last year's real wealth in three parts, E the opening nominal position
 * held untouched (nominal assets and floating debt with their interest, less fixed debt), V the opening real assets held untouched, S the rest (saving since
 * the start and what it earned); the same at the start (E0, V0); each for all adults and by fifth of starting wealth (suffix 1-5); the top 1% of adults'
 * share of private business equity at the end of Year 0 and of the last year (rtBt1S, rtBt1E, %); the last year's real assets, nominal assets, floating
 * and fixed debt (rtRE, rtNE, rtDvE, rtDfE). */
var RETURNS = null, RTR = null, RT_CLASSES = ['home', 'ore', 'eq', 'bus', 'oth'],
  RT_DEFAULTS = {ix:1, phi:0.46, psi:1, chi:0, rho:{home:0.0094, ore:0.0094, eq:0.0402, bus:0.0402, oth:0}, ns:'nom', all:null, bo:false, ci:false, ng:false, rg:false, cr:false},
  RT_EDGES = [0, 37073, 196748, 665427, 1855827, 12803724],  /* corrected Nov 12, 2026: the Nov 10 edges were 1.09438 times too high (the Fed re-issued the extract in 2025 dollars; sources/s59_portfolio.py) */
  RT_GROUPS = [[1.8197, 0.431, 0.0231, 0.0774, 0.0064, 0.2727, 0.9285], [0.681, 0.4099, 0.0089, 0.0533, 0.0077, 0.3875, 0.9034], [0.564, 0.673, 0.025, 0.0591, 0.0097, 0.1343, 0.9071], [0.3191, 0.6074, 0.0427, 0.1032, 0.0225, 0.0845, 0.9067], [0.1898, 0.4523, 0.0801, 0.1971, 0.0284, 0.0478, 0.9142], [0.0898, 0.2431, 0.0835, 0.3038, 0.1453, 0.0219, 0.8852], [0.0288, 0.0761, 0.0872, 0.2025, 0.4854, 0.0171, 0.7482]];

// index.html line 4065
var RT2_KEYS = ['rtYkS', 'rtYkE', 'rtYkShE', 'rtYbE', 'rtOwnS', 'rtOwnLoS', 'rtOwnHiS', 'rtGt1E', 'rtGt10E'];

// index.html line 4066
var RT_KEYS = ['rtE', 'rtV', 'rtS', 'rtE0', 'rtV0'].reduce(function(r, k){ r.push(k); [1, 2, 3, 4, 5].forEach(function(q){ r.push(k + q); }); return r; }, []).concat(['rtBt1S', 'rtBt1E', 'rtRE', 'rtNE', 'rtDvE', 'rtDfE']).concat(RT2_KEYS);

// index.html line 4083
/* S59, part 2 (Nov 12, 2026; research-update prereg/2026-11-s59-tail-returns.md; dev/reports/s59-tail-returns.md): options of rt, each off by default.
 *  bo  business owners: each household draws once, on its own stream (seed + 600091), whether it holds private-business equity, with its wealth group's
 *      SCF share (RT_OWN); its net worth is split by the holdings of owners (RT_GROUPS_O) or of the others (RT_GROUPS_N) in its group (SCF 2022,
 *      sources/s59_capital.py; columns as RT_GROUPS).
 *  ci  the income wealth pays: each year the adult receives, as money, the group's SCF rate (RT_YLD: interest over nominal assets, dividends over shares,
 *      rents and other business income over other real estate plus private business) on the year's holdings. It is cash income (a.yrCapUSD): disposable
 *      income, basket poverty, the spending rule; untaxed; no hours response. Sole-proprietorship income stays inside earnings (RT_SOLE: its share of owners'
 *      wage-plus-business income, reporting only).
 *  ng  the interest gradient at the very top, with WEALTH_TAIL only (it needs the adult's place in the population, a._wtP): RT_NG, Smith, Zidar and Zwick,
 *      QJE 2023 (2016: 0.91% at P99-99.9, 1.52% at P99.9-99.99, 3.79% for the top 0.01%). 'base': on the SCF interest rate; 'all': on phi's pass-through too.
 *  rg  a reading: the top group's real gain on homes times 2.00/1.64 and on other real estate times 9.06/7.55 (Campbell, Robbins and Wylde 2025, who rank
 *      by income: read here as a wealth ranking, a modelling assumption).
 * Reporting (RT2_KEYS, weighted by a._w, Year-0 dollars): capital income per adult at the start and the end (rtYkS, rtYkE) and as a share of money income
 * (rtYkShE, %); sole-proprietorship income inside owners' earnings (rtYbE); owners among adults (rtOwnS, %), in the bottom half and the top tenth of money
 * income (rtOwnLoS, rtOwnHiS); the share of the last year's real gains on real assets received by the top 1% and 10% of adults ranked by disposable
 * income plus those gains (rtGt1E, rtGt10E, %). */
var RTO = null, RT_OWN = [0.0457, 0.0559, 0.1049, 0.1145, 0.2008, 0.4498, 0.8731],
  RT_GROUPS_O = [[1.4865, 0.075, 0.259, 0.1523, 0.0846, 0.2136, 0.8558], [0.8379, 0.4388, 0.037, 0.0297, 0.057, 0.3396, 0.9417], [0.5768, 0.626, 0.0209, 0.0455, 0.0903, 0.1222, 0.9252], [0.3462, 0.5259, 0.0456, 0.0725, 0.1791, 0.0788, 0.9041], [0.2015, 0.4381, 0.0691, 0.1418, 0.1325, 0.0495, 0.917], [0.0957, 0.2272, 0.0936, 0.2117, 0.2943, 0.0201, 0.8776], [0.029, 0.0734, 0.0668, 0.184, 0.5468, 0.0111, 0.7628]],
  RT_GROUPS_N = [[1.8471, 0.4604, 0.0036, 0.0712, 0, 0.2776, 0.9334], [0.6563, 0.4054, 0.0044, 0.057, 0, 0.395, 0.8958], [0.5624, 0.6787, 0.0255, 0.0608, 0, 0.1358, 0.9049], [0.3152, 0.6191, 0.0423, 0.1077, 0, 0.0853, 0.9071], [0.1867, 0.4562, 0.0831, 0.2122, 0, 0.0473, 0.9134], [0.0841, 0.2586, 0.0736, 0.3937, 0, 0.0236, 0.8936], [0.0269, 0.097, 0.249, 0.348, 0, 0.0642, 0.6234]],
  RT_YLD = [[0.00477, 0.00068, -0.00404], [0.00057, 0.01722, 0.0176], [0.00121, 0.00067, 0.09495], [0.00083, 0.00686, 0.05394], [0.00273, 0.00197, 0.04122], [0.00393, 0.00694, 0.03594], [0.01094, 0.01407, 0.03532]],
  RT_SOLE = [0.1216, 0.163, 0.097, 0.0931, 0.045, 0.0606, 0.0146], RT_NG = [1.52/0.91, 3.79/0.91], RT_RG = [2.00/1.64, 9.06/7.55];

// index.html line 4109
/* S71 (Nov 13, 2026; research-update prereg/2026-11-s71-creditor-side.md; dev/reports/s71-creditor-side.md): option cr of rt, a creditor side for
 * fixed-rate debt. Off (false) by default; off, nothing below is read and no figure moves (guard test). No random draw. With chi below 1 a fixed-rate debt
 * loses real value as prices rise; cr charges that loss to the households that hold the debt, in proportion to their claims. RT_CR (sources/
 * s71_creditors.py; the Fed's Financial Accounts at 2022:Q4, looked through by the rule of Doepke and Schneider, JPE 2006): led, where one dollar of
 * household fixed-rate debt is finally held (dHH, dGOV, dROW deposit-like claims of households, the government and foreigners; bHH bond-like claims of
 * households; BUS businesses, for their shareholders; GOV, ROW direct holdings); own, who owns U.S. shares; w, the engine families' share of all
 * families' deposit-like assets, bond-like assets and stocks over their share of all families' fixed-rate debt (SCF 2022: retired households hold claims
 * too and are outside the model); t, the bond-like fraction of nominal assets by wealth group (tAll: an adult with no group).
 * A nominal asset is already paid only phi of inflation, so a claim dollar's loss of (1 - phi) is on the books before cr; cr charges the rest, down to
 * what the debt itself is paid (chi): (phi - chi) pi per claim dollar. inc 'pass' (main): bond-like claims are charged; deposits keep phi, and what a
 * depositor does not lose on a deposit-funded loan the lenders' shareholders do, with businesses' own holdings. 'hold': deposit claims are charged like
 * bonds; shareholders carry businesses' own holdings only. 'hedge': shareholders are not charged (their part is reported as outside).
 * pop 1: the model's families are the whole household sector (w = 1). out 0: nothing is outside (the government's and foreigners' parts are spread
 * over households' claims; w = 1). w 0: the year's totals are unweighted. With w 1 (main) the totals D, NB, ND, EQ are sums weighted by a._w: THE ONE
 * RULE THAT READS A WEIGHT, and only through these four totals, so that the ledger balances in the population the weighted measures describe.
 * Each year (crYear, at the first adult's turn, last year's saving placed first): claims are capped at holdings; the excess is reported (crUn).
 * Reporting (CR_KEYS, with cr only; Year-0 dollars per adult, weighted, summed over the run): crRel the debt inflated away; crBook the part of the
 * model households' loss already on the books; crNom, crEq the new charges on nominal assets and on shares (measured from the balances); crOutG, crOutF,
 * crOutH, crOutS the parts left outside (government, foreigners, households outside the model, lenders' shareholders not charged); crUn unplaced; crGap
 * relief less all of these (zero if the build is right); crN1-5, crR1-5 new charges and relief per adult by fifth of starting wealth; crT1 the top 1%
 * of adults' (by starting wealth) share of new charges (%). */
var RT_CR = {led:{dHH:0.2393, bHH:0.0845, BUS:0.3242, GOV:0.2556, ROW:0.0641, dGOV:0.0182, dROW:0.0141}, own:{eH:0.7313, eG:0.071, eR:0.1977},
    w:{wD:0.6566, wB:0.6067, wE:0.6233}, t:[0.3805, 0.392, 0.4977, 0.5883, 0.6648, 0.726, 0.6624], tAll:0.6753},
  CR_DEFAULTS = {inc:'pass', pop:0, out:1, w:1}, CRS = null, CRY = null, CRP = null,
  CR_KEYS = ['crRel', 'crBook', 'crNom', 'crEq', 'crOutG', 'crOutF', 'crOutH', 'crOutS', 'crUn', 'crGap', 'crN1', 'crN2', 'crN3', 'crN4', 'crN5', 'crR1', 'crR2', 'crR3', 'crR4', 'crR5', 'crT1'];

// index.html line 4113
function crOpts(v){ if (!v) return false; var o = Object.assign({}, CR_DEFAULTS, v === true ? {} : v);
  if (o.inc !== 'pass' && o.inc !== 'hold' && o.inc !== 'hedge') throw new Error('rt.cr.inc must be \'pass\', \'hold\' or \'hedge\'');
  var L = RT_CR.led, s = L.dHH + L.bHH + L.BUS; o.led = +o.out === 0 ? {dHH:L.dHH/s, bHH:L.bHH/s, BUS:L.BUS/s, GOV:0, ROW:0, dGOV:0, dROW:0} : Object.assign({}, L);
  o.own = +o.out === 0 ? {eH:1, eG:0, eR:0} : Object.assign({}, RT_CR.own); o.wf = +o.out === 0 || +o.pop === 1 ? {wD:1, wB:1, wE:1} : Object.assign({}, RT_CR.w); return o; }

// index.html line 4117
function crT(b){ return b.g >= 0 ? RT_CR.t[b.g] : RT_CR.tAll; }

// index.html line 4118
function crRates(D, NB, ND, EQ, pi, R){  /* the year's charges per dollar held, and the ledger in dollars, from the four totals */
  var C = R.cr, L = C.led, O = C.own, W = C.wf, a = 1 - R.chi, k = R.phi - R.chi, h = 1 - R.phi, dAll = L.dHH + L.dGOV + L.dROW, hold = C.inc === 'hold', dl = hold ? a : h;
  var Kb = L.bHH*W.wB*D, Kd = L.dHH*W.wD*D, kb = Math.min(Kb, Math.max(0, NB)), kd = Math.min(Kd, Math.max(0, ND));
  var pool = hold ? a*L.BUS*D : (a*L.BUS + k*dAll)*D, ch = C.inc !== 'hedge', eq = ch ? pool*O.eH*W.wE : 0, pl = EQ > 0 ? Math.max(-EQ, Math.min(EQ, eq)) : 0;  /* shares cannot lose more than their value times inflation */
  return {pi:pi, rb:NB > 0 ? k*pi*kb/NB : 0, rd:hold && ND > 0 ? k*pi*kd/ND : 0, re:EQ > 0 ? pi*pl/EQ : 0,
    rel:a*pi*D, book:h*pi*(kb + kd), un:pi*(a*(Kb - kb) + dl*(Kd - kd) + (eq - pl)),
    outG:pi*(a*L.GOV*D + dl*L.dGOV*D + (ch ? pool*O.eG : 0)), outF:pi*(a*L.ROW*D + dl*L.dROW*D + (ch ? pool*O.eR : 0)),
    outH:pi*(a*L.bHH*(1 - W.wB)*D + dl*L.dHH*(1 - W.wD)*D + (ch ? pool*O.eH*(1 - W.wE) : 0)), outS:ch ? 0 : pi*pool}; }

// index.html line 4126
function crYear(agents, P, yr){  /* at the first adult's turn, before any adult's year: the totals of adults already in the model, with last year's saving placed */
  if (yr === 0 || !CRS) CRS = {p0:P, A:{rel:0, book:0, nom:0, eq:0, outG:0, outF:0, outH:0, outS:0, un:0}};
  var R = RETURNS, D = 0, NB = 0, ND = 0, EQ = 0, Wt = 0, pi = null;
  agents.forEach(function(a){ var b = a._rt; if (!b || a._rtNew) return; var w = R.cr.w && a._w !== undefined ? +a._w : 1, k = {r:b.r.slice(), n:b.n, dv:b.dv, al:b.al}, t = crT(b);
    rtPlace(k, a.wealth - b.w, R); if (pi === null) pi = P/b.p - 1; D += w*b.df; NB += w*t*k.n; ND += w*(1 - t)*k.n; EQ += w*k.r[2]; Wt += w; });
  if (pi === null || !(Wt > 0)) return null;
  var y = crRates(D, NB, ND, EQ, pi, R), f = CRS.p0/P/Wt; y.f = CRS.p0/P; y.Wt = Wt; ['rel', 'book', 'outG', 'outF', 'outH', 'outS', 'un'].forEach(function(k){ CRS.A[k] += y[k]*f; }); return y; }

// index.html line 4133
function rtCap(b){ if (b.g < 0) return 0; var y = RT_YLD[b.g]; return y[0]*(b.ng || 1)*b.n + y[1]*b.r[2] + y[2]*(b.r[1] + b.r[3]); }  /* the year's capital income at the year's holdings */

// index.html line 4134
function rtOpts(v){ var o = Object.assign({}, RT_DEFAULTS, v === true ? {} : v), rho = {};
  RT_CLASSES.forEach(function(c){ rho[c] = typeof o.rho === 'number' ? o.rho : (o.rho && o.rho[c] !== undefined ? +o.rho[c] : RT_DEFAULTS.rho[c]); }); o.rho = rho;
  if (o.ns !== 'nom' && o.ns !== 'port') throw new Error('rt.ns must be \'nom\' or \'port\''); if (o.ng && o.ng !== 'base' && o.ng !== 'all') throw new Error('rt.ng must be \'base\' or \'all\''); if (o.all && o.all !== 'nom' && o.all !== 'real') throw new Error('rt.all must be \'nom\' or \'real\'');
  o.cr = crOpts(o.cr); return o; }

// index.html line 4138
function rtGroup(W){ var g = 0; while (g < RT_EDGES.length && W >= RT_EDGES[g]) g++; return g; }  /* 0: below zero */

// index.html line 4139
function rtOpen(w, Wh, R, P, own){  /* one adult's opening balances: w the adult's net worth, Wh the household's (in Year-0 dollars for the group), P the price level */
  var b = {r:[0, 0, 0, 0, 0], v:[0, 0, 0, 0, 0], n:0, dv:0, df:0, en:0, ed:0, al:null, g:-1, w0:w, w:w, p:P, p0:P}, c, q = R.all ? null : (R.bo ? (own ? RT_GROUPS_O : RT_GROUPS_N) : RT_GROUPS)[rtGroup(Wh)], G = q ? w/(1 - q[0]) : 0; b.own = !!own; b.gy = 0;
  if (q && G >= 0){ var s = 0; b.g = rtGroup(Wh); for (c = 0; c < 5; c++){ b.r[c] = G*q[1 + c]; s += q[1 + c]; } b.n = G*(1 - s); b.df = G*q[0]*q[6]; b.dv = G*q[0]*(1 - q[6]); b.al = q.slice(1, 6).concat([1 - s]); }
  else { if (w >= 0){ if (R.all === 'real') b.r[4] = w; else b.n = w; } else b.dv = -w; b.al = R.all === 'real' ? [0, 0, 0, 0, 1, 0] : [0, 0, 0, 0, 0, 1]; }  /* all in one class (or an adult whose sign differs from the household's) */
  for (c = 0; c < 5; c++) b.v[c] = b.r[c]; b.en = b.n; b.ed = b.dv; b.e0 = b.n - b.dv - b.df; b.v0 = b.r[0] + b.r[1] + b.r[2] + b.r[3] + b.r[4]; return b; }

// index.html line 4144
function rtPlace(b, flow, R){  /* a year's saving: repays floating debt, then nominal assets (or the group's asset shares); a shortfall draws nominal assets, then borrows */
  if (flow >= 0){ var pay = Math.min(b.dv, flow), c; b.dv -= pay; flow -= pay; if (R.ns === 'port'){ for (c = 0; c < 5; c++) b.r[c] += flow*b.al[c]; b.n += flow*b.al[5]; } else b.n += flow; }
  else { var d = Math.min(b.n, -flow); b.n -= d; b.dv += -flow - d; } }

// index.html line 4147
function rtStep(b, flow, pi, R, cr){  /* one year: last year's saving, then the revaluation; returns the revaluation in dollars (what is added to the adult's wealth). cr (S71): the year's creditor charges, from crYear */
  var c, f, x, I = 0; rtPlace(b, flow, R);
  var rh, gy = 0; for (c = 0; c < 5; c++){ rh = R.rho[RT_CLASSES[c]]; if (R.rg && b.g === 6 && c < 2) rh *= RT_RG[c]; gy += b.r[c]*rh*(1 + R.ix*pi); f = (1 + R.ix*pi)*(1 + rh) - 1; if (cr && c === 2){ b.ce = b.r[2]*cr.re; f -= cr.re; } I += b.r[c]*f; b.r[c] += b.r[c]*f; b.v[c] += b.v[c]*f; } b.gy = gy;  /* gy: the year's real gain at the year's prices (reporting) */
  x = R.phi*pi; if (R.ng === 'all' && b.ng) x *= b.ng; if (cr){ f = crT(b); f = f*cr.rb + (1 - f)*cr.rd; b.cn = b.n*f; x -= f; } I += b.n*x; b.n += b.n*x; b.en += b.en*x; x = R.psi*pi; I -= b.dv*x; b.dv += b.dv*x; b.ed += b.ed*x; x = R.chi*pi; I -= b.df*x; b.df += b.df*x; return I; }

// index.html line 4151
function rtInit(agents, P, yr){  /* before the year's loop: adults seen for the first time (every adult in Year 0), from the household's net worth before any of its members' year */
  if (SAVE) throw new Error('rt (wealth by asset class) and sv (savings that keep up with prices) would revalue wealth twice: use one');
  agents.forEach(function(a){ if (a._rt) return; var Wh = a.wealth; if (a._hh && a._hh.a && a._hh.a.length > 1){ Wh = 0; a._hh.a.forEach(function(m){ Wh += m.wealth; }); } var own = false; if (RETURNS.bo){ var H = a._hh; if (H && H._rtOwn !== undefined) own = H._rtOwn; else { if (!RTO) throw new Error('rt.bo needs a run that sets its stream (testbed runs do)'); own = RTO() < RT_OWN[rtGroup(Wh/P)]; if (H) H._rtOwn = own; } }
    a._rt = rtOpen(a.wealth, Wh/P, RETURNS, P, own); a._rtNew = true;
    if (RETURNS.ng && a._wtP !== undefined) a._rt.ng = a._wtP >= 0.9999 ? RT_NG[1] : a._wtP >= 0.999 ? RT_NG[0] : 1; });
  CRY = null; CRP = RETURNS.cr ? {agents:agents, yr:yr} : null; }  /* S71: the year's creditor charges are taken at the first adult's turn (rtAdult), after every start-of-year payment (a pathway exit pays equity into wealth after this point) */

// index.html line 4157
function rtAdult(a, P){  /* in the year's loop, where SAVE pays its interest: returns the revaluation added to the adult's wealth */
  var b = a._rt; if (CRP){ CRY = crYear(CRP.agents, P, CRP.yr); CRP = null; }  /* S71: before any adult's year moves a balance */
  if (a._rtNew){ a._rtNew = false; if (RETURNS.ci) a._rtCk = rtCap(b); return 0; }
  var I = rtStep(b, a.wealth - b.w, P/b.p - 1, RETURNS, CRY); if (CRY){ var cw = RETURNS.cr.w && a._w !== undefined ? +a._w : 1, cf = CRY.f, cx = (1 - RETURNS.chi)*CRY.pi*b.df; CRS.A.nom += cw*b.cn*cf/CRY.Wt; CRS.A.eq += cw*b.ce*cf/CRY.Wt; b.crn = (b.crn || 0) + (b.cn + b.ce)*cf; b.crr = (b.crr || 0) + cx*cf; }  /* S71 (reporting state) */
  a.wealth += I; b.w = a.wealth; b.p = P; if (RETURNS.ci) a._rtCk = rtCap(b); return I; }

// index.html line 4162
function rtRep(S, agents, o, yr, T){  /* reporting only: the end of Year 0 and of the last year */
  var n = agents.length; if (!n || (yr !== 0 && yr !== T - 1)) return;
  var lf = o.lines === 'nominal' ? 1 : agents[0].yrBasketUSD/CFG.LIVING_WAGE_ANNUAL/(agents[0]._hhF || 1), sfx = yr === 0 ? 'S' : 'E';
  var L = agents.filter(function(a){ return a._rt; }), wt = L.map(function(a){ return a._w === undefined ? 1 : +a._w; }), tw = 0, tb = 0, cw = 0, top = 0;
  var ord = L.map(function(a, i){ return i; }).sort(function(i, j){ return L[j].wealth - L[i].wealth || i - j; });
  wt.forEach(function(w, i){ tw += w; tb += w*L[i]._rt.r[3]; });
  ord.forEach(function(i){ var take = Math.max(0, Math.min(wt[i], 0.01*tw - cw)); cw += wt[i]; top += take*L[i]._rt.r[3]; });
  S['rtBt1' + sfx] = tb > 0 ? top/tb*100 : 0;
  RT2_KEYS.forEach(function(k){ if (S[k] === undefined) S[k] = 0; });
  if (RETURNS.ci || RETURNS.bo){ var yk = 0, mi = 0, yb = 0, ow = 0;
    L.forEach(function(a, i){ var b = a._rt; yk += wt[i]*(+a.yrCapUSD || 0); mi += wt[i]*tbCashIncome(a); if (b.own){ ow += wt[i]; if (b.g >= 0) yb += wt[i]*RT_SOLE[b.g]*(+a.yrWageUSD || 0); } });
    S['rtYk' + sfx] = tw > 0 ? yk/tw/lf : 0;
    if (yr === 0){ S.rtOwnS = tw > 0 ? ow/tw*100 : 0; var oi = L.map(function(a, i){ return i; }).sort(function(i, j){ return tbCashIncome(L[i]) - tbCashIncome(L[j]) || i - j; }), ci0 = 0, lo = [0, 0], hi = [0, 0];
      oi.forEach(function(i){ var m = (ci0 + wt[i]/2)/tw; ci0 += wt[i]; if (m < 0.5){ lo[0] += wt[i]; if (L[i]._rt.own) lo[1] += wt[i]; } if (m >= 0.9){ hi[0] += wt[i]; if (L[i]._rt.own) hi[1] += wt[i]; } });
      S.rtOwnLoS = lo[0] > 0 ? lo[1]/lo[0]*100 : 0; S.rtOwnHiS = hi[0] > 0 ? hi[1]/hi[0]*100 : 0; }
    if (yr === T - 1){ S.rtYkShE = mi > 0 ? yk/mi*100 : 0; S.rtYbE = tw > 0 ? yb/tw/lf : 0; } }
  if (yr === T - 1){ var gs = 0, og = L.map(function(a, i){ return i; }).sort(function(i, j){ return ((+L[j]._tbDisp || 0) + L[j]._rt.gy) - ((+L[i]._tbDisp || 0) + L[i]._rt.gy) || i - j; }), cg = 0, g1 = 0, g10 = 0;
    L.forEach(function(a, i){ gs += wt[i]*a._rt.gy; });
    og.forEach(function(i){ var t1 = Math.max(0, Math.min(wt[i], 0.01*tw - cg)), t10 = Math.max(0, Math.min(wt[i], 0.10*tw - cg)); cg += wt[i]; g1 += t1*L[i]._rt.gy; g10 += t10*L[i]._rt.gy; });
    S.rtGt1E = gs > 0 ? g1/gs*100 : 0; S.rtGt10E = gs > 0 ? g10/gs*100 : 0; }
  if (yr === 0){ var o0 = L.map(function(a, i){ return i; }).sort(function(i, j){ return L[i]._rt.w0 - L[j]._rt.w0 || i - j; }), c0 = 0;  /* fifths of starting wealth (by weight) */
    o0.forEach(function(i){ L[i]._rt.q = Math.min(5, Math.floor((c0 + wt[i]/2)/tw*5) + 1); c0 += wt[i]; });
    if (RETURNS.cr){ var c1 = 0; o0.slice().reverse().forEach(function(i){ L[i]._rt.t1 = wt[i] > 0 ? Math.max(0, Math.min(wt[i], 0.01*tw - c1))/wt[i] : 0; c1 += wt[i]; }); } }  /* S71: the part of the adult inside the top 1% by starting wealth */
  if (yr !== T - 1) return;
  var A = {}, W = [0, 0, 0, 0, 0, 0]; ['rtE', 'rtV', 'rtS', 'rtE0', 'rtV0', 'rtRE', 'rtNE', 'rtDvE', 'rtDfE'].forEach(function(k){ A[k] = [0, 0, 0, 0, 0, 0]; });
  L.forEach(function(a, i){ var b = a._rt, q = b.q || 0, w = wt[i], E = (b.en - b.ed - b.df)/lf, V = (b.v[0] + b.v[1] + b.v[2] + b.v[3] + b.v[4])/lf, k = {r:b.r.slice(), n:b.n, dv:b.dv, al:b.al}; rtPlace(k, a.wealth - b.w, RETURNS);  /* k: the classes with this year's saving placed */
    var R = (k.r[0] + k.r[1] + k.r[2] + k.r[3] + k.r[4])/lf;
    [0, q].forEach(function(j, t){ if (t && !q) return; W[j] += w; A.rtE[j] += w*E; A.rtV[j] += w*V; A.rtS[j] += w*(a.wealth/lf - E - V); A.rtE0[j] += w*b.e0/b.p0; A.rtV0[j] += w*b.v0/b.p0;
      A.rtRE[j] += w*R; A.rtNE[j] += w*k.n/lf; A.rtDvE[j] += w*k.dv/lf; A.rtDfE[j] += w*b.df/lf; }); });
  ['rtE', 'rtV', 'rtS', 'rtE0', 'rtV0'].forEach(function(k){ for (var j = 0; j < 6; j++) S[k + (j || '')] = W[j] > 0 ? A[k][j]/W[j] : 0; });
  ['rtRE', 'rtNE', 'rtDvE', 'rtDfE'].forEach(function(k){ S[k] = W[0] > 0 ? A[k][0]/W[0] : 0; });
  if (RETURNS.cr && CRS){ var CA = CRS.A, cn = [0, 0, 0, 0, 0, 0], cr_ = [0, 0, 0, 0, 0, 0], cwq = [0, 0, 0, 0, 0, 0], ct = 0, cs = 0;  /* S71 */
    L.forEach(function(a, i){ var b = a._rt, q = b.q || 0, w = wt[i], x = b.crn || 0; cwq[q] += w; cn[q] += w*x; cr_[q] += w*(b.crr || 0); cs += w*x; ct += w*(b.t1 || 0)*x; });
    S.crRel = CA.rel; S.crBook = CA.book; S.crNom = CA.nom; S.crEq = CA.eq; S.crOutG = CA.outG; S.crOutF = CA.outF; S.crOutH = CA.outH; S.crOutS = CA.outS; S.crUn = CA.un;
    S.crGap = CA.rel - CA.book - CA.nom - CA.eq - CA.outG - CA.outF - CA.outH - CA.outS - CA.un;
    for (var cq = 1; cq <= 5; cq++){ S['crN' + cq] = cwq[cq] > 0 ? cn[cq]/cwq[cq] : 0; S['crR' + cq] = cwq[cq] > 0 ? cr_[cq]/cwq[cq] : 0; } S.crT1 = cs !== 0 ? ct/cs*100 : 0; } }

// index.html line 4216
/* S59, part 2 (Nov 12, 2026; research-update prereg/2026-11-s59-tail-returns.md; dev/reports/s59-tail-returns.md): WEALTH_TAIL, a weighted top tail.
 * Off (null) unless a study row sets wt (true, or an object over WT_DEFAULTS); off, nothing is read and no figure moves (guard test). It acts where households
 * take their net worth from the SCF tables (HOUSEHOLDS.wealth 'scf'; hhScfWealth). In each household type the m households with the highest wealth rank
 * (main 3) become tail households; the others keep the type's table, squeezed so that together they stand for the share of the type below the cutoff
 * (1 - pi). The type's tail runs from the cutoff u to the net worth at which one family of the type is left (N families of the type in the SCF's
 * population); it is cut into m layers of equal ratio in the share of the tail above a point (from 1 down to B = 1/(N pi)); tail household j takes layer j
 * and draws its place in the layer on the tail's own stream (mulberry32(seed + 600073); m draws per type whatever the type's size, so both runs of a pair
 * hold the same tail). Its net worth is the fitted tail's value there: Pareto u s^(-1/a) ('pareto'), or generalised Pareto u (1 + sg/xi (s^-xi - 1))
 * ('gpd'), s the share of the type's tail above the household. WT_CUTS (sources/s59_tail.py; SCF 2022, the engine's families; u in the engine's 2025
 * dollars): 'main' the cutoff the preregistered rule picks (the 97.5th percentile, exponent 1.490, se 0.136), 'p99' and 'p90' readings. a: another
 * exponent; xi, sg: another generalised Pareto; flat: no change of wealth and every weight 1 (the check row).
 * Every adult carries a weight a._w: a tail adult the people its layer holds, any other adult n (1 - pi)/(n - m), summing to the type's adults; and a._wtP,
 * the adult's place in the population by wealth (0 to 1, by weight). WEIGHTS ENTER MEASURES ONLY: no rule reads a._w (S57's dm keys, RT_KEYS and
 * WT_KEYS do); prices, the Source, taxes and every decision are computed as without the tail.
 * Reporting (WT_KEYS, with wt or the study option wtm; s = S the end of Year 0, E the end of the last year; weighted): wtPov adults under the wealth line
 * (%, pov's test), wtF0 adults whose income is below their basket (%), wtGn, wtGz the wealth Gini with debts kept and with debts as zero, wtT01, wtT1,
 * wtT10, wtB50 the top 0.1%, 1%, 10% and bottom 50% shares of wealth (%), wtP999 the 99.9th percentile, wtMean, wtMed (Year-0 dollars); wtN tail adults,
 * wtW the sum of weights, wtTailW the tail adults' weight (% of all). */
var WEALTH_TAIL = null, WTS = null, WT_DEFAULTS = {m:3, form:'pareto', cut:'main', a:null, xi:null, sg:null, flat:false},
  WT_CUTS = {main:{u:6774757, a:1.4901, xi:0.6305, sg:0.6986, pi:{coupleKids:0.030313, coupleNoKids:0.042749, singleParent:0.002314, single:0.006641}, N:{coupleKids:33616456, coupleNoKids:19066648, singleParent:9073826, single:16813316}},
    p99:{u:12803723, a:1.5762, xi:0.7125, sg:0.5861, pi:{coupleKids:0.012798, coupleNoKids:0.014752, singleParent:0.000351, single:0.0041}, N:{coupleKids:33616456, coupleNoKids:19066648, singleParent:9073826, single:16813316}},
    p90:{u:1855828, a:1.1274, xi:0.6087, sg:1.155, pi:{coupleKids:0.118385, coupleNoKids:0.166789, singleParent:0.013064, single:0.034377}, N:{coupleKids:33616456, coupleNoKids:19066648, singleParent:9073826, single:16813316}}};

// index.html line 4220
var WT_KEYS = (function(){ var k = []; ['S', 'E'].forEach(function(s){ ['Pov', 'F0', 'Gn', 'Gz', 'T01', 'T1', 'T10', 'B50', 'P999', 'Mean', 'Med'].forEach(function(m){ k.push('wt' + m + s); }); }); k.push('wtN', 'wtW', 'wtTailW'); return k; })();

// index.html line 4221
function wtOpts(v){ var o = Object.assign({}, WT_DEFAULTS, v === true ? {} : v); o.m = Math.max(1, Math.round(+o.m));
  if (!WT_CUTS[o.cut]) throw new Error('wt.cut must be one of ' + Object.keys(WT_CUTS).join(', ')); if (o.form !== 'pareto' && o.form !== 'gpd') throw new Error('wt.form must be \'pareto\' or \'gpd\''); return o; }

// index.html line 4223
function wtTailQ(s, C, O){ if (O.form === 'gpd'){ var xi = O.xi || C.xi, sg = O.sg || C.sg; return C.u*(1 + sg/xi*(Math.pow(s, -xi) - 1)); } return C.u*Math.pow(s, -1/(O.a || C.a)); }

// index.html line 4224
function wtTable(Q, P, pc, u){  /* the type's table up to its last point (99.5%); beyond it, where the cutoff lies higher still, a bridge to the cutoff */
  var q = Q[Q.length - 1]; if (P <= 0.995 || pc <= 0.995 || !(q > 0) || u <= q) return hhScfQ(Q, P); return q*Math.pow(u/q, Math.min(1, (P - 0.995)/(pc - 0.995))); }

// index.html line 4226
function wtAssign(L, t, Q, p, u){  /* one household type: L its households, Q its table, p each household's place (0 to 1), u the type's m draws */
  var O = WEALTH_TAIL, C = WT_CUTS[O.cut], n = L.length, pi = C.pi[t], m = Math.min(O.m, n - 1);
  if (O.flat || m < 1){ L.forEach(function(H, i){ var W = hhScfQ(Q, p[i]); H._wtJ = 0; H.a.forEach(function(a){ a.wealth = W/H.a.length; a._w = 1; a._wtJ = 0; }); }); return; }
  var B = 1/(C.N[t]*pi), ord = L.map(function(H, i){ return i; }).sort(function(x, y){ return p[x] - p[y] || x - y; }), c = (1 - pi)/(1 - m/n), wN = n*(1 - pi)/(n - m);
  ord.forEach(function(i, k){ var H = L[i], W, w, j = k - (n - m) + 1;
    if (j < 1){ W = Math.min(wtTable(Q, Math.min(p[i]*c, 1 - pi), 1 - pi, C.u), C.u); w = wN; j = 0; }
    else { var b0 = Math.pow(B, (j - 1)/m), b1 = Math.pow(B, j/m); W = wtTailQ(b1 + u[j - 1]*(b0 - b1), C, O); w = n*pi*(b0 - b1)/(1 - B); }
    H._wtJ = j; H.a.forEach(function(a){ a.wealth = W/H.a.length; a._w = w; a._wtJ = j; }); }); }

// index.html line 4234
function wtRank(list){  /* each adult's place in the population by wealth (by weight) */
  var A = []; list.forEach(function(H){ H.a.forEach(function(a){ A.push(a); }); }); var idx = A.map(function(a, i){ return i; }).sort(function(i, j){ return A[i].wealth - A[j].wealth || i - j; }), W = 0, c = 0;
  A.forEach(function(a){ W += a._w; }); idx.forEach(function(i){ A[i]._wtP = W > 0 ? (c + A[i]._w/2)/W : 0; c += A[i]._w; }); }

// index.html line 4237
function wtGini(v, w){ var idx = dmSort(v), W = 0, T = 0, c = 0, g = 0; idx.forEach(function(i){ W += w[i]; T += w[i]*v[i]; }); if (!(T > 0) || !(W > 0)) return 0;
  idx.forEach(function(i){ var c1 = c + w[i]*v[i]; g += w[i]*(c + c1); c = c1; }); return 1 - g/(W*T); }  /* 1 - twice the area under the Lorenz curve */

// index.html line 4239
function wtRep(S, agents, o, yr, T){  /* reporting only: the end of Year 0 and of the last year */
  var n = agents.length; if (!n || (yr !== 0 && yr !== T - 1)) return;
  var lf = o.lines === 'nominal' ? 1 : agents[0].yrBasketUSD/CFG.LIVING_WAGE_ANNUAL/(agents[0]._hhF || 1), s = yr === 0 ? 'S' : 'E';
  var w = agents.map(function(a){ return a._w === undefined ? 1 : +a._w; }), v = agents.map(function(a){ return a.wealth/lf; }), z = v.map(function(x){ return Math.max(0, x); }), W = 0, pv = 0, f0 = 0, tn = 0, tw = 0, tot = dmTot(v, w);
  agents.forEach(function(a, i){ W += w[i]; if (a.wealth < CFG.POVERTY_LINE*lf) pv += w[i]; if (a._tbGap > 0) f0 += w[i]; if (a._wtJ > 0){ tn++; tw += w[i]; } });
  var sh = function(f, top){ return tot > 0 ? dmTail(v, w, f, top)/tot*100 : 0; }, q = dmQuantiles(v, w, [0.5, 0.999]);
  S['wtPov' + s] = pv/W*100; S['wtF0' + s] = f0/W*100; S['wtGn' + s] = wtGini(v, w); S['wtGz' + s] = wtGini(z, w); S['wtT01' + s] = sh(0.001, true); S['wtT1' + s] = sh(0.01, true); S['wtT10' + s] = sh(0.10, true);
  S['wtB50' + s] = sh(0.50, false); S['wtP999' + s] = q[1]; S['wtMean' + s] = tot/W; S['wtMed' + s] = q[0]; S.wtN = tn; S.wtW = W; S.wtTailW = tw/W*100;
  if (yr === 0) WT_KEYS.forEach(function(k){ if (S[k] === undefined) S[k] = 0; }); }

// index.html line 4256
/* S61 (Nov 9, 2026; research-update prereg/2026-11-s61-baseline-scope.md; dev/reports/s61-baseline-scope.md): LF_SCOPE, adults outside the labour force
 * (null = off: every adult is in the labour force, as released). When an object (row option lf; LF_DEFAULTS), each adult is drawn out of the labour
 * force for the whole run with the CPS ASEC 2026 probability for the adult's household type and reason (disability, early retirement, care, school;
 * CFG.LF_SHARES, or CFG.LF_SHARES_AGE by age band where adults have ages), and given an own yearly income drawn from the CPS distribution for the
 * reason (CFG.LF_INCOME; benefits, pensions, support; not earnings, not income from wealth; SNAP and tax credits come from the safety net), in year-0
 * dollars moved with the price level. Such an adult reuses the engine's rules for a retired adult (a._ret): no wages, no job loss, no paid ESP work, out
 * of the wage index, the income in place of the wage. conv 'none': no conversion income either (a reading). Status is fixed for the run; at 67 nothing
 * changes; a new adult (ageing) is drawn at entry. Own stream (seed + 600071), two draws per adult: no draw on any other stream. Reporting: LF_KEYS. */
var LF_SCOPE = null, LF_DEFAULTS = {conv:'keep'}, LFS = null, LF_REASONS = ['dis', 'ret', 'care', 'sch'];

// index.html line 4257
var LF_KEYS = ['lfShare', 'lfDis', 'lfRet', 'lfCare', 'lfSch', 'lfInc0', 'lfZero'];

// index.html line 4258
CFG.LF_SHARES = {"single":{"dis":0.11595,"ret":0.03691,"care":0.02447,"sch":0.02074},"singleParent":{"dis":0.05227,"ret":0.00483,"care":0.07683,"sch":0.01429},"coupleNoKids":{"dis":0.04321,"ret":0.08113,"care":0.04624,"sch":0.0049},"coupleKids":{"dis":0.01902,"ret":0.01005,"care":0.11405,"sch":0.00771}};  /* share of adults 25-64 out of the labour force all year, by household type and reason (CPS ASEC 2026; sources/lf_scope.json) */

// index.html line 4259
CFG.LF_SHARES_AGE = {"25-34":{"single":{"dis":0.05813,"ret":0.00821,"care":0.02373,"sch":0.04242},"singleParent":{"dis":0.02778,"ret":0.00102,"care":0.12405,"sch":0.02082},"coupleNoKids":{"dis":0.0114,"ret":0.01394,"care":0.03503,"sch":0.01433},"coupleKids":{"dis":0.00762,"ret":0.00351,"care":0.1565,"sch":0.01386}},"35-49":{"single":{"dis":0.11426,"ret":0.01154,"care":0.0258,"sch":0.01239},"singleParent":{"dis":0.05536,"ret":0.00366,"care":0.06117,"sch":0.0122},"coupleNoKids":{"dis":0.0329,"ret":0.02652,"care":0.04967,"sch":0.00503},"coupleKids":{"dis":0.01566,"ret":0.00287,"care":0.10781,"sch":0.00634}},"50-61":{"single":{"dis":0.17631,"ret":0.05555,"care":0.02752,"sch":0.00293},"singleParent":{"dis":0.09328,"ret":0.01711,"care":0.04619,"sch":0.00998},"coupleNoKids":{"dis":0.05328,"ret":0.08009,"care":0.05539,"sch":0.00182},"coupleKids":{"dis":0.03902,"ret":0.03089,"care":0.08009,"sch":0.00408}},"62-64":{"single":{"dis":0.20814,"ret":0.19892,"care":0.01428,"sch":0.00212},"singleParent":null,"coupleNoKids":{"dis":0.07567,"ret":0.27701,"care":0.02772,"sch":0.00063},"coupleKids":{"dis":0.12498,"ret":0.18691,"care":0.05752,"sch":0.00452}}};  /* the same by age band (null: fewer than 100 survey records, the type's all-ages row is used) */

// index.html line 4260
CFG.LF_INCOME = {"dis":[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,186,472,800,1030,1244,1800,2120,2400,2925,3557,4020,4586,5079,5791,6085,6837,7429,7800,8400,8924,9000,9402,9600,9888,10200,10440,10620,10800,10800,10800,10980,11167,11271,11292,11400,11520,11568,11604,11700,11820,11880,11928,11928,11928,11952,12000,12000,12000,12000,12240,12435,12661,12924,13020,13200,13200,13420,13620,13800,14000,14172,14220,14220,14367,14400,14400,14599,14928,15030,15324,15420,15560,15600,15936,16285,16620,16800,16896,17160,17400,17649,17861,18000,18000,18025,18432,18900,19020,19176,19324,19809,20158,20323,20500,20724,21000,21326,21600,21726,22117,22536,22800,23400,23683,23959,24000,24108,24625,25088,25549,26267,26593,27520,28380,28800,29316,29952,30000,30996,32035,33201,34092,35880,37260,38790,41000,43740,46093,49524,52448,53618,57420,62215,67980,73992,90084,103167,250000],"ret":[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,56,834,1185,1308,2100,2638,3120,3600,4020,4466,4980,5520,5989,6328,7200,7856,8220,8940,9420,9612,10000,10620,11000,11244,11400,11830,12000,12013,12351,12835,13200,13834,14064,14220,14220,14400,14400,14400,14445,14609,14723,15000,15420,15594,16090,16546,16620,17152,17820,18000,18848,19000,19020,19200,19380,20000,20220,20724,21000,21600,21600,22360,22800,23362,23654,24000,24000,24949,25005,25020,25284,26100,26400,26785,27600,27869,28620,28800,30000,30000,30804,31200,31980,32400,33210,33428,34703,35100,35817,36000,36324,37945,38400,39321,40620,42000,44180,45604,47632,48188,49980,50400,52800,55165,56220,58800,60000,61248,62220,64414,66000,69807,72000,75000,79932,81304,86348,91014,99868,105506,120000,140000,457976],"care":[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,186,855,1045,1652,2381,3303,4002,5000,7191,9000,10408,12000,13001,15182,19136,22080,25644,34526,56287,240000],"sch":[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,452,560,600,1000,1127,1556,2000,2000,2086,2493,2500,2500,3208,3616,4000,4000,4345,4856,5000,5000,5699,6000,7000,7500,7987,7996,8000,8000,8000,9000,9300,9669,10248,10457,11148,11473,12000,12000,12545,13344,13554,14500,15000,18000,18000,19227,19560,20000,20000,20000,20235,22499,23069,25002,26539,27347,30663,32000,34438,36000,36000,38400,40000,44400,47767,50000,59702,68000,70256,95217,109599]};  /* own yearly income by reason, percentiles 0, 0.5, ..., 100, 2025 dollars (CPS ASEC 2026; sources/lf_scope.json; S61 Amendment 2) */

// index.html line 4261
function lfType(a){ var H = a._hh; if (!H) return 'single'; return H.a.length > 1 ? (H.kids.length ? 'coupleKids' : 'coupleNoKids') : (H.kids.length ? 'singleParent' : 'single'); }

// index.html line 4263
function lfIncome(Q, u){ var h = u*(Q.length - 1), k = Math.min(Q.length - 2, Math.floor(h)); return Q[k] + (Q[k + 1] - Q[k])*(h - k); }

// index.html line 4264
function lfDraw(a){ if (LFS.u) a._lpU = LFS.u();  /* S73: the programme margin's personal draw (own stream; rows with lf.pm only) */
  var r = LFS.r, u1 = r(), u2 = r(), t = lfType(a), S = CFG.LF_SHARES[t], c = 0, why = null;
  if (typeof a.age === 'number' && a.age < CFG.RETIRE_AGE){ var B = CFG.LF_SHARES_AGE[lfBand(a.age)]; if (B && B[t]) S = B[t]; if (LFS.fl) S = lfCell(CFG.LF_FLOWS.stock, lfBand(a.age), lfSx(a), t); }  /* S73: with the flows, the fitted stock by sex as well */
  for (var i = 0; i < LF_REASONS.length; i++){ c += S[LF_REASONS[i]]; if (u1 < c){ why = LF_REASONS[i]; break; } }
  LFS.n++; if (!why || a._ret) return;  /* a retiree (67 and over, ageing) keeps the engine's own retirement */
  var y = lfIncome(CFG.LF_INCOME[why], u2); a._lf = why; a._lfW = a.wage; a._ret = true; a._ssB0 = y; a._ssY = y*DR_PL; a.wage = a._ssY/12/CFG.WAGE_TO_USD; LFS.k[why]++; LFS.inc += y; if (!(y > 0)) LFS.z++; }

// index.html line 4270
function lfInit(agents, seed){ LFS = {r:mulberry32(seed + 600071), n:0, k:{dis:0, ret:0, care:0, sch:0}, inc:0, z:0}; var L = LF_SCOPE || {};
  if (L.fl !== undefined && L.fl !== null && L.fl !== 'stock' && L.fl !== 'panel') throw new Error('lf.fl must be \'stock\' or \'panel\'');
  if (L.pm !== undefined && !(+L.pm >= 0 && +L.pm <= 1)) throw new Error('lf.pm must be between 0 and 1');
  if (L.fl || +L.pm > 0){ LFS.fl = L.fl || null; LFS.pm = +L.pm || 0; LFS.f = L.fl ? mulberry32(seed + 730073) : null; LFS.u = LFS.pm > 0 ? mulberry32(seed + 730079) : null;  /* S73 */
    LFS.ac = {iy:0, oy:0, ex:0, rt:0, ev:0, k:{dis:0, ret:0, care:0, sch:0}, ay:0, pt:0, out:0, lp:0, lpE:0, ayY:[], outY:[]}; }
  DR_PL = 1; agents.forEach(lfDraw); }

// index.html line 4276
function lfRes(out){ if (BGS) bgRes(out);  /* S60: BARGAIN's measures (rows with bg only) */
  if (DR_ACC){ out.drHit = DR_ACC.n ? DR_ACC.h/DR_ACC.n*100 : 0; out.drCut = DR_ACC.h ? DR_ACC.c/DR_ACC.h : 0; }  /* S61: % of graded spending decisions the limit cut, and the mean cut (year-0 dollars) */
  if (!LFS) return out; var S = LFS, m = S.k.dis + S.k.ret + S.k.care + S.k.sch, n = Math.max(1, S.n);
  out.lfShare = m/n*100; out.lfDis = S.k.dis/n*100; out.lfRet = S.k.ret/n*100; out.lfCare = S.k.care/n*100; out.lfSch = S.k.sch/n*100; out.lfInc0 = m ? S.inc/m : 0; out.lfZero = m ? S.z/m*100 : 0; if (S.ac) lfFlowRes(out); return out; }  /* the starting population's draws (year-0 dollars) */

// index.html line 4299
/* S73 (Nov 14, 2026; research-update prereg/2026-11-s73-participation.md; dev/reports/s73-participation.md): two options of lf, each off by default
 * (unset: S61's reading, identical).
 *  fl  yearly movement in and out of the labour force. 'stock' (main) or 'panel'. Each year from year 1, on its own stream (seed + 730073, two draws per
 *      adult-year whatever the state), an adult under 67 in the labour force leaves for reason r with the chance for the cell (age band x sex x household
 *      type; CFG.LF_FLOWS.exit), and an adult out for reason r returns with the reason's chance (age band x sex; .ret). Linked CPS ASEC 2025-2026
 *      (sources/s73_lf_flows.py). 'stock': exits that hold each cell's out share where ages do not move (exit_r = ret_r x stock_r / (1 - stock)); 'panel':
 *      the survey's own exits, which include the life cycle (for runs with ageing). A leaver gets an own income drawn as S61's; a returner's wage is the
 *      wage at exit moved with the price level (no growth while out). Year 0 draws from the fitted stock (by sex as well). Adults with no age (runs without
 *      ageing) read the tables by household type (.pooled: the cells weighted by the survey's adults, so each type's share is held); with no sex, the mean of the two. Adults 67 and over are the engine's retirement and are not touched.
 *  pm  the programme's participation margin: the share of the income effect taken by leaving work (main 0.43 = 0.25 / (0.25 + 0.33), Chetty's extensive
 *      and intensive compensated elasticities; swept 0-1). L = the income effect's dollars from the programme (its unconditional dollars at the income
 *      effect's weights, without today's safety net, as S60's outside option), E = this year's earnings after the raise, displacement and the safety
 *      net's response. A worker leaves for the year when a personal draw fixed for the run (own stream seed + 730079, one per adult, at year 0 or entry)
 *      is below q = pm x min(L, E) / E; a worker who stays loses (1 - pm) x min(L, E) / (1 - q). Expected earnings equal today's max(0, E - L): one
 *      income effect (guardrail 7), only how it falls changes. A leaver earns nothing that year and gets no unemployment insurance (a quit). Needs LABOR.
 * Reporting (LF_FLOW_KEYS, rows with fl or pm; adult-years 25-66 from year 1, weighted by a._w where the row has the tail): lfOut0, lfOut, lfOutL the share out
 * (%; year 0, mean over years 1 on, last year); lfEx exits per 100 adult-years in the labour force; lfRt returns per 100 adult-years out; lfEver the starting adults out
 * at some point (%, approximate with ageing); lfExDis, lfExRet, lfExCare, lfExSch the exits' reasons (%); lfPart adult-years with earnings (%);
 * lpOut adult-years out because of the programme (%); lpE their earnings forgone per adult-year (year-0 dollars at the price level agP). */
CFG.LF_FLOWS = {"stock":{"25-34":{"m":{"single":{"dis":0.05293,"ret":0.00702,"care":0.01094,"sch":0.03497},"singleParent":{"dis":0.02645,"ret":0.002,"care":0.00652,"sch":0.01953},"coupleNoKids":{"dis":0.01434,"ret":0.01112,"care":0.02033,"sch":0.01222},"coupleKids":{"dis":0.00891,"ret":0.00371,"care":0.01729,"sch":0.01302}},"f":{"single":{"dis":0.0584,"ret":0.00962,"care":0.04877,"sch":0.04627},"singleParent":{"dis":0.02722,"ret":0.00236,"care":0.10497,"sch":0.02962},"coupleNoKids":{"dis":0.01589,"ret":0.01521,"care":0.08774,"sch":0.01629},"coupleKids":{"dis":0.00917,"ret":0.00437,"care":0.23926,"sch":0.01981}}},"35-49":{"m":{"single":{"dis":0.10478,"ret":0.01016,"care":0.00884,"sch":0.01257},"singleParent":{"dis":0.05383,"ret":0.0029,"care":0.00527,"sch":0.00695},"coupleNoKids":{"dis":0.02957,"ret":0.01606,"care":0.01647,"sch":0.00433},"coupleKids":{"dis":0.01848,"ret":0.00538,"care":0.014,"sch":0.00461}},"f":{"single":{"dis":0.11495,"ret":0.0139,"care":0.03972,"sch":0.01676},"singleParent":{"dis":0.05537,"ret":0.00342,"care":0.08645,"sch":0.01061},"coupleNoKids":{"dis":0.03271,"ret":0.02193,"care":0.07202,"sch":0.00578},"coupleKids":{"dis":0.01902,"ret":0.00633,"care":0.2024,"sch":0.00705}}},"50-61":{"m":{"single":{"dis":0.17111,"ret":0.04518,"care":0.00944,"sch":0.00431},"singleParent":{"dis":0.0912,"ret":0.01325,"care":0.00562,"sch":0.00237},"coupleNoKids":{"dis":0.051,"ret":0.06999,"care":0.01756,"sch":0.00148},"coupleKids":{"dis":0.03214,"ret":0.02433,"care":0.01493,"sch":0.00157}},"f":{"single":{"dis":0.18639,"ret":0.06103,"care":0.0423,"sch":0.00576},"singleParent":{"dis":0.09369,"ret":0.01556,"care":0.09177,"sch":0.00363},"coupleNoKids":{"dis":0.05628,"ret":0.09368,"care":0.07653,"sch":0.00197},"coupleKids":{"dis":0.03307,"ret":0.02852,"care":0.2132,"sch":0.00241}}},"62-64":{"m":{"single":{"dis":0.21896,"ret":0.17379,"care":0.00522,"sch":0.00204},"singleParent":{"dis":0.11994,"ret":0.05632,"care":0.0031,"sch":0.00112},"coupleNoKids":{"dis":0.06801,"ret":0.25067,"care":0.00975,"sch":0.0007},"coupleKids":{"dis":0.04314,"ret":0.09979,"care":0.00828,"sch":0.00074}},"f":{"single":{"dis":0.23729,"ret":0.22415,"care":0.02376,"sch":0.00272},"singleParent":{"dis":0.1231,"ret":0.06565,"care":0.05274,"sch":0.00172},"coupleNoKids":{"dis":0.07492,"ret":0.31482,"care":0.04367,"sch":0.00093},"coupleKids":{"dis":0.04439,"ret":0.11543,"care":0.12992,"sch":0.00114}}}},"exit":{"25-34":{"m":{"single":{"dis":0.01215,"ret":0.0016,"care":0.00688,"sch":0.01999},"singleParent":{"dis":0.00574,"ret":0.00043,"care":0.00388,"sch":0.01056},"coupleNoKids":{"dis":0.00312,"ret":0.0024,"care":0.01213,"sch":0.00663},"coupleKids":{"dis":0.00191,"ret":0.00079,"care":0.01016,"sch":0.00695}},"f":{"single":{"dis":0.0118,"ret":0.00235,"care":0.01489,"sch":0.02},"singleParent":{"dis":0.00551,"ret":0.00058,"care":0.03208,"sch":0.01282},"coupleNoKids":{"dis":0.00311,"ret":0.00359,"care":0.02592,"sch":0.00681},"coupleKids":{"dis":0.00213,"ret":0.00123,"care":0.08403,"sch":0.00985}}},"35-49":{"m":{"single":{"dis":0.0175,"ret":0.00251,"care":0.00455,"sch":0.00763},"singleParent":{"dis":0.00834,"ret":0.00066,"care":0.00252,"sch":0.00391},"coupleNoKids":{"dis":0.00457,"ret":0.00366,"care":0.00785,"sch":0.00243},"coupleKids":{"dis":0.00278,"ret":0.0012,"care":0.00651,"sch":0.00252}},"f":{"single":{"dis":0.01655,"ret":0.00365,"care":0.0086,"sch":0.00769},"singleParent":{"dis":0.00769,"ret":0.00087,"care":0.01807,"sch":0.0047},"coupleNoKids":{"dis":0.00442,"ret":0.0054,"care":0.01465,"sch":0.00249},"coupleKids":{"dis":0.00292,"ret":0.00177,"care":0.04667,"sch":0.00344}}},"50-61":{"m":{"single":{"dis":0.024,"ret":0.00583,"care":0.00517,"sch":0.00293},"singleParent":{"dis":0.0111,"ret":0.00148,"care":0.00267,"sch":0.0014},"coupleNoKids":{"dis":0.0064,"ret":0.00809,"care":0.00861,"sch":0.0009},"coupleKids":{"dis":0.00374,"ret":0.00261,"care":0.00679,"sch":0.00089}},"f":{"single":{"dis":0.02305,"ret":0.00865,"care":0.0098,"sch":0.00306},"singleParent":{"dis":0.01026,"ret":0.00195,"care":0.01883,"sch":0.00171},"coupleNoKids":{"dis":0.00635,"ret":0.01212,"care":0.01619,"sch":0.00095},"coupleKids":{"dis":0.00399,"ret":0.00394,"care":0.04813,"sch":0.00125}}},"62-64":{"m":{"single":{"dis":0.03472,"ret":0.02348,"care":0.00269,"sch":0.00178},"singleParent":{"dis":0.01392,"ret":0.00557,"care":0.00117,"sch":0.00072},"coupleNoKids":{"dis":0.00964,"ret":0.03029,"care":0.00449,"sch":0.00055},"coupleKids":{"dis":0.00484,"ret":0.00954,"care":0.00302,"sch":0.00046}},"f":{"single":{"dis":0.03546,"ret":0.03565,"care":0.00495,"sch":0.00198},"singleParent":{"dis":0.01245,"ret":0.00706,"care":0.00744,"sch":0.00085},"coupleNoKids":{"dis":0.01013,"ret":0.04533,"care":0.00824,"sch":0.00061},"coupleKids":{"dis":0.00479,"ret":0.01326,"care":0.01956,"sch":0.0006}}}},"exitPanel":{"25-34":{"m":{"single":{"dis":0.01432,"ret":0.00285,"care":0.00915,"sch":0.00987},"singleParent":{"dis":0.01212,"ret":0.00052,"care":0.0047,"sch":0.02278},"coupleNoKids":{"dis":0.00478,"ret":0.00355,"care":0.00956,"sch":0.00456},"coupleKids":{"dis":0.00268,"ret":0.00115,"care":0.00779,"sch":0.00335}},"f":{"single":{"dis":0.0162,"ret":0.00474,"care":0.02388,"sch":0.01529},"singleParent":{"dis":0.01652,"ret":0.00062,"care":0.03508,"sch":0.02304},"coupleNoKids":{"dis":0.00541,"ret":0.00591,"care":0.02492,"sch":0.00709},"coupleKids":{"dis":0.00366,"ret":0.00139,"care":0.05697,"sch":0.00338}}},"35-49":{"m":{"single":{"dis":0.01882,"ret":0.00519,"care":0.00736,"sch":0.00444},"singleParent":{"dis":0.01594,"ret":0.00095,"care":0.00377,"sch":0.01033},"coupleNoKids":{"dis":0.0063,"ret":0.00647,"care":0.00768,"sch":0.00205},"coupleKids":{"dis":0.00353,"ret":0.0021,"care":0.00626,"sch":0.0015}},"f":{"single":{"dis":0.02128,"ret":0.00863,"care":0.01925,"sch":0.0069},"singleParent":{"dis":0.0217,"ret":0.00114,"care":0.02835,"sch":0.01045},"coupleNoKids":{"dis":0.00714,"ret":0.01075,"care":0.0201,"sch":0.00319},"coupleKids":{"dis":0.00483,"ret":0.00253,"care":0.04624,"sch":0.00152}}},"50-61":{"m":{"single":{"dis":0.02656,"ret":0.01904,"care":0.00738,"sch":0.00158},"singleParent":{"dis":0.02253,"ret":0.00351,"care":0.00378,"sch":0.00368},"coupleNoKids":{"dis":0.00894,"ret":0.02366,"care":0.0077,"sch":0.00073},"coupleKids":{"dis":0.00501,"ret":0.00778,"care":0.00627,"sch":0.00053}},"f":{"single":{"dis":0.02999,"ret":0.03137,"care":0.0193,"sch":0.00246},"singleParent":{"dis":0.03059,"ret":0.00422,"care":0.02841,"sch":0.00373},"coupleNoKids":{"dis":0.01012,"ret":0.03887,"care":0.02014,"sch":0.00113},"coupleKids":{"dis":0.00685,"ret":0.00935,"care":0.04634,"sch":0.00054}}},"62-64":{"m":{"single":{"dis":0.03195,"ret":0.067,"care":0.00195,"sch":0.0},"singleParent":{"dis":0.02712,"ret":0.01286,"care":0.001,"sch":0.0},"coupleNoKids":{"dis":0.01079,"ret":0.08229,"care":0.00204,"sch":0.0},"coupleKids":{"dis":0.00606,"ret":0.02821,"care":0.00166,"sch":0.0}},"f":{"single":{"dis":0.03605,"ret":0.10701,"care":0.00515,"sch":0.0},"singleParent":{"dis":0.03676,"ret":0.01543,"care":0.00764,"sch":0.0},"coupleNoKids":{"dis":0.01221,"ret":0.13016,"care":0.00538,"sch":0.0},"coupleKids":{"dis":0.00827,"ret":0.03375,"care":0.01263,"sch":0.0}}}},"ret":{"dis":{"25-34":{"m":0.20527,"f":0.16915},"35-49":{"m":0.14428,"f":0.11731},"50-61":{"m":0.108,"f":0.08712},"62-64":{"m":0.09513,"f":0.07652}},"ret":{"25-34":{"m":0.20324,"f":0.20405},"35-49":{"m":0.21296,"f":0.2138},"50-61":{"m":0.09937,"f":0.09981},"62-64":{"m":0.08107,"f":0.08144}},"care":{"25-34":{"m":0.56215,"f":0.25545},"35-49":{"m":0.44496,"f":0.17643},"50-61":{"m":0.42187,"f":0.16318},"62-64":{"m":0.30903,"f":0.10675}},"sch":{"25-34":{"m":0.51106,"f":0.36169},"35-49":{"m":0.52395,"f":0.3737},"50-61":{"m":0.52395,"f":0.3737},"62-64":{"m":0.52395,"f":0.3737}}},"pooled":{"stock":{"single":{"dis":0.11595,"ret":0.0369,"care":0.02447,"sch":0.02074},"singleParent":{"dis":0.05227,"ret":0.00483,"care":0.07683,"sch":0.01429},"coupleNoKids":{"dis":0.04322,"ret":0.08113,"care":0.04624,"sch":0.0049},"coupleKids":{"dis":0.01902,"ret":0.01005,"care":0.11405,"sch":0.00771}},"exit":{"single":{"dis":0.01747,"ret":0.00507,"care":0.00798,"sch":0.01143},"singleParent":{"dis":0.00753,"ret":0.0009,"care":0.01855,"sch":0.00642},"coupleNoKids":{"dis":0.00554,"ret":0.0099,"care":0.01292,"sch":0.00254},"coupleKids":{"dis":0.00284,"ret":0.00173,"care":0.02883,"sch":0.00384}},"exitPanel":{"single":{"dis":0.0206,"ret":0.01439,"care":0.01316,"sch":0.00708},"singleParent":{"dis":0.02021,"ret":0.00138,"care":0.02516,"sch":0.01311},"coupleNoKids":{"dis":0.00804,"ret":0.02716,"care":0.01358,"sch":0.00233},"coupleKids":{"dis":0.00418,"ret":0.00338,"care":0.02516,"sch":0.00176}},"ret":{"single":{"dis":0.12081,"ret":0.11011,"care":0.26149,"sch":0.4417},"singleParent":{"dis":0.12274,"ret":0.15847,"care":0.2056,"sch":0.38264},"coupleNoKids":{"dis":0.10577,"ret":0.10057,"care":0.23029,"sch":0.42827},"coupleKids":{"dis":0.12666,"ret":0.14624,"care":0.21462,"sch":0.42285}}}};  /* sources/s73_lf_flows.json: stock, exit (stock-holding), exitPanel, ret; pooled (by type, for adults with no age) */

// index.html line 4300
var LF_FLOW_KEYS = ['lfOut0', 'lfOut', 'lfOutL', 'lfEx', 'lfRt', 'lfEver', 'lfExDis', 'lfExRet', 'lfExCare', 'lfExSch', 'lfPart', 'lpOut', 'lpE'];

// index.html line 4301
function lfSx(a){ return a._fem === true ? 'f' : a._fem === false ? 'm' : null; }

// index.html line 4303
function lfRetP(r, b, s, t){ if (!b) return CFG.LF_FLOWS.pooled.ret[t][r]; var R = CFG.LF_FLOWS.ret[r][b]; return s ? R[s] : (R.m + R.f)/2; }

// index.html line 4304
function lfWt(a){ return a._w !== undefined ? +a._w : 1; }

// index.html line 4305
function lfOut(a, why, y, P){ a._lf = why; a._lfW = a.wage; a._lfNB = a._lwNB; a._lfWN = a._wNB; a._lfP = P; a._ret = true; a._ssB0 = y; a._ssY = y*P; a.wage = a._ssY/12/CFG.WAGE_TO_USD; }

// index.html line 4306
function lfFlow(a, P, yr){ var F = LFS.f, u1 = F(), u2 = F();
  if (!(yr >= 1) || (a._ret && !a._lf) || (typeof a.age === 'number' && a.age >= CFG.RETIRE_AGE)) return;
  var b = typeof a.age === 'number' ? lfBand(a.age) : null, s = lfSx(a), t = lfType(a), A = LFS.ac, w = lfWt(a);
  if (a._lf){ A.oy += w; if (u1 < lfRetP(a._lf, b, s, t)){ var k = P/(a._lfP || 1); a.wage = a._lfW*k; if (a._lwNB !== undefined) a._lwNB = a._lfNB !== undefined ? a._lfNB*k : a.wage;
      if (a._wNB !== undefined) a._wNB = a._lfWN !== undefined ? a._lfWN*k : a.wage; a._ret = false; a._lf = null; a._ssY = 0; A.rt += w; } return; }
  A.iy += w; var X = LFS.fl === 'panel' ? 'exitPanel' : 'exit', S = b ? lfCell(CFG.LF_FLOWS[X], b, s, t) : CFG.LF_FLOWS.pooled[X][t], c = 0, why = null;
  for (var i = 0; i < LF_REASONS.length; i++){ c += S[LF_REASONS[i]]; if (u1 < c){ why = LF_REASONS[i]; break; } }
  if (!why) return; lfOut(a, why, lfIncome(CFG.LF_INCOME[why], u2), P); A.ex += w; A.k[why] += w; if (!a._lfEv){ a._lfEv = 1; A.ev++; } }

// index.html line 4314
function lfPM(a, Ep, I, L, emQ, yr, P){ L = Math.min(I, L); var E = Ep - (I - L); if (!(E > 0)) return 0; var m = Math.min(L, E), q = LFS.pm*m/E;
  if (a._lpU < q){ if (emQ) emQ.ui = 0; if (yr >= 1 && LFS.ac){ LFS.ac.lp += lfWt(a); LFS.ac.lpE += lfWt(a)*E/P; } return 0; }
  return Math.max(0, E - (1 - LFS.pm)*m/(1 - q)); }

// index.html line 4317
function lfAcc(a, E, yr){ if (!(yr >= 0) || (a._ret && !a._lf) || (typeof a.age === 'number' && a.age >= CFG.RETIRE_AGE)) return; var A = LFS.ac, w = lfWt(a);
  A.ayY[yr] = (A.ayY[yr] || 0) + w; if (a._lf) A.outY[yr] = (A.outY[yr] || 0) + w; if (yr < 1) return; A.ay += w; if (E > 0) A.pt += w; if (a._lf) A.out += w; }

// index.html line 4319
function lfFlowRes(out){ var A = LFS.ac, S = LFS, x = A.ex || 1, T = A.ayY.length - 1;
  out.lfOut0 = A.ayY[0] ? (A.outY[0] || 0)/A.ayY[0]*100 : 0; out.lfOut = A.ay ? A.out/A.ay*100 : 0; out.lfOutL = T >= 1 && A.ayY[T] ? (A.outY[T] || 0)/A.ayY[T]*100 : 0; out.lfEx = A.iy ? A.ex/A.iy*100 : 0; out.lfRt = A.oy ? A.rt/A.oy*100 : 0;
  out.lfEver = (S.k.dis + S.k.ret + S.k.care + S.k.sch + A.ev)/Math.max(1, S.n)*100; out.lfExDis = A.k.dis/x*100; out.lfExRet = A.k.ret/x*100; out.lfExCare = A.k.care/x*100; out.lfExSch = A.k.sch/x*100;
  out.lfPart = A.ay ? A.pt/A.ay*100 : 0; out.lpOut = A.ay ? A.lp/A.ay*100 : 0; out.lpE = A.ay ? A.lpE/A.ay : 0; return out; }

// index.html line 4331
/* S61 (Nov 9, 2026; research-update prereg/2026-11-s61-baseline-scope.md; dev/reports/s61-baseline-scope.md): three more parts, each off by default, so
 * S35's reading ({lim:0}) is unchanged.
 *  lim  the borrowing limit for ordinary spending is in year-0 dollars and moves with the price level (DR_PL; at lim 0 nothing changes). S61's main
 *       value is $2,500 (SCF 2025, sources/s61_borrowing.py); swept 0-10,000.
 *  liq  the share of positive start-of-year wealth that can pay ordinary spending (default 1, as S35; reading 0.046, the SCF 2025 median liquid share).
 *  fl   'fpl': the graded rule applies only to spending above the household's official poverty threshold (CFG.HH_FPL, as a share of its year-0 budget):
 *       spending is F + (cost - F) x ((income - F)/(cost - F))^eps between F and the cost, and F below F; the limit above then applies. Default 'none'.
 * No random draw. */
var DR_PL = 1, DR_ACC = null;  /* S61: the price level the limit moves with (set each year where the run computes it); the tally of cuts by the limit (reporting only) */

// index.html line 4332
function drExtra(inc, cost, cut, w0){ var ex = cost - cut - Math.max(0, inc), ok = Math.max(0, (DEBT_READ.liq !== undefined && DEBT_READ.liq !== 1 && w0 > 0 ? w0*DEBT_READ.liq : w0) + (DEBT_READ.lim ? DEBT_READ.lim*DR_PL : 0)), x = ex > ok ? ex - ok : 0;
  if (DR_ACC){ DR_ACC.n++; if (x > 0){ DR_ACC.h++; DR_ACC.c += x/DR_PL; } } return x; }  /* S35: the further cut (0 when the excess is covered) */

// index.html line 4348
/* S13 (Oct 31, 2026; outside audit of the engine, dev/reports/s13-engine-audit.md): corrections found by the audit, each its own part, all off by default
 * (null = off, as released; every released figure is unchanged). Per row: c.au (true = the three corrections {gate, sg, fbs}; or an object naming parts).
 *  gate  the BLEI gate on the wage bonus (and the PTF adoption term that reads the same BLEI) in year-0 prices, divided by the year's price level, as
 *        every reported BLEI figure is (audit E3). As released the gate compares this year's dollars with the fixed $68.33 a day.
 *  sg    income-graded spending on all of the year's cash income: as released it reads wages, Social Security, cash grants, unemployment insurance
 *        and the safety net, and leaves out conversion income (projects, business payouts, the ESP premium) and the testbed's transfers less its
 *        contribution, which are added later in the year (audit E4).
 *  fbs   the financial-stability score that drives octave advancement (framework conversion) in year-0 dollars, divided by the year's price level,
 *        since its lambda is set in year-0 dollars (audit E7).
 *  wOut  a reading, not a correction (not in c.au === true): wages also follow the environment's outside inflation (inflRate, 2% a year in Adverse
 *        and Stress), added to wage growth as the programme's own price rise is (audit E5). As released wages follow only the programme's price level.
 * No random draw in any part. */
var AUD = null;

// index.html line 4362
/* S47 (Nov 5, 2026; the design freeze): fixes found by the second, independent implementation of the release row (dev/reports/s50-independent-implementation/
 * GAPS.md, phase 2), each its own part, all off by default (null = off, as released; every released figure is unchanged). Per row: c.fx (true = every part below;
 * or an object naming parts). Each makes the engine do what its own comments say it does. No part makes a random draw.
 *  pthb  PTH's books are opened after households are formed (GAPS item 6). As released pthbInit runs before hhInit, so household members who take the head's
 *        PTH decision have no books (about 28% of members) and about 25 homes a seed have books but no member; the books' header says every PTH home has them.
 *  hb    the PTH home's price and the trust's market rent at the member's market housing cost, the housing share of the basket the run prices the adult's
 *        cost of living at (mainLoopCostUSD), as the books' header says (GAPS item 7). As released they use the BLEI daily cost (about half the basket).
 *  ab    SNAP's work rule counts a month only if it is at least 1e-9 of a month (GAPS item 8): a wholly insured spell leaves a rounding remainder of about
 *        1e-16 that was counted. Reporting only (snAbN).
 *  sp    the essentials' supply path (each year's capacity) from the reported no-programme testbed run of the same seed, environment, population and
 *        rules (GAPS item 2), instead of the separate price-only run (s3BaseS: no job loss, safety net, labour response or wage indexation, and always
 *        500 adults). See tbBaseS. It is a study-level reading in effect: every row that sets it gets the path of the same no-programme run.
 * fx: true is all four parts. */
var FX = null;

// index.html line 4370
/* v5.3 B7 (Oct 7, 2026; plan item B7, "FBS lambda -> FBS50"; dev/DECISIONS.md Session 39, "B7"): FBS50, the advancement rule in interpretable units. The
 * chance of advancing an octave in a year is 1 - exp(-lambda x FBS) (BLEI paper, Index IV); FBS50 = ln 2 / lambda is the monthly free bandwidth surplus at
 * which that chance is even ($524 to $4,191 a month over the model's lambda range, CFG.FBS_HALF_SAT_LO/HI). null (the default) leaves the rule as it is.
 * When an object (row option fb): dist 'lambda' keeps each adult's lambda (evenly spread in lambda, as now) and 'fbs50' spreads FBS50 evenly over the same
 * range instead (the same uniform draw, read in FBS50: more adults need a larger surplus); scale multiplies every FBS50 (a sweep: how hard advancing is).
 * It also reports the share of participant-years whose FBS reaches their own FBS50 (better than even odds), for everyone and for adults in households
 * with children (FBS_KEYS). No draw is added. */
var FBS50 = null, FBSS = null, FBS_KEYS = ['fbsAbove', 'fbsAboveKids', 'fbs50Med'];

// index.html line 4372
function fbsRes(F, out){ if (!F) return out; out.fbsAbove = F.n ? F.a/F.n*100 : 0; out.fbsAboveKids = F.nK ? F.aK/F.nK*100 : 0; var v = F.f.sort(function(x, y){ return x - y; }); out.fbs50Med = v.length ? v[Math.floor(v.length/2)] : 0; return out; }

// index.html line 4373
CFG.CE_SPEND_ELAST = 0.5573;  /* the income elasticity of spending (BLS CE 2024, quintiles 2-5, per equivalent adult) */

// index.html line 4374
function normCdf(z){ var x = Math.abs(z)/Math.SQRT2, t = 1/(1 + 0.5*x), r = t*Math.exp(-x*x - 1.26551223 + t*(1.00002368 + t*(0.37409196 + t*(0.09678418 + t*(-0.18628806 + t*(0.27886807 + t*(-1.13520398 + t*(1.48851587 + t*(-0.82215223 + t*0.17087277)))))))));
  return z >= 0 ? 1 - r/2 : r/2; }  /* the complementary error function of Numerical Recipes (erfcc), relative error < 1.2e-7 everywhere, so the tails stay accurate */

// index.html line 4376
function normInv(p){ var a = [-39.69683028665376, 220.9460984245205, -275.9285104469687, 138.3577518672690, -30.66479806614716, 2.506628277459239], b = [-54.47609879822406, 161.5858368580409, -155.6989798598866, 66.80131188771972, -13.28068155288572],
  c = [-0.007784894002430293, -0.3223964580411365, -2.400758277161838, -2.549732539343734, 4.374664141464968, 2.938163982698783], d = [0.007784695709041462, 0.3224671290700398, 2.445134137142996, 3.754408661907416], q, r;
  p = Math.min(1 - 1e-12, Math.max(1e-12, p));
  if (p < 0.02425){ q = Math.sqrt(-2*Math.log(p)); return (((((c[0]*q + c[1])*q + c[2])*q + c[3])*q + c[4])*q + c[5])/((((d[0]*q + d[1])*q + d[2])*q + d[3])*q + 1); }
  if (p > 1 - 0.02425){ q = Math.sqrt(-2*Math.log(1 - p)); return -(((((c[0]*q + c[1])*q + c[2])*q + c[3])*q + c[4])*q + c[5])/((((d[0]*q + d[1])*q + d[2])*q + d[3])*q + 1); }
  q = p - 0.5; r = q*q; return (((((a[0]*r + a[1])*r + a[2])*r + a[3])*r + a[4])*r + a[5])*q/(((((b[0]*r + b[1])*r + b[2])*r + b[3])*r + b[4])*r + 1); }  /* Acklam's rational approximation, relative error < 1.2e-9 */

// index.html line 4385
function latentAdjust(l){ var L = LATENT, zw = (Math.log(l.wage) - 3.5)/0.5;  /* the wage's own normal score (makeLatentAgent draws lognormal(3.5, 0.5)) */
  if (L.risk){ var zr = normInv(autoRiskCdf(l.automationRisk)); l.automationRisk = autoRiskInv(normCdf(L.risk*zw + Math.sqrt(1 - L.risk*L.risk)*zr)); }
  if (L.wealth){ var zq = (Math.log(l.wealth) - CFG.WEALTH_INIT_MU)/CFG.WEALTH_INIT_SIGMA; l.wealth = scfWealthQ(normCdf(L.wealth*zw + Math.sqrt(1 - L.wealth*L.wealth)*zq)); }
  if (L.wsd || L.wmed) l.wage = Math.exp((L.wmed ? Math.log(L.wmed/(12*CFG.WAGE_TO_USD)) : 3.5) + (L.wsd || 0.5)*zw);
  return l; }

// index.html line 4438
/* ─── v5.3 B3 (Oct 7, 2026; plan item B3; dev/DECISIONS.md Session 39, "B3, households"): HOUSEHOLDS. null (the default, and the page's) leaves every run
 * bit-identical. When an object (HH_DEFAULTS), and in the framework (Hub-spec) conversion model, the adults are grouped into households once at the start, on
 * their own random stream (seed + 500009), as fixed counts from the Census CPS ASEC 2023 tables (sources/households.py): couples with and without children
 * under 18, single parents, and single adults; partners are paired at random; children are dependants with an age each (no draws on the main stream, so
 * every adult keeps its eight draws a year and its pairing with the no-programme run).
 *  - What a household needs: MIT's budget for its family type (one or two working adults, up to three children), each component as a ratio to the
 *    one-adult budget (CFG.HH_RATIO, so a single adult is exactly the adult-only model), plus childcare for each child under 13 at MIT's own prices in MIT's
 *    order (CFG.HH_CHILDCARE: first $12,914, second $11,638, third and more $7,824 at the model's level; priced with the general price level). An adult
 *    carries an equal share of the household's budget and of the children's BU (each child childBU x the adult BU: Duke's quarter, d167).
 *  - pool 'household' (d168, the main reading): at the end of the year a couple's cash surplus is pooled before the spending rule takes its share, their
 *    wealth is shared equally, the debt floor applies to the household, and poverty status is the household's; 'individual': each adult pays their equal
 *    share from their own income and keeps their own savings.
 *  - Decisions are the household's: a partner takes the first adult's participation, PTF and PTH draws at the start and follows the first adult's later
 *    joins (open enrolment, PTF adoption).
 *  - BLEI: the daily cost of basic living (rent, food, utilities, transport: the BLEI paper's definition) is the household's, from MIT's (housing + food +
 *    transport) for its type, and each adult's BLEI uses their own resources against an equal share of it (a._hhD multiplies agentBLEI's daily cost).
 * With ageing on (AGE), households live through the run: see CHILDREN'S LIVES below (v5.3 B4, B5). Single adults (one adult, no children) take the
 * adult-only path everywhere. */
/* v5.3 B6 (Oct 7, 2026; plan item B6; dev/DECISIONS.md Session 39, "B6"): shock 0 (the default: partners' yearly income swings are independent, as before)
 * | 'shore' | a number in [-1, 1]. The model's income shock is the year's macro multiplier (the recession path, common to everyone) times each adult's own
 * swing (uniform 0.90-1.10 on the main stream). With a shock, a couple's two swings share a household part drawn once a year on its own stream
 * (seed + 500041), so their correlation is the chosen value and each adult's swing keeps its spread; 'shore' takes Shore (2010, Review of Economics and
 * Statistics 92(3)): spouses' labour-income changes correlate about +0.10 in good years and -0.10 in bad ones (CFG.HH_SHOCK_CORR; recession years are bad). */
/* v5.3 B7 (Oct 7, 2026; plan item B7; dev/DECISIONS.md Session 39, "B7"): wealth 'model' (the default: each adult's own starting draw, as before) | 'scf'
 * (a calibration reading, applied in every run that sets it, no programme included): each household's starting net worth comes from the 2022 Survey of
 * Consumer Finances for its type (families with a head aged 25-66 and wage income; sources/scf_households.py; CFG.HH_SCF_PCTL, 100 quantiles in 2025
 * dollars; single adults use CFG.SCF_NETWORTH_PCTL, the same group), linked to the household's wage income by a Gaussian copula with the survey's own
 * correlation for the type (CFG.HH_SCF_RHO), and shared equally by its adults. No draw is added: within each type, the households' wages and their
 * adults' own wealth draws are ranked, and the two normal scores are combined. Newcomers with ageing keep the model's own draw (a stated limit). */
var HOUSEHOLDS = null, HH_DEFAULTS = {pool:'household', childBU:0.25, estate:'heirs', shock:0, wealth:'model'}, HHS = null;

// index.html line 4439
CFG.HH_SCF_PCTL = {coupleKids:[-113197,-43954,-15181,-6496,-648,550,3318,5514,7686,10638,12871,16177,20793,23597,29152,33434,38624,46061,51242,62142,67200,70162,71778,79282,86766,93332,98264,103187,109809,112868,120128,125519,130909,134684,141743,146350,150805,157902,164834,172540,183823,188443,197345,205295,214361,223351,229204,235416,245171,266822,281541,295456,310843,323777,334693,349461,360614,377408,396441,412994,434695,463932,489119,510287,541255,555660,594647,612821,630061,662465,691728,723106,749286,815013,843011,880062,930555,994603,1044523,1119505,1197983,1320665,1394148,1437558,1477815,1540792,1611177,1698713,1965287,2150866,2536985,2807946,3108593,3499511,4041682,4833081,5629278,7436513,11651611,22097732],
  coupleNoKids:[-414584,-84673,-49841,-21672,550,2035,3521,6820,9571,12541,16242,19712,24227,27350,30563,32646,36701,40544,50923,61246,64426,72970,80103,88567,95604,106954,120035,128872,139820,141997,151695,168294,171997,174282,176892,188310,194809,198842,209291,224647,240939,254862,273927,286803,301411,311105,318511,324538,331350,345401,368353,379527,392917,404828,417463,424960,429845,443661,460753,474492,502081,519495,528288,556934,609464,677232,695805,724041,772885,804706,858709,886499,919297,959817,1001515,1033835,1113078,1184339,1261568,1341780,1427758,1561764,1697419,1883320,1981924,2264727,2350679,2539754,2720822,2836723,3211332,3308371,4122563,4508115,5003150,6470032,7587033,8836987,12771253,31326977],
  singleParent:[-112095,-89908,-75679,-59714,-52584,-35407,-27424,-21055,-18711,-15279,-13864,-12871,-10308,-7657,-5269,-692,0,110,286,330,880,3045,4026,4917,5433,6215,7021,7756,9030,10040,10531,11609,12816,13751,14022,15353,16146,18902,21858,22734,25319,28640,31410,34554,36527,38602,40821,42903,44113,46182,49935,53772,55829,56549,59016,60374,66126,67794,72332,78953,85470,94579,97274,105388,118390,122396,134848,147462,157395,168279,171779,181121,186234,203059,211897,220952,240508,249601,249827,252607,265636,272112,290860,297241,325623,336015,390942,399548,428076,446241,464453,495084,739215,768154,805099,915532,1109721,1140010,1697112,3699413]};  /* net worth at 0.5%, 1.5%, ..., 99.5%, 2025 dollars (SCF 2022, sources/scf_households.py) */

// index.html line 4442
CFG.HH_SCF_RHO = {coupleKids:0.6458, coupleNoKids:0.4978, singleParent:0.3347, single:0.3585};  /* normal-score correlation of wage income with net worth, by type (single = CFG.SCF_WAGE_WEALTH_RHO) */

// index.html line 4443
CFG.HH_SHOCK_CORR = [0.10, -0.10];  /* correlation of spouses' income changes: good years, recession years (Shore 2010) */

// index.html line 4444
CFG.HH_COMP = {coupleKids:0.3163, coupleNoKids:0.3291, singleParent:0.0495, single:0.3050};  /* adults 25-64 by household type (CPS ASEC 2023, tables A1, A3, UC3) */

// index.html line 4445
CFG.HH_KIDS = {couple:[0.4063, 0.3838, 0.1462, 0.0637], single:[0.5651, 0.2785, 0.1101, 0.0463]};  /* 1, 2, 3, 4 or more own children under 18, per parent (table A3) */

// index.html line 4446
CFG.HH_KID_AGES = {couple:[0.3278, 0.3308, 0.3414], single:[0.2649, 0.3433, 0.3918]};  /* children aged 0-5, 6-11, 12-17, with two parents or one (table C2) */

// index.html line 4447
CFG.HH_RATIO = {'1a0k':{food:1, housing:1, medical:1, transport:1, civic:1, internet:1, other:1, taxes:1},
  '1a1k':{food:1.46685, housing:1.357341, medical:2.842683, transport:1.157305, civic:1.688049, internet:1, other:1.818304, taxes:1.522541},
  '1a2k':{food:2.197896, housing:1.357341, medical:2.890464, transport:1.457801, civic:2.226109, internet:1, other:1.987634, taxes:2.202741},
  '1a3k':{food:2.925225, housing:1.765906, medical:2.942673, transport:1.677405, civic:2.535119, internet:1, other:2.164186, taxes:3.084082},
  '2a0k':{food:1.833247, housing:1.100935, medical:2.147724, transport:1.157305, civic:1.688049, internet:1.375771, other:1.818304, taxes:1.10112},
  '2a1k':{food:2.275206, housing:1.357341, medical:3.142813, transport:1.457801, civic:2.226109, internet:1.375771, other:2.035738, taxes:1.65003},
  '2a2k':{food:2.926551, housing:1.357341, medical:3.240001, transport:1.677405, civic:2.535119, internet:1.375771, other:2.164186, taxes:2.070551},
  '2a3k':{food:3.570563, housing:1.765906, medical:3.348802, transport:1.877961, civic:2.838304, internet:1.375771, other:2.423002, taxes:2.731563}};  /* MIT family-type components over one adult's (sources/households.py; couples: both working) */

// index.html line 4455
CFG.HH_CHILDCARE = [12913.68, 11637.65, 7823.75];  /* MIT childcare at the model's level: first child (toddler care), second (preschool), third and more (school-age) */

// index.html line 4456
CFG.HH_CARE_AGE = 13;  /* childcare for children under 13 (dev/reports/v5-3-design.md, 1.3) */

// index.html line 4457
CFG.HH_BLEI_KEYS = ['housing', 'food', 'transport'];  /* the BLEI paper's basic living cost: rent and utilities (MIT housing is HUD rent with utilities), food, transport */

// index.html line 4458
function hhNeed(H){  /* the household's needs at year-0 prices (static until children age, B4) */
  var nA = H.a.length, nK = H.kids.length, R = CFG.HH_RATIO[nA + 'a' + Math.min(3, nK) + 'k'], need = {}, tot = 0, cc = 0, nc = 0, bl = 0, bl1 = 0;
  CFG.BASKET_KEYS.forEach(function(k){ need[k] = CFG.LIVING_WAGE_ANNUAL*CFG.BASKET[k]*R[k]; tot += need[k]; });
  H.kids.slice().sort(function(x, y){ return x - y; }).forEach(function(age){ if (age < CFG.HH_CARE_AGE){ cc += CFG.HH_CHILDCARE[Math.min(nc, CFG.HH_CHILDCARE.length - 1)]; nc++; } });
  need.childcare = cc; tot += cc;
  CFG.HH_BLEI_KEYS.forEach(function(k){ bl += CFG.BASKET[k]*R[k]; bl1 += CFG.BASKET[k]; });
  H.single = nA === 1 && nK === 0; H.need = need; H.need0 = tot; H.buM = 1 + (HOUSEHOLDS.childBU || 0)*nK/nA; H.dM = bl/bl1/nA;
}

// index.html line 4466
function hhInit(agents, seed){
  var r = mulberry32(seed + 500009), n = agents.length, C = CFG.HH_COMP, ord = [], i, list = [], q = 0;
  for (i = 0; i < n; i++) ord.push(i);
  for (i = n - 1; i > 0; i--){ var j = Math.floor(r()*(i + 1)), t = ord[i]; ord[i] = ord[j]; ord[j] = t; }  /* the adults in a random order: consecutive adults pair up */
  var nC = Math.round(n*(C.coupleKids + C.coupleNoKids)/2), nCK = Math.round(nC*C.coupleKids/(C.coupleKids + C.coupleNoKids)), nSP = Math.round(n*C.singleParent);
  function kids(arr){ var u = r(), K = CFG.HH_KIDS[arr], k = 0, c = K[0], A = CFG.HH_KID_AGES[arr], out = [];
    while (k < K.length - 1 && u >= c){ k++; c += K[k]; }
    for (var m = 0; m <= k; m++){ var v = r(), b = v < A[0] ? 0 : v < A[0] + A[1] ? 1 : 2; out.push(b*6 + Math.floor(r()*6)); }
    return out; }
  for (i = 0; i < nC; i++){ var a1 = agents[ord[q++]], a2 = agents[ord[q++]]; list.push({a:[a1, a2], kids:i < nCK ? kids('couple') : []}); }
  for (i = 0; i < nSP && q < n; i++) list.push({a:[agents[ord[q++]]], kids:kids('single')});
  while (q < n) list.push({a:[agents[ord[q++]]], kids:[]});
  list.forEach(function(H, h){ H.id = h; H.grown = []; var hd = H.a[0]; hhNeed(H);
    H.a.forEach(function(a, j){ a._hh = H; a._hhHead = j === 0; if (!H.single) a._hhD = H.dM;
      if (j > 0){ a.inCCO = hd.inCCO; a.inPTF = hd.inPTF; a.inPTH = hd.inPTH; a.uCCO = hd.uCCO; } }); });  /* decisions are the household's */
  if (HOUSEHOLDS.wealth === 'scf') hhScfWealth(list, seed);  /* v5.3 B7; S59: the seed for the tail's own stream */
  HHS = {list:list, grown:[], elig:[], nextId:list.length, rng:null, st:null, srng:mulberry32(seed + 500041)};  /* grown, elig, rng, st: children's lives (B4; read only with ageing); srng: the household part of income shocks (B6) */
}

// index.html line 4484
function hhScfQ(Q, p){ var h = p*100 - 0.5, k = Math.floor(h); if (k < 0) return Q[0]; if (k >= Q.length - 1) return Q[Q.length - 1]; return Q[k] + (Q[k + 1] - Q[k])*(h - k); }  /* as scfWealthQ, for any table */

// index.html line 4485
function hhScfWealth(list, seed){  /* v5.3 B7: household net worth from the SCF by type, ranked on the households' own wages and wealth draws (no draw) */
  if (LATENT && LATENT.wealth) throw new Error('HOUSEHOLDS wealth \'scf\' replaces the singles reading LATENT.wealth: use one or the other');
  var G = {coupleKids:[], coupleNoKids:[], singleParent:[], single:[]}, wr = WEALTH_TAIL ? mulberry32(seed + 600073) : null;  /* S59: the tail's own stream */
  list.forEach(function(H){ G[H.a.length > 1 ? (H.kids.length ? 'coupleKids' : 'coupleNoKids') : (H.kids.length ? 'singleParent' : 'single')].push(H); });
  Object.keys(G).forEach(function(t){ var L = G[t], n = L.length, Q = t === 'single' ? CFG.SCF_NETWORTH_PCTL : CFG.HH_SCF_PCTL[t], rho = CFG.HH_SCF_RHO[t], wu = null; if (wr){ wu = []; for (var wj = 0; wj < WEALTH_TAIL.m; wj++) wu.push(wr()); } if (!n) return;
    function scores(f){ var o = L.map(function(H, i){ return [f(H), i]; }).sort(function(x, y){ return x[0] - y[0]; }), z = new Array(n); o.forEach(function(q, r){ z[q[1]] = normInv((r + 0.5)/n); }); return z; }
    var zw = scores(function(H){ return H.a.reduce(function(m, a){ return m + a.wage; }, 0); }), zq = scores(function(H){ return H.a.reduce(function(m, a){ return m + a.wealth; }, 0); });
    if (wr){ wtAssign(L, t, Q, L.map(function(H, i){ return normCdf(rho*zw[i] + Math.sqrt(1 - rho*rho)*zq[i]); }), wu); return; }  /* S59 */
    L.forEach(function(H, i){ var W = hhScfQ(Q, normCdf(rho*zw[i] + Math.sqrt(1 - rho*rho)*zq[i])); H.a.forEach(function(a){ a.wealth = W/H.a.length; }); }); });
  if (wr) wtRank(list);
}

// index.html line 4496
function hhYear(agents){  /* each household's cost factor and shares at this year's prices (no draw) */
  var bI = PRICE ? PRICE.bIdx : 1;
  HHS.list.forEach(function(H){ if (H.single) return;
    if (HOUSEHOLDS.shock && H.a.length > 1) H.hv = 0.90 + HHS.srng()*0.20;  /* v5.3 B6: the couple's shared part of this year's income swing */
    var N = H.need, P = 0, e = 0, f, hs, t;
    function c(k){ return PRICE ? PRICE.comp[k === 'childcare' ? 'other' : k] : 1; }
    Object.keys(N).forEach(function(k){ P += N[k]*c(k); });
    buEss().forEach(function(k){ e += N[k]*c(k); }); if (BU_SCOPE === 'hub') e += N.childcare*c('childcare');  /* v5.3 B3f: BU scope (childcare at PTF centres under 'hub') */
    f = N.food*c('food')/P; hs = N.housing*c('housing')/P; t = DISC_BASE === 'pretax' ? N.taxes*c('taxes')/P : 0;
    var pS = PTFS ? {f:f, h:hs, t:N.transport*c('transport')/P, m:N.medical*c('medical')/P, k:(N.childcare || 0)*c('childcare')/P} : null;  /* v5.4 item 4: the household's sector shares */
    var q22 = 0; if (C22) C22_NEEDS.forEach(function(k){ q22 += N[k]*c(k); });  /* S6: the household's C2.2 needs (reporting only) */
    H.a.forEach(function(a){ if (C22) a._hhC22 = q22/P; a._hhF = P/(H.a.length*CFG.LIVING_WAGE_ANNUAL*bI); a._hhE = e/P; a._hhFd = f; a._hhH = hs; a._hhT = t; a._hhBU = H.buM; if (pS) a._hhS = pS; }); });
}

// index.html line 4509
function hhSync(what){  /* partners follow the first adult's decision */
  HHS.list.forEach(function(H){ if (H.a.length < 2) return; var hd = H.a[0];
    for (var j = 1; j < H.a.length; j++){ var a = H.a[j]; if (what === 'cco'){ a.inCCO = hd.inCCO; a._jnY = hd._jnY; } else a.inPTF = hd.inPTF; } });
}

// index.html line 4513
function hhPool(yr, tbOn){  /* pool 'household': the end-of-year step for couples (spending rule, shared wealth, floor, household poverty status, the accounting check) */
  HHS.list.forEach(function(H){ if (H.a.length < 2) return;
    var n = H.a.length, cs = 0, w = 0;
    if (SURPLUS_CONSUMPTION_SHARE > 0){ H.a.forEach(function(a){ cs += SURPLUS_CONSUMPTION_BASE === 'cash' ? a._hhCS : a._hhWS; });
      var sc = SURPLUS_CONSUMPTION_SHARE*Math.max(0, cs)/n; H.a.forEach(function(a){ a.wealth -= sc; if (ACCT) a._acSc += sc; if (LEDGER) ledAdd(yr, 'surplusConsumed', sc); }); }
    if (SPEND_GRADE){ var gA = 0, gC = 0; H.a.forEach(function(a){ gA += a._grA; gC += a._grC; });  /* v5.3 B7: the couple spends less when its income is below its costs */
      var gc = gC > 0 && gA < gC ? (DEBT_READ && DEBT_READ.fl === 'fpl' ? drFloorCut(gA, gC, SPEND_GRADE.eps, drFloorShare(H)) : gC - gC*Math.pow(Math.max(0, gA)/gC, SPEND_GRADE.eps)) : 0;  /* S61: fl */
      if (DEBT_READ && gc > 0){ var gW = 0; H.a.forEach(function(a){ gW += a.yrWealthStartUSD; }); gc += drExtra(gA, gC, gc, gW); }  /* S35: the debt reading */
      H.a.forEach(function(a){ a._grCut = gc/n; a.wealth += gc/n; if (ACCT) a._acGr = gc/n; }); }
    H.a.forEach(function(a){ w += a.wealth; }); w /= n;
    H.a.forEach(function(a){ if (ACCT) a._acHt = w - a.wealth; a.wealth = w; });
    if (PRICE && PRICE.acc){ var A = PRICE.acc; H.a.forEach(function(a){ var pmW = a.wealth < CFG.WEALTH_FLOOR ? CFG.WEALTH_FLOOR - a.wealth : 0, pmU = a._hhPmB > 0 ? Math.min(1, (SPEND_GRADE ? pmW + a._grCut : pmW)/a._hhPmB) : 0;
      A.essD -= pmU; A.unmet += pmW; if (pmW > 0) A.unmetN++; }); }  /* the price module's unmet need, after pooling (the year loop counted none for these adults) */
    if (tbOn){ var inc = 0, mlc = 0, cost = 0, disp = 0; H.a.forEach(function(a){ inc += a._hhInc; mlc += a._hhMlc; cost += a._hhCost; disp += a._hhDisp; });
      if (SECS){ var sE = 0, sC = 0; H.a.forEach(function(a){ sE += a._seE || 0; sC += a._seC || 0; }); H.a.forEach(function(a){ a._seE = sE/n; a._seC = sC/n; }); }  /* S47: the household's parts per adult, as its income */
      H.a.forEach(function(a){ tbPov(a, TB.cur, a._hhIdx, inc/n, mlc/n, cost/n, disp/n); }); }
    H.a.forEach(function(a){ if (a.wealth < CFG.WEALTH_FLOOR){ if (ACCT) a._acFl = CFG.WEALTH_FLOOR - a.wealth;
      if (LEDGER){ var lf = CFG.WEALTH_FLOOR - a.wealth; ledAdd(yr, 'floor', lf); ledAdd(yr, 'floorHits', 1); a._ledFloor = (a._ledFloor || 0) + lf; } a.wealth = CFG.WEALTH_FLOOR; } });
    if (ACCT){ var tg = 0, ts = 0; H.a.forEach(function(a){ acctAgent(a, yr); tg += a._acHt; ts += Math.abs(a._acHt) + Math.abs(a.wealth); }); acctChk('household', yr, tg, ts, H.id); }  /* the scale: the transfers and the wealth pooled (rounding is relative to the wealth: v5.3 B6) */
  });
}

// index.html line 4542
/* v5.3 B6 (Oct 7, 2026; plan item B6; dev/DECISIONS.md Session 39, "B6"): THE MEASURED EDC (reporting only: no draw, nothing any rule reads; EDC_MEASURE
 * false, the default, adds nothing). The Extractive Drain Coefficient as the page's glossary defines it, the share of income captured by contracts that
 * build no household wealth (rent, interest, fees), measured from the year's flows: rent paid to a landlord (MIT's housing with utilities, the household's
 * at its own prices; a community-housing (PTH) payment counts 0, as the glossary says) plus interest paid on debt (only where the savings reading charges it;
 * the model has no fees), over gross income (wages, conversion income, Social Security, cash transfers before the contribution, and the BU allowance at
 * face value, since BU pay rent too). With households it is the household's (its adults' rent over their income), counted for every person; otherwise
 * each adult's. Keys EDC_KEYS: the mean over person-years of the ratio (capped at 1), the ratio of the totals, the mean for adults in and outside PTH,
 * and the design target proxy (agentEDC, the formula the earlier engine shows) for comparison. */
var EDC_MEASURE = false, EDCS = null;

// index.html line 4543
var EDC_KEYS = ['edcM', 'edcMagg', 'edcMPth', 'edcMOut', 'edcProxy'];

// index.html line 4552
function edcRes(E, out){ if (!E) return out;
  out.edcM = E.n ? E.s/E.n*100 : 0; out.edcMagg = E.y ? E.r/E.y*100 : 0; out.edcMPth = E.nP ? E.sP/E.nP*100 : 0; out.edcMOut = E.nO ? E.sO/E.nO*100 : 0; out.edcProxy = E.pn ? E.px/E.pn*100 : 0; return out; }

// index.html line 4577
/* ─── v5.3 B4 and B5 (Oct 7, 2026; plan items B4, B5; dev/DECISIONS.md Session 39, "B4"): CHILDREN'S LIVES. Read only when ageing (AGE) and households
 * are both on; either off leaves every run as before. Sources and derivations: sources/households.py, section 6; sources/births_us.md.
 *  - Ages at the start (hhAges, own stream seed + 500021, after ageInit): a mother's age given her children's ages is drawn in proportion to the population
 *    at each age (CFG.AGE_WEIGHTS) times the 2024 birth rate at the age she had each child (CFG.HH_ASFR, NCHS); a partner's age adds the spouses' age gap
 *    (CFG.HH_GAP, Census CPS 2023 Table FG3, with or without children; redrawn while outside 25-66); a childless couple's woman follows FG3's wives without
 *    children (CFG.HH_AGE_WIFE_NOKIDS); single adults follow the CPS singles by age (CFG.HH_AGE_SINGLE). Couples are a woman and a man (FG3 covers opposite-sex
 *    married couples; cohabiting couples are assumed alike); a single parent is a mother with C2's share (CFG.HH_FEMALE.singleParent), a single adult a woman
 *    with the share left by the population (CFG.HH_FEMALE.single), a new 25-year-old a woman with the 2024 population's share at 25.
 *  - Each year, at the start (ageYear; own stream seed + 500029 for every draw below): deaths as before; the place of an adult who dies goes to a grown child
 *    of a household turning 25 that year if one is waiting (drawn at random among them), otherwise to an unrelated 25-year-old, as before; the newcomer
 *    forms a household of one, drawn like every new adult (no inheritance of earnings: a stated limit). A partner who survives keeps the household and its
 *    children; when the last adult of a household dies, its children under 18 leave the model (to relatives outside it; counted). Children age a year;
 *    at 18 a child stops being a dependant and leaves the household (outside the model from 18 to 24, as people that age always have been; at 25 they can
 *    take a place, and those who find none leave the model: the population stays at its size). Then each woman aged up to 49 gives birth with the 2024
 *    rate at her age times CFG.HH_FERT_K (partner present or not; chosen so that women as a whole give birth at the national rates and 22% of births are to
 *    women without a partner, C2's share of children under 6 living with one parent, which also stands in for young families that split: the model has no
 *    separations or new partnerships, a stated limit). A household's needs, childcare and child allowance follow its children every year.
 *  - Estates (B5, Duke's decision d169; estate 'heirs', the default): an adult's estate (positive wealth and Acre Equity; debts are not inherited and BU
 *    held for later conversion lapse, as before) passes to the surviving partner, else to the children in equal shares (children under 18, whose shares
 *    leave the model with them, and grown children, whose shares reach them if they are adults in the model), else it leaves the model. Acre Equity stays
 *    Acre Equity for an heir in community housing, otherwise it is paid out at the deceased's liquid share and the rest stays with the trust (Claude's
 *    reading of the Hub's "Inheritance Rights", dev/reports/v5-3-design.md 1.5). estate 'leave': every estate leaves the model, as in the adult-only model.
 *    Estates pass at the start of the year, before the year's accounts open, so the yearly identities are unchanged. No inheritance tax (none on the Hub). */
CFG.HH_ASFR = [12.6, 55.8, 89.5, 93.7, 54.3, 12.7, 1.1];  /* births per 1,000 women a year at ages 15-19, 20-24, ..., 45-49 (NCHS, Births: Final Data for 2024, Table 2) */

// index.html line 4578
CFG.HH_FERT_K = {couple:1.2376, single:0.5975};  /* the rate's multiple for a woman with a partner present and without (sources/households.py, section 6) */

// index.html line 4579
CFG.HH_FEMALE = {single:0.4461, singleParent:0.8317, entrant:0.4910};  /* shares of women: single adults, single parents (C2), new 25-year-olds (Census 2024) */

// index.html line 4580
CFG.HH_GAP = [[20,24,357,209],[15,19,516,319],[10,14,1911,1016],[6,9,4420,2718],[4,5,4834,2960],[2,3,7810,4979],[-1,1,13892,8748],[-3,-2,2760,1717],[-5,-4,1447,689],[-9,-6,1139,437],[-14,-10,453,150],[-19,-15,170,41],[-24,-20,122,58]];  /* husband's age minus wife's: lowest, highest, couples (thousands) without and with own children under 18 (FG3; "20+" taken as 20-24) */

// index.html line 4581
CFG.HH_AGE_SINGLE = [1800.7,1797.5,1800.7,1812.4,1842.6,1878.5,1905.9,1945.4,1970.4,1972.0,1099.1,1077.8,1063.9,1063.7,1060.4,1036.6,1049.1,1044.7,1027.8,1021.3,1018.1,993.8,979.8,945.1,953.6,933.8,944.4,987.8,1044.4,1026.3,1382.9,1351.2,1353.2,1369.4,1418.7,1449.4,1446.4,1447.4,1440.3,1410.3,1379.2,1363.0];  /* single adults at ages 25..66 (CPS 2023 tables A1, UC3, A3 by ten-year band, spread by the 2024 population) */

// index.html line 4582
CFG.HH_AGE_WIFE_NOKIDS = [285.9,286.0,287.5,289.3,294.3,319.1,323.8,331.2,336.2,336.7,265.4,260.3,256.4,256.1,255.8,291.0,294.8,293.9,289.4,287.9,527.0,515.0,509.3,491.3,496.3,854.4,865.4,903.5,953.5,938.2,1139.8,1116.0,1122.6,1138.7,1185.7,1212.8,1214.5,1217.8,1215.0,1192.3,1106.9,1096.9];  /* wives in couples without children under 18 at ages 25..66 (FG3, spread by the 2024 female population) */

// index.html line 4583
CFG.HH_ADULT_AGE = 18;  /* a child stops being a dependant (the Census counts children under 18; the draft Act gives BU from 18) */

// index.html line 4650
var HH_LIFE_KEYS = ['hhBirthR', 'hhBirthSg', 'hhKid0', 'hhEntK', 'hhGrOut', 'hhOrph', 'hhEstN', 'hhEstP', 'hhEstK', 'hhEstO', 'hhMom0', 'hhGap0'];  /* v5.3 B4, B5: children's lives (households with ageing) */

// index.html line 4651
function hhLifeRes(out){ var t = HHS && HHS.st; if (!t) return out;
  out.hhBirthR = t.wy ? t.births/t.wy*1000 : 0; out.hhBirthSg = t.births ? t.birthsSg/t.births*100 : 0; out.hhKid0 = t.kid0;
  out.hhEntK = t.entK + t.entU ? t.entK/(t.entK + t.entU)*100 : 0; out.hhGrOut = t.grOut; out.hhOrph = t.orph; out.hhEstN = t.estN;
  out.hhEstP = t.estV ? t.estP/t.estV*100 : 0; out.hhEstK = t.estV ? t.estK/t.estV*100 : 0; out.hhEstO = t.estV ? t.estO/t.estV*100 : 0;
  out.hhMom0 = t.momN ? t.mom/t.momN : 0; out.hhGap0 = t.gapN ? t.gap/t.gapN : 0; return out; }

// index.html line 4664
/* v5.3 B3 (Oct 7, 2026): the household reading's measures (reporting only: no draw, nothing any rule reads). Every person counts, children included, with the
 * status of their household (its resources against its needs, under either pooling rule; the adult measures above keep each adult's own status under
 * 'individual'). Per year: below the cost of living (household cash income after the contribution against the household's cost after price cuts and BU), below
 * the official poverty line for the household's size and children (Census 2025 thresholds, CFG.HH_FPL, moved with prices; money income before tax: wage,
 * conversion, cash transfers, Social Security), too little wealth (household net wealth below six months of the household's own cost of living, CFG.HH_WEALTH_MONTHS:
 * the reading of the $25,000 line for one adult, $24,685), and below 30 days of basic living (the household's BLEI: the mean of its adults'). Shares of persons
 * and of children, as person-years over the run and at Year 7 and the last year; the same by household type; and the Gini and median of disposable income per
 * equivalent adult (household income over the square root of its size, the OECD's square-root scale), across persons, at the last year. Keys HH_KEYS. */
CFG.HH_FPL = {'1a0k':16749, '1a1k':22190, '1a2k':25938, '1a3k':32762, '1a4k':37833, '2a0k':21558, '2a1k':25913, '2a2k':32649, '2a3k':38421, '2a4k':43018};  /* Census, Poverty Thresholds for 2025 by Size of Family and Number of Related Children (householder under 65) */

// index.html line 4665
CFG.HH_WEALTH_MONTHS = 6;  /* too little wealth for a household: net wealth below six months of its own cost of living (one adult: $24,685, the $25,000 line's reading) */

// index.html line 4666
var HH_TYPES = ['sg', 'sp', 'cn', 'ck'];  /* single adult, single parent, couple without children, couple with children */

// index.html line 4667
var HH_KEYS = ['hhPer', 'hhKid', 'hhCostPY', 'hhCostKidPY', 'hhFplPY', 'hhFplKidPY', 'hhWlthPY', 'hhWlthKidPY', 'hhBleiPY', 'hhBleiKidPY',
  'hhFpl7', 'hhFplKid7', 'hhCost7', 'hhCostKid7', 'hhFplEnd', 'hhFplKidEnd', 'hhCostEnd', 'hhCostKidEnd', 'hhWlthEnd', 'hhWlthKidEnd', 'hhBleiEnd', 'hhBleiKidEnd',
  'hhGiniEq', 'hhMedEq'].concat(HH_TYPES.map(function(t){ return 'hhCost_' + t; }), HH_TYPES.map(function(t){ return 'hhWlth_' + t; }), HH_TYPES.map(function(t){ return 'hhShare_' + t; }));

// index.html line 4670
function hhTypeOf(H){ return H.a.length === 1 ? (H.kids.length ? 'sp' : 'sg') : (H.kids.length ? 'ck' : 'cn'); }

// index.html line 4671
function hhRepAcc(){ var R = {py:0, kpy:0, c:{}, y7:null, end:null, per:0, kid:0}; ['cost', 'fpl', 'wlth', 'blei'].forEach(function(k){ R.c[k] = 0; R.c[k + 'K'] = 0; });
  HH_TYPES.forEach(function(t){ R['t_' + t] = {py:0, cost:0, wlth:0}; }); R.ab = {a25:{py:0, c:0}, a35:{py:0, c:0}, a50:{py:0, c:0}, a67:{py:0, c:0}}; R.sp = []; return R; }  /* ab, sp: v5.3 B8 */

// index.html line 4673
function hhRepYear(R, agents, p, o, yr, T){
  var lf = o.lines === 'nominal' ? 1 : agents[0].yrBasketUSD/CFG.LIVING_WAGE_ANNUAL/(agents[0]._hhF || 1), s = {per:0, kid:0, cost:0, costK:0, fpl:0, fplK:0, wlth:0, wlthK:0, blei:0, bleiK:0}, eq = [];
  HHS.list.forEach(function(H){ var nA = H.a.length, nK = H.kids.length, n = nA + nK, inc = 0, cost = 0, need = 0, money = 0, disp = 0, w = 0, b = 0;
    H.a.forEach(function(a){ inc += a._hhInc; cost += a._hhCost; need += a._hhMlc; disp += a._hhDisp; money += tbCashIncome(a); w += a.wealth; b += agentBLEI(a, p.bu, p.ccoOn, p.pth, p.szh, p.szhCoh, p.ptf)/lf; });
    var fC = inc < cost, fF = money < CFG.HH_FPL[nA + 'a' + Math.min(4, nK) + 'k']*lf, fW = w < need*CFG.HH_WEALTH_MONTHS/12, fB = b/nA < CFG.BLEI_PRECARIOUS_MAX, t = R['t_' + hhTypeOf(H)];
    s.per += n; s.kid += nK; if (fC){ s.cost += n; s.costK += nK; } if (fF){ s.fpl += n; s.fplK += nK; } if (fW){ s.wlth += n; s.wlthK += nK; } if (fB){ s.blei += n; s.bleiK += nK; }
    t.py += n; if (fC) t.cost += n; if (yr === T - 1){ t.n = (t.n || 0) + n; if (fW) t.w = (t.w || 0) + n; }
    if (!H._sp){ H._sp = {c:[], t:hhTypeOf(H)}; R.sp.push(H._sp); } H._sp.c.push(fC);  /* v5.3 B8: each household's years below the cost of living, for spells by its type at the start */
    H.a.forEach(function(a){ if (typeof a.age !== 'number') return; var q = R.ab[a.age >= 67 ? 'a67' : a.age >= 50 ? 'a50' : a.age >= 35 ? 'a35' : 'a25']; q.py++; if (fC) q.c++; });  /* v5.3 B8: adults by age group (with ageing) */
    if (yr === T - 1){ var e = disp/Math.sqrt(n)/lf; for (var i = 0; i < n; i++) eq.push(e); } });
  R.py += s.per; R.kpy += s.kid; R.per = s.per; R.kid = s.kid;
  ['cost', 'fpl', 'wlth', 'blei'].forEach(function(k){ R.c[k] += s[k]; R.c[k + 'K'] += s[k + 'K']; });
  function snap(){ return {cost:s.cost/s.per*100, costK:s.kid ? s.costK/s.kid*100 : 0, fpl:s.fpl/s.per*100, fplK:s.kid ? s.fplK/s.kid*100 : 0, wlth:s.wlth/s.per*100, wlthK:s.kid ? s.wlthK/s.kid*100 : 0, blei:s.blei/s.per*100, bleiK:s.kid ? s.bleiK/s.kid*100 : 0}; }
  if (yr === 6) R.y7 = snap();
  if (yr === T - 1){ R.end = snap(); R.gini = giniOfArr(eq); R.med = quantileOf(eq, 0.5); }
}

// index.html line 4689
function hhRepRes(R, out){
  function pc(k, kid){ var d = kid ? R.kpy : R.py; return d ? R.c[k]/d*100 : 0; }
  out.hhPer = R.per; out.hhKid = R.kid;
  out.hhCostPY = pc('cost'); out.hhCostKidPY = pc('costK', 1); out.hhFplPY = pc('fpl'); out.hhFplKidPY = pc('fplK', 1); out.hhWlthPY = pc('wlth'); out.hhWlthKidPY = pc('wlthK', 1); out.hhBleiPY = pc('blei'); out.hhBleiKidPY = pc('bleiK', 1);
  var y7 = R.y7 || {}, e = R.end || {};
  out.hhFpl7 = y7.fpl || 0; out.hhFplKid7 = y7.fplK || 0; out.hhCost7 = y7.cost || 0; out.hhCostKid7 = y7.costK || 0;
  out.hhFplEnd = e.fpl || 0; out.hhFplKidEnd = e.fplK || 0; out.hhCostEnd = e.cost || 0; out.hhCostKidEnd = e.costK || 0; out.hhWlthEnd = e.wlth || 0; out.hhWlthKidEnd = e.wlthK || 0; out.hhBleiEnd = e.blei || 0; out.hhBleiKidEnd = e.bleiK || 0;
  out.hhGiniEq = R.gini || 0; out.hhMedEq = R.med || 0;
  HH_TYPES.forEach(function(t){ var q = R['t_' + t]; out['hhCost_' + t] = q.py ? q.cost/q.py*100 : 0; out['hhWlth_' + t] = q.n ? (q.w || 0)/q.n*100 : 0; out['hhShare_' + t] = R.py ? q.py/R.py*100 : 0; });
  return out;
}

// index.html line 4704
/* v5.3 B8 (Oct 7, 2026; plan item B8; dev/DECISIONS.md Session 39, "B8"): more of the household reading's measures (reporting only). Adult-years below the
 * cost of living by age group (25-34, 35-49, 50-66, 67 and over; with ageing, else 0; children are hhCostKidPY), and poverty spells by household type:
 * each household's run of years below the cost of living (its status, as for every person in it), counted with tbRepSpells (Bane-Ellwood/Stevens, the
 * method of the US-data check), by the household's type at the start: the share of spells that end after their first year, and spells per run. */
var HH_REP_KEYS = ['hhCostA25', 'hhCostA35', 'hhCostA50', 'hhCostA67', 'hhSpEx1', 'hhSpN'].concat(HH_TYPES.map(function(t){ return 'hhSpEx1_' + t; }), HH_TYPES.map(function(t){ return 'hhSpN_' + t; }));

// index.html line 4705
function hhRepRes2(R, out){
  ['a25', 'a35', 'a50', 'a67'].forEach(function(k){ var q = R.ab[k]; out['hhCostA' + k.slice(1)] = q.py ? q.c/q.py*100 : 0; });
  function sp(L){ var o = {}; tbRepSpells(L, 'c', o, 'q'); return {ex:o.qN1 ? o.qX1/o.qN1 : 0, n:o.qN1}; }
  var a = sp(R.sp); out.hhSpEx1 = a.ex; out.hhSpN = a.n;
  HH_TYPES.forEach(function(t){ var q = sp(R.sp.filter(function(x){ return x.t === t; })); out['hhSpEx1_' + t] = q.ex; out['hhSpN_' + t] = q.n; });
  return out; }

// index.html line 4711
function hhRes(R, out){ return R ? hhLifeRes(hhRepRes2(R, hhRepRes(R, out))) : out; }  /* v5.3 B4: + children's lives, with ageing */

// index.html line 4712
function spNewAcc(){ return {pool:0, own:0, ptf:0, rest:0, pricePool:0, cut:0, cutN:0, cutP:0, freed:0, cash:0, carry:0, profit:0, profitN:0, reinv:0, wkY:0, wkY1:0,
  d1:0, n1:0, d2:0, n2:0, non:0, yrs:0}; }

// index.html line 4718
/* PRICE (A2 issuance and price module): null = off (index.html). When an object, runYear() reprices the basket by
 * PRICE.bIdx (the endogenous index, set each year by priceRun from the previous year's flows), reads COLA off the
 * endogenous headline rate, indexes wages to P_G by PRICE.wIdx, and accumulates the year's flows into PRICE.acc.
 * No RNG is drawn; with bIdx = 1 and no accumulation a run is bit-identical (checked by `unit`). */
var PRICE = null;

// index.html line 4744
/* LABOR (A3 labor-supply module, session 4; decisions d14, d15 and d2 on the project dashboard): null = off (index.html).
 * When an object, each agent's wage earnings E0 for the year are replaced by
 *   E = max(0, E0 x raise^eps - rho x cash - rhoBU x BUspent - rhoR x BUexpired - conversion term)
 *  rho     income effect per dollar of unconditional cash (p.ubi). Source: Vivalt et al., NBER w32719 (revised Aug 2026):
 *          $1,000 a month for three years; for every dollar received, individual income excluding the transfer fell about
 *          16 cents and household income about 28 cents. The model's agents are single adults, so 0.16 is central (d15).
 *  rhoBU   income effect per BU spent on the agent's own essentials (engine: the CCO relief dollars; framework: the BU
 *          spent up to the essentials budget). These BU are inframarginal (below own essentials spending), and Hoynes &
 *          Schanzenbach (AEJ Applied 2009) find inframarginal food stamps act like cash, so rhoBU = rho by default. Hastings &
 *          Shapiro (AER 2018) reject fungibility in spending (mental accounting), the case for sweeping rhoBU below rho.
 *  rhoR    income effect per BU that expire unspent (framework: directed to projects). The holder cannot consume them, so 0
 *          by default. d2's "UBI-equivalent toggle" sets rhoBU = rhoR = rho (every BU treated as cash).
 *  eps     compensated (Hicksian) wage elasticity. Chetty (Econometrica 2012): 0.33 on the intensive margin and 0.25 on the
 *          extensive margin, pooled. The program's raises are uncompensated wage increases, so earnings scale by
 *          raise^(eps - rho) (Slutsky: e_u = e_c + eta, with eta = w dh/dI = -rho, the same rho as the income effect), where
 *          raise = wage / wage without the program's raises (octave, CIP; the N7 split) x (1 + the framework's business
 *          payout per wage dollar). One elasticity for every change in the return to work (the plan's fairness rule).
 *  delta   conversion (d14). Conversion proceeds in both models do not depend on effort; the framework says they reward
 *          project work. Last year's creator proceeds C (engine: own conversion; framework: project conversion, not the
 *          wage-linked business payout) enter as  delta x C + rho x (1 - delta) x C : delta = 0 treats C as a rent (an
 *          unconditional dollar, the engine as coded); delta = 1 as fully dissipated project time that displaces wage
 *          time one for one (a fixed BU pool bid for competitively, so a marginal project hour earns the wage).
 * No RNG is drawn. With rho = rhoBU = rhoR = eps = delta = 0 a run is bit-identical to LABOR null (checked by `unit`).
 * LABOR.acc (when an object) tallies each channel in dollars. p.ubi (harness-only): annual cash to every adult, nominal,
 * money-created; counted as cash income in the income and basket measures. Unset in every preset. */
var LABOR = null;

// index.html line 4745
var LABOR_DEFAULTS = {rho:0.16, rhoBU:0.16, rhoR:0, eps:0.33, delta:0};

// index.html line 4769
/* S60 (Nov 13, 2026; research-update prereg/2026-11-s60-bargaining-power.md; dev/reports/s60-bargaining-power.md): BARGAIN, a worker's outside option and an
 * employer markdown, in reduced form (no firms, vacancies or hiring). null (the default) = off: nothing below is read and no figure moves (guard test). It
 * acts inside LABOR's block (a row needs the labour response); no random draw. Sources: sources/s60_bargain.py.
 *  m    the wage as a share of what the worker adds: MRPL = w/m on the year's wage (the engine takes the programme's raises as matched by output), so the
 *       room for a bargained raise is 1/m - 1 of the wage. 1/1.21 (main; Azar, Berry and Marinescu, NBER w30365, 2022: median markdown 21%, firm-level
 *       elasticity 4.8); 1/1.53 (Yeh, Macaluso and Hershbein, AER 2022, US manufacturing plants); 1 = no markdown, no room (identical to off).
 *  pi   cents of yearly wage per dollar of yearly outside option. 0 (main: Jager, Schoefer, Young and Zweimuller, QJE 2020, preferred estimates 0.00 and
 *       -0.027, more than 0.03 ruled out); 0.03 (their bound); 0.10 (Vivalt et al., NBER w32719 revised Aug 2026: hourly pay -$0.14, more than +$0.58
 *       ruled out, against $1,000 a month over 2,080 hours); 0.24 and 0.48 (the Nash benchmarks Jager et al. calibrate and reject).
 * The outside option O is what the programme adds to what a worker keeps without working: the unconditional dollars the income effect counts, at its own
 * weights (cash; BU spent x rhoBU/rho, so a BU counts at the value of what it buys; expired BU x rhoR/rho, 0 by default; conversion proceeds x (1 - delta);
 * the testbed's cash, guarantee, endowment and in-kind dollars; owners' dollars), without today's safety net (the baseline the wages were measured under) or
 * the contribution's terms. With no programme O is 0, so a no-programme run is identical to off. The year's bargained raise g = min(pi O / E_full, 1/m - 1),
 * E_full the year's full-year earnings before any response. Earnings are multiplied by (1 + g)^(1 + eps - rho): the wage, and the hours response to it at
 * the one elasticity every raise gets (guardrail 7); the income effect is unchanged. The raise is not added to the wage path (it goes when O goes), and
 * the hours measure divides it out (a._lbE0 is set at the bargained wage).
 * Reporting (BG_KEYS, rows with bg only; workers = adults with earnings in the year, years 1 to T-1, weighted by a._w where the row has the tail; Year-0
 * dollars at the basket's price level): bgN worker-years per adult-year (%); bgO the outside-option rise per worker-year; bgR the bargained raise (the
 * wage part, before the hours response); bgE the earnings it adds after the hours response; bgSh the bargained share of the programme's raises to the
 * wage rate (BLEI, octave, CIP, ESP payroll and business payout, bargained; earnings-weighted log shares, %); bgCap worker-years at the markdown cap (%);
 * bgMd the mean markdown (earnings-weighted wage over MRPL, %); bgOP10, bgOP50, bgOP90 the outside-option rise as a share of full-year earnings in the
 * last year (%; the Nash relation's reservation wage is (1 - (1 - pi)/m)/pi of the wage plus this share, bgRw0); bgK the bargained raise over the capital
 * income adults receive (%, rows with rt.ci; who pays is not modelled). */
var BARGAIN = null, BG_DEFAULTS = {m:1/1.21, pi:0}, BGS = null,
  BG_KEYS = ['bgN', 'bgO', 'bgR', 'bgE', 'bgSh', 'bgCap', 'bgMd', 'bgOP10', 'bgOP50', 'bgOP90', 'bgK'];

// index.html line 4771
function bgOpts(v){ var o = Object.assign({}, BG_DEFAULTS, v === true ? {} : v); o.m = +o.m; o.pi = +o.pi;
  if (!(o.m > 0 && o.m <= 1)) throw new Error('bg.m must be above 0 and at most 1'); if (!(o.pi >= 0)) throw new Error('bg.pi must be 0 or more'); return o; }

// index.html line 4773
function bgRaise(O, Ef, B){ return Ef > 0 && O > 0 && B.pi > 0 ? Math.min(B.pi*O/Ef, 1/B.m - 1) : 0; }  /* the year's bargained raise, a share of the wage */

// index.html line 4775
function bgNew(){ return {wy:0, ay:0, O:0, R:0, E:0, cap:0, md:0, mdW:0, lg:0, lgB:0, Kc:0, L:[]}; }

// index.html line 4776
function bgAcc(a, yr, T, E0, g, O, Ef, Rp, Eg, idx){  /* one worker-year (reporting only) */
  var S = BGS, w = a._w !== undefined ? +a._w : 1; S.yIdx = idx; if (yr === T - 1) S.L.push([Ef > 0 ? O/Ef*100 : 0, w]); if (yr < 1) return;
  S.wy += w; S.O += w*O/idx; S.R += w*E0*g/idx; S.E += w*Eg/idx; if (g > 0 && g >= 1/BARGAIN.m - 1 - 1e-12) S.cap += w;
  S.md += w*E0*BARGAIN.m*(1 + g); S.mdW += w*E0; var lr = Math.log(Math.max(1e-12, Rp)) + Math.log(1 + g); if (lr > 0){ S.lg += w*E0*lr; S.lgB += w*E0*Math.log(1 + g); } }

// index.html line 4780
function bgYear(agents, yr, idx){ if (!BGS || yr < 1) return; agents.forEach(function(a){ var w = a._w !== undefined ? +a._w : 1; BGS.ay += w; BGS.Kc += w*(+a.yrCapUSD || 0)/idx; }); }  /* reporting only: adult-years and the capital income adults receive */

// index.html line 4781
function bgQ(L, p){ if (!L.length) return 0; var v = L.slice().sort(function(x, y){ return x[0] - y[0]; }), W = 0, c = 0, i; for (i = 0; i < v.length; i++) W += v[i][1]; for (i = 0; i < v.length; i++){ c += v[i][1]; if (c >= p*W - 1e-12) return v[i][0]; } return v[v.length - 1][0]; }  /* weighted quantile */

// index.html line 4782
function bgRes(out){ var S = BGS, n = S.wy > 0 ? S.wy : 1;
  out.bgN = S.ay > 0 ? S.wy/S.ay*100 : 0; out.bgO = S.O/n; out.bgR = S.R/n; out.bgE = S.E/n; out.bgSh = S.lg > 0 ? S.lgB/S.lg*100 : 0; out.bgCap = S.cap/n*100;
  out.bgMd = S.mdW > 0 ? S.md/S.mdW*100 : BARGAIN.m*100; out.bgOP10 = bgQ(S.L, 0.1); out.bgOP50 = bgQ(S.L, 0.5); out.bgOP90 = bgQ(S.L, 0.9); out.bgK = S.Kc > 0 ? S.R/S.Kc*100 : 0; return out; }

// index.html line 4799
/* Session 5 restudy switches (harness-only; each off by default, so every shipped figure is bit-identical; checked by `unit`).
 *  THETA_GATE  'szh' = index.html: SZH theta (the PTF conversion bonus add-on, the PTF induction boost and the BLEI term)
 *              is read off the SZH zone-coherence slider. 'density' = the framework's gate (claims ledger C08, dashboard
 *              d12): theta is read off the population's realised PTF share at the start of each year, through the same
 *              szhTheta() curve (55% threshold, full at 90%, cap 0.25). THETA_DENS holds the latest share for agentBLEI().
 *  PTH_MODE    'basket' = index.html: PTH cuts the whole (post-PTF) basket by 35%, which is 127% of MIT's housing
 *              component. 'housing' (d4): PTH cuts the housing component by PTH_HOUSING_CUT (the same 35% rate, applied
 *              to what PTH provides). Under shipped PTF the housing component has already been cut by PTF's rate.
 *  DISC_BASE   'basket' = index.html: PTF, PTH and CCO relief discount the whole basket. 'pretax' (d5): they skip the
 *              basket's income and payroll tax share (17.97% at year-0 prices), which no price cut reduces.
 * With PTH_MODE or DISC_BASE changed, the PTH saving that funds equity routing is PTH's own cut on the agent's post-relief
 * basket (identical to index.html's cf/0.65 formula in the engine model; in the framework model BU purchases are not a
 * price cut, so the saving is PTH's cut before them). BLEI keeps its own daily-cost anchor (dual-anchor table, v4.14),
 * so PTH_MODE and DISC_BASE act on the wealth loop only. */
var THETA_GATE = 'szh', PTH_MODE = 'basket', DISC_BASE = 'basket', THETA_DENS = null, PTH_HOUSING_CUT = 0.35;

// index.html line 4800
function setRestudy(o){ var old = {THETA_GATE:THETA_GATE, PTH_MODE:PTH_MODE, DISC_BASE:DISC_BASE};
  if (o){ if (o.THETA_GATE) THETA_GATE = o.THETA_GATE; if (o.PTH_MODE) PTH_MODE = o.PTH_MODE; if (o.DISC_BASE) DISC_BASE = o.DISC_BASE; }
  return old; }

// index.html line 4821
/* ─── Session 6 (A4): the policy testbed (harness-only; dashboard s11, decisions d24–d29). TB = null (the default) or an unset
 * p.tb leaves every run bit-identical (checked by `unit`). When TB is an object AND p.tb is set, runYear() adds:
 *  - Programs (p.tb): ubi (cash to every adult, year-0 $/yr), xc {amt, delta} (X-Cents adult exchange; delta 1 = the
 *    community-work variant's hours displace wage time one for one, the d14 bracket), nit {G, t} (benefit max(0, G - t x wage
 *    earnings)), groc {cut, cover} (public grocery: a cut on the food component for covered adults), endow {amt, thresh}
 *    (one-time endowment in year 0 to adults whose year-0 wealth is below thresh). Cash amounts follow the same COLA rule as BU
 *    (the preset's cola flag; colaF).
 *  - One income effect for every unconditional dollar (the plan's fairness rule; d25): with LABOR on, earnings fall by rho per
 *    dollar of cash transfer, NIT guarantee (virtual income), endowment annuity value (amt / years), contribution virtual income,
 *    and (TB.inkindRho, default true) every price-cut dollar (PTF, PTH, public grocery) and last year's PTH liquid appreciation.
 *    Session 4's module applied rho to cash and BU only.
 *  - One elasticity for every change in the return to work: earnings scale by (1 - t)^(eps - rho) for adults in the NIT phase-out
 *    and by (1 - tau)^(eps - rho) for adults above the contribution threshold, the same exponent the module applies to raises.
 *  - Financing (TB.fin; d26): 'tax' = a contribution tau on wage earnings above TB.X, set each year to last year's program cost /
 *    last year's base (year 0 from a pre-pass of year 0), capped at tauMax, with the treasury reported; 'money' = the program's
 *    cost is created money, counted in the price module by one rule for every design (d24); 'none' = unfinanced (sessions 2-5).
 *  - A uniform cost ledger (TB.cur, per year) and basket FGT0-2 on income including transfers, less the contribution, plus the
 *    endowment's annuity value, against the agent's own cost (gross basket less in-kind cuts). */
var TB = null;

// index.html line 4827
/* Audit V5-02 (v5.1; Oct 3, 2026). In framework mode the BLEI gate on the wage-growth bonus (agentBLEI, and tbGate in the testbed) reads a._fwBUm, the BU an
 * agent spends on essentials. runYear used to call the gate before writing this year's _fwBUm, so from year 1 the gate read last year's value (the stale value
 * differed from the current one in about 73% of framework agent-years). GATE_CURRENT = true writes the same value first, with the same expression the engine
 * assigns later (checked equal in every agent-year by the unit suite), so the gate reads this year's spend. false (the default) is bit-identical to v5.0. A
 * testbed row sets it with c.gc (n1Row option gc); v5.1's release row turns it on (REL_V5). No random draw is added or moved. */
var GATE_CURRENT = false;

// index.html line 4828
var TB_DEFAULTS = {fin:'tax', aT:0, eP:0, tauMax:0.9, X:0, inkindRho:true, neutralGate:true, rep52:false, giniNN1:false};  /* v5.2 step 2: rep52 (the Year 7 and federal-poverty-line reporting) and giniNN1 (the n/(n - 1) Gini correction), reporting only, off by default */

// index.html line 4837
/* S68 (Nov 14, 2026; Nov 13 audit, finding 1): THE FINANCING IDENTITY, AND THE FLAT CONTRIBUTION'S GAP (row option fx: {fin: ...}; not part of fx: true).
 * Each year, for every financing reading: the programme's payout at face value under the reading's timing = taxes raised + new money for the payout (U less
 * `extra`, the floor's unmatched part and the wage bonus, new money in every reading) + output that matches or backs it + the stated unpaid part - the surplus
 * raised beyond the payout. The unpaid part is need - tax where a capped contribution pays need (flat 'tax', 'hybrid', 'source'; 'tax' with a taxBase
 * already makes it new money), and the transfers and price cuts under 'none' (its definition). fx.fin 'report': keys only, no figure moves; 'money': the
 * gap of flat 'tax', 'hybrid' and 'source' is new money, as for taxBase 'prog' and 'land'; 'debt': S72 (refused until built). The check (ACCT id 'fin')
 * runs with ACCT on; no figure depends on it. Keys (FIN_KEYS, only with fx.fin): per adult-year in year-0 dollars, finGapSh % of payout, finCapYrs the
 * years the flat rate sat at its cap. No RNG. */
var FIN_KEYS = ['finPay', 'finTax', 'finMoney', 'finMatch', 'finGap', 'finSur', 'finGapM', 'finGapSh', 'finCapYrs'];

// index.html line 4838
function finStep(L, o, C, A, need, U, extra, gRun, bkP, bkU, T, tauUsed){
  var F = FX && FX.fin, cuts = (1 - o.eP)*(C.cutPT - C.cutFree + C.cutG), taxed = o.fin === 'tax' || o.fin === 'hybrid' || o.fin === 'source', gp = 0, sr = 0, gm = 0, P, M, B, G;
  if (F && F !== 'report' && F !== 'money' && F !== 'debt' && F !== 'cap') throw new Error('fx.fin: unknown reading ' + F);
  if ((F === 'debt' || F === 'cap') && (!GOV || !taxed || o.taxBase)) throw new Error("fx.fin '" + F + "' needs gv (the government account, S72) and a contribution that pays need without a taxBase (the progressive and land taxes already make their unpaid part new money)");
  if (taxed){ gp = Math.max(0, need - C.tax); sr = Math.max(0, C.tax - need); }
  if ((F === 'money' || F === 'cap') && (o.fin === 'hybrid' || o.fin === 'source' || (o.fin === 'tax' && !o.taxBase))){ gm = gp; U += gp; }  /* S72: 'cap' (a higher rate cap) makes what the higher cap cannot raise new money; 'debt' leaves it to the government account (gvStep), which borrows it */
  if (o.fin === 'tax' && o.taxBase) gm = gp;  /* already new money (v5.2 step 7) */
  M = U - extra;
  if (o.fin === 'tax'){ P = need; B = 0; G = gp - gm; }
  else if (o.fin === 'hybrid'){ P = need + C.conv; B = o.a*(C.conv - C.convM) + C.convM; G = gp - gm; }
  else if (o.fin === 'source'){ var cvS = gRun ? C.conv - C.pjg + L.pjg/(T - 1) : C.conv; P = need + C.bu + cvS; B = bkP - bkU + C.convM + (o.faceM ? C.bu : 0); G = gp - gm; }
  else { P = C.cash + C.endow + C.cap + C.bu + cuts + C.conv + C.pthLiq;
    if (o.fin === 'money'){ B = o.aT*(C.cash + C.endow + C.cap) + (o.buAtA ? o.a : o.aT)*C.bu + o.a*(C.conv - C.convM) + C.convM + (o.pthUnmatched ? 0 : C.pthLiq); G = 0; }
    else { B = o.a*A.conv; G = C.cash + C.endow + C.cap + C.bu + cuts + (C.conv - A.conv) + (o.pthUnmatched ? C.pthLiq - A.pthLiq : C.pthLiq); } }
  var Tx = taxed ? C.tax : 0;
  if (ACCT) acctChk('fin', L.yr, P - Tx - M - B - G + sr, Math.abs(P) + Math.abs(Tx) + Math.abs(M) + Math.abs(B) + Math.abs(G), o.fin);
  if (F){ var Q = L.fi || (L.fi = {P:0, T:0, M:0, B:0, G:0, S:0, GM:0, cap:0}), i = C.idx || 1;
    Q.P += P/i; Q.T += Tx/i; Q.M += M/i; Q.B += B/i; Q.G += (taxed ? gp : G)/i; Q.S += sr/i; Q.GM += gm/i; if (o.fin === 'tax' && !o.taxBase && tauUsed >= (TB.capE !== undefined ? TB.capE : o.tauMax) - 1e-12) Q.cap++;
    if (F === 'debt') Q.GB = (Q.GB || 0) + gp/i; }  /* S72: the part borrowed */
  return U; }

// index.html line 4858
function finRes(r, Q, NY){ Q = Q || {P:0, T:0, M:0, B:0, G:0, S:0, GM:0, cap:0};
  r.finPay = Q.P/NY; r.finTax = Q.T/NY; r.finMoney = Q.M/NY; r.finMatch = Q.B/NY; r.finGap = Q.G/NY; r.finSur = Q.S/NY; r.finGapM = Q.GM/NY;
  r.finGapSh = Q.P > 0 ? (Q.G - Q.GM - (Q.GB || 0))/Q.P*100 : 0; r.finCapYrs = Q.cap; return r; }

// index.html line 4883
/* S72 (Nov 14, 2026; research-update prereg/2026-11-s72-government-budget.md; dev/reports/s72-government-budget.md): THE GOVERNMENT ACCOUNT (row option gv,
 * switch GOV; off, nothing below is read and no figure moves). Each year, in the year's dollars: the payout the government finances (need: what a
 * contribution is meant to pay; under the Source the Source's own payout stays new money and backed output, FIN_KEYS), the contribution raised (C.tax),
 * interest on programme debt, the deficit (need + interest - contribution) and how it is met: new money (fx.fin 'money' or 'cap', and taxBase rows),
 * borrowing (fx.fin 'debt'), unpaid (otherwise), less a surplus. Identity (ACCT id 'gov'): need + interest - tax = money + borrowing + unpaid - surplus.
 * Rates (fx.fin 'debt'): r 'fixed' (main) pays the real rate rr (FRED DFII10 mean, as SAVE_DEFAULTS) plus a premium dk x (programme debt / GDP per adult)
 * (Laubach 2003: about 4 basis points per point of debt to GDP), so the debt keeps its real value; r 'rule' sets the year's nominal rate from last year,
 * max(0, rs + pi + a(pi - pt) + b gap) plus the premium (Taylor 1993's weights as the Federal Reserve writes the rule; gap: the log of the environment's
 * recession income multiplier, 0 in calm years; Claude's reading: hours chosen in response to the programme move potential output, so they are not a
 * gap), and this year's inflation erodes it. ip 'tax' (main): next year's contribution targets sh x need plus this year's interest, up to the cap;
 * 'borrow': interest is borrowed. Interest goes to bondholders outside the modelled incomes (a cautious modelling assumption). fx.fin 'cap': the rate cap
 * is capHi; what it cannot raise is new money. The frontier (flat contribution): sh, the share of need the rate is set to raise; base 'w' wages (today),
 * 'wc' wages plus conversion proceeds, 'all' the engine's money income (tbCashIncome); the parts other than wages are charged on last year's amounts,
 * unindexed, and enter the labour response as an income effect only (rule 7). wb (default on with gv; found by the build): the contribution's books (its
 * base and what it raised) count each adult at its weight a._w, so that with the weighted tail (wt) the tail's few adults, who stand for very few people,
 * do not carry a third of the wage base and nearly all capital income; without wt every weight is 1 and nothing moves. The payout, prices and every
 * decision stay unweighted (S59's rule). Reporting: today's debt per adult (GV_US.D0, debt held by the public at
 * Sept 30, 2025 over adults; sources/s72_government.py), its fixed-coupon share fc eroded at each year's inflation, with no repricing (gvEr, an upper
 * bound) and with 1/m of it repricing a year (gvErM; m a design parameter). Debt ratios use GDP per adult of fiscal 2025 (Y0), held fixed in real
 * terms (the model has no GDP). Keys GV_KEYS (with gv only): per adult-year in year-0 dollars unless stated; gvDebt programme debt per adult at the
 * last year; gvDebtY, gvDebtY15 it as % of GDP per adult at the last year and five years before; gvRate, gvRReal mean nominal and real rate (%);
 * gvIntSh interest over the payout (%); gvShR the contribution over the payout (%); gvCapYrs years at the effective cap; gvY100 the first year programme debt passed 100% of GDP per adult (T + 1: never); gvGuard the years the rate sat at its numerical guard. No RNG. */
var GOV = null, GVS = null, GV_DEFAULTS = {sh:1, base:'w', r:'fixed', rr:0.0097, dk:0.04, a:0.5, b:0.5, rs:0.0097, pt:0.02, ip:'tax', capHi:0.99, m:6, wb:true},
  GV_US = {D0:113410, Y0:113579, fc:0.697},
  GV_KEYS = ['gvPay', 'gvTax', 'gvInt', 'gvDef', 'gvMon', 'gvBor', 'gvUnp', 'gvSur', 'gvDebt', 'gvDebtY', 'gvDebtY15', 'gvIntSh', 'gvRate', 'gvRReal', 'gvEr', 'gvErM', 'gvShR', 'gvCapYrs', 'gvY100', 'gvGuard'];

// index.html line 4886
function gvOpts(v){ var o = Object.assign({}, GV_DEFAULTS, v === true ? {} : v);
  if (['w', 'wc', 'all'].indexOf(o.base) < 0) throw new Error("gv.base must be 'w', 'wc' or 'all'"); if (o.r !== 'fixed' && o.r !== 'rule') throw new Error("gv.r must be 'fixed' or 'rule'");
  if (o.ip !== 'tax' && o.ip !== 'borrow') throw new Error("gv.ip must be 'tax' or 'borrow'"); if (!(o.sh >= 0 && o.sh <= 1)) throw new Error('gv.sh must be in [0, 1]');
  if (!(o.capHi > 0 && o.capHi < 1)) throw new Error('gv.capHi must be in (0, 1)'); if (!(o.m >= 1)) throw new Error('gv.m must be at least 1'); return o; }

// index.html line 4890
function gvNew(){ return {D:0, int:0, piP:0, gapP:0, ixP:null, ratio:0, r15:0, y100:0, gd:0, fix:GV_US.D0*GV_US.fc, fixM:GV_US.D0*GV_US.fc, cap:0,
  A:{pay:0, tax:0, int:0, def:0, mon:0, bor:0, unp:0, sur:0, er:0, erM:0, rate:0, rr:0, ny:0}}; }

// index.html line 4892
function gvIdx(agents){ var a = agents[0]; return a && a.yrBasketUSD > 0 ? a.yrBasketUSD/CFG.LIVING_WAGE_ANNUAL/(a._hhF || 1) : 1; }  /* the price level (as tbAccount's C.idx), read in both runs */

// index.html line 4893
function gvStep(S, o, C, need, agents, yr, T, mult, tauUsed){
  var G = GOV, F = FX && FX.fin, taxed = o.fin === 'tax' || o.fin === 'hybrid' || o.fin === 'source', ix = gvIdx(agents), n = Math.max(1, agents.length);
  if (!taxed && need > 0) throw new Error("gv: the government account reads a contribution's need ('tax', 'hybrid' or 'source')");
  var pi = S.ixP === null ? 0 : ix/S.ixP - 1, prem = G.dk*S.ratio, Dp = S.D, tx = taxed ? C.tax : 0;
  var i = F !== 'debt' ? 0 : G.r === 'fixed' ? (1 + G.rr + prem)*(1 + pi) - 1 : Math.max(0, G.rs + S.piP + G.a*(S.piP - G.pt) + G.b*S.gapP) + prem;
  if (i > 1){ i = 1; S.gd++; }  /* a numerical guard, not a reading: the rate is held at 100% a year (reached only when the premium has made the debt many times GDP; gvGuard counts the years) */
  var it = i*Dp, def = need + it - tx, gp = Math.max(0, need - tx), sr = Math.max(0, tx - need), mon = 0, bor = 0, unp = 0, sur = 0;
  if (F === 'debt'){ bor = Math.max(def, -Dp); sur = Math.max(0, -def - Dp); }
  else { mon = (F === 'money' || F === 'cap' || (o.fin === 'tax' && o.taxBase)) ? gp : 0; unp = gp - mon; sur = sr; }
  if (ACCT) acctChk('gov', yr, need + it - tx - mon - bor - unp + sur, Math.abs(need) + Math.abs(it) + Math.abs(tx) + Math.abs(bor), F || 'none');
  S.D = Dp + bor; S.int = it; S.piP = pi; S.gapP = Math.log(mult > 0 ? mult : 1); S.ixP = ix; S.ratio = Math.max(0, S.D/ix/n/GV_US.Y0); if (yr === T - 6) S.r15 = S.ratio; if (!S.y100 && S.ratio > 1) S.y100 = yr + 1;
  var A = S.A; A.pay += need/ix; A.tax += tx/ix; A.int += it/ix; A.def += def/ix; A.mon += mon/ix; A.bor += bor/ix; A.unp += unp/ix; A.sur += sur/ix;
  if (F === 'debt'){ A.rate += i; A.rr += (1 + i)/(1 + pi) - 1; A.ny++; }
  var er = S.fix*pi/(1 + pi), erM = S.fixM*pi/(1 + pi); S.fix /= 1 + pi; S.fixM *= (1 - 1/G.m)/(1 + pi); A.er += er; A.erM += erM;  /* per adult, year-0 dollars */
  if (o.fin === 'tax' && !o.taxBase && need > 0 && tauUsed >= (TB.capE !== undefined ? TB.capE : o.tauMax) - 1e-12) S.cap++; }

// index.html line 4908
function gvTarget(need){ return GOV.sh*need + (GOV.ip === 'tax' && FX && FX.fin === 'debt' && GVS ? GVS.int : 0); }  /* what next year's rate is set to raise */

// index.html line 4909
function gvRes(r, S, NY, T){ var A = S.A;
  r.gvPay = A.pay/NY; r.gvTax = A.tax/NY; r.gvInt = A.int/NY; r.gvDef = A.def/NY; r.gvMon = A.mon/NY; r.gvBor = A.bor/NY; r.gvUnp = A.unp/NY; r.gvSur = A.sur/NY;
  r.gvDebt = S.ratio*GV_US.Y0; r.gvDebtY = S.ratio*100; r.gvDebtY15 = S.r15*100; r.gvIntSh = A.pay > 0 ? A.int/A.pay*100 : 0; r.gvShR = A.pay > 0 ? A.tax/A.pay*100 : 0;
  r.gvRate = A.ny ? A.rate/A.ny*100 : 0; r.gvRReal = A.ny ? A.rr/A.ny*100 : 0; r.gvEr = A.er/T; r.gvErM = A.erM/T; r.gvCapYrs = S.cap; r.gvY100 = S.y100 || T + 1; r.gvGuard = S.gd; return r; }

// index.html line 4917
/* S68 (Nov 14, 2026; Nov 13 audit, finding 4): COSTS AT THE WITHIN-YEAR PRICE LEVEL (study or row option o.wy; reporting only). Each adult-year's cost of
 * living and its reference (mlc) times the year's within-year average price level over its opening level, exp(avg) from the capacity rule's record (1 when
 * the year is not split, q = 1, or the rule is off); basket poverty and its depth recounted (WY_KEYS). Incomes are the year's nominal dollars, paid through
 * the year; wages are indexed once a year. The general level stands for every item (a modelling assumption). No figure reads it; no RNG. */
var WYS = null, WY_KEYS = ['wyF0PY', 'wyF1PY', 'wyF2PY', 'wyAvg'];

// index.html line 4918
function wyYear(W, f){ for (var j = 0; j < W.cur.length; j += 3){ var g = Math.max(0, W.cur[j]*f - W.cur[j + 1])/(W.cur[j + 2]*f); W.f0 += g > 0 ? 1 : 0; W.f1 += g; W.f2 += g*g; W.n++; }
  W.cur = []; W.fs += f; W.ny++; }

// index.html line 4920
function wyRes(r, W){ var n = Math.max(1, W.n); r.wyF0PY = W.f0/n*100; r.wyF1PY = W.f1/n*100; r.wyF2PY = W.f2/n*100; r.wyAvg = W.ny ? W.fs/W.ny : 1; return r; }

// index.html line 4921
function tbNewAcc(){ return {pjg:0, n:0, cash:0, endow:0, bu:0, conv:0, convM:0, buIss:0, ctax:0, cutFree:0, cutPT:0, cutG:0, cap:0, pthLiq:0, tax:0, base:0, E:0, f0:0, f1:0, f2:0, idx:1, pd:0, tgt:0, emp:0, hrs:0, bR:0, bP:0,
  bz:0, es:0, n1:0, nP1:0, nN1:0, pyP:0, pyN:0, nWP1:0, esWP:0}; }  /* session 19 (s38): business premium and ESP payroll by group, years 1-19 (reporting only) */

// index.html line 4923
function tbYear(p, colaF){
  var s = p.tb;
  TB.cur = tbNewAcc();
  return {ubi:(s.ubi || 0)*colaF, xc:(s.xc ? s.xc.amt : 0)*colaF, xd:s.xc ? (s.xc.delta || 0) : 0, G:s.nit ? s.nit.G*colaF : 0, t:s.nit ? s.nit.t : 0,
    tau:TB.tau || 0, X:(TB.X || 0)*(TB.xIdx || 1), tb:TB.tb, xi:TB.tb === 'prog' ? (TB.pxi || 1) : (TB.xIdx || 1), cap:TB.tauMax || 0.9, W:s.endow ? s.endow.amt : 0, T:p.years, gcap:s.groc ? (s.groc.cap || 0) : 0, gcov:s.groc ? s.groc.cover : 0, Gp:!!(s.nit && s.nit.part),
    nw:!!(GOV && GOV.base !== 'w' && !TB.tb)};  /* S72: the flat contribution also charges last year's money income other than wages (gv.base 'wc' | 'all') */
}

// index.html line 4933
/* d28: the BLEI gate on the engine's wage-growth bonus, read the same way for every design: Baseline rules (gamma 0.12, the base
 * daily cost, no SZH term) plus one month of the design's regular support, BU (the credit agentBLEI gives participants) or cash
 * (UBI, X-Cents, the NIT benefit on last year's earnings). agentBLEI itself, and every BLEI figure reported, are unchanged. */
function tbGate(a, p, buEff, y){
  var Ep = a.yrWageUSD !== undefined ? a.yrWageUSD : a.wage*12*CFG.WAGE_TO_USD, Bx = (y.G > 0 && (!y.Gp || a.inCCO)) ? (y.t > 0 ? Math.max(0, y.G - y.t*Ep) : y.G) : 0;  /* the NIT benefit expected on last year's earnings; session 11: a participant-only top-up (Gp) reaches participants only */
  var m = (y.ubi + y.xc + Bx)/12;
  if (p.ccoOn && a.inCCO && buEff > 0) m += (CONVERSION_MODEL === 'framework' && a._fwBUm !== undefined) ? a._fwBUm : buEff*(990/1200);
  a._tbM = m;  /* session 7: kept for the design-neutral BLEI poverty figure (d28) */
  return agentBLEI(a, 0, false, false, false, 0, false) + m/CFG.BASE_DAILY_COST;
}

// index.html line 4940
function tbNitElig(y, E0){ return y.G > 0 && (y.t <= 0 || E0 < y.G/y.t); }

// index.html line 4943
/* Labor terms for one agent-year: F multiplies earnings (net-of-rate factors), V is extra unconditional dollars (x rho), D is
 * time displaced from wage work. Eligibility for the phase-out and the contribution is read on earnings before the response. */
function tbLab(a, y, E0, cutUSD){
  var ex = LABOR.eps - LABOR.rho, F = 1, el = tbNitElig(y, E0) && (!y.Gp || a.inCCO), tx = y.tau > 0 && E0 > y.X;
  var V = y.ubi + y.xc*(1 - y.xd) + (el ? y.G : 0), D = y.xc*y.xd;  /* cash first, so an NIT at t = 0 is bit-identical to a UBI */
  if (a._tbEl) V += y.W/y.T;
  var O = V;  /* S60: the programme's unconditional dollars so far (cash, guarantee, endowment); BARGAIN's outside option reads it, nothing else does */
  if (y.tb === 'prog'){ if (y.tau > 0){ var ft = fedTax(E0, y.xi, y.tau, y.cap); if (ft.m > 0) F *= Math.pow(1 - ft.m, ex); V += ft.m*E0 - ft.tax; } }  /* v5.2 step 7: the marginal rate, and the virtual income of the schedule linearised at E0 (for a flat rate above X this is tau x X, as below) */
  else if (y.tb === 'land'){ if (y.tau > 0) V -= y.tau*Math.max(0, a.yrWealthStartUSD || 0); }  /* v5.2 step 7: a tax on what is owned, not on work: an income effect only (one income effect per unconditional dollar, rule 7) */
  else if (tx){ F *= Math.pow(1 - y.tau, ex); V += y.tau*y.X; }
  if (y.nw && y.tau > 0) V -= y.tau*(a._gvNW || 0);  /* S72: the contribution on last year's other money income is an income effect only (rule 7) */
  if (el) F *= Math.pow(1 - y.t, ex);
  if (SNET && SNS && a._snB !== undefined){ F *= Math.pow(1 - a._snM, ex); V += a._snB + a._snM*E0; }  /* session 2b: today's safety net, its marginal rate (one elasticity) and its dollars linearised at last year's position (one income effect) */
  if (TB.inkindRho){ V += cutUSD + (a._tbPthPrev || 0); O += cutUSD + (a._tbPthPrev || 0); }
  return {F:F, V:V, D:D, O:O};
}

// index.html line 4957
function tbCashFlow(a, y, E, yr){
  var B = (y.G > 0 && (!y.Gp || a.inCCO)) ? (y.t > 0 ? Math.max(0, y.G - y.t*E) : y.G) : 0, cash = y.ubi + y.xc + B, tax = y.tau > 0 ? (y.tb === 'prog' ? fedTax(E, y.xi, y.tau, y.cap).tax : y.tb === 'land' ? y.tau*Math.max(0, a.yrWealthStartUSD || 0) : y.tau*Math.max(0, E - y.X)) : 0;  /* v5.2 step 7: tb 'prog' | 'land' */
  if (SNET && SNS && a._snB) cash += a._snB;  /* session 2b: today's safety net, paid as cash (kept out of programme cost in tbAccount) */
  if (y.nw && y.tau > 0) tax += y.tau*(a._gvNW || 0);  /* S72 (gv.base 'wc' | 'all') */
  a.yrTbCash = cash; a.yrTax = tax; a._tbNit = B;
  return {net:cash - tax, endow:(yr === 0 && a._tbEl) ? y.W : 0};
}

// index.html line 4977
/* Session 21 (s41; dashboard i10-1, decision d82): BLEI by group beside FGT2. Reporting only: no RNG, no state the model reads.
 * Three readings of an adult's BLEI (days of basic living the adult could cover), each deflated to year-0 prices like the
 * testbed's other lines (o.lines):
 *  N  design-neutral (d34): Baseline rules (gamma 0.12, the base daily cost, no SZH term) plus one month of the design's regular
 *     support (a._tbM, the d28 gate's measure). Heads the tables.
 *  O  the design's own BLEI (agentBLEI with the scenario's settings; the page's and the shipped definition).
 *  X  N with income read as this year's wage earnings net of the testbed's contribution (after any change in hours), in place of
 *     the gross monthly wage rate. agentBLEI reads the wage rate, so the contribution and the hours response reach N and O only
 *     through savings (20% of wealth); X shows what they do to the income term. Same function, same 0.1-unit wage floor.
 * Groups: all adults; participants (a._tbPart); adults who chose not to take part (!a._tbPart); the same adults in every design.
 * Measures per reading and group: person-year share below the BLEI poverty line (30 days; Crisis + Precarious) over 20 years,
 * person-year share in Crisis (below 7 days), the year-20 share below 30 days, and the year-20 median in days. The year-20 'all'
 * values of N and O equal the testbed's nbleiPov and bleiPov (checked by tbBleiUnitSuite). */
var TB_BLEI_DEFS = ['N', 'O', 'X'], TB_BLEI_GRPS = ['A', 'P', 'N'], TB_BLEI_NET = {wealth:0, wage:1};

// index.html line 4979
/* Accumulators, flat for speed: index d*3 + g (d: N, O, X; g: all, participants, non-participants). */
function tbBleiAcc(){ var r = {py:new Float64Array(9), pov:new Float64Array(9), cri:new Float64Array(9), pov20:new Float64Array(9), n20:new Float64Array(9), v20:[], y20:new Float64Array(3)};  /* y20: S47 */
  for (var i = 0; i < 9; i++) r.v20.push([]); return r; }

// index.html line 4981
function tbBleiNet(a){ var q = TB_BLEI_NET; q.wealth = a.wealth; q._hhD = a._hhD;  /* v5.3 B3 */ q.wage = Math.max(0, (+a.yrWageUSD || 0) - (+a.yrTax || 0))/12/CFG.WAGE_TO_USD; return q; }

// index.html line 4982
function tbBleiYear(BG, agents, p, o, last, y20){
  var lf = o.lines === 'nominal' ? 1 : agents[0].yrBasketUSD/CFG.LIVING_WAGE_ANNUAL/(agents[0]._hhF || 1), L30 = CFG.BLEI_PRECARIOUS_MAX, L7 = CFG.BLEI_CRISIS_MAX, v = [0, 0, 0];
  for (var i = 0; i < agents.length; i++){ var a = agents[i], m = (a._tbM || 0)/CFG.BASE_DAILY_COST, g2 = a._tbPart ? 1 : 2;
    v[0] = (agentBLEI(a, 0, false, false, false, 0, false) + m)/lf; v[1] = agentBLEI(a, p.bu, p.ccoOn, p.pth, p.szh, p.szhCoh, p.ptf)/lf;
    v[2] = (agentBLEI(tbBleiNet(a), 0, false, false, false, 0, false) + m)/lf;
    for (var d = 0; d < 3; d++){ var x = v[d], j0 = d*3, j1 = j0 + g2;
      BG.py[j0]++; BG.py[j1]++; if (x < L30){ BG.pov[j0]++; BG.pov[j1]++; } if (x < L7){ BG.cri[j0]++; BG.cri[j1]++; }
      if (last){ BG.n20[j0]++; BG.n20[j1]++; if (x < L30){ BG.pov20[j0]++; BG.pov20[j1]++; } BG.v20[j0].push(x); BG.v20[j1].push(x); } }
    if (y20){ BG.y20[2]++; if (v[0] < L30) BG.y20[0]++; if (v[1] < L30) BG.y20[1]++; }  /* S47: all adults at year 20 (index 19), whatever the run's length */
  }
}

// index.html line 4993
function tbBleiRes(BG, R){
  TB_BLEI_DEFS.forEach(function(d, di){ TB_BLEI_GRPS.forEach(function(g, gi){ var j = di*3 + gi, k = 'b' + d + g;
    R[k + 'Py'] = BG.py[j] ? BG.pov[j]/BG.py[j]*100 : 0; R[k + 'Cr'] = BG.py[j] ? BG.cri[j]/BG.py[j]*100 : 0; R[k + '20'] = BG.n20[j] ? BG.pov20[j]/BG.n20[j]*100 : 0; R[k + 'Md'] = medianOf(BG.v20[j]); }); });
  R.bNAy20 = BG.y20[2] ? BG.y20[0]/BG.y20[2]*100 : 0; R.bOAy20 = BG.y20[2] ? BG.y20[1]/BG.y20[2]*100 : 0;  /* S47 */
  return R;
}

// index.html line 5013
/* v5.2 round, step 2 (Oct 3, 2026; Duke's answers d148 and d149; dev/DECISIONS.md, Session 35). Reporting only: no random draw and no state any rule reads. With the testbed
 * option rep52 (off by default, so every earlier figure and table is unchanged) a run also records:
 *  - the share of adults below the US official poverty line (CFG.POVERTY_THRESHOLD_ONE, one person under 65, 2025 dollars), indexed each year to the model's price level
 *    the way the Census indexes its thresholds to prices: "fpl" on the official measure's own income (money income before tax: wage earnings, conversion proceeds and
 *    cash transfers; the BU, like food stamps in the official measure, are not money income), and "fplX" on resources closer to the Census Supplemental Poverty Measure
 *    (disposable income after the contribution plus the value of the BU and the price cuts, a._tbExt), still against the official threshold;
 *  - each measure at Year 7 (year index 6, the Research Hub's date for its targets) and at the run's last year: those two poverty-line shares, the shares below the cost of
 *    living, below 30 days of basic living (BLEI, the BLEI paper's own reading and the design-neutral one) and with too little wealth, the unhoused share, and four Ginis:
 *    disposable income (giniD), income counting the value of price cuts (giniX), wealth with debts counted as zero (giniW, the convention of the income Ginis and of the
 *    BLEI paper's wealth Gini) and wealth with debts kept (giniWN, the Survey of Consumer Finances convention; it can exceed 1);
 *  - the same shares on fixed-dollar lines ("Nom": the wealth line, the 30-day BLEI line and the poverty threshold not moved with prices), to show what the price indexing
 *    of the lines does; the main readings move with the price level (decision D2, session 2);
 *  - person-year shares over the run for the poverty-line measures and the fixed-dollar BLEI readings.
 * giniNN1 multiplies every Gini of the run by n/(n - 1), which removes the sample Gini's downward bias with n adults (0.2% at 500); off, every Gini is as before. */
var TB_REP_SNAP = ['fpl', 'fplX', 'fplNom', 'f0', 'bO', 'bN', 'bONom', 'bNNom', 'pov', 'povNom', 'ep', 'giniD', 'giniX', 'giniW', 'giniWN'];

// index.html line 5020
/* v5.2 step 5: the year-0 snapshot ('y0', the calibration year, for the check against US data) and poverty spells from each adult's year-by-year history, on the
 * official line ('sf') and the cost of living ('sc'): spells that begin after an adult's first year (spells already under way when the record starts are left
 * out, as in Bane and Ellwood 1986 and Stevens 1994), N_d = spells observed at duration d (d years poor and the next year observed), X_d = those that end there
 * (the next year is above the line), d = 1..4 and 5 = 5 or more; RN = years just after an exit with the following year observed, R = those poor again then
 * (the re-entry rate after one year out). Counts are summed over the run; ratios are taken after summing over seeds. everFpl: % of adults below the official
 * line at least once. */
var TB_REP_SPELL = ['sf', 'sc'].reduce(function(r, m){ [1, 2, 3, 4, 5].forEach(function(d){ r.push(m + 'N' + d, m + 'X' + d); }); r.push(m + 'RN', m + 'R'); return r; }, []);

// index.html line 5024
/* v5.2 step 8: the year-by-year path for the page's small charts (reporting only): each year's share of adults below the cost of living (f0), with too little
 * wealth (pov), below 30 days of basic living (bO; the BLEI paper's reading), the median savings in today's dollars (medW), what a month of the BU buys in
 * today's dollars (buR; 0 with no programme), and what a month of the median wage buys in today's dollars (wageR; working adults). Keys p<measure>_<year>. */
var TB_PATH_M = ['f0', 'pov', 'bO', 'medW', 'buR', 'wageR'], TB_PATH_N = 40;

// index.html line 5029
/* S35 (Oct 30, 2026; research-update prereg/2026-11-study-program.md, before the first run, item 2): reporting only, no draw, nothing any rule reads. The
 * price level at the end of each year to year 40 (plv_<year>; the same value as pLev10 and pLev20 at years 10 and the last; 0 past the run), and the share
 * of families with net worth below zero at year 20 and year 40 (hhDebt20, hhDebt40; 0 if the run is shorter): a family is a household where households are
 * on, an adult otherwise; its net worth is its adults' wealth together. */
var TB_PLV_KEYS = Array.from({length:40}, function(_, t){ return 'plv_' + t; });

// index.html line 5030
var TB_PROG_KEYS = TB_PLV_KEYS.concat(['hhDebt20', 'hhDebt40', 'bNAy20', 'bOAy20']);

// index.html line 5034
/* S47 (Nov 6, 2026; research-update prereg/2026-11-study-program.md, Amendment 9 / S35 report item 3; reporting only, no draw): bNAy20 and bOAy20, the share of
 * all adults below 30 days of basic living at year 20 (year index 19) on the design-neutral (N) and the design's own (O) BLEI, in a run of any length (0 if it is
 * shorter than 20 years). In a 20-year run they equal bNA20 and bOA20; in a 40-year run they give the year-20 reading bNA20 cannot (it is the last year's). */
function tbDebtShare(agents){ var n = 0, k = 0;
  if (HHS && HHS.list) HHS.list.forEach(function(H){ if (!H.a.length) return; var w = 0; H.a.forEach(function(a){ w += a.wealth; }); n++; if (w < 0) k++; });
  else agents.forEach(function(a){ n++; if (a.wealth < 0) k++; });
  return n ? k/n*100 : 0; }

// index.html line 5038
var TB_PATH_KEYS = TB_PATH_M.reduce(function(r, m){ for (var t = 0; t < TB_PATH_N; t++) r.push('p' + m + '_' + t); return r; }, []);

// index.html line 5039
var TB_REP_KEYS = ['fplPY', 'fplXPY', 'fplNomPY', 'bOAPyNom', 'bNAPyNom'].concat(TB_REP_SNAP.map(function(k){ return 'y7' + k.charAt(0).toUpperCase() + k.slice(1); }), TB_REP_SNAP.map(function(k){ return 'e' + k.charAt(0).toUpperCase() + k.slice(1); }),
  TB_REP_SNAP.map(function(k){ return 'y0' + k.charAt(0).toUpperCase() + k.slice(1); }), TB_REP_SPELL, ['everFpl'], TB_PATH_KEYS);  /* v5.2 step 8: + the year-by-year path */

// index.html line 5041
function tbCashIncome(a){ var c = (+a.yrWageUSD || 0) + (+a.yrConvUSD || 0) + (+a.yrUbiUSD || 0) + (+a.yrSSUSD || 0) + (+a.yrTbCash || 0); if (RETURNS && RETURNS.ci) c += (+a.yrCapUSD || 0);  /* S59 part 2 */ return SNET && SNS && a._snB ? c - a._snB : c; }  /* session 2b: the official measure's money income leaves out SNAP and tax credits */

// index.html line 5043
/* A Gini that keeps negative values (debts) as they are: the sorted-rank formula equals the mean absolute difference over twice the mean for any values with a positive total. */
function giniOfArrNeg(x){ var v = x.map(function(z){ return +z || 0; }).sort(function(a, b){ return a - b; }), n = v.length, t = 0, w = 0;
  for (var i = 0; i < n; i++){ t += v[i]; w += (i + 1)*v[i]; } return n > 0 && t > 0 ? 2*w/(n*t) - (n + 1)/n : 0; }

// index.html line 5045
var REP_HOOK = null;  /* v5.2 step 5: an optional reporting hook (dev/tools/us_check.js reads the adults at Year 0, 7 and the last year); null in every run */

// index.html line 5046
function tbRepAcc(){ return {n:0, fpl:0, fplX:0, fplNom:0, bONom:0, bNNom:0, y7:null, end:null, y0:null, hist:[], path:{f0:[], pov:[], bO:[], medW:[], buR:[], wageR:[]}}; }

// index.html line 5047
function tbRepYear(R, agents, p, o, yr, T, ep){
  var n = agents.length, lf = o.lines === 'nominal' ? 1 : agents[0].yrBasketUSD/CFG.LIVING_WAGE_ANNUAL/(agents[0]._hhF || 1), thr = CFG.POVERTY_THRESHOLD_ONE, L30 = CFG.BLEI_PRECARIOUS_MAX;
  var s = {fpl:0, fplX:0, fplNom:0, f0:0, bO:0, bN:0, bONom:0, bNNom:0, pov:0, povNom:0};
  for (var i = 0; i < n; i++){ var a = agents[i], c = tbCashIncome(a), bo = agentBLEI(a, p.bu, p.ccoOn, p.pth, p.szh, p.szhCoh, p.ptf), bn = agentBLEI(a, 0, false, false, false, 0, false) + (a._tbM || 0)/CFG.BASE_DAILY_COST;
    var th = a.age >= 65 ? CFG.POVERTY_THRESHOLD_SENIOR : thr, pf = c < th*lf, h = a._h52;  /* v5.2 step 5: the official threshold for 65 and over where adults age (a.age is undefined otherwise) */
    if (!h){ h = a._h52 = {f:[], c:[]}; R.hist.push(h); } h.f.push(pf ? 1 : 0); h.c.push((a._tbGap || 0) > 0 ? 1 : 0);  /* each adult's year-by-year record (a new adult starts its own) */
    if (RISK_MEASURE){ if (!h.w){ h.w = []; h.b = []; h.y = []; } h.w.push(a.wealth/lf); h.b.push(bo/lf); h.y.push(c/lf); }  /* v5.4 item 1 (reporting only) */
    if (pf) s.fpl++; if (c < th) s.fplNom++; if ((a._tbExt || 0) < th*lf) s.fplX++; if ((a._tbGap || 0) > 0) s.f0++;
    if (bo/lf < L30) s.bO++; if (bn/lf < L30) s.bN++; if (bo < L30) s.bONom++; if (bn < L30) s.bNNom++;
    if (a.wealth < CFG.POVERTY_LINE*lf) s.pov++; if (a.wealth < CFG.POVERTY_LINE) s.povNom++; }
  R.n += n; R.fpl += s.fpl; R.fplX += s.fplX; R.fplNom += s.fplNom; R.bONom += s.bONom; R.bNNom += s.bNNom;
  var wk = agents.filter(function(a){ return !a._ret && a.yrWageUSD > 0; }).map(function(a){ return a.yrWageUSD/12/lf; });  /* v5.2 step 8: the year's path */
  R.path.f0[yr] = s.f0/n*100; R.path.pov[yr] = s.pov/n*100; R.path.bO[yr] = s.bO/n*100; R.path.medW[yr] = quantileOf(agents.map(function(a){ return a.wealth/lf; }), 0.5);
  R.path.buR[yr] = p.ccoOn && p.bu > 0 && PRICE && PRICE.buY ? PRICE.buY/lf : 0; R.path.wageR[yr] = wk.length ? quantileOf(wk, 0.5) : 0;
  if (REP_HOOK) REP_HOOK(agents, yr, T, lf, ep);  /* session 7: + the year's extreme-poverty figure (explore_export.js --suite) */
  if (yr === 0 || yr === 6 || yr === T - 1){ var gc = o.giniNN1 && n > 1 ? n/(n - 1) : 1, q = {ep:ep};
    Object.keys(s).forEach(function(k){ q[k] = s[k]/n*100; });
    q.giniD = giniOfArr(agents.map(function(a){ return a._tbDisp || 0; }))*gc; q.giniX = giniOfArr(agents.map(function(a){ return a._tbExt || 0; }))*gc;
    q.giniW = giniOfArr(agents.map(function(a){ return a.wealth; }))*gc; q.giniWN = giniOfArrNeg(agents.map(function(a){ return a.wealth; }))*gc;
    if (yr === 0) R.y0 = q; if (yr === 6) R.y7 = q; if (yr === T - 1) R.end = q; }
}

// index.html line 5068
function tbRepSpells(hist, m, out, key){  /* spell counts on one measure (m: 'f' official line, 'c' cost of living) into out[key + ...] */
  var N = [0, 0, 0, 0, 0, 0], X = [0, 0, 0, 0, 0, 0], RN = 0, RR = 0;
  hist.forEach(function(h){ var x = h[m], L = x.length;
    for (var t = 0; t < L; t++){ if (!x[t] || (t > 0 && x[t - 1])) continue; var e = t; while (e < L && x[e]) e++; var len = e - t;
      if (t > 0) for (var d = 1; d <= len; d++){ if (t + d >= L) break; var k = Math.min(d, 5); N[k]++; if (d === len) X[k]++; }  /* observed at duration d when year t + d is in the record */
      if (e < L && e + 1 < L){ RN++; if (x[e + 1]) RR++; } t = e; } });
  for (var d = 1; d <= 5; d++){ out[key + 'N' + d] = N[d]; out[key + 'X' + d] = X[d]; } out[key + 'RN'] = RN; out[key + 'R'] = RR; }

// index.html line 5088
/* v5.4 item 1 (Oct 7, 2026; dev/reports/v5-21-v54-design.md, 1.5; dev/DECISIONS.md Session 40): RISK MEASURES beside the stability score. Reporting only:
 * false (the default) records and reports nothing new. When true (v54 row option rk), each adult's year-by-year record (tbRepYear) also keeps real wealth,
 * real BLEI days and real cash income, and the run reports (RISK_KEYS):
 *  rkDdW, rkDdW6   drawdown of wealth: the largest fall from an earlier peak, in months of the basic-living cost (CFG.LIVING_WAGE_ANNUAL/12, year-0 $);
 *                  the median over adults, and the % of adults whose fall exceeds 6 months
 *  rkDdB, rkDdB30  the same for BLEI days: median largest fall in days, % of adults whose fall exceeds 30 days
 *  rkEv            income shocks per 100 adult-years: a year whose real cash income is below 80% of the year before's (any cause)
 *  rkRec1/3/5      % of income shocks after which income is back to the year-before level within 1, 3, 5 years (each over shocks with that many years observed)
 *  rkRecM          mean years to recover, over shocks that recover
 *  rkRecB3         % of the same shocks after which BLEI days are back to the year-before level within 3 years
 *  rkReC1/3/5      re-entry: of exits from below the cost of living, % below it again within 1, 3, 5 years (Stevens 1999 reads about half within 4-5
 *                  years in the PSID, official line); rkReF5 the same at 5 years on the official line
 * Reads only what the run already computed; no draw is added and no adult's path changes. */
var RISK_MEASURE = false, RISK_KEYS = ['rkDdW', 'rkDdW6', 'rkDdB', 'rkDdB30', 'rkEv', 'rkRec1', 'rkRec3', 'rkRec5', 'rkRecM', 'rkRecB3', 'rkReC1', 'rkReC3', 'rkReC5', 'rkReF5'];

// index.html line 5089
function rkDraw(x){ var pk = x[0], d = 0; for (var t = 1; t < x.length; t++){ if (x[t] > pk) pk = x[t]; else if (pk - x[t] > d) d = pk - x[t]; } return d; }

// index.html line 5090
function rkReentry(hist, m, K){  /* exits: a year not below the line after one below it; re-entry within k years: below it in any of the next k years */
  var N = K.map(function(){ return 0; }), X = K.map(function(){ return 0; });
  hist.forEach(function(h){ var x = h[m], L = x.length; for (var e = 1; e < L; e++){ if (x[e] || !x[e - 1]) continue;
    K.forEach(function(k, i){ if (e + k >= L) return; N[i]++; for (var j = 1; j <= k; j++) if (x[e + j]){ X[i]++; break; } }); } });
  return K.map(function(k, i){ return N[i] ? X[i]/N[i]*100 : 0; }); }

// index.html line 5095
function tbRiskRes(hist, out){
  var mo = CFG.LIVING_WAGE_ANNUAL/12, dW = [], dB = [], ev = 0, ay = 0, R = [[0, 0], [0, 0], [0, 0]], B3 = [0, 0], rs = 0, rn = 0;
  hist.forEach(function(h){ if (!h.w || !h.w.length) return; var y = h.y, b = h.b, L = y.length; ay += L;
    dW.push(rkDraw(h.w)/mo); dB.push(rkDraw(b));
    for (var t = 1; t < L; t++){ if (!(y[t - 1] > 0) || y[t] >= 0.8*y[t - 1]) continue; ev++;
      var u = t + 1; while (u < L && y[u] < y[t - 1]) u++; var got = u < L ? u - t : Infinity; if (got < Infinity){ rs += got; rn++; }
      [1, 3, 5].forEach(function(k, i){ if (t + k < L){ R[i][0]++; if (got <= k) R[i][1]++; } });
      if (t + 3 < L){ B3[0]++; for (var v = t + 1; v <= t + 3; v++) if (b[v] >= b[t - 1]){ B3[1]++; break; } } } });
  function pc(x){ return x[0] ? x[1]/x[0]*100 : 0; }
  var rc = rkReentry(hist, 'c', [1, 3, 5]), rf = rkReentry(hist, 'f', [5]);
  out.rkDdW = dW.length ? medianOf(dW) : 0; out.rkDdW6 = dW.length ? dW.filter(function(v){ return v > 6; }).length/dW.length*100 : 0;
  out.rkDdB = dB.length ? medianOf(dB) : 0; out.rkDdB30 = dB.length ? dB.filter(function(v){ return v > 30; }).length/dB.length*100 : 0;
  out.rkEv = ay ? ev/ay*100 : 0; out.rkRec1 = pc(R[0]); out.rkRec3 = pc(R[1]); out.rkRec5 = pc(R[2]); out.rkRecM = rn ? rs/rn : 0; out.rkRecB3 = pc(B3);
  out.rkReC1 = rc[0]; out.rkReC3 = rc[1]; out.rkReC5 = rc[2]; out.rkReF5 = rf[0]; return out; }

// index.html line 5132
/* v5.4 item 2 (Oct 7, 2026; dev/reports/v5-21-v54-design.md, 1.1; dev/DECISIONS.md Session 40): LOSING A JOB AND FINDING ANOTHER. null = off (every
 * earlier run). When an object (v54 row option empl), every working-age adult (not retired) is employed, out of work, or back at work, year by year:
 *  - Entering unemployment: each year an adult at work can lose or leave their job into unemployment with chance CFG.EMPL_P (normal years; recession years
 *    CFG.EMPL_P_REC), from the CPS (sources/unemp_flows.py: job losers and leavers, 2015-2025 without 2020-21; 2009-10). During an automation wave
 *    (auto 'jobs', the default) the wave's existing yearly rate (popAIDisp, the same schedule as before) times the adult's automation risk is an extra chance
 *    of losing the job, and replaces the slower pay growth the wave used to cause; auto 'pay' keeps the old pay drag instead (a labelled reading).
 *  - How long: the spell's length in weeks is drawn from the share of spells lasting at least d weeks, S(d), read from the CPS's unemployed-by-duration
 *    counts (log-linear between 2.5, 9.5 and 20.5 weeks, then a constant ending rate; normal or recession figures by the year the spell starts). It starts at
 *    a point of the year drawn evenly; weeks beyond the year carry into the next (no new spell begins while one runs). Pay that year falls by the share of the
 *    year out of work (before the labour-supply response, which then applies as before).
 *  - Unemployment insurance (both runs, as in the US): with chance CFG.EMPL_UI_RECIP (CPS continued claims / unemployed) the spell is insured; it pays
 *    CFG.EMPL_UI_REPL (DOL: average weekly benefit / average weekly covered wage) of the adult's weekly pay for up to 26 weeks of the spell. It is cash income
 *    like the UBI comparator's (yrUbiUSD carries both), with no effect on hours (it is paid only while out of work).
 *  - Coming back at lower pay: a permanent job loss (chance CFG.EMPL_PERM of a spell, CPS permanent job losers / losers and leavers; every automation loss)
 *    cuts pay on return by a share drawn evenly from 0 to 2 x cut (cut 0.10: a design parameter, swept 0 and 0.20; the displaced-worker literature's
 *    long-run losses for long-tenured workers in mass layoffs run 10-25%: Jacobson, LaLonde and Sullivan 1993; von Wachter, Song and Manchester 2009). The
 *    cut also applies to the no-programme-raise wages (_lwNB, _wNB): job loss is not the programme's. After an automation loss the adult's automation risk
 *    becomes the low-risk group's mean (they move to other work).
 *  - The labour-supply response (LABOR) scales with the share of the year at work: hours already at zero while out of work cannot fall further.
 *  - Recessions (rec 'replace', the default): the recession's income cut for everyone is reduced by the extra share of the year that recession job loss takes
 *    on average ((EMPL_P_REC x EMPL_W_REC - EMPL_P x EMPL_W)/52, about 4.2 points), so the recession's loss is not counted twice; rec 'add' keeps both.
 * Six draws per adult-year from the switch's own stream (mulberry32(seed + 600031)), taken whatever the adult's state, so the two runs stay paired; the main
 * stream's eight draws per adult-year are untouched. No effect of BU on search length beyond the existing income effect (standing rule 7). */
var EMPL = null, EMPL_DEFAULTS = {auto:'jobs', cut:0.10, rec:'replace', ui:true, occ:true}, EMS = null;

// index.html line 5133
CFG.EMPL_P = 0.0851; CFG.EMPL_P_REC = 0.1423; CFG.EMPL_PERM = 0.413; CFG.EMPL_PERM_REC = 0.621; CFG.EMPL_UI_RECIP = 0.273; CFG.EMPL_UI_RECIP_REC = 0.356;

// index.html line 5134
CFG.EMPL_UI_REPL = 0.322; CFG.EMPL_UI_WEEKS = 26; CFG.EMPL_W = 15.2; CFG.EMPL_W_REC = 24.5;

// index.html line 5135
CFG.EMPL_S = {n:[0.4434, 0.1871, 24.18], r:[0.5978, 0.3618, 30.90]};  /* S(9.5), S(20.5), weeks of the constant-rate tail */

// index.html line 5143
/* Occupations (EMPL.occ, on by default with EMPL): the common cause of pay and automation risk. Each adult holds one of 700 occupations (Frey and Osborne's
 * probabilities with May 2016 BLS employment and median pay; sources/fo_occupations.py), drawn at the start on the switch's own stream (mulberry32(seed +
 * 600041), one draw per adult): the occupations are ranked by median pay, and an adult's place in that ranking follows their own pay rank with correlation
 * rho = sqrt(between-occupation variance of log pay (vb, the data) / the variance of log pay across the run's adults), so occupation explains the measured
 * share of the spread of pay and no more. Their automation risk is their occupation's probability (replacing the separate draw). Hours are not tied to
 * occupation: the model's hours enter only as each adult's change from their own starting hours, so occupation's usual hours would change nothing (a
 * stated limit). Adults who arrive later (with ageing) keep their own draw. */
CFG.EMPL_OCC = {"vb":0.2651,"cum":[0.00073,0.02701,0.02713,0.03107,0.03197,0.03581,0.03891,0.05859,0.06079,0.08796,0.09121,0.09232,0.09621,0.10084,0.1052,0.10721,0.10756,0.11409,0.11568,0.11582,0.11694,0.12404,0.12407,0.12548,0.13693,0.13837,0.14028,0.14032,0.14573,0.14643,0.1491,0.14945,0.15029,0.15059,0.15322,0.15947,0.15955,0.1943,0.19757,0.19864,0.19882,0.21429,0.21443,0.21701,0.21707,0.22641,0.243,0.2457,0.24715,0.24881,0.24887,0.25002,0.25007,0.25014,0.25329,0.25356,0.25686,0.25716,0.258,0.25938,0.26014,0.26042,0.26103,0.27073,0.27419,0.27503,0.2757,0.27584,0.27622,0.27635,0.28481,0.28515,0.30501,0.30515,0.30529,0.30541,0.30543,0.31239,0.31264,0.31284,0.31346,0.31434,0.3149,0.31542,0.31542,0.31548,0.31548,0.31548,0.3193,0.31938,0.31946,0.31963,0.31986,0.32077,0.32088,0.32098,0.32105,0.32116,0.3223,0.32996,0.33464,0.33533,0.3359,0.33607,0.33903,0.33909,0.33937,0.33976,0.34043,0.34102,0.34115,0.34131,0.34151,0.34344,0.3464,0.34697,0.34725,0.34731,0.34773,0.34873,0.34943,0.3495,0.34974,0.35029,0.3522,0.35223,0.35325,0.35337,0.36191,0.36341,0.36736,0.3677,0.36814,0.36926,0.36939,0.36958,0.37616,0.39884,0.39915,0.39937,0.39951,0.40257,0.40304,0.40312,0.40831,0.40859,0.41026,0.41049,0.41071,0.41111,0.41288,0.41985,0.42464,0.42741,0.42741,0.42743,0.42886,0.42895,0.42908,0.44985,0.45133,0.4555,0.45626,0.45681,0.45689,0.45876,0.45942,0.45989,0.46047,0.46118,0.46174,0.46199,0.46274,0.463,0.46317,0.46352,0.46487,0.47187,0.47191,0.47228,0.4723,0.47657,0.47682,0.47702,0.47704,0.47759,0.4777,0.47773,0.4781,0.47825,0.47839,0.47929,0.47952,0.47993,0.48003,0.48082,0.48094,0.48104,0.49865,0.49897,0.49903,0.49934,0.49935,0.50047,0.50135,0.50365,0.50422,0.50553,0.50576,0.50599,0.50617,0.50717,0.50718,0.5076,0.50768,0.50782,0.50793,0.50808,0.50814,0.51186,0.51193,0.51194,0.51266,0.51271,0.51281,0.51291,0.51311,0.51364,0.51418,0.51425,0.51524,0.5167,0.51671,0.52069,0.52073,0.521,0.52115,0.52143,0.52395,0.53417,0.53426,0.53462,0.53533,0.5354,0.53541,0.53543,0.53621,0.53637,0.53813,0.53852,0.53856,0.53876,0.53897,0.53913,0.53938,0.54105,0.54133,0.54193,0.54282,0.54313,0.5434,0.54348,0.5446,0.54612,0.54619,0.54772,0.54882,0.5508,0.55203,0.55224,0.55243,0.5528,0.56482,0.56512,0.56723,0.5722,0.57332,0.57358,0.57373,0.57396,0.57412,0.57584,0.57636,0.57651,0.57725,0.57742,0.57768,0.57794,0.57917,0.57956,0.58062,0.58978,0.59112,0.59405,0.59409,0.59419,0.5955,0.59563,0.59637,0.59645,0.59648,0.5965,0.59665,0.59693,0.59727,0.59749,0.5975,0.59753,0.5979,0.59803,0.59806,0.59876,0.5997,0.5998,0.60051,0.60081,0.61389,0.61444,0.61554,0.61567,0.61585,0.61885,0.61921,0.61989,0.62014,0.62056,0.6211,0.62145,0.62268,0.62269,0.62311,0.6232,0.62377,0.6238,0.62393,0.62481,0.62492,0.62823,0.62931,0.63033,0.63057,0.63286,0.6339,0.6391,0.64449,0.64565,0.64712,0.64737,0.6474,0.64792,0.64806,0.64832,0.64901,0.64932,0.64936,0.65018,0.65213,0.65214,0.65229,0.6525,0.65268,0.65284,0.65322,0.65401,0.6549,0.65528,0.65569,0.65576,0.65627,0.659,0.65905,0.66132,0.66184,0.66224,0.66224,0.66238,0.66239,0.66486,0.66494,0.66597,0.66738,0.66812,0.66818,0.66833,0.66995,0.67002,0.67059,0.67067,0.67309,0.67343,0.67352,0.67373,0.67377,0.67464,0.67469,0.67502,0.6753,0.67542,0.67549,0.67563,0.67566,0.67569,0.67597,0.6761,0.67656,0.67705,0.678,0.67806,0.68019,0.68028,0.68028,0.68037,0.68077,0.68133,0.68429,0.68685,0.68718,0.68737,0.68752,0.68819,0.68927,0.6893,0.68935,0.68952,0.68971,0.69016,0.69025,0.6918,0.69189,0.69244,0.69258,0.69574,0.69648,0.69653,0.69664,0.69717,0.69744,0.69753,0.698,0.69805,0.69849,0.70457,0.70462,0.70496,0.70527,0.70537,0.70614,0.7073,0.71196,0.7124,0.71289,0.71373,0.71381,0.71383,0.71559,0.7157,0.71693,0.71703,0.72811,0.72824,0.72833,0.72868,0.72917,0.72952,0.73152,0.73161,0.73178,0.73181,0.73198,0.732,0.73241,0.73252,0.7432,0.74805,0.7489,0.74942,0.74943,0.74955,0.7497,0.75035,0.75039,0.7552,0.75531,0.75534,0.75597,0.75629,0.75767,0.76844,0.76919,0.77074,0.77136,0.77169,0.77179,0.77209,0.77308,0.77777,0.77951,0.78721,0.78973,0.78974,0.78983,0.78992,0.79065,0.79134,0.79232,0.79238,0.79285,0.79314,0.79521,0.79532,0.79565,0.79591,0.80096,0.80198,0.80202,0.80228,0.80248,0.80347,0.80349,0.80352,0.80366,0.80399,0.80412,0.80415,0.80543,0.80577,0.80742,0.80757,0.8077,0.80781,0.80841,0.80945,0.80956,0.81017,0.81074,0.81187,0.81616,0.81761,0.8177,0.81793,0.81798,0.81813,0.81824,0.82172,0.82407,0.82617,0.82628,0.82725,0.82734,0.82749,0.82772,0.82779,0.82785,0.82788,0.83962,0.84172,0.84176,0.84193,0.84464,0.84496,0.84521,0.84535,0.84605,0.84629,0.8472,0.84729,0.85685,0.85713,0.85777,0.86513,0.86516,0.86611,0.86661,0.867,0.86756,0.86782,0.8679,0.86797,0.86801,0.8686,0.86948,0.86959,0.8698,0.87009,0.87166,0.8736,0.87443,0.87444,0.87511,0.87553,0.87665,0.87666,0.87681,0.87709,0.87753,0.87857,0.87884,0.87911,0.87928,0.87938,0.88015,0.88042,0.88072,0.88153,0.8817,0.88422,0.88427,0.88511,0.88549,0.88838,0.8884,0.89049,0.89062,0.89067,0.89092,0.89176,0.89665,0.89881,0.8989,0.89981,0.90003,0.90004,0.90225,0.90444,0.90641,0.90718,0.90758,0.90845,0.91012,0.91027,0.91228,0.91247,0.91684,0.91736,0.91823,0.92014,0.92038,0.92065,0.9227,0.92425,0.92531,0.92536,0.92548,0.92555,0.92741,0.92762,0.92768,0.92774,0.92915,0.92925,0.92939,0.93194,0.93323,0.93418,0.93443,0.93544,0.95224,0.9523,0.95287,0.95896,0.95911,0.95933,0.95948,0.96028,0.96042,0.96043,0.96353,0.96355,0.9638,0.96408,0.96722,0.96822,0.96871,0.96924,0.96979,0.96999,0.97004,0.9706,0.97073,0.97085,0.97365,0.9784,0.97882,0.98299,0.98533,0.98551,0.98559,0.98566,0.98587,0.98588,0.9865,0.98676,0.98834,0.9897,0.99241,0.99322,0.99493,0.99992,0.99996,1.0],"p":[0.96,0.92,0.79,0.81,0.96,0.96,0.97,0.94,0.72,0.97,0.91,0.67,0.77,0.77,0.084,0.86,0.81,0.87,0.71,0.43,0.87,0.69,0.98,0.94,0.74,0.82,0.94,0.97,0.38,0.95,0.37,0.83,0.83,0.41,0.87,0.39,0.91,0.92,0.98,0.89,0.83,0.64,0.25,0.006,0.52,0.96,0.66,0.11,0.89,0.99,0.94,0.94,0.99,0.13,0.83,0.37,0.66,0.91,0.7,0.89,0.95,0.72,0.86,0.56,0.97,0.064,0.51,0.98,0.61,0.8,0.84,0.047,0.85,0.39,0.75,0.95,0.97,0.95,0.13,0.99,0.6,0.48,0.49,0.47,0.96,0.87,0.77,0.83,0.98,0.97,0.94,0.73,0.96,0.79,0.64,0.94,0.72,0.1,0.7,0.96,0.01,0.96,0.94,0.84,0.98,0.27,0.61,0.86,0.93,0.97,0.81,0.91,0.97,0.92,0.007,0.95,0.92,0.72,0.57,0.97,0.94,0.93,0.21,0.74,0.98,0.18,0.93,0.92,0.97,0.99,0.89,0.29,0.92,0.95,0.87,0.83,0.69,0.96,0.9,0.97,0.93,0.92,0.043,0.98,0.98,0.92,0.95,0.1,0.93,0.95,0.013,0.63,0.3,0.13,0.3,0.057,0.94,0.61,0.95,0.55,0.78,0.93,0.029,0.93,0.95,0.049,0.91,0.86,0.95,0.99,0.66,0.39,0.92,0.94,0.92,0.97,0.98,0.88,0.035,0.37,0.83,0.81,0.93,0.97,0.87,0.91,0.73,0.96,0.021,0.88,0.55,0.91,0.97,0.78,0.21,0.009,0.79,0.67,0.96,0.99,0.91,0.77,0.97,0.61,0.93,0.95,0.71,0.83,0.42,0.83,0.88,0.83,0.95,0.89,0.72,0.37,0.45,0.37,0.54,0.96,0.87,0.048,0.63,0.86,0.94,0.59,0.83,0.099,0.99,0.88,0.46,0.076,0.99,0.98,0.87,0.71,0.93,0.97,0.51,0.64,0.84,0.61,0.67,0.97,0.98,0.97,0.74,0.91,0.13,0.68,0.76,0.65,0.79,0.97,0.72,0.75,0.97,0.41,0.9,0.11,0.75,0.79,0.86,0.96,0.84,0.91,0.87,0.085,0.94,0.95,0.87,0.88,0.98,0.62,0.98,0.59,0.5,0.84,0.91,0.74,0.025,0.92,0.81,0.66,0.49,0.84,0.97,0.85,0.47,0.83,0.9,0.28,0.94,0.94,0.005,0.89,0.67,0.98,0.54,0.59,0.54,0.62,0.77,0.75,0.53,0.83,0.96,0.88,0.94,0.88,0.97,0.033,0.4,0.16,0.79,0.82,0.79,0.98,0.91,0.76,0.94,0.65,0.73,0.99,0.83,0.69,0.55,0.78,0.97,0.92,0.96,0.9,0.3,0.65,0.36,0.003,0.94,0.6,0.005,0.1,0.65,0.028,0.7,0.72,0.058,0.86,0.98,0.77,0.9,0.82,0.85,0.04,0.86,0.074,0.9,0.34,0.73,0.82,0.57,0.64,0.007,0.89,0.008,0.57,0.61,0.015,0.99,0.84,0.57,0.95,0.61,0.65,0.61,0.38,0.98,0.003,0.91,0.88,0.66,0.82,0.42,0.037,0.066,0.9,0.082,0.28,0.76,0.39,0.17,0.27,0.8,0.31,0.004,0.35,0.93,0.93,0.055,0.25,0.71,0.62,0.18,0.97,0.014,0.25,0.98,0.82,0.4,0.008,0.94,0.84,0.99,0.1,0.022,0.75,0.92,0.67,0.79,0.2,0.015,0.25,0.54,0.91,0.76,0.28,0.36,0.19,0.042,0.083,0.006,0.84,0.5,0.35,0.52,0.08,0.41,0.83,0.004,0.54,0.9,0.59,0.93,0.65,0.48,0.9,0.59,0.93,0.49,0.15,0.15,0.045,0.03,0.29,0.007,0.5,0.36,0.13,0.004,0.89,0.014,0.53,0.23,0.38,0.68,0.63,0.008,0.86,0.88,0.82,0.6,0.44,0.23,0.81,0.004,0.86,0.79,0.41,0.37,0.91,0.83,0.018,0.067,0.17,0.01,0.49,0.95,0.97,0.81,0.85,0.055,0.029,0.009,0.83,0.26,0.96,0.65,0.016,0.18,0.008,0.68,0.93,0.87,0.48,0.63,0.016,0.066,0.008,0.004,0.028,0.014,0.91,0.38,0.89,0.098,0.008,0.06,0.85,0.81,0.71,0.061,0.91,0.3,0.025,0.7,0.01,0.9,0.038,0.57,0.016,0.68,0.24,0.47,0.84,0.021,0.31,0.24,0.004,0.61,0.21,0.88,0.31,0.008,0.045,0.98,0.003,0.98,0.98,0.077,0.007,0.86,0.021,0.015,0.9,0.004,0.047,0.032,0.08,0.57,0.012,0.016,0.71,0.027,0.78,0.99,0.037,0.097,0.48,0.94,0.23,0.033,0.23,0.091,0.33,0.35,0.89,0.98,0.13,0.003,0.041,0.2,0.17,0.022,0.75,0.9,0.27,0.68,0.075,0.005,0.49,0.1,0.94,0.012,0.25,0.13,0.02,0.004,0.006,0.85,0.015,0.38,0.003,0.018,0.04,0.55,0.34,0.39,0.25,0.85,0.035,0.17,0.03,0.059,0.48,0.34,0.014,0.22,0.004,0.13,0.23,0.64,0.004,0.027,0.012,0.019,0.011,0.029,0.004,0.018,0.03,0.021,0.037,0.22,0.028,0.006,0.038,0.59,0.071,0.63,0.023,0.73,0.58,0.01,0.95,0.64,0.67,0.005,0.021,0.01,0.14,0.1,0.004,0.43,0.007,0.03,0.014,0.017,0.025,0.16,0.021,0.004,0.042,0.21,0.039,0.43,0.14,0.07,0.041,0.25,0.047,0.006,0.14,0.13,0.006,0.015,0.017,0.03,0.015,0.039,0.22,0.1,0.96,0.013,0.035,0.018,0.069,0.012,0.11,0.005,0.009,0.4,0.055,0.18,0.16,0.014,0.017,0.035,0.004,0.015,0.004,0.023,0.004]};

// index.html line 5144
function emplOcc(agents, seed){ var O = CFG.EMPL_OCC, r = mulberry32(seed + 600041), n = agents.length; if (!n) return 0;
  var lw = agents.map(function(a){ return Math.log(Math.max(1e-9, a.wage)); }), m = lw.reduce(function(s, x){ return s + x; }, 0)/n,
    v = lw.reduce(function(s, x){ return s + (x - m)*(x - m); }, 0)/n, rho = v > 0 ? Math.sqrt(Math.min(1, O.vb/v)) : 0;
  var ord = agents.map(function(a, i){ return i; }).sort(function(i, j){ return agents[i].wage - agents[j].wage || i - j; }), rk = new Array(n);
  ord.forEach(function(i, k){ rk[i] = k; });
  agents.forEach(function(a, i){ var e = normInv(Math.min(1 - 1e-12, Math.max(1e-12, r()))), z = rho*normInv((rk[i] + 0.5)/n) + Math.sqrt(1 - rho*rho)*e, q = normCdf(z), lo = 0, hi = O.cum.length - 1;
    while (lo < hi){ var mid = (lo + hi) >> 1; if (O.cum[mid] >= q) hi = mid; else lo = mid + 1; }
    a._emOcc = lo; a.automationRisk = O.p[lo]; });
  return rho; }

// index.html line 5153
var EMPL_KEYS = ['emUrate', 'emSpells', 'emWeeks', 'emAuto', 'emUI', 'emCut', 'emLong', 'emRho'];  /* % of adult-years out of work (weeks/52); spells per 100 adult-years; weeks out per adult-year with any; automation losses per 100 adult-years; UI as % of pay lost; mean pay cut on return (%); % of spells over 26 weeks */

// index.html line 5154
function emplWeeks(u, rec){ var s = CFG.EMPL_S[rec ? 'r' : 'n'], S1 = s[0], S2 = s[1];  /* the spell length d with S(d) = u */
  if (u >= 1) return 2.5; if (u >= S1) return 2.5 + 7*Math.log(u)/Math.log(S1); if (u >= S2) return 9.5 + 11*(Math.log(u) - Math.log(S1))/(Math.log(S2) - Math.log(S1));
  return 20.5 + s[2]*Math.log(S2/u); }

// index.html line 5157
function emplInit(agents, seed){ EMS = {r:mulberry32(seed + 600031), n:0, out:0, spells:0, weeks:0, auto:0, ui:0, lost:0, cut:0, cutN:0, long:0, rho:EMPL.occ ? emplOcc(agents, seed) : 0}; }

// index.html line 5158
function emplYear(a, rec, aiH, u, wkPay){  /* u: six draws. Returns {out: share of the year out of work, ui: dollars}. */
  var A = EMS, w = 0, ui = 0, carry = Math.min(52, a._emW || 0); a._emW = (a._emW || 0) - carry; w = carry;
  if (carry > 0 && a._emUi){ var uw = Math.min(carry, Math.max(0, CFG.EMPL_UI_WEEKS - a._emUiW)); a._emUiW += uw; ui += uw*CFG.EMPL_UI_REPL*wkPay; }
  if (carry === 0){ var hA = EMPL.auto === 'jobs' ? Math.max(0, aiH*a.automationRisk) : 0, h = rec ? CFG.EMPL_P_REC : CFG.EMPL_P, pE = 1 - (1 - h)*(1 - hA);
    if (u[0] < pE){ var auto = u[0] < hA, D = emplWeeks(u[2], rec), st = u[3]*52, now = Math.min(D, 52 - st); A.spells++; if (auto) A.auto++; if (D > 26) A.long++;
      w = now; a._emW = D - now; a._emUi = EMPL.ui && u[4] < (rec ? CFG.EMPL_UI_RECIP_REC : CFG.EMPL_UI_RECIP); a._emUiW = 0;
      if (a._emUi){ var uw2 = Math.min(now, CFG.EMPL_UI_WEEKS); a._emUiW = uw2; ui += uw2*CFG.EMPL_UI_REPL*wkPay; }
      a._emCut = (auto || u[1] < (rec ? CFG.EMPL_PERM_REC : CFG.EMPL_PERM)) ? 2*EMPL.cut*u[5] : 0; a._emAuto = auto; } }
  if (a._emW <= 0 && (a._emCut || a._emAuto)){ var f = 1 - (a._emCut || 0); a.wage *= f; if (a._lwNB !== undefined) a._lwNB *= f; if (a._wNB !== undefined) a._wNB *= f;  /* back at work: the lower pay */
    A.cut += a._emCut || 0; A.cutN++; if (a._emAuto) a.automationRisk = 1/(1 + CFG.AUTO_LOW_B); a._emCut = 0; a._emAuto = false; }
  A.n++; A.weeks += w; A.ui += ui; A.lost += w*wkPay; if (w > 0) A.out++; return {out:Math.min(1, w/52), ui:ui}; }

// index.html line 5169
function emplRes(out){ var A = EMS; out.emUrate = A && A.n ? A.weeks/52/A.n*100 : 0; out.emSpells = A && A.n ? A.spells/A.n*100 : 0; out.emWeeks = A && A.out ? A.weeks/A.out : 0;
  out.emAuto = A && A.n ? A.auto/A.n*100 : 0; out.emUI = A && A.lost > 0 ? A.ui/A.lost*100 : 0; out.emCut = A && A.cutN ? A.cut/A.cutN*100 : 0; out.emLong = A && A.spells ? A.long/A.spells*100 : 0; out.emRho = A ? A.rho : 0; return out; }

// index.html line 5195
/* v5.4 item 3 (Oct 7, 2026; dev/reports/v5-21-v54-design.md, 1.2; dev/DECISIONS.md Session 40): PTH AS A HOUSING BALANCE SHEET. null = off (every earlier
 * run). When an object (v54 row option pthb), every PTH home has the trust's books beside its member's Acre Equity:
 *  - The home: bought when its first member's books open, at CFG.PTHB_PR years of the member's market housing cost (hSA x dcA: the housing share of their
 *    basket, at market prices), financed by the trust's debt less the member's starting Acre Equity, so the community's equity starts at zero. Its value moves
 *    each year with the model's price level and CFG.PTHB_G real growth (FHFA over CPI-U, 1991-2025); CFG.PTHB_LAND of it is land.
 *  - The trust's cash each year: in, the market housing cost (the member's fee plus the programme's payment for the cut, which the programme's cost already
 *    carries) and the member's equity contribution; out, interest (a real rate CFG.PTHB_RREAL on top of the year's price rise, so inflation does not shrink the
 *    debt for free), upkeep (CFG.PTHB_UPK of the structure's value: BEA's yearly wear of owner-occupied homes), property tax (CFG.PTHB_TAX of value) and the
 *    appreciation paid to the member in cash. What is left pays down the debt; a shortfall adds to it.
 *  - Acre Equity grows with the home's value but at most at the year's price rise + 2% (cap 'hub': the Democratic Governance paper's cap, Duke's question
 *    d175's default); cap 'old' keeps the 3-5% rule (plus the Social Zone bonus) as before. What the home gains beyond the credit is the community's.
 *  - Leaving: each year a member leaves the network with chance exit (0.062: renters' moves to another county, CPS ASEC 2023; 'owners' reading 0.019; one
 *    draw per adult a year on the switch's own stream mulberry32(seed + 600043); in a household the head's draw decides for its PTH members). A leaver takes
 *    cash share x of their Acre Equity (0.40: the Real Estate paper's cash value on exit; Duke's question d174) and the rest becomes the community's; the
 *    trust borrows the cash. The home passes to the next adult waiting (non-members in the order of their PTH uptake draw, fixed at the start), who starts
 *    with no Acre Equity. Moves within the county stay in the network with their equity (not modelled as moves).
 *  - Cash from appreciation (the existing liquid share, 15% rising to 85% with tenure) is paid only on the gain above the year's price rise; the part that
 *    keeps up with prices stays as Acre Equity (otherwise inflation would turn members' equity into spending).
 *  - pbCover: the share of home-years whose market rent and equity contribution cover the real cost of the debt (interest less the price rise's erosion of
 *    it), upkeep, tax and cash paid out. pbAprP is the year's nominal gain from the price rise, pbAprR the real gain, pbAprC what the community keeps beyond the
 *    members' credit (all in year-0 dollars per home-year).
 *  - The identity homes - debt = members' equity + community equity is checked for every home every year (ACCT 'pth-books'): it ties the engine's Acre Equity
 *    to the trust's flows. Insurance is not modelled (no separate source; BEA folds it into intermediate costs).
 * Only the programme run has PTH; the no-programme run is untouched. No draw on the main stream. */
var PTHB = null, PTHB_DEFAULTS = {cap:'hub', x:0.40, exit:0.062}, PBS = null;

// index.html line 5196
CFG.PTHB_PR = 18.23; CFG.PTHB_LAND = 0.377; CFG.PTHB_UPK = 0.0231; CFG.PTHB_TAX = 0.0065; CFG.PTHB_G = 0.0172; CFG.PTHB_RREAL = 0.0180; CFG.PTHB_EXIT_OWN = 0.019;

// index.html line 5197
var PTHB_KEYS = ['pbV', 'pbD', 'pbME', 'pbCE', 'pbCover', 'pbExit', 'pbCash', 'pbAprP', 'pbAprR', 'pbAprC', 'pbFill'];

// index.html line 5198
function pthbInit(agents, latent, seed){ PBS = {r:mulberry32(seed + 600043), q:[], P:1, pi:0, n:0, exits:0, cash:0, cover:0, aP:0, aR:0, aC:0, fill:0, slots:[]};
  agents.forEach(function(a, i){ a._pbU = latent[i] ? latent[i].uPTH : 1; if (a.inPTH){ a._pbS = {V:0, D:0, CE:0}; PBS.slots.push(a._pbS); } else PBS.q.push(a); });
  PBS.q.sort(function(x, y){ return x._pbU - y._pbU; }); }

// index.html line 5201
function pthbYear(agentSet, yr, P){  /* before the year's adults: this year's price rise, then leavers and their homes' new members */
  PBS.pi = yr > 0 && PBS.P > 0 ? P/PBS.P - 1 : 0; PBS.P = P; if (yr === 0) return;
  var x = PTHB.x, rate = PTHB.exit === 'owners' ? CFG.PTHB_EXIT_OWN : PTHB.exit, u = agentSet.map(function(){ return PBS.r(); }), go = [];
  agentSet.forEach(function(a, i){ if (!a.inPTH || !a._pbS) return; var h = a._hh && !a._hh.single && a._hh.a ? a._hh.a[0] : a, j = agentSet.indexOf(h);
    if ((j >= 0 ? u[j] : u[i]) < rate) go.push(a); });
  go.forEach(function(a){ var S = a._pbS, E = Math.max(0, +a.acreEquity || 0), c = x*E; a.wealth += c; S.D += c; S.CE += E - c; a.acreEquity = 0; a.inPTH = false; a.pthTenure = 0; a._pbS = null; if (ACCT){ a._acW0 += c; a._acE0 = 0; }  /* the exit is booked at the year's opening (the trust's side: D and CE above) */
    PBS.exits++; PBS.cash += c/P; if (LEDGER) ledAdd(yr, 'pthExitCash', c);
    while (PBS.q.length && (PBS.q[0].inPTH || agentSet.indexOf(PBS.q[0]) < 0)) PBS.q.shift();
    if (PBS.q.length){ var b = PBS.q.shift(); b.inPTH = true; b.acreEquity = 0; b.pthTenure = 0; b._pbS = S; if (ACCT) b._acE0 = 0; PBS.fill++; } }); }

// index.html line 5210
function pthbRes(out){ var A = PBS, n = A && A.slots.length ? A.slots.length : 0, P = A ? A.P : 1; function sum(k){ return A ? A.slots.reduce(function(s, S){ return s + S[k]; }, 0) : 0; }
  out.pbV = n ? sum('V')/n/P : 0; out.pbD = n ? sum('D')/n/P : 0; out.pbCE = n ? sum('CE')/n/P : 0; out.pbME = n ? out.pbV - out.pbD - out.pbCE : 0;
  out.pbCover = A && A.n ? A.cover/A.n*100 : 0; out.pbExit = A && A.n ? A.exits/A.n*100 : 0; out.pbCash = A && A.exits ? A.cash/A.exits : 0;
  out.pbAprP = A && A.n ? A.aP/A.n : 0; out.pbAprR = A && A.n ? A.aR/A.n : 0; out.pbAprC = A && A.n ? A.aC/A.n : 0; out.pbFill = A && A.exits ? A.fill/A.exits*100 : 0; return out; }

// index.html line 5228
/* v5.4 item 4 (Oct 7, 2026; dev/reports/v5-21-v54-design.md, 1.3; dev/DECISIONS.md Session 40): PTF BY SECTOR, AND MEMBERS WHO LEAVE. null = off (every
 * earlier run: 12% off the whole cost of living, more with Social Zone Harmonization, and members never leave). When an object (v54 row option ptfs):
 *  - A member's cut is the sum over five sectors of the sector's share of their household's basket times the sector's PTF price cut:
 *      food        1 - 1/2.64 (the BLEI paper's food epsilon; 1 - 1/1.65 while fewer than 40% of adults are members: the paper's "below approximately 40%
 *                  PTF merchant participation ... epsilon falls toward 1.5-1.8x", its midpoint)
 *      utilities   1 - 1/1.80 (the paper's utility epsilon) on CFG.PTFS_UTIL of the housing share (BEA 2025: electricity, gas, water and sanitation over
 *                  housing plus those, 487.7 / 3,814.0)
 *      transport, health care, childcare: other (0: the Hub gives no figure, so the cautious main value is no cut; swept 0.12 and 0.25)
 *    With Social Zone Harmonization the cut is raised in the same proportion as before ((0.12 + 0.04 x cohesion)/0.12).
 *  - Leaving: each year a member household leaves with chance leave (0.032: moves to another county, CPS ASEC 2023 Table 1; one draw per adult a year on
 *    the switch's own stream mulberry32(seed + 600047), the head's draw deciding for the household). Leavers can join again through the adoption curve.
 *    No leaving for lack of value: membership has no fee in the model, so nothing weighs against the cut (a stated limit).
 *  - Capacity: the membership gate the model already has (the production side's capacity, PROD) limits how many adults can be members; the sectors share
 *    it (no sector has its own capacity data: a stated limit). */
var PTFS = null, PTFS_DEFAULTS = {other:0, leave:0.032}, PFS = null;

// index.html line 5229
CFG.PTFS_EPS_FOOD = 2.64; CFG.PTFS_EPS_FOOD_LOW = 1.65; CFG.PTFS_EPS_UTIL = 1.80; CFG.PTFS_LOW_DENS = 0.40; CFG.PTFS_UTIL = 487.685/(3326.284 + 487.685);

// index.html line 5230
var PTFS_KEYS = ['pfCut', 'pfLeave', 'pfMem'];

// index.html line 5231
function ptfsShares(a, HHA){  /* the member's basket shares: food, housing, transport, medical, childcare */
  if (HHA && a._hhS) return a._hhS; var c = function(k){ return PRICE ? PRICE.comp[k]/PRICE.bIdx : 1; };
  return {f:CFG.BASKET.food*c('food'), h:CFG.BASKET.housing*c('housing'), t:CFG.BASKET.transport*c('transport'), m:CFG.BASKET.medical*c('medical'), k:0}; }

// index.html line 5234
function ptfsCut(a, HHA, p, quiet, full){ if (POS) return poPtfsCut(a, HHA, p, quiet, full); var s = ptfsShares(a, HHA), eF = PFS && (PAS ? paW(a) : CMS && a._cm !== undefined ? CMS.sh[a._cm] : PFS.dens) < CFG.PTFS_LOW_DENS ? CFG.PTFS_EPS_FOOD_LOW : CFG.PTFS_EPS_FOOD, o = PTFS.other;  /* S55: under open access the 40% test reads the zone's PTF share of essential sales */
  var c = (PRICE && PRICE.sxF ? sxPtf(s.f, s.h, eF) : s.f*(1 - 1/eF) + s.h*CFG.PTFS_UTIL*(1 - 1/CFG.PTFS_EPS_UTIL)) + (s.t + (HLS && HLS.planOn ? 0 : s.m) + s.k)*o;  /* session 2b (DECISIONS, 'Nothing counted twice', item 7): under single payer (B, C) the health-sector cut lowers the plan's costs (hlSingle), not the household's */ if (p.szh) c *= (0.12 + p.szhCoh*0.04)/0.12;
  if (PAS && !full) c = paW(a)*Math.min(0.95, c);  /* S55 open access: the adult buys the zone's share of these sectors at PTF prices (full: the cut on what is bought there) */
  if (PFS && !quiet){ PFS.cut += c; PFS.cn++; } return Math.min(0.95, c); }

// index.html line 5238
function ptfsYear(agentSet, yr){  /* before the year's adults: leavers, then the share of adults who are members (the food epsilon's density test) */
  var u = agentSet.map(function(){ return PFS.r(); }), m = 0;
  if (yr > 0) agentSet.forEach(function(a, i){ if (!a.inPTF || (a._hh && !a._hh.single && a._hh.a && a._hh.a[0] !== a)) return; if (u[i] < PTFS.leave){ a.inPTF = false; PFS.leave++;
    if (a._hh && a._hh.a) a._hh.a.forEach(function(b){ b.inPTF = false; }); } });
  agentSet.forEach(function(a){ if (a.inPTF) m++; }); PFS.dens = m/Math.max(1, agentSet.length); PFS.mem += PFS.dens; PFS.yrs++; }

// index.html line 5243
function ptfsRes(out){ var A = PFS; out.pfCut = A && A.cn ? A.cut/A.cn*100 : 0; out.pfLeave = A && A.yrs ? A.leave/A.yrs : 0; out.pfMem = A && A.yrs ? A.mem/A.yrs*100 : 0; return out; }

// index.html line 5289
/* S55, part 1 (Nov 8, 2026; research-update audits/2026-11-ptf-access.md, Duke's answers D16; dev/DECISIONS.md S55): OPEN PTF ACCESS. PTF_ACCESS
 * 'members' is the default (every earlier run; PAS null). 'open' (study row option pa: 'open', or an object {fix}) reads the design as Duke stated it on
 * Nov 7: anyone may shop at a PTF business, in dollars or BU, at one posted price. Until now the engine read "PTF member" as "PTF customer" everywhere.
 * 'open' runs only with PTF and v5.4's PTF by sector (PTFS, the release model's); with an earlier PTF model it is refused. Under 'open':
 *  - Zones and their share. Each zone (a community of the S37 layer; without the layer the population is one zone) has a PTF share s of its essential
 *    sales: the share of its food and utilities purchases (and the other sectors', where swept) made at PTF businesses. At the start s is the zone's
 *    share of adults who are members (the same draws; with SZH the same placement as S37), so year 0's tests read what they read under 'members'.
 *    fix holds every zone at fix instead (the fixed-share sweep, D16). Part 1 held s for the whole run; part 2's growth rule (capacity, operations
 *    and demand, reading 6) is below.
 *  - Customer rules use s. Every adult in a zone, member or not, buys the share s of these sectors at PTF prices and no more (reading 2). So for the
 *    share s of their purchases every adult is what a member was for all of them: the PTF price cut (ptfsCut returns s x the member's cut, wherever
 *    the cut enters: the cost of living, the essentials BU buy, the BLEI gate's BU, the joining reading, PTH's cut on PTF-priced utilities); the ESP
 *    split's PTF price pool (every adult a customer on s of their essentials at PTF prices); its sizing (BU spent at PTFs: s x each holder's BU; the
 *    private ESPs' customers hold the rest); theta's term in the BLEI's cost of basic living (s x theta x 0.20); the discount PTFs fund from forgone
 *    profit (accounting only); the health-sector cut on the public plan's costs (only where PTFS.other > 0, which no main row sets).
 *  - The tests read s. The 40% test for epsilon (in ptfsCut) and the 55% test for theta (THETA_DENS and, with the layer, each community's theta) read
 *    the zone's s instead of its member share (readings 3 and 4), and PTF's damping of the outside inflation rate reads the population's s.
 *  - Membership keeps the rest (reading 5): joining and leaving (imitation still reads the member share; SZH's induction reads theta, now from s), the
 *    capacity gate on joining, the conversion-rate bonus 1.30 + theta (members only), the ESP workforce option, PTH, and reporting by membership.
 * No draw is added anywhere (CRN holds), and the no-programme run is untouched (PAS needs PTF). Reported (PA_KEYS; rows with 'open' only): paSh the
 * population's PTF share of essential sales (%, mean over years); paLo the share of adult-years in zones below the 40% test (%); paTh the share of
 * adult-years in zones above the 55% test (%). Under 'open' pfCut is the mean cut over every adult (under 'members', over members).
 *
 * S55, part 2 (Nov 8, 2026; reading 6 and Duke's answer D16; dev/DECISIONS.md S55 part 2; dev/reports/s55-ptf-growth.md): THE GROWTH RULE. Under 'open'
 * with fix null and grow true (the defaults), each year from year 1, before any test reads a share, every zone's s grows as far as three limits allow,
 * whichever binds first; s never falls (limits stop expansion; no rule here closes a PTF):
 *  - capacity (cap 'own'): the PTFs can supply at most the share c of the population's essential sales, c = min(1, c0 + the ESP capital account per
 *    adult / K), the production side's capital rule (d101: K = $18,862, BEA net stock of food and beverage stores, food services and utilities per
 *    adult), with c0 the population's starting s. It reads the capital the PTFs own (reinvestment to the end of last year); the one-year borrowing
 *    rule (d137) still serves membership as before and is not extended to sales. Where the production side is off, capacity is unlimited, as for
 *    members. cap 'none': no capacity limit (sensitivity: capital free and at once). With zones, the population's c bounds the population's s;
 *    where the zones want more than the room left, every growing zone gets the same fraction of its wanted growth (capacity by zone is not modelled).
 *  - operations (ops): a zone's PTFs expand only where their sales cover their operating costs. 'hub' (main): the BLEI paper (section 3.3) sets
 *    PTF prices at cost, "direct costs plus minimal cooperative overhead" (epsilon = market price / (variable cost share + cooperative overhead
 *    share)), so sales cover costs at every share and the limit never binds, by construction. 'outside': running costs from outside data, the
 *    engine's step 5 figures (BEA net operating surplus less depreciation, Census's grocers' gross margin): a PTF's cost per market dollar is 1 less
 *    the industry's net margin (COST.food on food, COST.util / PTFS_UTIL on utilities); the zone expands only to shares at which its sales at PTF
 *    prices (epsilon by the 40% test, raised by SZH as in ptfsCut) cover those costs (paCover >= 1).
 *  - demand (dem): the largest share of a zone's essential purchases its shoppers make at PTFs at PTF prices. A labelled design parameter (the Hub
 *    gives no figure; it says PTFs "complement private markets"): main 0.49, the 49.0% of Finland's grocery sales held in 2025 by S Group, a consumer
 *    cooperative open to every shopper (NielsenIQ Grocery Shop Directory, Finnish Grocery Trade Association); swept. A constant ceiling: no larger
 *    pull when a zone's price gap widens at the 40% test (the reading with the smaller effect).
 * grow false holds s at the start (part 1's rows); fix rows never grow. Reported (with 'open'): paCap, paOps, paDem the share of adult-years from
 * year 1 in zones where that limit stopped growth (%); paCv the PTFs' sales at PTF prices over their running costs at outside margins (%, mean
 * over adult-years, every reading); paS5, paS10, paS19, paS39 the population's s at that year's index (%); paC5 ... paC39 capacity c then (%). */
var PTF_ACCESS = 'members', PA = null, PA_DEFAULTS = {fix:null, grow:true, cap:'own', ops:'hub', dem:0.49}, PAS = null;

// index.html line 5290
var PA_KEYS = ['paSh', 'paLo', 'paTh', 'paCap', 'paOps', 'paDem', 'paCv', 'paS5', 'paS10', 'paS19', 'paS39', 'paC5', 'paC10', 'paC19', 'paC39'];

// index.html line 5291
function paZ(a){ return CMS && a._cm !== undefined ? a._cm : 0; }

// index.html line 5292
function paW(a){ return PAS.z[paZ(a)]; }  /* the adult's zone's PTF share of essential sales */

// index.html line 5293
function paInit(agents){ var C = CMS ? CMS.C : 1, m = new Float64Array(C), t = new Float64Array(C), z = new Float64Array(C), i;
  if (PA.fix !== null && !(PA.fix >= 0 && PA.fix <= 1)) throw new Error('pa: fix must be a share from 0 to 1');
  if (typeof PA.grow !== 'boolean' || ['own', 'none'].indexOf(PA.cap) < 0 || ['hub', 'outside'].indexOf(PA.ops) < 0 || !(PA.dem > 0 && PA.dem <= 1))
    throw new Error('pa: grow true or false, cap own or none, ops hub or outside, dem a share above 0 and at most 1');
  agents.forEach(function(a){ var j = paZ(a); t[j]++; if (a.inPTF) m[j]++; });
  for (i = 0; i < C; i++) z[i] = PA.fix !== null ? PA.fix : m[i]/Math.max(1, t[i]);
  PAS = {z:z, s:0, sh:0, lo:0, th:0, yrs:0, cb:0, ob:0, db:0, yu:0, cv:0, sY:[], cY:[]}; paPop(agents); }

// index.html line 5300
function paCapNow(yr, p){  /* this year's capacity c for the PTFs' share of sales: the production side's capital rule on the capital the PTFs own (no draw) */
  if (PA.cap === 'none' || !(PROD && CONVERSION_MODEL === 'framework' && p.ptf && PROD.cap === 'ptf' && PDS)) return 1;
  var K = SURP ? SURP.K : Infinity, A = yr > 0 && SURP && SPS ? SPS.capPA : 0; return K <= 0 ? 1 : Math.min(1, PDS.c0 + A/K); }

// index.html line 5303
function paCover(s, p){  /* a zone's PTF sales at PTF prices over their running costs at outside margins, at the zone share s (food and utilities, basket weights) */
  var g = p.szh ? (0.12 + p.szhCoh*0.04)/0.12 : 1, eF = s < CFG.PTFS_LOW_DENS ? CFG.PTFS_EPS_FOOD_LOW : CFG.PTFS_EPS_FOOD, M = COST || COST_DEFAULTS;
  var f = CFG.BASKET.food, u = CFG.BASKET.housing*CFG.PTFS_UTIL, pf = Math.max(0, 1 - g*(1 - 1/eF)), pu = Math.max(0, 1 - g*(1 - 1/CFG.PTFS_EPS_UTIL));
  return (f*pf + u*pu)/(f*(1 - M.food) + u*(1 - M.util/CFG.PTFS_UTIL)); }

// index.html line 5307
function paOpsMax(s, p){  /* the highest share a zone's PTFs can reach on their operations: 'hub' 1 (priced at cost); 'outside' only shares at which sales cover costs */
  if (PA.ops === 'hub' || paCover(1, p) >= 1) return 1;
  return paCover(0, p) >= 1 ? Math.max(s, CFG.PTFS_LOW_DENS*(1 - 1e-12)) : s; }

// index.html line 5310
function paGrow(agentSet, yr, p){  /* year >= 1: each zone grows toward min(demand, operations), the growth scaled down together where capacity binds (no draw) */
  var S = PAS, C = S.z.length, n = Math.max(1, agentSet.length), w = new Float64Array(C), o = new Float64Array(C), want = new Float64Array(C), tot = 0, all = 0, i;
  agentSet.forEach(function(a){ w[paZ(a)]++; });
  for (i = 0; i < C; i++){ w[i] /= n; tot += w[i]*S.z[i]; o[i] = paOpsMax(S.z[i], p); want[i] = Math.max(0, Math.min(PA.dem, o[i]) - S.z[i]); all += w[i]*want[i]; }
  var k = all > 0 ? Math.min(1, Math.max(0, S.cY[yr] - tot)/all) : 0;
  for (i = 0; i < C; i++){ if (want[i] > 0 && k < 1) S.cb += w[i]; else if (PA.dem <= o[i]) S.db += w[i]; else S.ob += w[i]; S.z[i] += k*want[i]; }
  S.yu++; }

// index.html line 5317
function paPop(agents){ var C = PAS.z.length, t = new Float64Array(C), n = Math.max(1, agents.length), s = 0, lo = 0, th = 0, i;
  agents.forEach(function(a){ t[paZ(a)]++; });
  for (i = 0; i < C; i++){ s += t[i]/n*PAS.z[i]; if (PAS.z[i] < CFG.PTFS_LOW_DENS) lo += t[i]/n; if (PAS.z[i] > CFG.SZH_THETA_THRESHOLD) th += t[i]/n; }
  PAS.s = s; return [lo, th]; }

// index.html line 5321
function paYear(agentSet, yr, p){  /* at the start of the year's PTF steps, before any test reads a share: growth (part 2), the population's share, the year's tallies (no draw) */
  if (yr > 0){ PAS.cY[yr] = paCapNow(yr, p); if (POS) poYear(agentSet, yr, p); if (PA.grow && PA.fix === null){ if (POS && PTF_OPS.hire !== null) poHireGrow(agentSet, yr, p); else paGrow(agentSet, yr, p); } } else if (POS) poYear(agentSet, yr, p);  /* S62 */
  var q = paPop(agentSet), C = PAS.z.length, t = new Float64Array(C), n = Math.max(1, agentSet.length), i; PAS.sh += PAS.s; PAS.lo += q[0]; PAS.th += q[1]; PAS.yrs++; PAS.sY[yr] = PAS.s;
  agentSet.forEach(function(a){ t[paZ(a)]++; }); for (i = 0; i < C; i++) PAS.cv += t[i]/n*paCover(PAS.z[i], p); if (POS) poTally(agentSet, p); }

// index.html line 5325
function paRes(out){ var S = PAS; out.paSh = S && S.yrs ? S.sh/S.yrs*100 : 0; out.paLo = S && S.yrs ? S.lo/S.yrs*100 : 0; out.paTh = S && S.yrs ? S.th/S.yrs*100 : 0;
  out.paCap = S && S.yu ? S.cb/S.yu*100 : 0; out.paOps = S && S.yu ? S.ob/S.yu*100 : 0; out.paDem = S && S.yu ? S.db/S.yu*100 : 0; out.paCv = S && S.yrs ? S.cv/S.yrs*100 : 0;
  [5, 10, 19, 39].forEach(function(y){ out['paS' + y] = S && S.sY[y] !== undefined ? S.sY[y]*100 : 0; out['paC' + y] = S && S.cY[y] !== undefined ? S.cY[y]*100 : 0; }); return out; }

// index.html line 5360
/* S62 (Nov 14, 2026; research-update prereg/2026-11-s62-ptf-realism.md; dev/DECISIONS.md S62; dev/reports/s62-ptf-realism.md): PTF REALISM. PTF_OPS null is
 * the default (every earlier run; POS null). An object (row option po: true for the defaults, or an object) runs only with open access (pa 'open' or
 * {fix}, which needs PTF by sector) and refuses S55's ops 'outside' (the payer readings below replace it); the no-programme run is untouched (POS needs
 * PAS). No draw is added (CRN holds). po {cost:'hub', bonus:'members', curve:'step', test:'sales'} is identical to no po.
 *  cost   a PTF's running cost per market dollar of sales, food (f) and utilities (u). 'full' (main): full-cost break-even for a not-for-profit whose
 *         capital comes from the reinvestment account: 1 less BEA's net operating surplus less depreciation (plan step 5: f 0.0494, u 0.0260/PTFS_UTIL,
 *         what owners, lenders and income tax take; capital replacement is in the cost) plus the reserve res (0.017: FMI's 2025 food-retail net margin,
 *         what a going concern keeps; swept 0). 'sector': observed costs and margins: f the stores' cost of goods plus operating expenses (1 - 0.288,
 *         Census's grocers' gross margin, + 0.2603, Census AIES 2024 NAICS 445 operating expenses over revenue); u public power's residential price over
 *         investor-owned utilities' in the same state (0.839, EIA-861 2024). 'hub': the Hub's cost structure as stated (BLEI paper 3.3): the cost is the
 *         PTF price, 1/epsilon, so there is no gap.
 *  pay    who pays when the PTF price sits below the running cost (D19, answered by Duke). 'source' (main): prices stay at the Hub's epsilon and the Source
 *         pays the gap, counted in programme cost (the cut less its free part, market price less running cost; the engine counted the cut less the
 *         step-5 forgone profit before). 'price': prices rise to the running cost, so the cut is 1 - cost per market dollar on food and utilities (no
 *         density test, no SZH addition, no cut on the other sectors) and nothing is paid. Under cost 'hub' nothing is paid either way. The growth
 *         rule's operations limit never binds under either payer.
 *  bonus  'workers' (main): the Hub gives the conversion-rate bonus (1.30 + theta) to PTF workers. Each worker (wage above 0, not retired, not outside
 *         the labour force) works the share k s of their hours at PTFs (k 0.02423: food and beverage stores plus utilities over all nonfarm jobs, CES
 *         2024; s the zone's PTF share of sales) and gets 1 + k s (pcb - 1) on their own rate; membership no longer gives it. 'members': S55's rule.
 *  wages  set as every wage is, by S60's BARGAIN where the row has it: the PTF payroll per market dollar (f 0.1035, u 0.1138: Census AIES 2024 payroll
 *         over revenue) rises by last year's earnings-weighted mean bargained raise, which raises the running cost (and the subsidy, or the price).
 *  hire   null (main): no hiring limit (the PTFs' staff are the sector's workers moving with its sales). A number: the population's PTF share may rise at
 *         most hire a year (a labelled design parameter with no source, swept 0.05 and 0.02: stress readings); capital capacity still applies.
 *  curve  the Hub's food epsilon by the share the test reads (D20, answered by Duke). 'smooth' (main): the PTF cost share 1/epsilon moves linearly from
 *         1/1.65 to 1/2.64 across [0.40 - w, 0.40 + w] (w 0.20, swept 0.10 and 0.40); 'step': 1.65 below 40%, 2.64 at or above (the papers' wording).
 *         theta is already continuous (0 below 55%, linear to 0.25 at 90%) and is unchanged.
 *  test   what the 40% and 55% tests read: 'sales' (main, S55: the zone's PTF share of sales); 'members' (the zone's share of adults who are members at
 *         the start of the year); 'capacity' (min(1, capacity / demand ceiling), population-wide: the share of demand the PTFs' capacity can serve).
 * Reported (PO_KEYS, rows with po): poSub the PTF subsidy and poFree the cut's free part ($ per adult-year, year-0 dollars, as cost); poSubSh poSub over
 * programme cost (%); poEpsF the mean food epsilon at PTF purchases (weighted by s); poCov PTF sales at PTF prices over running cost (%, mean over
 * adult-years); poWk PTF jobs per 100 adults; poWkH the PTF share of workers' hours (%); poBon the mean bonus over converting participants (rate
 * multiplier - 1, %); poHire the share of years from year 1 in which the hiring limit binds (%); poG the mean PTF payroll raise from bargaining (%). */
var PTF_OPS = null, PO_DEFAULTS = {cost:'full', pay:'source', res:0.017, bonus:'workers', curve:'smooth', w:0.20, test:'sales', hire:null}, POS = null;

// index.html line 5361
var PO_KEYS = ['poSub', 'poFree', 'poSubSh', 'poEpsF', 'poCov', 'poWk', 'poWkH', 'poBon', 'poHire', 'poG'];

// index.html line 5362
CFG.PO_SECTOR = {f:1 - 0.288 + 255664944/982152009, u:0.839}; CFG.PO_JOBS = (3228.2917 + 592.4583)/157693.8333; CFG.PO_PAY = {f:101653223/982152009, u:89920406/790488295};

// index.html line 5363
function poOpts(v){ var o = Object.assign({}, PO_DEFAULTS, v === true ? {} : v); o.res = +o.res; o.w = +o.w;
  if (['full', 'sector', 'hub'].indexOf(o.cost) < 0 || ['source', 'price'].indexOf(o.pay) < 0 || ['workers', 'members'].indexOf(o.bonus) < 0 || ['smooth', 'step'].indexOf(o.curve) < 0 || ['sales', 'members', 'capacity'].indexOf(o.test) < 0)
    throw new Error('po: cost full, sector or hub; pay source or price; bonus workers or members; curve smooth or step; test sales, members or capacity');
  if (!(o.res >= 0 && o.res < 0.5) || !(o.w >= 0 && o.w <= 0.40) || !(o.hire === null || (+o.hire > 0 && +o.hire <= 1))) throw new Error('po: res from 0 to 0.5, w from 0 to 0.40, hire null or a share above 0'); if (o.hire !== null) o.hire = +o.hire; return o; }

// index.html line 5367
function poForg(k){ /* the cut's free part (market price less running cost): food per food dollar; utilities per housing-component dollar (as step 5) */
  var P = PTF_OPS, M = COST || COST_DEFAULTS, g = POS ? POS.g : 0;
  if (k === 'f') return P.cost === 'sector' ? 1 - CFG.PO_SECTOR.f - CFG.PO_PAY.f*g : M.food - P.res - CFG.PO_PAY.f*g;
  return P.cost === 'sector' ? CFG.PTFS_UTIL*(1 - CFG.PO_SECTOR.u - CFG.PO_PAY.u*g) : M.util - CFG.PTFS_UTIL*(P.res + CFG.PO_PAY.u*g); }

// index.html line 5371
function poCost(k){ return k === 'f' ? 1 - poForg('f') : 1 - poForg('u')/CFG.PTFS_UTIL; }  /* running cost per market dollar (not for 'hub') */

// index.html line 5372
function poEps(sh){ var P = PTF_OPS, lo = CFG.PTFS_EPS_FOOD_LOW, hi = CFG.PTFS_EPS_FOOD, t = CFG.PTFS_LOW_DENS;  /* the Hub's food epsilon at the share the test reads */
  if (P.curve === 'step' || !(P.w > 0)) return sh < t ? lo : hi; var x = Math.min(1, Math.max(0, (sh - (t - P.w))/(2*P.w))); return 1/((1 - x)/lo + x/hi); }

// index.html line 5374
function poPrice(){ return PTF_OPS.pay === 'price' && PTF_OPS.cost !== 'hub'; }

// index.html line 5375
function poTZ(z){ var P = PTF_OPS; return P.test === 'members' ? POS.mz[z] : P.test === 'capacity' ? POS.cs : PAS.z[z]; }  /* the share a zone's tests read */

// index.html line 5376
function poTPop(){ if (PTF_OPS.test === 'sales') return PAS.s; var s = 0, i; for (i = 0; i < PAS.z.length; i++) s += POS.wz[i]*poTZ(i); return s; }

// index.html line 5378
function poCutParts(sh, ts, p){ /* [food cut, utilities cut] per market dollar at the zone's test share ts (before the purchase share s and the 0.95 cap) */
  if (poPrice()) return [Math.max(0, 1 - poCost('f')), Math.max(0, 1 - poCost('u'))];
  var g = p.szh ? (0.12 + p.szhCoh*0.04)/0.12 : 1; return [g*(1 - 1/poEps(ts)), g*(1 - 1/CFG.PTFS_EPS_UTIL)]; }

// index.html line 5381
function poCover(i, p){ /* zone i's PTF sales at PTF prices over running cost (food and utilities at basket weights) */
  if (PTF_OPS.cost === 'hub') return 1; var c = poCutParts(PAS.z[i], poTZ(i), p), f = CFG.BASKET.food, u = CFG.BASKET.housing*CFG.PTFS_UTIL;
  return (f*Math.max(0, 1 - c[0]) + u*Math.max(0, 1 - c[1]))/(f*poCost('f') + u*poCost('u')); }

// index.html line 5384
function poBonus(a, p, pcb){ if (PTF_OPS.bonus === 'members') return (p.ptf && a.inPTF) ? pcb : 1.0;  /* the conversion-rate multiplier PTF work gives */
  if (!p.ptf || !poWorker(a)) return 1.0; return 1 + Math.min(1, CFG.PO_JOBS*paW(a))*(pcb - 1); }

// index.html line 5386
function poWorker(a){ return !a._ret && !(LFS && a._lf) && a.wage > 0; }

// index.html line 5387
function poFree(a, M, cfP, fS, hS){ /* the part of the adult's PTF cut that costs nothing (market price less running cost; all of it under 'hub' or 'price') */
  var cut = M*(1 - cfP); if (PTF_OPS.cost === 'hub' || poPrice()) return cut;
  return Math.max(0, Math.min(cut, M*(fS*poForg('f') + hS*poForg('u'))*paW(a))); }

// index.html line 5390
function poPtfsCut(a, HHA, p, quiet, full){ /* ptfsCut under PTF_OPS: the Hub's epsilon by the test's share (step or smooth), or prices at running cost */
  var s = ptfsShares(a, HHA), pr = poPrice(), eF = pr ? 1/Math.min(1, Math.max(1e-9, poCost('f'))) : poEps(poTZ(paZ(a))), eU = pr ? 1/Math.min(1, Math.max(1e-9, poCost('u'))) : CFG.PTFS_EPS_UTIL, o = pr ? 0 : PTFS.other;
  var c = (PRICE && PRICE.sxF ? sxPtf(s.f, s.h, eF, eU) : s.f*(1 - 1/eF) + s.h*CFG.PTFS_UTIL*(1 - 1/eU)) + (s.t + (HLS && HLS.planOn ? 0 : s.m) + s.k)*o; if (p.szh && !pr) c *= (0.12 + p.szhCoh*0.04)/0.12;
  if (!full) c = paW(a)*Math.min(0.95, c);
  if (PFS && !quiet){ PFS.cut += c; PFS.cn++; POS.eN += paW(a)*eF; POS.eD += paW(a); } return Math.min(0.95, c); }

// index.html line 5398
function poInit(agents){ var C = PAS.z.length, wz = new Float64Array(C), n = Math.max(1, agents.length);
  agents.forEach(function(a){ wz[paZ(a)] += 1/n; });
  POS = {wz:wz, mz:new Float64Array(C), cs:0, g:0, gN:0, gD:0, gY:0, gy:0, sub:0, fr:0, eN:0, eD:0, cv:0, cy:0, wk:0, wh:0, wn:0, ay:0, bn:0, bc:0, hb:0, yu:0}; }

// index.html line 5401
function poYear(agentSet, yr, p){ /* start of the year, inside paYear before growth: shares the tests read, last year's bargained payroll raise (no draw) */
  var S = POS, C = PAS.z.length, t = new Float64Array(C), m = new Float64Array(C), n = Math.max(1, agentSet.length), i;
  agentSet.forEach(function(a){ var j = paZ(a); t[j]++; if (a.inPTF) m[j]++; }); for (i = 0; i < C; i++){ S.wz[i] = t[i]/n; S.mz[i] = m[i]/Math.max(1, t[i]); }
  S.g = S.gD > 0 ? S.gN/S.gD : 0; S.gN = 0; S.gD = 0; if (yr > 0){ S.gY += S.g; S.gy++; }
  S.cs = Math.min(1, (yr > 0 && PAS.cY[yr] !== undefined ? PAS.cY[yr] : paCapNow(0, p))/PA.dem); }

// index.html line 5406
function poTally(agentSet, p){ /* after growth: the year's coverage, jobs and hours (reporting only) */
  var S = POS, n = Math.max(1, agentSet.length), wk = 0, wh = 0, i;
  agentSet.forEach(function(a){ if (!poWorker(a)) return; wk++; wh += Math.min(1, CFG.PO_JOBS*paW(a)); });
  for (i = 0; i < PAS.z.length; i++) S.cv += S.wz[i]*poCover(i, p); S.cy++;
  S.wk += wh/n*100; S.wh += wk > 0 ? wh/wk*100 : 0; S.wn++; }

// index.html line 5411
function poRes(out, NY, cost){ var S = POS; out.poSub = S.sub/Math.max(1, NY); out.poFree = S.fr/Math.max(1, NY); out.poSubSh = cost > 0 ? out.poSub/cost*100 : 0;
  out.poEpsF = S.eD > 0 ? S.eN/S.eD : 0; out.poCov = S.cy ? S.cv/S.cy*100 : 0; out.poWk = S.wn ? S.wk/S.wn : 0; out.poWkH = S.wn ? S.wh/S.wn : 0;
  out.poBon = S.bc ? S.bn/S.bc*100 : 0; out.poHire = S.yu ? S.hb/S.yu*100 : 0; out.poG = S.gy ? S.gY/S.gy*100 : 0; return out; }

// index.html line 5436
/* S37 (Oct 31, 2026; dev/reports/community-layer.md; dev/DECISIONS.md S37): THE COMMUNITY AND ZONE LAYER. null = off (every earlier run: the tests that
 * read PTF density read the share of all adults who are members). When an object (row option cl), and only in runs with PTF:
 *  - Communities. At the start of the run the households (each adult alone, without households) are dealt into round(n/k) communities of about k adults,
 *    in an order drawn on the switch's own stream mulberry32(seed + 600059), one draw per household. Households are never split. k (100) is a design
 *    parameter: how many simulated adults stand for one zone, not a zone's population (the Hub: zones "scale from neighborhood to regional"); swept 50
 *    and 250. An adult who dies is replaced in the same community (no draw).
 *  - Zones. When zones form (SZH and PTF on; with zc, CIP on too: the Hub forms zones through CIP surveys), the starting PTF members are placed together,
 *    as Social Zone Harmonization "organizes the geographic deployment of PTF businesses": communities are filled in turn with member households until
 *    members are a share f of the community, then with non-member households up to its size; the last zone takes the members left. f (0.5: the Hub's
 *    zone formation by survey majority) is a design parameter, swept 2/3 (the zone charter's supermajority) and 1. The other communities are dealt as
 *    above. Who is a member does not change (the same draws decide it), only who lives with whom. No zones form if members are already a share f of all
 *    adults.
 *  - Local density. Each year each community's member share replaces the share of all adults in the three tests that read PTF density: the food price
 *    cut (epsilon 2.64, or 1.65 below 40%: the BLEI paper, "below approximately 40% PTF merchant participation in a given zone"); the synergy
 *    coefficient theta (0 below 55%, 0.25 at 90%, the same paragraph), which sets the PTF rate bonus, the SZH induction into PTF and the design's BLEI
 *    term; and the Bass imitation term of PTF adoption (bass 'local'; 'pop' keeps it population-wide). Each share is taken at the point of the year where
 *    the population share is taken, so with one community (k at least n) every figure equals the switch off. Price damping and the PTF's capacity stay
 *    population-wide (a stated limit: capacity is not placed by zone).
 *  - Not modelled: PTH density. The Hub's one PTH quantity is a count (break-even at 30-40 households), which a sample of a zone's adults cannot show,
 *    and the "community coherence" PTH needs has no size.
 * Reported (CL_KEYS): clN communities; clZ zones formed at the start; clSd the spread of the member share across communities (standard deviation, points,
 * mean over years); clHi the share of members living where the share is at least 40% (%, mean over years); clTh the same where theta is above 0 (%). */
var COMM = null, COMM_DEFAULTS = {k:100, f:0.5, zc:false, bass:'local'}, CMS = null;

// index.html line 5437
var CL_KEYS = ['clN', 'clZ', 'clSd', 'clHi', 'clTh'];

// index.html line 5453
/* S6 (Oct 31, 2026; research-update prereg/2026-11-c22-coverage-adequacy.md; dev/reports/c22-coverage-adequacy.md): who receives the BU and whether it
 * covers basic needs (NEEC criterion C2.2: unconditional provision covering 100% of housing, food, healthcare and utilities for all residents). Off by
 * default (C22 null): nothing below runs and every figure is unchanged. Study row option c22: {u, auto, idx}.
 *  - u: the Act's status rule (section 102: "every citizen and legal resident"). A share u of households is not eligible: their adults never receive
 *    the BU (they cannot join, and emergency enrolment skips them); everything else about them is unchanged. Drawn once per household (a single adult is
 *    a household of one) on its own stream (seed + 600067), so no draw moves on any other stream. u = 0 draws nothing.
 *  - auto: the Act's "distribution shall be automatic": every eligible adult receives the BU from year 0 and nobody leaves (taking part costs nothing).
 *    Joining still means what it means in the model (BU, octaves, conversion); the BU's receipt no longer waits on a choice.
 *  - idx 'needs': the BU indexed every year to the price of the C2.2 needs (food, housing with utilities, medical care: C22_NEEDS) instead of the
 *    cost-of-living adjustment's 5% trigger. With it, a BU set at c22NeedsBU() keeps paying for those needs at the prices a non-member pays.
 * Reported (C22_KEYS; reporting only, no draw): c22PY the share of adult-years in which the BU the adult receives (12 months, the adult's share of the
 *   household's allowance) is at least the cost of the C2.2 needs at market prices (the adult's share of the household's needs; no member price cut);
 *   c22R the mean of that ratio capped at 1 (%); buPY the share of adult-years receiving the BU; elN the share of adults not eligible (%); elF0, elW,
 *   elRes those adults' share of years below the cost of living, share with too little wealth at the end, and mean real resources (as gNonF0, gNonW,
 *   gNonRes). With u > 0 on the no-programme row as well, the same adults are found there (the draw does not depend on the row). */
var C22 = null, C22_DEFAULTS = {u:0, auto:false, idx:false}, C22S = null, C22_NEEDS = ['food', 'housing', 'medical'];

// index.html line 5454
var C22_KEYS = ['c22PY', 'c22R', 'buPY', 'elN', 'elF0', 'elW', 'elRes'];

// index.html line 5455
function c22Share(comp){ var s = 0; C22_NEEDS.forEach(function(k){ s += CFG.BASKET[k]*(comp ? comp[k] : 1); }); return s; }

// index.html line 5456
function c22NeedsBU(){ return CFG.LIVING_WAGE_ANNUAL*c22Share(null)/12; }  /* a single adult's C2.2 needs a month at reference prices (MIT 2026): $1,788.40 */

// index.html line 5457
function c22Init(agents, seed){
  C22S = {n:0, k:0, r:0, b:0};
  if (C22.u > 0){ var r = mulberry32(seed + 600067), seen = {};
    agents.forEach(function(a){ var H = a._hh; if (H){ if (seen[H.id]) return; seen[H.id] = 1; } var x = r() < C22.u; (H ? H.a : [a]).forEach(function(b){ if (x){ b._inel = true; b.inCCO = false; } }); }); }
  if (C22.auto) agents.forEach(function(a){ if (!a._inel) a.inCCO = true; });
}

// index.html line 5463
function c22Res(out, g, n){ var S = C22S;
  out.c22PY = S && S.n ? S.k/S.n*100 : 0; out.c22R = S && S.n ? S.r/S.n*100 : 0; out.buPY = S && S.n ? S.b/S.n*100 : 0;
  out.elN = g.k/Math.max(1, n)*100; out.elF0 = g.f0; out.elW = g.wp; out.elRes = g.res; return out; }

// index.html line 5475
/* S14 (Oct 31, 2026; research-update prereg/2026-11-lw-weighted-line.md; dev/reports/lw-weighted-line.md): the cost-of-living line at another level.
 * CFG.LIVING_WAGE_ANNUAL ($49,370) is the unweighted mean of MIT's 51 state one-adult living wages. Three sets of constants are fitted at that level
 * from the eight MIT state pages (sources/households.py): the basket shares CFG.BASKET, the household ratios CFG.HH_RATIO and the childcare dollars
 * CFG.HH_CHILDCARE; project pay (PROJ_DEFAULTS.pay) is the line over 2,080 hours. Every other dollar that follows the line reads it when it runs.
 * Study row option lw: a key of CFG.LW_SETS (sources/lw_line.py prints them): the line and the three sets refitted at it, by the same method. For that
 * row only, lwSet writes them in place (the objects keep their identity) and lwReset puts the values back; the no-programme reference path is keyed
 * by the line. Off by default (LW null): nothing changes and every figure is unchanged. No draw is added.
 *  ext: $51,201.28, a population-weighted mean of MIT's 51 states computed outside the project (v4.11; not re-derived: MIT licenses data for more
 *       than ten locations). bea: $51,837.76, the line x the population-weighted over unweighted ratio of a fit on BEA's price parities (sources/lw_bea.py). */
CFG.LW_SETS = {"ext":{"L":51201.28,"basket":{"food":0.0884,"housing":0.2881,"medical":0.0653,"transport":0.1892,"civic":0.0657,"internet":0.0302,"other":0.0903,"taxes":0.1828},"ratio":{"1a0k":{"food":1.0,"housing":1.0,"medical":1.0,"transport":1.0,"civic":1.0,"internet":1.0,"other":1.0,"taxes":1.0},"1a1k":{"food":1.466864,"housing":1.361395,"medical":2.867701,"transport":1.157298,"civic":1.688056,"internet":1.0,"other":1.818302,"taxes":1.551209},"1a2k":{"food":2.197915,"housing":1.361395,"medical":2.916119,"transport":1.457795,"civic":2.226143,"internet":1.0,"other":1.987649,"taxes":2.270729},"1a3k":{"food":2.925249,"housing":1.776497,"medical":2.969052,"transport":1.677398,"civic":2.535163,"internet":1.0,"other":2.164198,"taxes":3.179257},"2a0k":{"food":1.833269,"housing":1.098858,"medical":2.169752,"transport":1.157298,"civic":1.688056,"internet":1.379819,"other":1.818302,"taxes":1.091745},"2a1k":{"food":2.275222,"housing":1.361395,"medical":3.171906,"transport":1.457795,"civic":2.226143,"internet":1.379819,"other":2.03575,"taxes":1.652083},"2a2k":{"food":2.926572,"housing":1.361395,"medical":3.270417,"transport":1.677398,"civic":2.535163,"internet":1.379819,"other":2.164198,"taxes":2.101813},"2a3k":{"food":3.570596,"housing":1.776497,"medical":3.380697,"transport":1.877953,"civic":2.838346,"internet":1.379819,"other":2.423008,"taxes":2.811523}},"care":[13341.57,12099.58,7936.27]},"bea":{"L":51837.76,"basket":{"food":0.0878,"housing":0.292,"medical":0.0643,"transport":0.1871,"civic":0.0655,"internet":0.0298,"other":0.0896,"taxes":0.1839},"ratio":{"1a0k":{"food":1.0,"housing":1.0,"medical":1.0,"transport":1.0,"civic":1.0,"internet":1.0,"other":1.0,"taxes":1.0},"1a1k":{"food":1.466869,"housing":1.362664,"medical":2.87653,"transport":1.157296,"civic":1.688058,"internet":1.0,"other":1.818302,"taxes":1.56048},"1a2k":{"food":2.197922,"housing":1.362664,"medical":2.925173,"transport":1.457792,"civic":2.226154,"internet":1.0,"other":1.987654,"taxes":2.292716},"1a3k":{"food":2.925258,"housing":1.779812,"medical":2.978362,"transport":1.677396,"civic":2.535178,"internet":1.0,"other":2.164201,"taxes":3.210037},"2a0k":{"food":1.833277,"housing":1.098208,"medical":2.177526,"transport":1.157296,"civic":1.688058,"internet":1.381231,"other":1.818302,"taxes":1.088714},"2a1k":{"food":2.275228,"housing":1.362664,"medical":3.182172,"transport":1.457792,"civic":2.226154,"internet":1.381231,"other":2.035754,"taxes":1.652747},"2a2k":{"food":2.926579,"housing":1.362664,"medical":3.281151,"transport":1.677396,"civic":2.535178,"internet":1.381231,"other":2.164201,"taxes":2.111923},"2a3k":{"food":3.570608,"housing":1.779812,"medical":3.391953,"transport":1.877951,"civic":2.838361,"internet":1.381231,"other":2.423011,"taxes":2.837382}},"care":[13490.28,12260.11,7975.38]}};

// index.html line 5476
var LW = null;

// index.html line 5477
function lwSet(id){
  if (!id) return null; var L = CFG.LW_SETS[id]; if (!L) throw new Error('lw: no line ' + id);
  var sv = {lw:LW, L:CFG.LIVING_WAGE_ANNUAL, b:Object.assign({}, CFG.BASKET), r:JSON.parse(JSON.stringify(CFG.HH_RATIO)), c:CFG.HH_CHILDCARE.slice(), pay:PROJ_DEFAULTS.pay};
  CFG.LIVING_WAGE_ANNUAL = L.L; Object.assign(CFG.BASKET, L.basket); Object.keys(L.ratio).forEach(function(t){ Object.assign(CFG.HH_RATIO[t], L.ratio[t]); });
  L.care.forEach(function(x, i){ CFG.HH_CHILDCARE[i] = x; }); PROJ_DEFAULTS.pay = L.L/2080; LW = id; return sv; }

// index.html line 5482
function lwReset(sv){
  if (!sv) return; CFG.LIVING_WAGE_ANNUAL = sv.L; Object.assign(CFG.BASKET, sv.b); Object.keys(sv.r).forEach(function(t){ Object.assign(CFG.HH_RATIO[t], sv.r[t]); });
  sv.c.forEach(function(x, i){ CFG.HH_CHILDCARE[i] = x; }); PROJ_DEFAULTS.pay = sv.pay; LW = sv.lw; }

// index.html line 5531
/* v5.4 item 5 (Oct 7, 2026; dev/reports/v5-21-v54-design.md, 1.6; dev/DECISIONS.md Session 40): A DISASTER. null = off (every earlier run). When an object
 * (v54 row option dis), in year yr (default 6, the model's Year 7) a share of households (share 0.25: design, swept 0.10 and 0.50) is hit, the same
 * households in both runs (one draw per adult on the switch's own stream mulberry32(seed + 600053), the head's draw deciding for the household; a second
 * draw for federal aid). A hit household:
 *  - loses loss dollars of wealth (10,000 in year-0 dollars, moved with the price level: design, swept 5,000 and 25,000; the uninsured part of the damage) and
 *    weeks of pay (4: design, swept 0 and 12; work stops while the area recovers), shared equally among its adults;
 *  - receives the federal Individuals and Households Program's mean award, CFG.DIS_AID ($3,092), with chance CFG.DIS_APPR (50.6%; OpenFEMA, disasters
 *    4400 and later, sources/fema_ihp.py), in both runs;
 *  - with the programme, if taking part: an emergency distribution of emerg (0.20) times the year's BU (the Roadmap's Natural Disaster Response "preload
 *    emergency units" gives no amount; the Recession Protocol's 20% is used, a modelling assumption). Suspended expiry has no effect in the release model,
 *    where BU are allocated and used within the year; Reconstruction Collectives and "enhanced PTF support" have no size in the Hub and are not modelled.
 * Reported (DIS_KEYS): the share of adults hit, and of them the share whose real wealth is back to its level before the disaster within 3 years and by the
 * end, and the mean years it takes those who recover; the same two shares for adults not hit (dsCtl3, dsCtlEnd: real wealth back to its level at the
 * start of the disaster year), so the disaster's own effect is the difference (prices rise much faster with the programme, which slows every adult's return). */
var DIS = null, DIS_DEFAULTS = {yr:6, share:0.25, loss:10000, weeks:4, emerg:0.20}, DSS = null;

// index.html line 5532
CFG.DIS_AID = 3092; CFG.DIS_APPR = 0.506;

// index.html line 5533
var DIS_KEYS = ['dsHit', 'dsRec3', 'dsRecEnd', 'dsRecYrs', 'dsCtl3', 'dsCtlEnd'];

// index.html line 5560
/* v5.4: one entry point for the round's switches, per row (tbStudy's row option v54, an object; absent = every switch as it is). Returns the old values. */
/* ─── Session 2a (Oct 13, 2026): HEALTH COVERAGE MADE EXPLICIT, setting A (today's system) ───────────────────────────────────────────
 * Design and sources: dev/reports/v5-25-health-today.md; choices: dev/DECISIONS.md, Session 2a. HEALTH null (the default) adds nothing: no draw, no
 * state any rule reads (dev/tools/guard_test.js proves it). With HEALTH on, every person (each adult and, with households, each child) has a yearly
 * medical need in year-0 dollars: the CMS spending for the age (adults without an age take the working-age figure), times a lasting chronic state
 * (multiple chronic conditions, MEPS), a spread fitted to MEPS's concentration of spending, and an acute shock. The draws come from a counter-based
 * hash of (seed, person, year, slot), not from any stream the engine uses, so the main stream's eight draws per adult-year and every other stream are
 * untouched, and a person's draws are the same in the programme run and the no-programme run. Coverage each year: Medicare from 65 (only adults who
 * age reach it), Medicaid by the shared income test (incomeTest; expansion and non-expansion limits), employer coverage (more likely at higher pay; lost
 * in a year mostly out of work), the ACA marketplace (premium tax credit by income), or none. Out-of-pocket cost follows each plan's deductible,
 * coinsurance and limit; a household whose bills are high against its income skips part of its non-acute care; bills it cannot pay become medical
 * debt (tracked; the debt is the negative wealth the bills caused). Who pays is recorded (household, employer, government, insurer).
 * Calibration (no constant tuned to a result): the household's expected premiums and out-of-pocket cost are scaled, by household type, so that their
 * average equals the basket's medical line (6.85% of the MIT basket, by household type). Each household then pays the difference between its own bill
 * and its line, in cash, on top of the basket (which still carries the average line, so BU, PTF's sector cut and the price module see what they saw).
 * Turning it on adds spread, not cost. */
var HEALTH = null, HLS = null;

// index.html line 5561
var HEALTH_DEFAULTS = {set:'A', exp:true, skip:0.5, persist:0.9, countBU:false, cs:'central', start:1, adm:0.011, cap:0.5, induce:0.25, gap:0.04, sel:0.11, priv:0.55, gov:'fixed'};

// index.html line 5569
/* Session 2c (Oct 13, 2026; ledger decision d194; dev/DECISIONS.md, Session 2c): GOVERNMENT'S SHARE UNDER SINGLE PAYER, FIXED. Under B and C the government keeps paying
 * what it pays today (Medicaid, the premium tax credits, Medicare), and the health tax pays the rest. HEALTH.gov 'float' (session 2b's behaviour, kept as a
 * sensitivity row) reads that share from the run's own incomes, so when the programme raises incomes and fewer people would qualify for Medicaid, the government
 * pays less and the flat health tax rises for everyone: a change in bookkeeping, not in anyone's care or coverage. HEALTH.gov 'fixed' (the main runs) holds it,
 * year by year, at the no-programme run's level per person, for the same seed, health setting and safety net (HL_GOVREF, filled by tbStudy's no-programme run
 * of the row; a programme run without such a reference falls back to 'float', and hlGovFix reports the share of plan years that were fixed). Medicare's part
 * depends on age and need only, so it is the same in both runs; what the fixing holds is the income-tested part. No draw, no state outside the health block. */
var HL_GOVREF = null;

// index.html line 5586
/* Session 2c (ledger step s141; dev/reports/v5-28-safety-net-grid.md, section 4; dev/DECISIONS.md, Session 2c): THE PREVENTION LINK. PREV null (the default) adds
 * nothing: no draw, no state any rule reads. When an object (row option pv), an adult's chance of entering the lasting chronic state (two or more chronic conditions,
 * the state that raises need; persistence is unchanged) depends on last year's exposure to two things the programme, the safety net and single payer can change:
 *  - care skipped for cost (the person skipped some care last year under today's system; nobody skips in the years under B or C): risk ratio PREV.care;
 *  - food access: the chance that the household was food insecure, read from its income for food last year (money income as in the Medicaid test, plus last
 *    year's safety-net benefits and BU allowance, year-0 dollars) against the poverty guideline, by USDA ERS's 2023 rates (Household Food Security in the United
 *    States in 2023, ERR-337, Table 2: 38.7% under 1.00; 34.1% from 1.00 to 1.30 and 27.6% from 1.30 to 1.85, derived from the table's counts; 7.5% at 1.85 and
 *    over): risk ratio PREV.food, applied as the expected weight 1 + (food - 1) x P(food insecure).
 * The weights multiply. So that the chronic share stays MEPS's 25.9% in today's world, each run divides by the mean weight over adults not in the chronic state in
 * year 0, whose exposures do not depend on the programme (year 0's incomes are the pay rates; no benefit or allowance has been paid yet): the same in both runs.
 * Cases (each labelled in PREV_CASES): zero (the switch off: the Oregon Health Insurance Experiment found no detectable effect of Medicaid on blood pressure,
 * cholesterol or blood sugar control in two years; Baicker et al., NEJM 2013), central (care 1.10, food 1.10: design values, about half of the associations
 * below, because associations in observational data overstate causal effects), high (care 1.51: people who restricted medicines for cost reported a significant
 * decline in health over two to three years 32.1% of the time against 21.2%, Heisler et al., Medical Care 2004, a risk ratio of 1.51, derived; food 1.30: the
 * largest significant adjusted relative risk among food-insecure poor adults in NHANES 1999-2004, for hyperlipidemia; hypertension 1.20, Seligman et al., J Nutr 2010).
 * Diet quality beyond access, and any effect on how long the chronic state lasts, are not modelled (stated limits). */
var PREV = null;

// index.html line 5587
var PREV_CASES = {central:{care:1.10, food:1.10}, high:{care:1.51, food:1.30}};

// index.html line 5588
var PREV_DEFAULTS = PREV_CASES.central;

// index.html line 5589
CFG.PV_FI = [[1.00, 0.387], [1.30, 0.341], [1.85, 0.276], [Infinity, 0.075]];  /* food insecurity by income over the poverty guideline (upper bound, share): USDA ERS, ERR-337, 2023 */

// index.html line 5610
/* Setting C (session 2b, step 2; dev/reports/v5-27-health-financing.md): SINGLE PAYER WITH A PRIVATE LAYER. Everything in setting B holds (one public base for everyone
 * from HEALTH.start, no premiums and no out-of-pocket cost, the same care, cost per unit, waits, administrative jobs, health tax and price rule), plus:
 *  - Medicaid kept: people who would be on Medicaid today (the shared income test, take-up as in setting A) stay on Medicaid, run by states and counties and paid
 *    by government as today. Their care costs what the public base pays per unit (a modelling assumption: keeping Medicaid changes who runs it, not its unit
 *    cost), and they do not take private plans;
 *  - a private layer: the household of anyone else may take a private plan that the public programme pays per person, as Medicare Advantage is paid. Share
 *    HEALTH.priv (0.55: Medicare Advantage's share of beneficiaries with Parts A and B in 2025, MedPAC March 2026; applied at every age, a modelling assumption),
 *    one draw per household head (hash slot 94), lasting. For each enrollee the programme pays the enrollee's public-base cost times (1 + gap) x (1 + sel):
 *      gap  the payment gap from coding: plans record more diagnoses, so risk scores and payments are higher than for the same person in the public base.
 *           MedPAC (March 2026 report; press release Mar 12, 2026): about 4% in 2026 after CMS's coding adjustment (central); 0 (low: risk adjustment removes
 *           it); 8% (high: MedPAC's 2025 estimate, 20% in all less selection's 11%, before the V28 risk model was fully in place);
 *      sel  selection: healthier people choose private plans, so the payment set by risk score exceeds what the enrollees would have cost the public base
 *           (and the public base keeps the costlier people). MedPAC: about 11% in 2026 and in 2025 (central); half and one and a half times (5.5% and 16.5%,
 *           design values) as low and high.
 *    MedPAC's total for 2026 is about 14% ($76 billion); the central case's (1.04 x 1.11 = 15.4%) is close. Enrollees are drawn at random and selection enters as
 *    the payment factor, which gives the same programme cost as a pool of healthier enrollees paid at average rates; who chooses, and why, is not modelled
 *    (a stated limit). The extra payment funds plans' extra benefits and profit (MedPAC: rebates go to lower cost sharing, extra benefits, Part D and Part B
 *    premiums, and administration and profit); here it is counted as programme cost only, not as value to enrollees (a stated limit).
 * The health tax pays the larger plan cost, so the setting's question is how much of setting B's savings the private layer gives back. */
CFG.HL_HOSP = 1634.7;  /* hospital care spending, 2024, $ billion (CMS National Health Expenditure fact sheet): the base for the preprint's avoided emergency and inpatient care (CFG.HL_B.avoided) */

// index.html line 5633
/* Setting B (session 2a, step 5): SINGLE PAYER, PUBLIC PLAN ONLY (as in the Medicare for All Act). From year HEALTH.start (1; year 0 is today's system, which sets
 * the calibration and the first incomes) everyone is covered by one public plan with no premiums and no out-of-pocket cost, paid for by a flat health tax on money
 * income. Today's system keeps running in the background as the counterfactual (who would have been covered how, and what each payer would have paid), so the
 * comparison is like for like, person by person, every year:
 *  - care: everyone's full need (nothing skipped for cost), plus HEALTH.induce (25%) more for people who would have been uninsured (the Oregon Health Insurance
 *    Experiment: Medicaid coverage raised spending about 25%; Finkelstein et al., QJE 2012);
 *  - cost per unit of care: today's (all payers, after the calibration) times the case's factor, from the Yale preprint (Galvani, Pandey, Wells and Ye, medRxiv
 *    2026, doi 10.64898/2026.07.22.26358689; not peer reviewed): 2024 spending $5,278.6 billion; gross savings $1,345.2 billion (drug prices 377.5, Medicare rates
 *    for providers 295.6, administration 286.3, fraud 285.7, avoided emergency and inpatient care 100.0); added $304.0 billion (induced use 197.7, dental 54.7,
 *    care now unpaid 51.7); net 19.7%. Per unit: central 1 - 1345.2/5278.6; cautious (net savings of at least $663.3 billion, 12.6%: the preprint's lower bound
 *    with the drug and fraud savings cut) 1 - (663.3 + 304.0)/5278.6; costs run higher (providers paid near commercial rates, so the savings vanish)
 *    1 - 304.0/5278.6, so that with the added care the total is about today's. Dental and the payment for care now unpaid (54.7 + 51.7 = 2.0% of spending) are
 *    added as a share of today's spending; the model's own added care (skipped care, induced use) replaces the preprint's induced use;
 *  - financing: the government keeps paying what it pays today (Medicaid, Medicare, tax credits: financed as now, inside the basket's taxes); the rest of the
 *    public plan's cost is a new flat tax on households' money income (the same base as the Medicaid test). The employer's former premium share comes back to
 *    the household as a cost offset (it was counted as pay forgone; d-health-price rule b: health money enters costs, never total cash income);
 *  - access: today's care delivered is the system's capacity; capacity grows to meet the share HEALTH.cap (0.5, a design parameter swept 0.25-1) of the extra
 *    demand; demand beyond capacity waits (the share of needed care delayed), and the capped budget pays for the care delivered;
 *  - administrative jobs: at the start, the share HEALTH.adm (1.1%) of working adults lose their jobs (about 1.8 million insurance and billing jobs, Pollin et
 *    al., PERI 2018, as reported by secondary summaries: the report itself was not read; over about 160 million employed) and enter the job-loss path: a spell
 *    of the usual length, unemployment insurance as for anyone, and the pay cut on return that a permanent loss carries. Only with the job-loss part on;
 *  - prices: no market price response for medical care (d-health-price rule a): the public payer sets rates; a shortage shows as waits. */
CFG.HL_B = {base:5278.6, gross:{central:1345.2, cautious:663.3 + 304.0, high:304.0}, added:304.0, extra:54.7 + 51.7, avoided:100.0};

// index.html line 5634
CFG.HL_AGE = [[17, 4217], [44, 6669], [64, 12577], [84, 20503], [999, 35995]];  /* personal health care per person by age (upper age, $), 2020: CMS National Health Expenditure, Age and Sex tables (0-18, 19-44, 45-64, 65-84, 85+; the model's adults start at 18) */

// index.html line 5635
CFG.HL_AGE_NONE = 9154;  /* CMS 2020, working-age adults (19-64): for adults the model gives no age (no ageing) */

// index.html line 5636
CFG.HL_LEVEL = 15474/12530;  /* to year-0 dollars: national health spending per person, 2024 ($15,474, CMS NHE fact sheet) over 2020 ($12,530) */

// index.html line 5637
CFG.HL_MCC = {prev:0.259, share:0.57};  /* adults treated for two or more chronic conditions: 25.9% of adults, 57.0% of spending (MEPS 2012; AHRQ Statistical Brief 485) */

// index.html line 5638
CFG.HL_ACUTE = {p:0.08, share:0.30};  /* an acute event (a hospital stay) in a year and its share of mean spending: design parameters (swept), not sourced */

// index.html line 5639
CFG.HL_SIGMA = {base:1.5, acute:0.6};  /* log spreads, fitted to MEPS 2017's concentration (top 1% 21.9%, top 5% 50.1%, bottom half 2.9% of spending; Statistical Brief 528): the fit gives 22.2 / 50.4 / 3.5 */

// index.html line 5640
CFG.HL_FPL = {one:15650, add:5500};  /* HHS poverty guidelines 2025, 48 states: one person, each added person */

// index.html line 5641
CFG.HL_MCAID = {exp:1.38, parentNx:0.405, adultNx:0, kids:2.55, take:0.80, takeKids:0.90};  /* income limits, share of the poverty guideline (KFF state indicators, Jan 2026): expansion states 138%; non-expansion parents, the median of the ten states' limits (15-105%); non-expansion adults without children 0; children (Medicaid and CHIP) 255%. Take-up among the eligible: design parameters */

// index.html line 5642
CFG.HL_ESI = {premS:9325, wkS:1440, premF:26993, wkF:6850, ded:1886, coins:0.20, oopMax:9200, offer:[0.20, 0.80]};  /* KFF Employer Health Benefits Survey 2025: premiums and the worker's share (single, family), single deductible; coinsurance 20% (design); the ACA's 2025 out-of-pocket limit; offer-and-take-up rising from 20% at the lowest pay to 80% at the highest, set so about 63% of the model's adult-years have employer coverage (Census 2024, ages 19-64: private coverage 74.0%, of which about 11 points direct purchase) */

// index.html line 5643
CFG.HL_MKT = {prem:5964, kid:0.5, ded:2759, coins:0.20, oopMax:9200, oopCSR:3050, take:0.60};  /* KFF: benchmark silver premium for a 40-year-old, 2025 ($497 a month); a child's at half (design); average marketplace deductible 2025; cost-sharing reductions cap out-of-pocket cost at $3,050 under 200% of poverty (2025); take-up among those not otherwise covered, set so about 11-13% of the model's adult-years are uninsured (Census 2024: 11% at 19-64; the model has too few adults on Medicaid, see the report) */

// index.html line 5644
CFG.HL_MCARE = {partB:2220, ded:257, coins:0.20, oopMax:9350};  /* Medicare 2025: Part B premium ($185 a month) and deductible, 20% coinsurance, capped at the Medicare Advantage in-network limit (a stand-in for supplemental cover) */

// index.html line 5645
CFG.HL_UNDER = {oop:0.10, oopLow:0.05, lowFpl:2.0, ded:0.05};  /* Commonwealth Fund: insured all year with out-of-pocket cost (not premiums) of 10% of income or more, 5% under 200% of poverty, or a deductible of 5% of income or more */

// index.html line 5646
CFG.HL_DEBT_LINE = 250;  /* medical debt counted above $250 (KFF analysis of SIPP 2021: about 1 in 12 adults) */

// index.html line 5647
var HL_KEYS = ['hlEsi', 'hlMkt', 'hlMcaid', 'hlMcare', 'hlUnins', 'hlUnder', 'hlSkip', 'hlSkipD', 'hlNeed', 'hlOop', 'hlPrem', 'hlEmp', 'hlGov', 'hlIns', 'hlPaid', 'hlLine', 'hlDev', 'hlDebt', 'hlDebtM', 'hlKap', 'hlKidMcaid', 'hlKidUnins', 'hlMcaidLost', 'hlTax', 'hlRate', 'hlWait', 'hlSA', 'hlSB', 'hlAdded', 'hlAdm', 'hlBack', 'hlCliff', 'hlCliffD', 'hlCliffN', 'hlPriv', 'hlXtra', 'hlPtfP', 'hlGovB', 'hlGovFix', 'hlChron', 'hlPvX'];

// index.html line 5663
/* hlEsi..hlUnins: % of adult-years by coverage; hlUnder: % of insured adult-years underinsured; hlSkip: % of adult-years skipping some care for cost; hlSkipD: care skipped,
 * $ per adult-year; hlNeed: medical need (care used plus skipped) per person-year; hlOop, hlPrem: what households pay out of pocket and in premiums, per adult-year;
 * hlEmp: employers' premium share (pay forgone) per adult-year; hlGov: government (Medicaid, Medicare, premium tax credits) per adult-year; hlIns: insurers' claims per
 * adult-year; hlPaid and hlLine: the household's bill after calibration and its basket line, per adult-year; hlDev: the mean absolute gap between them; hlDebt: % of
 * adult-years with medical debt over $250; hlDebtM: mean medical debt per adult-year; hlKap: the calibration factor; hlKidMcaid, hlKidUnins: % of child-years;
 * hlMcaidLost: % of adult-years that had Medicaid the year before and lost it to income. Setting B: hlTax, the health tax per adult-year; hlRate, its rate (% of
 * money income, mean over the years under B); hlWait, % of needed care delayed; hlSA and hlSB, today's system's spending and the public plan's, per person-year
 * (the years under B; all payers, after the calibration); hlAdded, the added care (% of today's care delivered); hlAdm, % of adults laid off from administrative
 * jobs; hlBack, the employer share returned per adult-year. In the years under B the coverage keys read the counterfactual (today's system). Dollars: year-0.
 * Session 2b: hlCliff, the benefit cliff at the adult Medicaid limit (hlJump): the mean jump in a household's expected health bill when its tested income crosses the
 * limit, over households within a quarter of the guideline of it, in points of the household's basket medical line (every year under today's system; in the years
 * under B and C it is 0, because the bill does not depend on Medicaid, so their figure is year 0's share); hlCliffD, the same in dollars per household; hlCliffN, the share of household-years (%) near the limit; hlPriv, % of person-years in private plans (setting C); hlXtra, the programme's payments to private plans above the
 * enrollees' public-base cost, per person-year; hlPtfP, PTF's health-sector cut to the plan's costs (B and C, with PTF's rate for health care above 0), per person-year.
 * Session 2c: hlChron, % of adult-years in the chronic state; hlPvX, the prevention link's mean exposure weight over adult-years (0 with PREV off); hlGovB, government's share of the public plan's cost (Medicaid, Medicare, the tax credits) per adult-year in the years under B or C, as the health tax
 * nets it; hlGovFix, % of those years in which it was held at the no-programme run's level (100 in a programme run with HEALTH.gov 'fixed', 0 otherwise). */
function hlU(s, id, yr, j){  /* a uniform draw from the hash of (seed, person, year, slot): murmur3's finaliser over the mixed integers */
  var h = Math.imul(s ^ 0x5bd1e995, 0x85ebca6b) ^ Math.imul((id | 0) + 0x632be5ab, 0xc2b2ae35) ^ Math.imul((yr | 0) + 0x7f4a7c15, 0x27d4eb2f) ^ Math.imul((j | 0) + 0x165667b1, 0x9e3779b1);
  h ^= h >>> 16; h = Math.imul(h, 0x85ebca6b); h ^= h >>> 13; h = Math.imul(h, 0xc2b2ae35); h ^= h >>> 16; return ((h >>> 0) + 0.5)/4294967296; }

// index.html line 5673
/* The shared income test (session 2a; reused by the today's-safety-net row and session 2b's benefit-cliff check): a household's money income against the
 * poverty guideline for its size. income in year-0 dollars; returns {n: people, line: the guideline, ratio: income over the guideline}. */
function incomeTest(nAdults, nKids, income){ var n = Math.max(1, nAdults + nKids), line = CFG.HL_FPL.one + CFG.HL_FPL.add*(n - 1); return {n:n, line:line, ratio:income/line}; }

// index.html line 5698
function hlUnits(agents, HHON){ return HHON ? HHS.list.filter(function(H){ return H.a.length > 0; }).map(function(H){ return {a:H.a, kids:H.kids, H:H}; }) : agents.map(function(a){ return {a:[a], kids:[], H:null}; }); }

// index.html line 5872
/* ─── Session 2b (Oct 13, 2026; dev/reports/v5-27-health-financing.md, part 1; dev/DECISIONS.md, Session 2b): TODAY'S SAFETY NET, a comparison row ─────
 * SNET null (the default) adds nothing: no draw, no state any rule reads. When an object (row option sn), each household receives, from year 0, SNAP, the
 * earned income tax credit (EITC) and the refundable part of the Child Tax Credit (CTC). Each is set on last year's money income in year-0 dollars (the
 * tax credits are paid on the year before's return; SNAP's monthly test is read on last year's income as well, a modelling simplification) and paid at this
 * year's price level (the statutes index them to prices). Income: pay, Social Security, unemployment insurance, the UBI comparator and conversion income;
 * year 0 reads the pay rate, as the health block does. The BU allowance is not income here (like SNAP itself, an allowance for essentials).
 *  - SNAP (USDA FNS, FY2026 maximum allotments and deductions, 48 states and DC): maximum allotment by household size; net income = gross income - 20% of
 *    earnings - the standard deduction - dependent care (the household's childcare line) - excess shelter (the housing line, MIT's HUD rent with utilities,
 *    over half of income after the other deductions; capped at $744 a month unless an adult is 60 or older); benefit = allotment - 30% of net income, at
 *    least $24 for one or two people. Gross income limit 200% of the poverty guideline (broad-based categorical eligibility, used by most states, which
 *    waives the net income and asset tests; the federal 130% is swept: gross 1.3). Take-up 88% of eligible people (USDA FNS, national SNAP participation
 *    rates, FY2022). The work rule for adults without dependants (three months in three years) is SNET.abawd, off by default (session 7, below); with it
 *    off it is not modelled (a stated limit: it overstates SNAP for adults without children who are out of work long).
 *  - SNAP's work rule (session 7, Oct 14, 2026; ledger s166, d209; sources/snap_work_rule.md; dev/reports/v5-33-snap-work-rule.md). SNET.abawd false (the
 *    default) adds nothing: no state is stored and no rule reads one. When true, 7 U.S.C. 2015(o) as amended by P.L. 119-21 sec. 10102: an adult aged 18
 *    to 64 (USDA's reading of the law's "over 65"; adults without an age count as subject) in a household with no child under 14 gets SNAP for at most 3
 *    months in 36 in which they do not work 20 hours a week averaged monthly. In a yearly model: the months that count are the weeks out of work that are
 *    not on unemployment insurance (UI claimants are exempt under section 6(d)(2)(A)), or every week without UI when the adult's hours at work are under
 *    half of full time (the model's pay is for a full-time job, 2,080 hours, the hours MIT's living wage assumes; the labor response scales hours).
 *    Retirees are treated as exempt (a modelling assumption, the cautious reading: the rule's bite is not overstated). The status is last year's, as
 *    SNAP's income is. Each adult's clock holds the countable months credited in each of the last two years; this year at most 3 minus those, and only
 *    while the household receives SNAP; months beyond that are lost. In a lost month the adult is not a household member for SNAP (size one smaller, all
 *    income still counted, 7 CFR 273.11(c)); the yearly benefit falls by (lost months / 12) x the difference, summed over the adults, times 1 - abawdEx
 *    (the 8% of covered people a State may exempt each year, sec. 6(o)(6)(F), applied as an expected share: no draw). Not modelled: area waivers (now
 *    only where unemployment is over 10%, which the model's economy does not reach), the medical, pregnancy, student, treatment and caregiver
 *    exemptions (the model has no such states), and regaining eligibility by 80 hours in 30 days (a year with enough work counts no months anyway).
 *    No draw on any stream.
 *  - EITC (IRS Rev. Proc. 2024-40, sec. 3.06, tax year 2025): by qualifying children (the model's children are all under 19), the credit phases in up to
 *    the earned income amount, stays at the maximum, then phases out on the larger of earnings and income; couples file jointly (a modelling assumption:
 *    the model's couples are treated as married), single parents as heads of household; adults without children qualify at 25-64 (adults without an age
 *    count as working age). Take-up 80.8% (IRS, EITC participation rate, tax year 2022).
 *  - CTC (P.L. 119-21, sec. 70101: $2,200 per child under 17 from 2025; IRC sec. 24(d): refundable at 15% of earnings above $2,500; Rev. Proc. 2024-40,
 *    sec. 3.05: refundable part at most $1,700 per child): only the refundable part is paid, the smaller of $1,700 per child, 15% of earnings above
 *    $2,500, and the credit left after income tax before credits (2025 brackets, Rev. Proc. 2024-40 sec. 3.01; standard deductions $15,750 / $31,500 /
 *    $23,625, P.L. 119-21). The part that offsets income tax is not added: the basket's tax line is MIT's tax after credits at the living wage
 *    (PolicyEngine), so adding it would count it twice. Claimed on the same return as the EITC (the same take-up draw).
 * Financing: nothing new. These programmes are paid for by taxes the basket already charges every household (its income and payroll tax line), so they
 * are not new money in the price module, not programme cost and not in the testbed's contribution. They count as income in basket poverty, FGT and the
 * household's income-graded spending, not in the official poverty measure (money income before taxes, which leaves out SNAP and tax credits) and not in
 * the Medicaid test (federal rules disregard SNAP and tax refunds).
 * Work (guardrail 7): with the labour response on, the household's combined marginal rate m (the benefits lost per $1,000 more earnings, at last year's
 * position; negative where the EITC phases in) scales earnings by (1 - m)^(eps - rho), the one elasticity for every change in the return to work, and the
 * benefits enter as unconditional dollars linearised at last year's earnings (the adult's share of the benefits + m x the adult's earnings), the one income
 * effect. Draws: take-up is a hash of (seed, household head, slot) with the health block's hash on its own seed offset; no stream the engine uses. */
var SNET = null, SNS = null;

// index.html line 5873
var SNET_DEFAULTS = {gross:2.0, snapTake:0.88, taxTake:0.808, snap:true, eitc:true, ctc:true, abawd:false, abawdEx:0.08, slope:false};  /* abawd, abawdEx: session 7, SNAP's work rule (below); slope: session 9, the marginal rate without SNAP's income-limit cliff (below) */

// index.html line 5874
CFG.SN_SNAP = {max:[298, 546, 785, 994, 1183, 1421, 1571, 1789], add:218, std:[209, 209, 209, 223, 261, 299], shCap:744, min:24, earnDed:0.20, rate:0.30, old:60};

// index.html line 5875
CFG.SN_EITC = [{inc:8490, max:649, ps:10620, pj:17730, es:19104, ej:26214}, {inc:12730, max:4328, ps:23350, pj:30470, es:50434, ej:57554},
  {inc:17880, max:7152, ps:23350, pj:30470, es:57310, ej:64430}, {inc:17880, max:8046, ps:23350, pj:30470, es:61555, ej:68675}];  /* none, one, two, three or more children */

// index.html line 5877
CFG.SN_CTC = {per:2200, ref:1700, thr:2500, rate:0.15, age:17, po:{s:200000, h:200000, j:400000}, poR:0.05};

// index.html line 5878
CFG.SN_TAX = {std:{s:15750, j:31500, h:23625}, br:{s:[[11925, 0.10], [48475, 0.12], [103350, 0.22], [197300, 0.24], [Infinity, 0.32]],
  j:[[23850, 0.10], [96950, 0.12], [206700, 0.22], [394600, 0.24], [Infinity, 0.32]], h:[[17000, 0.10], [64850, 0.12], [103350, 0.22], [197300, 0.24], [Infinity, 0.32]]}};

// index.html line 5880
var SN_KEYS = ['snSnap', 'snEitc', 'snCtc', 'snSnapM', 'snEitcM', 'snCtcM', 'snAll', 'snMtr', 'snKids'];

// index.html line 5881
var SN_AB_KEYS = ['snAbN', 'snAbM', 'snAbLost'];  /* session 7, only with SNET.abawd: % of adult-years losing SNAP months to the work rule; SNAP dollars cut and months lost per adult-year */

// index.html line 5884
/* snSnap, snEitc, snCtc: % of adult-years in households receiving each; snSnapM, snEitcM, snCtcM, snAll: dollars per adult-year (year-0); snMtr: the mean combined
 * marginal rate (%) over adult-years in receiving households; snKids: % of child-years in households receiving any of the three. */
function snIncTax(f, agi){ var T = CFG.SN_TAX, x = Math.max(0, agi - T.std[f]), lo = 0, t = 0;  /* income tax before credits, filing status f ('s', 'h', 'j') */
  T.br[f].some(function(b){ t += Math.max(0, Math.min(x, b[0]) - lo)*b[1]; lo = b[0]; return x <= b[0]; }); return t; }

// index.html line 5886
function snBen(h, earn, keep){  /* one household's yearly benefits in year-0 dollars at earnings earn: [snap, eitc, ctc]. h: {nA, nK, k17, other, house, care, old, okAge, takeS, takeT}; keep (session 9, SNET.slope): SNAP's gross income test is passed */
  var E = SNET, Y = Math.max(0, earn + h.other), T = incomeTest(h.nA, h.nK, Y), n = T.n, f = h.nA >= 2 ? 'j' : h.nK > 0 ? 'h' : 's', snap = 0, eitc = 0, ctc = 0;
  if (E.snap && h.takeS && (keep || T.ratio <= E.gross)){ var S = CFG.SN_SNAP, ni = Math.max(0, Y - S.earnDed*earn - 12*S.std[Math.min(n, S.std.length) - 1] - h.care), sh = Math.max(0, h.house - 0.5*ni);
    if (!h.old) sh = Math.min(sh, 12*S.shCap); ni = Math.max(0, ni - sh);
    var mx = 12*(n <= S.max.length ? S.max[n - 1] : S.max[S.max.length - 1] + S.add*(n - S.max.length)); snap = Math.max(0, mx - S.rate*ni); if (n <= 2) snap = Math.max(snap, 12*S.min); }
  if (E.eitc && h.takeT && (h.nK > 0 || h.okAge)){ var P = CFG.SN_EITC[Math.min(3, h.nK)], st = f === 'j' ? P.pj : P.ps, en = f === 'j' ? P.ej : P.es;
    eitc = Math.max(0, Math.min(P.max, P.max/P.inc*Math.max(0, earn)) - P.max/(en - st)*Math.max(0, Math.max(earn, Y) - st)); }
  if (E.ctc && h.takeT && h.k17 > 0){ var C = CFG.SN_CTC, cr = Math.max(0, C.per*h.k17 - C.poR*Math.max(0, Y - C.po[f]));
    ctc = Math.max(0, Math.min(C.ref*h.k17, C.rate*Math.max(0, earn - C.thr), cr - snIncTax(f, Y))); }
  return [snap, eitc, ctc]; }

// index.html line 5896
function snAbClock(a, subject, gets){  /* session 7: one adult's work-rule clock for this year; returns the months of SNAP lost (a._snAbC: last year's countable months) */
  var pr = a._snAb || [0, 0], c = a._snAbC || 0, cr = subject && gets ? Math.min(c, Math.max(0, 3 - pr[0] - pr[1])) : 0; a._snAb = [cr, pr[0]]; return subject && gets ? c - cr : 0; }

// index.html line 5898
function snAbCut(h, earn, snap, lost){  /* session 7: the household's yearly SNAP cut for its adults' lost months (each lost month: one member fewer, all income counted) */
  if (!lost.length || snap <= 0) return 0; var h1 = Object.assign({}, h, {nA:h.nA - 1}), w = h1.nA + h1.nK > 0 ? snBen(h1, earn)[0] : 0, f = 0;
  lost.forEach(function(l){ f += l/12; }); return Math.min(snap, f*(1 - SNET.abawdEx)*Math.max(0, snap - w)); }

// index.html line 5901
function snInit(agents, seed){ SNS = {seed:(seed | 0) + 700001, idxPrev:1, acc:{ay:0, ky:0, kN:0, snapN:0, eitcN:0, ctcN:0, snap:0, eitc:0, ctc:0, mN:0, m:0, abN:0, abM:0, abL:0}}; agents.forEach(function(a, j){ a._snId = j; a._snB = 0; a._snM = 0; }); }

// index.html line 5902
function snYear(agents, yr, HHON, inflRate){
  var S = SNS, ac = S.acc, gIdx = Math.pow(1 + inflRate, yr)*(PRICE ? PRICE.bIdx : 1), next = 0;
  agents.forEach(function(a){ if (a._snId === undefined) a._snId = 1000000 + (a._id !== undefined ? a._id : agents.length + next++); });  /* adults who arrive with ageing */
  hlUnits(agents, HHON).forEach(function(u){
    var nA = u.a.length, nK = u.kids.length, earn = 0, other = 0, old = false, okAge = false, k17 = 0, hd = u.a[0]._snId;
    u.a.forEach(function(a){ if (yr === 0 || a.yrWageUSD === undefined) earn += a._ret ? 0 : a.wage*12*CFG.WAGE_TO_USD; else { earn += (a.yrWageUSD || 0)/S.idxPrev; other += ((a.yrSSUSD || 0) + (a.yrUbiUSD || 0) + (a.yrConvUSD || 0))/S.idxPrev; }
      if (yr === 0 && a._ret) other += (a._ssY || 0);
      if (typeof a.age === 'number'){ if (a.age >= CFG.SN_SNAP.old) old = true; if (a.age >= 25 && a.age <= 64) okAge = true; } else okAge = true; });
    u.kids.forEach(function(age){ if (age < CFG.SN_CTC.age) k17++; });
    var h = {nA:nA, nK:nK, k17:k17, other:other, house:u.H ? u.H.need.housing : CFG.LIVING_WAGE_ANNUAL*CFG.BASKET.housing, care:u.H ? (u.H.need.childcare || 0) : 0, old:old, okAge:okAge,
      takeS:hlU(S.seed, hd, 0, 31) < SNET.snapTake, takeT:hlU(S.seed, hd, 0, 32) < SNET.taxTake};
    var b0 = snBen(h, earn), b1 = snBen(h, earn + 1000, SNET.slope && b0[0] > 0);  /* session 9: with SNET.slope a household receiving SNAP keeps passing the gross test at +$1,000 (comment above) */
    if (SNET.abawd){ var abK = u.kids.some(function(age){ return age < 14; }), abL = [];  /* session 7: SNAP's work rule (comment above) */
      u.a.forEach(function(a){ var l = snAbClock(a, !abK && !a._ret && (typeof a.age !== 'number' || (a.age >= 18 && a.age <= 64)), b0[0] > 0); if (l > 0){ abL.push(l); ac.abN++; ac.abL += l; } });
      var abCut = snAbCut(h, earn, b0[0], abL); b0[0] -= abCut; b1[0] -= snAbCut(h, earn + 1000, b1[0], abL); ac.abM += abCut; }
    var B = b0[0] + b0[1] + b0[2], m = Math.max(-0.5, Math.min(0.9, (B - (b1[0] + b1[1] + b1[2]))/1000));
    u.a.forEach(function(a){ a._snB = B*gIdx/nA; a._snM = B > 0 || m !== 0 ? m : 0; });
    ac.ay += nA; ac.ky += nK; if (B > 0) ac.kN += nK; if (b0[0] > 0) ac.snapN += nA; if (b0[1] > 0) ac.eitcN += nA; if (b0[2] > 0) ac.ctcN += nA;
    ac.snap += b0[0]; ac.eitc += b0[1]; ac.ctc += b0[2]; if (B > 0){ ac.mN += nA; ac.m += m*nA; } });
  S.idxPrev = gIdx; }

// index.html line 5922
function snRes(out){ var A = SNS ? SNS.acc : null, ay = A && A.ay ? A.ay : 1, pc = function(x){ return A ? x/ay*100 : 0; };
  out.snSnap = pc(A ? A.snapN : 0); out.snEitc = pc(A ? A.eitcN : 0); out.snCtc = pc(A ? A.ctcN : 0); out.snSnapM = A ? A.snap/ay : 0; out.snEitcM = A ? A.eitc/ay : 0; out.snCtcM = A ? A.ctc/ay : 0;
  out.snAll = out.snSnapM + out.snEitcM + out.snCtcM; out.snMtr = A && A.mN ? A.m/A.mN*100 : 0; out.snKids = A && A.ky ? A.kN/A.ky*100 : 0;
  if (SNET && SNET.abawd){ out.snAbN = pc(A ? A.abN : 0); out.snAbM = A ? A.abM/ay : 0; out.snAbLost = A ? A.abL/ay : 0; } return out; }

// index.html line 5926
function tbSetV54(o){ var old = {rk:RISK_MEASURE, em:EMPL, pb:PTHB, pf:PTFS, ds:DIS}; if (o){ if (o.rk !== undefined) RISK_MEASURE = !!o.rk; if (o.empl) EMPL = Object.assign({}, EMPL_DEFAULTS, o.empl === true ? {} : o.empl);
  if (o.pthb) PTHB = Object.assign({}, PTHB_DEFAULTS, o.pthb === true ? {} : o.pthb); if (o.ptfs) PTFS = Object.assign({}, PTFS_DEFAULTS, o.ptfs === true ? {} : o.ptfs);
  if (o.dis) DIS = Object.assign({}, DIS_DEFAULTS, o.dis === true ? {} : o.dis); } return old; }

// index.html line 5929
function tbResetV54(old){ RISK_MEASURE = old.rk; EMPL = old.em; EMS = null; PTHB = old.pb; PBS = null; PTFS = old.pf; PFS = null; DIS = old.ds; DSS = null; }

// index.html line 5930
function tbRepRes(R, out){
  function pc(k){ return R && R.n ? R[k]/R.n*100 : 0; }
  out.fplPY = pc('fpl'); out.fplXPY = pc('fplX'); out.fplNomPY = pc('fplNom'); out.bOAPyNom = pc('bONom'); out.bNAPyNom = pc('bNNom');
  TB_REP_SNAP.forEach(function(k){ var K = k.charAt(0).toUpperCase() + k.slice(1); out['y7' + K] = R && R.y7 ? R.y7[k] : 0; out['e' + K] = R && R.end ? R.end[k] : 0; out['y0' + K] = R && R.y0 ? R.y0[k] : 0; });
  TB_PATH_M.forEach(function(m){ for (var t = 0; t < TB_PATH_N; t++){ var v = R && R.path[m][t]; out['p' + m + '_' + t] = typeof v === 'number' ? v : 0; } });  /* v5.2 step 8 */
  if (R && RISK_MEASURE) tbRiskRes(R.hist, out);  /* v5.4 item 1 */
  if (R){ tbRepSpells(R.hist, 'f', out, 'sf'); tbRepSpells(R.hist, 'c', out, 'sc'); out.everFpl = R.hist.length ? R.hist.filter(function(h){ return h.f.some(function(v){ return v; }); }).length/R.hist.length*100 : 0; }
  else { TB_REP_SPELL.forEach(function(k){ out[k] = 0; }); out.everFpl = 0; }
  return out;
}

// index.html line 5940
function tbAccount(a, y, yr, mlc, cf, cfPreCCO, costUSD, E, tbG, tbPT){
  var C = TB.cur, idx = mlc/CFG.LIVING_WAGE_ANNUAL/(a._hhF || 1), conv = +a.yrConvUSD || 0;  /* v5.3 B3: a household member's basket is its share of the household's; the index is the price level */
  TB.xIdx = idx;  /* d26: the contribution threshold X is in year-0 dollars, indexed to the basket with a one-year lag */
  var gw = GOV && GOV.wb && a._w !== undefined ? +a._w : 1;  /* S72 gv.wb: the contribution's books at the adult's weight (1 without the weighted tail) */
  C.n++; C.idx = idx; C.E += E; C.cash += a.yrTbCash; if (SNET && SNS && a._snB) C.cash -= a._snB; C.tax += gw*a.yrTax;  /* session 2b: the safety net is paid by the basket's taxes, not programme cost */ if (y.tb === 'prog'){ var e0 = a._lbE0 > 0 ? a._lbE0 : E; (C.Es || (C.Es = [])).push([E, e0, y.tau > 0 ? fedTax(e0, y.xi, y.tau, y.cap).m : 0]); } C.base += gw*(y.tb === 'prog' ? fedTax(E, y.xi, 1, Infinity).tax : y.tb === 'land' ? Math.max(0, a.yrWealthStartUSD || 0) : Math.max(0, E - y.X));  /* v5.2 step 7 */
  if (y.nw){ C.base += gw*(a._gvNW || 0); a._gvNW = Math.max(0, GOV.base === 'wc' ? (+a.yrConvUSD || 0) : tbCashIncome(a) - (+a.yrWageUSD || 0)); }  /* S72: this year's charged amount (last year's), then next year's */
  if (yr === 0 && a._tbEl) C.endow += y.W;
  var spCut = a._spCutY || 0, buR = Math.max(0, mlc*(cfPreCCO - cf) - tbG - spCut);  /* plan step 1 (d105): the split's price cut is conversion premium, not BU relief */
  if (a._csFree){ C.cutFree += a._csFree; a._csFree = 0; }  /* plan step 5 */
  if (POS && a._poS !== undefined){ POS.sub += a._poS/idx; POS.fr += a._poF/idx; a._poS = undefined; }  /* S62: the PTF subsidy and the free part (year-0 dollars, as cost) */
  C.bu += buR; C.conv += conv + spCut; if (a._pdM){ C.convM += a._pdM; if (LVS) LVS.pjM += a._pdM; a._pdM = 0; }  /* plan step 2: matched project output */ C.pjg += a.yrPjGift || 0; a.yrPjGift = 0; C.cutPT += tbPT; C.cutG += tbG; C.pthLiq += a._tbPthNow || 0;
  /* Session 7 (A5 targeting share): program dollars this agent received this year (cash, the endowment's annuity value, BU relief,
   * conversion, price-cut dollars, PTH liquid appreciation; not capital), and the part that closes the agent's shortfall before
   * transfers: the gross basket less wage earnings. Reporting only. */
  var pd = a.yrTbCash + (a._tbEl ? y.W/y.T : 0) + buR + conv + spCut + tbPT + tbG + (a._tbPthNow || 0);
  if (SNET && SNS && a._snB) pd -= a._snB;  /* session 2b */
  C.pd += pd; C.tgt += Math.min(pd, Math.max(0, mlc - E - (a.yrSSUSD || 0)));
  if (y.gcap && a._tbU < y.gcov) C.cap += y.gcap*idx;
  var inc = E + conv + (a.yrUbiUSD || 0) + (a.yrSSUSD || 0) + a.yrTbCash - a.yrTax + (a._tbEl ? y.W/y.T : 0);  /* v5.2 step 4: + the Social Security benefit (0 without ageing) */
  var disp = E + conv + (a.yrUbiUSD || 0) + (a.yrSSUSD || 0) + a.yrTbCash - a.yrTax;
  if (RETURNS && RETURNS.ci){ inc += a.yrCapUSD || 0; disp += a.yrCapUSD || 0; }  /* S59 part 2: the income wealth pays */
  if (EDCS) a._edcY = E + conv + (a.yrUbiUSD || 0) + (a.yrSSUSD || 0) + a.yrTbCash + (a._edcBU || 0);  /* v5.3 B6: gross income for the measured EDC (before the contribution; BU at face) */
  /* Session 8 (A5; dashboard s18). Reporting only, no RNG. Spells: a spell starts in any year the agent is below the basket after
   * being above it (or in year 0); spells are censored at the 20-year window. Hours: this year's earnings over the same agent's
   * earnings with no labor response (a._lbE0, set in runYear's LABOR block), which is hours at a fixed wage; 1 with LABOR off.
   * Disposable income, OECD definition (the Hub's C30): wage earnings + conversion proceeds + cash transfers - the contribution;
   * no in-kind benefits, no capital transfer (the endowment), no capital gains (PTH appreciation). Extended income adds the in-kind
   * cuts to the agent's basket (BU relief and PTF, PTH and grocery price cuts). */
  if (SECS){ a._seE = E; a._seC = conv; }  /* S47: money income's wage and conversion parts, for the security measures' cause split (reporting only) */
  if (a._hh){ a._hhInc = inc; a._hhDisp = disp; a._hhMlc = mlc; a._hhCost = costUSD; a._hhIdx = idx; }  /* v5.3 B3: kept for the household's measures (hhRepYear) and a pooled couple's status */
  if (!a._hhPool) tbPov(a, C, idx, inc, mlc, costUSD, disp);  /* v5.3 B3: a pooled couple's status is set at the end of the year (hhPool) */
  C.emp += E > 0 ? 1 : 0; C.hrs += a._lbE0 > 0 ? (a._pjHW ? E + a._pjHW : E)/a._lbE0 : 1;  /* N1 (session 15): + project hours at the worker's own wage */
  C.bR += a._bleiR || 0; C.bP += a._bleiP || 0;  /* session 9 (i3-2): BLEI raises, and those the program's support carried over the gate */
  /* Session 19 (s38): the framework model's business premium as received, the ESP's own payout and ESP payroll, by group, over the years it
   * is paid (1 to 19; year 0 pays none). Reporting only, no RNG; zero in the engine model. */
  if (yr > 0){ var bzY = a._fwPayY || 0, esY = a._esPrY || 0; C.n1++; C.bz += bzY; C.es += esY;
    if (a.inCCO){ C.nP1++; C.pyP += bzY + esY; if (a._esWk){ C.nWP1++; C.esWP += esY; } } else { C.nN1++; C.pyN += bzY; } }
  a._tbPthPrev = a._tbPthNow || 0; a._tbPthNow = 0;
}

// index.html line 5981
/* The poverty part of tbAccount: this year's shortfall against the adult's own cost (FGT), resources, spells, disposable and extended income. v5.3 B3: split out
 * so a pooled couple's members get the household's status (hhPool calls it with the household's totals per adult); unchanged for everyone else. */
function tbPov(a, C, idx, inc, mlc, costUSD, disp){
  var g = Math.max(0, costUSD - inc)/mlc;
  C.f0 += g > 0 ? 1 : 0; C.f1 += g; C.f2 += g*g;
  if (WYS) WYS.cur.push(costUSD, inc, mlc);  /* S68 (reporting only) */
  if (SXS) sxAcc(a, SXS.p, costUSD, mlc, g > 0);  /* S52 (reporting only) */
  if (SECS) secAcc(a, inc, mlc, costUSD, idx, g);  /* S53 (reporting only) */
  a._tbGap = g; a._tbF0 = (a._tbF0 || 0) + (g > 0 ? 1 : 0); a._tbF2 = (a._tbF2 || 0) + g*g;  /* session 21 (s41): FGT2 by group */
  a._tbRes = (a._tbRes || 0) + (inc + mlc - costUSD)/idx; a._tbYrs = (a._tbYrs || 0) + 1;
  if (g > 0){ if (!a._tbInSp) a._tbSp = (a._tbSp || 0) + 1; a._tbInSp = true; } else a._tbInSp = false;
  a._tbDisp = disp; a._tbExt = a._tbDisp + Math.max(0, mlc - costUSD);
}

// index.html line 5992
function runYear(agentSet,yr,p,recSt){
  var totalBU=0,totalConversion=0;recSt=recSt||{active:false,incomeMultiplier:1.0,yearsLeft:0};
  if(AGE&&AGS&&yr>0)ageYear(agentSet,yr,p);  // v5.2 step 4: deaths, new adults, a year older (own random stream)
  if(ACCT)acctYearStart(agentSet,yr);  // v5.3 B2: the accounting check (off by default; no RNG, nothing any rule reads)
  var HHON=!!HOUSEHOLDS&&!!HHS&&(CONVERSION_MODEL==='framework'||!p.ccoOn),HHPOOL=HHON&&HOUSEHOLDS.pool!=='individual';if(HHON)hhYear(agentSet);  // v5.3 B3: households (no RNG)
  var pthApprBonus=p.szh?p.szhCoh*0.01:0;
  var szhThetaVal=p.szh?szhTheta(p.szhCoh):0;
  if(PAS)paYear(agentSet,yr,p);  // S55 open access: this year's PTF shares of essential sales (part 2: grown), before any test reads them
  if(THETA_GATE==='density'){var tdN=0;if(p.ptf&&!PAS)agentSet.forEach(function(a){if(a.inPTF)tdN++;});THETA_DENS=PAS?(POS?poTPop():PAS.s):tdN/Math.max(1,agentSet.length);szhThetaVal=p.szh?szhTheta(THETA_DENS):0;}  // session 5 (C08/d12): harness-only  // S55: under open access the 55% test reads the PTF share of sales
  var ptfConvBonus=1.30+((p.szh&&p.ptf)?szhThetaVal:0);
  var szhPartBoost=(p.szh&&p.ccoOn)?szhThetaVal*0.16:0;
  if(CMS)CMS.th=PAS?(POS?poTArr():Float64Array.from(PAS.z)):clShares(agentSet);var clTh=CMS?function(a){return p.szh?szhTheta(THETA_GATE==='density'?CMS.th[a._cm]:p.szhCoh):0;}:null;  // S37: theta by community (CMS null: the population's, as before)
  function clPCB(a){return clTh?1.30+((p.szh&&p.ptf)?clTh(a):0):ptfConvBonus;}function clPB(a){return clTh?((p.szh&&p.ccoOn)?clTh(a)*0.16:0):szhPartBoost;}
  /* v4.14 parity fix — ported from index.html: PTF's inflation-damping term used to read
   * the static initial-share slider (p.ptfShare) rather than the population's actual
   * current PTF membership, which this same function already computes a few lines later
   * (for the Bass-diffusion adoption term) but never reused here. ptfAdoptFrac is moved up
   * and reused for both purposes — it draws no RNG, so this reordering shifts no draw
   * anywhere in the function. Verified inert on the documented seed-42/Full Integration
   * regression (inflRate=0 there, so the guard never fires); see CONTRIBUTING.md's v4.14
   * Release Notes for the full trail and measured effect size on configs it does touch. */
  var ptfAdoptFrac=0;
  if(PTFS&&PFS&&p.ptf)ptfsYear(agentSet,yr);  // v5.4 item 4: PTF leavers and this year's member share
  if(p.ptf&&p.ptfShare>0){var ptfCount0=0;agentSet.forEach(function(a){if(a.inPTF)ptfCount0++;});ptfAdoptFrac=ptfCount0/Math.max(1,agentSet.length);}
  if(CMS)clYear(agentSet);  // S37: each community's member share, where the population's is taken (after the leavers)
  /* v4.15 parity fix — ported from index.html: PTH's inflation damping used to be the flat,
   * toggle-triggered `inflRate*=0.90` below — the same defect class the v4.14 PTF fix closed
   * one line above it, in a coarser form (it referenced no adoption-scale quantity at all,
   * so 5% PTH uptake got the identical 10% population-wide reduction as 50%). Unlike PTF,
   * PTH membership is drawn once at construction and never changes during a run, so
   * pthMemberFrac is simply the population's fixed realised PTH share — counted the same
   * no-RNG way as ptfAdoptFrac (existing a.inPTH flags only), so no draw shifts anywhere.
   * Verified inert on the documented seed-42/Full Integration regression (inflRate=0 there)
   * and on Baseline (pth=false); see CONTRIBUTING.md's v4.15 Release Notes. */
  var pthMemberFrac=0;
  if(p.pth){var pthCount0=0;agentSet.forEach(function(a){if(a.inPTH)pthCount0++;});pthMemberFrac=pthCount0/Math.max(1,agentSet.length);}
  var inflRate=p.inflRate||0;
  if(p.ptf&&inflRate>0&&!(PRICE&&PRICE.noDamp))inflRate*=(1-(PAS?PAS.s:ptfAdoptFrac)*0.5);  // session 2: PRICE.noDamp (price module only)  // S55: under open access, the PTFs' share of sales
  /* v4.15: (1-pthMemberFrac*0.10) replaces the flat *0.90. The 0.10 coefficient (=1-0.90) is
   * unchanged from the historical value and is now the ceiling reached at 100% membership. */
  if(p.pth&&inflRate>0&&!(PRICE&&PRICE.noDamp))inflRate*=(1-pthMemberFrac*0.10);
  var dollarCost=CFG.BASE_DAILY_COST*365*Math.pow(1+inflRate,yr);
  if(HEALTH&&HLS)hlYear(agentSet,yr,p,HHON,inflRate);  // session 2a: health coverage (setting A); off by default; its own hashed draws, none from any stream
  if(PRICE)dollarCost*=PRICE.bIdx;  // session 2: endogenous basket index (price module only)
  var popShock=recSt.active?recSt.incomeMultiplier:1.0;
  if(EMPL&&EMPL.rec==='replace'&&recSt.active)popShock=1-Math.max(0,(1-popShock)-(CFG.EMPL_P_REC*CFG.EMPL_W_REC-CFG.EMPL_P*CFG.EMPL_W)/52);  // v5.4 item 2: the recession's job loss is not counted twice
  var mlNT=0;  // v5.2 step 6: the share added to every worker's wage by spending that fills idle labour in a year without a recession
  var hcM=0;if(HCAP){if(yr===0||!HCS)HCS={m:0,hb:0,h:0,mSum:0};else{HCS.m=HCS.h>0?HCAP.c*HCS.hb/HCS.h:0;HCS.hb=0;HCS.h=0;}hcM=HCS.m;HCS.mSum+=hcM;}  // v5.2 step 7: this year's rent mark-up outside PTH, from last year's flows
  if(MULT&&TB&&p.tb){if(yr===0||!MLS)MLS={push:0,y:[]};var mlFill=0,mlLoss=0,mlRest=0;  // plan step 16: the spending layer (testbed only; no RNG)
    if(recSt.active&&popShock<1&&MLS.push>0){var mlW=0;agentSet.forEach(function(a){if(!isNaN(a.wage)&&a.wage>0)mlW+=a.wage*12*CFG.WAGE_TO_USD;});mlLoss=(1-popShock)*mlW;
      if(mlLoss>0){mlRest=Math.min(mlLoss,MULT_LS*MULT.m*MLS.push);mlFill=mlRest/mlLoss;popShock+=(1-popShock)*mlFill;}}
    else if(MULT.nt&&!recSt.active&&MLS.push>0){var ntW=0;agentSet.forEach(function(a){if(!a._ret&&!isNaN(a.wage)&&a.wage>0)ntW+=a.wage*12*CFG.WAGE_TO_USD;});  // v5.2 step 6: normal-times slack
      if(ntW>0){mlRest=Math.min(MULT.nt.s*ntW,MULT_LS*MULT.nt.m*MLS.push);mlNT=mlRest/ntW;}}
    MLS.y[yr]={fill:mlFill,loss:mlLoss,rest:mlRest,push:MLS.push};if(MULT.nt){MLS.y[yr].nt=mlNT;MLS.y[yr].ntR=mlNT>0?mlRest:0;}}
  if(PRS&&PRICE&&PRICE.acc)PRICE.acc.slk=recSt.active?Math.max(0,1-popShock):0;  // S58: the share of income the recession left idle after the spending layer (capacity rule and mf only)
  var ptfLiveCount=0,ptfLiveTotal=agentSet.length;
  if(p.ptf&&p.ptfCap){agentSet.forEach(function(a){if(a.inPTF)ptfLiveCount++;});}
  var PDON=!!PROD&&CONVERSION_MODEL==='framework'&&!!p.ptf&&PROD.cap==='ptf',pdCap=1,pdLive=0;  /* plan step 2: PTF capacity (no RNG) */
  if(PDON){if(yr===0||!PDS){var pdN0=0;agentSet.forEach(function(a){if(a.inPTF)pdN0++;});PDS={c0:pdN0/Math.max(1,agentSet.length),y:[]};}
    var pdK=SURP?SURP.K:Infinity,pdA=(yr>0&&SURP&&SPS)?SPS.capPA:0;pdCap=pdK<=0?1:Math.min(1,PDS.c0+pdA/pdK);
    agentSet.forEach(function(a){if(a.inPTF)pdLive++;});
    var pdOwn=pdCap,pdBor=0;if(PROD.speed==='oneyear'){if(yr>0&&pdK<Infinity&&pdK>0){pdCap=Math.min(1,Math.max(pdOwn,(pdLive+(PDS.blk||0))/Math.max(1,agentSet.length)));pdBor=Math.max(0,pdCap-pdOwn)*pdK;}PDS.blk=0;PDS.borPA=pdBor;}  // plan step 15 (d137): last year's unmet demand is served this year; the capacity reinvestment has not paid for is borrowed (year-0 $ per adult)
    PDS.y[yr]={cap:pdCap,mem:pdLive/Math.max(1,agentSet.length),own:pdOwn,bor:pdBor};}
  function ptfCapAllows(){return (!p.ptfCap||ptfLiveCount<ptfLiveTotal*p.ptfShare)&&(!PDON||pdLive<ptfLiveTotal*pdCap);}
  var popAIDisp=0;
  if(p.automation){
    if(yr>=CFG.AI_DISPLACEMENT_YEAR_2)popAIDisp=CFG.AI_DISPLACEMENT_RATE_1*(CFG.AI_DISPLACEMENT_YEAR_2-CFG.AI_DISPLACEMENT_YEAR_1)+CFG.AI_DISPLACEMENT_RATE_2*(yr-CFG.AI_DISPLACEMENT_YEAR_2+1);
    else if(yr>=CFG.AI_DISPLACEMENT_YEAR_1)popAIDisp=CFG.AI_DISPLACEMENT_RATE_1*(yr-CFG.AI_DISPLACEMENT_YEAR_1+1);
    popAIDisp=Math.min(0.10,popAIDisp);
  }
  /* v4.19: automatic stabilizers (Research Hub Integrated Implementation Roadmap, Appendix G).
   * All off by default: with p.stab and p.cola unset, buEff===p.bu exactly (a multiply by 1),
   * emergLine is -1 and decay is untouched, so every documented figure is bit-identical.
   *  - Recession trigger: the year's recession is active and its population income loss
   *    (1 - incomeMultiplier) is at least p.stabThresh. The engine has no GDP or unemployment
   *    rate, so the hub's ">2% GDP decline" is read as a >=2% income loss; every engine
   *    recession (5-30%) clears it. The trigger reads the CURRENT year's shock (a timely
   *    trigger); harness.js measures what a one-year data lag costs.
   *  - Increase: fixed multiplier p.stabMult, or scaled 1 + p.stabK x loss (p.stabSev).
   *  - COLA: BU indexed by the same cost index mainLoopCostUSD uses, (1+inflRate)^yr, when the
   *    headline rate p.inflRate is above p.colaThresh (Inflation Surge Protocol: 5%).
   *    Inflation is a constant input rate here, so the threshold acts for the whole run.
   *  - buEff replaces p.bu at every read below: allocation, the 3x cap, FBS, and the BLEI
   *    check that gates the wage-growth bonus.
   *  - Suspended expiry (p.stabSusp, hub Natural Disaster Response): unspent BU carries over
   *    while triggered, up to the 3x cap.
   *  - Emergency enrollment (p.emerg, hub "relax requirements"): while triggered, a
   *    non-participant whose latent CCO uniform lies in [partRate, partRate + take-up x
   *    (1 - partRate)) gets the CCO cost relief for that year only. Deterministic: it reads
   *    a.uCCO, drawn at construction, so no RNG draw is added and CRN pairing holds.
   *    Enrollees do not enter octave advancement or conversion.
   * No RNG is drawn here. */
  var stabLoss=recSt.active?Math.max(0,1-recSt.incomeMultiplier):0;
  var stabOn=!!(p.stab&&p.ccoOn&&recSt.active&&stabLoss>=(p.stabThresh||0));
  var stabM=stabOn?(p.stabSev?1+Math.max(0,p.stabK||0)*stabLoss:Math.max(1,p.stabMult||1)):1;
  var colaF=(p.cola&&(p.inflRate||0)>(p.colaThresh||0))?Math.pow(1+inflRate,yr):1;
  /* Session 2, price module only: COLA reads the headline rate, exogenous plus endogenous, year by year, and ratchets BU
   * up to the full price index in any year that rate exceeds p.colaThresh (Inflation Surge Protocol, 5% in D6). */
  if(PRICE){var pmFull=Math.pow(1+inflRate,yr)*PRICE.bIdx;if(p.cola&&pmFull/PRICE.lastFull-1>(p.colaThresh||0))PRICE.colaLevel=pmFull;PRICE.lastFull=pmFull;colaF=p.cola?PRICE.colaLevel:1;}
  if(C22&&C22.idx==='needs')colaF=Math.pow(1+inflRate,yr)*(PRICE?c22Share(PRICE.comp)/c22Share(null):1);  // S6: the BU indexed every year to the price of the C2.2 needs
  var buEff=p.bu*stabM*colaF;if(PRICE)PRICE.buY=buEff;  // v5.2 step 8: this year's BU a month, for the purchasing-power path (reporting only)
  var agP=Math.pow(1+inflRate,yr)*(PRICE?PRICE.bIdx:1);  // v5.2 step 4: the price level the benefit moves with (read only when AGE is on)
  if(DEBT_READ||LF_SCOPE)DR_PL=agP;  // S61: the borrowing limit and the own income of adults outside the labour force move with it
  var svF=0;if(SAVE){var svP=Math.pow(1+inflRate,yr)*(PRICE?PRICE.bIdx:1);if(yr===0||!SVS)SVS={prevP:svP,intR:0,realR:0};else svF=(svP/SVS.prevP)*(1+SAVE.r)-1;var svPp=SVS.prevP;SVS.prevP=svP;}  // v5.2 step 3: savings that keep up with prices (no RNG)
  if(RETURNS){var rtP=Math.pow(1+inflRate,yr)*(PRICE?PRICE.bIdx:1);rtInit(agentSet,rtP,yr);}  // S59: wealth by asset class (no RNG)
  var tbY=(TB&&p.tb)?tbYear(p,colaF):null;  // session 6 (A4 testbed): null unless TB and p.tb are both set (harness-only; no RNG)
  if(SNET&&SNS&&tbY)snYear(agentSet,yr,HHON,inflRate);  // session 2b: today's safety net (SNAP, EITC, the refundable CTC), set on last year's income; off by default; no stream drawn
  if(DIS&&DSS)disYear(agentSet,yr,agP);  // v5.4 item 5: who the disaster hits (and, later, who has recovered)
  if(PTHB&&PBS&&p.pth)pthbYear(agentSet,yr,agP);  // v5.4 item 3: the year's price rise, PTH leavers and their homes' new members
  if(JOIN&&CONVERSION_MODEL==='framework'&&p.ccoOn){  /* plan step 4: open enrolment (no RNG) */
    if(yr===0||!JNS){JNS={y:[],join:0,leave:0};agentSet.forEach(function(a){a._jnY=0;});}
    var jnN=0,jnJ=0,jnL=0;
    if(yr>0){var jnIdx=Math.pow(1+inflRate,yr)*(PRICE?PRICE.bIdx:1),jnM=CFG.LIVING_WAGE_ANNUAL*jnIdx,jnE=0,jnTx=DISC_BASE==='pretax';
      buEss().forEach(function(k){jnE+=CFG.BASKET[k]*(PRICE?PRICE.comp[k]:1);});if(PRICE)jnE/=PRICE.bIdx;  // v5.3 B3f: what BU can buy
      var jnF=CFG.BASKET.food*(PRICE?PRICE.comp.food/PRICE.bIdx:1),jnH=CFG.BASKET.housing*(PRICE?PRICE.comp.housing/PRICE.bIdx:1),jnRs=PTH_MODE!=='basket'||DISC_BASE!=='basket';
      agentSet.forEach(function(a){var jHH=HHON&&a._hh&&!a._hh.single,ef=jHH?a._hhE:jnE,u=1,jF=jHH?a._hhFd:jnF,jH=jHH?a._hhH:jnH,jM=jHH?jnM*a._hhF:jnM,jB=jHH?buEff*a._hhBU:buEff;if(a._inel){a.inCCO=false;return;}if(a._ret&&AGE&&AGE.ret==='none'){a.inCCO=false;return;}/* S6: not eligible (C22.u) */ /* v5.2 step 4: under 'none' a retiree is outside the programme */  /* v5.3 B3: a household member's share of the household's essentials and BU */
        if(p.ptf&&(a.inPTF||PAS)){if(PTFS){var jnC=1-ptfsCut(a,jHH,p,true);ef=ef*jnC;if(jnRs)u=jnC;}else if(PTF_MODE==='shipped'){ef=ef*(1-(p.szh?0.12+p.szhCoh*0.04:0.12));if(jnRs)u=1-(p.szh?0.12+p.szhCoh*0.04:0.12);}else ef=ef-PTF_FOOD_CUT[PTF_MODE]*jF;}
        if(p.pth&&a.inPTH&&!PATHWAY_OFF.pthCost){if(PTH_MODE==='housing')ef-=PTH_HOUSING_CUT*sxH(jH)*u;else ef*=0.65;}
        var use=Math.min(12*jB,jM*ef),cost=(JOIN.cost==='none'||(C22&&C22.auto))?0:12*p.bu*(typeof a.uCCO==='number'?a.uCCO:1)/Math.max(1e-9,p.partRate)*(JOIN.cost==='nominal'?1:jnIdx),want=p.bu>0&&use>=cost;if(LVS&&LVS.jn==='conv'&&p.bu>0&&cost>0){var lvX=lvConvX(a,p,jnIdx,clPCB(a)),lvK=cost/(12*p.bu*(JOIN.cost==='nominal'?1:jnIdx));want=use+lvX[0]>=cost+lvX[1]*lvK;}  /* S54: joining sees the expected conversion income after tax (o.lv.jn 'conv') */
        if(a.inCCO&&!want&&yr-a._jnY>=JOIN.stay){a.inCCO=false;a._jnY=yr;jnL++;}
        else if(!a.inCCO&&want){a.inCCO=true;a._jnY=yr;jnJ++;}});if(HHON)hhSync('cco');}  // v5.3 B3: partners follow the first adult
    agentSet.forEach(function(a){if(a.inCCO)jnN++;});JNS.join+=jnJ;JNS.leave+=jnL;JNS.y[yr]={part:jnN/Math.max(1,agentSet.length),join:jnJ,leave:jnL};
  }
  var emergLine=(stabOn&&p.emerg)?p.partRate+Math.max(0,Math.min(1,p.emergTakeup||0))*(1-p.partRate):-1;
  var emergN=0;
  /* v4.19, Duke's decision (Option B): CCO's cost relief scales with the effective BU. Through
   * v4.18 it was a flat 0.80 whenever BU > 0, so the BU amount reached a household only through
   * conversion proceeds, credited once a year. BU is "redeemable at PTF businesses for essential
   * goods" (Research Hub glossary), so the amount now moves the relief directly: 20% of the
   * basket at the $1,200 reference, in proportion above and below it, capped at 50%. At $1,200
   * this is exactly 0.80, so every $1,200 preset and the seed-42 regression are bit-identical;
   * Stress Test ($900) and any run at another BU amount move. The 50% cap is a placeholder. */
  /* v4.21 units fix, ported from index.html (see its comment): the relief share reads BU in
   * year-0 dollars, buEff / priceIdx. RELIEF_PRICE_LEGACY (harness-only) restores v4.19-v4.20. */
  var priceIdx=RELIEF_PRICE_LEGACY?1:Math.pow(1+inflRate,yr);
  if(PRICE&&!RELIEF_PRICE_LEGACY)priceIdx*=PRICE.bIdx;  // session 2: BU erodes with the endogenous index too
  var ccoReliefF=CCO_RELIEF_FLAT?0.80:1-Math.min(CFG.CCO_RELIEF_CAP,CFG.CCO_RELIEF_AT_REF*buEff/(CFG.CCO_RELIEF_REF_BU*priceIdx));
  if(LEDGER){LEDGER.idx=Math.pow(1+inflRate,yr);var LY0=LEDGER.y[yr]||(LEDGER.y[yr]={});LY0.pIdx=LEDGER.idx;}  // A1 ledger (reporting only): this year's price index, the one mainLoopCostUSD uses
  /* Session 2: framework conversion state (N1-N4) and the basket's current essentials and food shares (price module). */
  var FWON=CONVERSION_MODEL==='framework';
  if(FWON){if(yr===0||!FWS)FWS={prev:null};FWS.next={bizBU:0,projBU:0,expiredBU:0,destroyedBU:0,wSum:0,pwSum:0,projAlloc:0,projGross:0,projTax:0,projNet:0,projLost:0,bizPaid:0};}
  var PJON=!!PROJ,pjPay=0,pjIdx=1,pjCipB=1,pjFg=0;  /* N1 (session 15): project hiring; see PROJ. No RNG is drawn in any PROJ step. */
  if(PJON){
    if(yr===0||!PJS)PJS={prev:null,acc:pjNewAcc()};PJS.next={pool:0,gpool:0};  // gpool: the launch gift's share, tracked for financing (d66)
    pjIdx=Math.pow(1+inflRate,yr)*(PRICE?PRICE.bIdx:1);pjPay=PROJ.pay*pjIdx;pjCipB=p.cip?(1+p.cipDemo*0.12):1.0;
    var pjP=[],pjWt=0,pjWR=0,pjIn=PJS.prev?PJS.prev.pool+PJS.prev.gpool:0,pjCarry=0;pjFg=pjIn>0?PJS.prev.gpool/pjIn:0;
    if(REVIEW&&REVS)agentSet.forEach(function(a){a._rvU=REVS.rng();});  // v5.2 step 7: one number per adult a year from the review stream
    if(p.ccoOn)agentSet.forEach(function(a){if(!a.inCCO)return;if(a._ret&&(AGE&&AGE.ret==='noconv'||LF_SCOPE&&a._lf&&LF_SCOPE.conv==='none')){a._pjBU=0;if(a._pjR===undefined)a._pjR=0;if(a._pjRu===undefined)a._pjRu=0;return;}/* S68 part 2: an adult who never had a project rate (outside the labour force, conv 'none') converts nothing; before, 0 x undefined gave NaN *//* v5.2 step 4: no conversion after retirement under 'noconv' */var r=pjOwnRate(a,p,clPCB(a)),cap=12*FW.octaveCapBase*Math.pow(2,a.octave),w=cap*Math.max(0,a.quality);if(POS){POS.bn+=poBonus(a,p,clPCB(a))-1;POS.bc++;}
      a._pjR=r;a._pjCap=cap;a._pjW=w;a._pjBU=0;pjWt+=w;pjWR+=w*r;pjP.push(a);});
    var pjRc=pjWt>0?pjWR/pjWt:1,pjSet=[];PJS.acc.rc+=pjRc;PJS.acc.rcN++;
    pjP.forEach(function(a){var ru=PROJ.rate==='max'?Math.max(a._pjR,pjRc):a._pjR,v=pjPay*ru*(1-pjTax(p,ru))*pjCipB,h=a.wage*12*CFG.WAGE_TO_USD/PROJ.hrsYr;
      a._pjRu=ru;a._pjWill=v>(a._ret?0:h);/* v5.2 step 4: a retiree gives up no wage for project hours */if(PROJ.alloc==='capqAll'||a._pjWill)pjSet.push(a);});
    if(LVS){var lvW=0;pjSet.forEach(function(a){lvW+=a._pjW;});LVS.ppw=lvW>0?pjIn/pjIdx/lvW:0;LVS.prc=pjRc;}  // S54: this year's project BU per unit of weight (year-0 dollars), read by next year's joining
    if(pjIn>0&&pjSet.length){
      if(PROJ.alloc==='low'){pjSet.sort(function(x,y){return x.wage-y.wage;});var pjL=pjIn;for(var pjI=0;pjI<pjSet.length&&pjL>0;pjI++){var pjT=Math.min(pjL,pjSet[pjI]._pjCap);pjSet[pjI]._pjBU=pjT;pjL-=pjT;}pjCarry=pjL;}
      else if(PROJ.alloc==='equal'){pjSet.forEach(function(a){a._pjBU=pjIn/pjSet.length;});}
      else{var pjS=0;pjSet.forEach(function(a){pjS+=a._pjW;});if(pjS>0)pjSet.forEach(function(a){a._pjBU=pjIn*a._pjW/pjS;});else pjCarry=pjIn;}
    } else pjCarry=pjIn;
    pjP.forEach(function(a){if(a._pjBU>0){PJS.acc.alloc+=a._pjBU/pjIdx;PJS.acc.work++;if(!a._pjWill)PJS.acc.unwilling++;}});
    PJS.acc.carry=pjCarry/pjIdx;PJS.next.pool+=pjCarry*(1-pjFg);PJS.next.gpool+=pjCarry*pjFg;PJS.acc.partY+=pjP.length;
    if(yr===0&&PROJ.giftMode==='forward'&&PROJ.gift>0){PJS.next.gpool+=PROJ.gift*pjP.length;if(ACCT)ACCT.cur.gift+=PROJ.gift*pjP.length;PJS.acc.gift+=PROJ.gift*pjP.length;PJS.acc.pool+=PROJ.gift*pjP.length;}
    if(yr===1&&PROJ.giftMode==='holder'&&PROJ.gift>0)pjP.forEach(function(a){a._pjGiftH=(a._pjGiftH||0)+PROJ.gift;PJS.acc.gift+=PROJ.gift;if(ACCT)ACCT.cur.gift+=PROJ.gift;});
  }
  var ESON=FWON&&!!ESP,esIdx=1,esCipB=1;  /* N1 (session 19, s38): ESP payroll. Framework model only; no RNG is drawn in any ESP step. */
  if(ESON){
    if(yr===0||!ESS)ESS={prev:null,acc:esNewAcc(),y:[]};
    esIdx=Math.pow(1+inflRate,yr)*(PRICE?PRICE.bIdx:1);esCipB=p.cip?(1+p.cipDemo*0.12):1.0;
    var esA=ESS.acc,esPool=ESS.prev?ESS.prev.pool:0,esW=0,esRet=0,esSv=0,esY=ESS.y[yr]={pool:esPool,conv:0,ret:0,sv:0};
    agentSet.forEach(function(a,i){
      if(a._esU===undefined)a._esU=((i+1)*ESP_GOLD)%1;  // d72: fixed by agent index
      a._esWk=(ESP.work==='all'?true:ESP.work==='ptf'?!!(p.ptf&&a.inPTF):a._esU<ESP.work)&&!a._ret;  // v5.2 step 4: no paid ESP work after 67
      a._esBU=0;a._esC=0;a._esX=0;a._esR=0;
      if(a._esWk)esW+=Math.max(0,a._fwW||0);
    });
    ESS.wW=esW;esA.poolPaid+=esPool/esIdx;
    agentSet.forEach(function(a){
      if(!a._esWk&&!(a._esSv>0))return;
      var w=Math.max(0,a._fwW||0),sh=0,bu=0;
      if(a._esWk){esA.wkY++;if(yr>0){esA.wkY1++;esA.wage+=w/esIdx;}
        if(esPool>0&&esW>0){sh=esPool*w/esW;bu=Math.min(sh,w);if(sh>bu){esRet+=sh-bu;esA.retWage+=(sh-bu)/esIdx;}if(w>0)esA.maxShare=Math.max(esA.maxShare,bu/w);}
        a._esBU=bu;esA.alloc+=bu/esIdx;}
      if(!(p.ccoOn&&a.inCCO)){esRet+=bu;esA.retNon+=bu/esIdx;return;}  // d73: non-participants have no earned rate; paid in dollars
      if(a._esWk)esA.partWkY++;
      var r=pjOwnRate(a,p,clPCB(a)),tx=pjTax(p,r),ok=ESP.take==='biz'?r>FW.bizRate:r*(1-tx)*esCipB>1;
      if(!ok){esRet+=bu;esA.retPar+=bu/esIdx;return;}  // below par (or below the ESP's rate, 'biz'): paid in dollars
      var have=bu+(ESP.cap==='save'?(a._esSv||0):0);
      var cap=ESP.cap==='none'?Infinity:Math.max(0,12*FW.octaveCapBase*Math.pow(2,a.octave)-(PJON?(a._pjBU||0)+(a._pjSaved||0):0));  // d74: net of project BU
      var c=Math.min(have,cap);a._esK=cap;  // _esK: reporting only (the capacity test)
      if(have>c+1e-9){esA.capBind++;if(ESP.cap==='save')a._esSv=have-c;else{esRet+=have-c;esA.retCap+=(have-c)/esIdx;}}
      else if(ESP.cap==='save')a._esSv=0;
      if(c>0){a._esC=c;a._esR=r;if(ACCT)a._acBc+=c;a._esX=w>0?c*(r*(1-tx)*esCipB-1)/w:0;esA.tk++;}  // the payroll raise for the labor module (before the income shock)
    });
    if(ESP.cap==='save')agentSet.forEach(function(a){esSv+=a._esSv||0;});
    esY.ret=esRet;esY.sv=esSv;esA.ret+=esRet/esIdx;esA.sv=esSv/esIdx;
    agentSet.forEach(function(a){esY.conv+=a._esC;});
    if(esRet>0&&FWS.prev){  // d73-d75: the BU returned to the ESP convert at FW.bizRate this year, paid with the rest of last year's premium
      var esBT=p.cip?p.tax*(1-p.cipDemo*0.18):p.tax,esTR=Math.min(CFG.PROG_TAX_MAX,esBT+Math.max(0,(FW.bizRate-CFG.PROG_PIVOT)*CFG.PROG_RATE)),esTP=Math.min(CFG.PROG_TAX_MAX,esBT);if(LVS){esBT=lvBizBase(p,esBT);esTR=Math.min(LVS.pc,esBT+Math.max(0,(FW.bizRate-CFG.PROG_PIVOT)*LVS.pr));esTP=Math.min(LVS.pc,esBT);}  // S54: o.lv's business rate, progression and cap
      var esRG=esRet*(FW.bizCap*FW.bizRate+(1-FW.bizCap)),esRT=esRet*(FW.bizCap*FW.bizRate*esTR+(1-FW.bizCap)*esTP),esRN=PATHWAY_OFF.conversion?0:esRG-esRT-esRet;if(LVS&&esRN<0){esRT+=esRN;esRN=0;}  /* S54: never below face value */
      FWS.prev.bizNet+=esRN;esA.retNet+=esRN/esIdx;if(tbY)TB.cur.ctax+=esRT;if(ACCT)ACCT.cur.esRet+=esRet;
      if(LEDGER){ledAdd(yr,'espRetGross',esRG);ledAdd(yr,'espRetTax',esRT);ledAdd(yr,'espRetPremium',esRN);}
    }
    if(LEDGER){ledAdd(yr,'espPoolPaid',esPool);ledAdd(yr,'espConvBU',esY.conv);ledAdd(yr,'espRetBU',esRet);}
  }
  var c22Cur=C22S?c22Share(PRICE?PRICE.comp:null)/(PRICE?PRICE.bIdx:1):0;  // S6: the C2.2 needs' share of the basket (reporting only)
  var eShareCur=0,fShareCur=CFG.BASKET.food;buEss().forEach(function(k){eShareCur+=CFG.BASKET[k]*(PRICE?PRICE.comp[k]:1);});  // v5.3 B3f: the share of the basket BU can buy (BU_SCOPE)
  if(PRICE){eShareCur/=PRICE.bIdx;fShareCur=CFG.BASKET.food*PRICE.comp.food/PRICE.bIdx;}
  var rsAlt=PTH_MODE!=='basket'||DISC_BASE!=='basket';  // session 5 (d4/d5): harness-only
  var tShareCur=DISC_BASE==='pretax'?CFG.BASKET.taxes*(PRICE?PRICE.comp.taxes/PRICE.bIdx:1):0,hShareCur=CFG.BASKET.housing*(PRICE?PRICE.comp.housing/PRICE.bIdx:1);
  var tShA=tShareCur;function discMul(c,m){return DISC_BASE==='pretax'?tShA+(c-tShA)*m:c*m;}  // v5.3 B3: tShA = a household member's own tax share (set per adult below)
  if(ACCT&&FWON)ACCT.cur.bizIn=FWS.prev?FWS.prev.bizNet:0;  // v5.3 B2: the premium to be paid out this year (with the returned BU's)
  var SPON=FWON&&!!SURP,spDelta=0,spProfW=0,spRestW=0,spOwnW=0;  /* plan step 1 (Oct 1, 2026): the ESP surplus split; see SURP. No RNG is drawn in any SURP step. */
  if(SPON){
    if(yr===0||!SPS)SPS={capPA:0,cap:0,carry:0,carryP:0,sw:-1,acc:spNewAcc(),y:[]};
    var spIdx=Math.pow(1+inflRate,yr)*(PRICE?PRICE.bIdx:1),spA=SPS.acc,spN=agentSet.length;
    var spPool=FWS.prev?FWS.prev.bizNet:0,spS=(SURP.priv==='owners'||SURP.priv==='prices')?((FWS.prev&&FWS.prev.bizBU>0)?(FWS.prev.bizBUptf||0)/FWS.prev.bizBU:0):1;  // the PTFs' share: BU PTF members spent last year / all BU accepted
    var spPh=yr===0?1:SURP.swYear!=null?(yr>=SURP.swYear?2:1):((PDON?(SURP.K<=0||PDS.c0+SPS.capPA/SURP.K>=1):SPS.capPA>=SURP.K)?2:1);if(spPh===2&&SPS.sw<0)SPS.sw=yr;  // plan step 2: with PTF capacity on, when c reaches 1  // year 0 has no pool  // d101: phase 2 the year after the capital account reaches K
    var spSh=spPh===1?SURP.p1:SURP.p2,spPtf=spPool*spS,spOwn=spPool-spPtf,spChD=0,spChI=0;
    if(PDON&&PROD.speed==='oneyear'){var spChDue=(PDS.borPA||0)*(PROD_CAP_DEP+PROD_CAP_INT)*spN*spIdx+(PDS.debt||0)*spIdx,spChPd=Math.min(spPtf,spChDue);PDS.debt=(spChDue-spChPd)/spIdx;spPtf-=spChPd;  // plan step 15: depreciation plus real interest on borrowed PTF capital, paid from the PTFs' premium first; any shortfall carries
      spChD=spChPd*PROD_CAP_DEP/(PROD_CAP_DEP+PROD_CAP_INT);spChI=spChPd-spChD;if(tbY){TB.cur.conv+=spChPd;TB.cur.convM+=spChD;}if(PRICE&&PRICE.acc)PRICE.acc.conv+=spChPd;SPS.acc.chD=(SPS.acc.chD||0)+spChD/spIdx;SPS.acc.chI=(SPS.acc.chI||0)+spChI/spIdx;}
    var spRest=spPtf*Math.max(0,1-spSh[0]-spSh[1]-spSh[2]),spCarryIn=SPS.carry;
    var spPP=spPtf*spSh[0]+(SURP.rv==='price'?spPtf*spSh[1]:0)+SPS.carry,spRv=SURP.rv==='price'?0:spPtf*spSh[1],spPr=spPtf*spSh[2]+SPS.carryP;SPS.carryP=0;
    var spCust=SURP.cust==='auto'?((SURP.priv==='owners'||SURP.priv==='prices')?'ptf':'all'):SURP.cust;
    var spVOn=SURP.priv==='prices',spVW=0,spVP=0,spVSum=0,spVUsed=0;  /* plan step 14 (Oct 2, 2026; d140): private ESPs pass their premium to BU customers as lower prices; workers matched */
    if(spVOn){if(SPS.carryV===undefined)SPS.carryV=0;spVW=SURP.privWk==='none'?0:spOwn*spSh[2];spVP=spOwn-spVW+SPS.carryV;spPr+=spVW;spOwn=0;}
    var spMlc=CFG.LIVING_WAGE_ANNUAL*Math.pow(1+inflRate,yr);if(PRICE)spMlc*=PRICE.bIdx;
    var spSum=0,spWW=0,spWO=0;
    if(!ESON)agentSet.forEach(function(a,i){if(a._esU===undefined)a._esU=((i+1)*ESP_GOLD)%1;a._esWk=a._esU<ESP_DEFAULTS.work&&!a._ret;});  // ESP payroll off: the same workforce (d72)
    agentSet.forEach(function(a){  // each customer's essentials at own prices, exactly as the agent loop computes them (start-of-year memberships)
      var bp=p.ccoOn&&a.inCCO&&p.bu>0&&!PATHWAY_OFF.relief,spPw=!!PAS&&(spCust==='ptf'||(spCust==='pp'&&!(p.ccoOn&&a.inCCO))),isC=spCust==='all'||(spCust==='pp'&&((p.ccoOn&&a.inCCO)||(p.ptf&&(a.inPTF||PAS))))||(spCust==='ptf'&&p.ptf&&(a.inPTF||PAS))||(spCust==='part'&&p.ccoOn&&a.inCCO),e=0;  // S55 spPw: under open access a customer through the PTFs only, on the zone's share of the basket
      var sHH=HHON&&a._hh&&!a._hh.single,sE=sHH?a._hhE:eShareCur,sF=sHH?a._hhFd:fShareCur,sH=sHH?a._hhH:hShareCur,sM=sHH?spMlc*a._hhF:spMlc;  // v5.3 B3: a household member's share of the household's essentials
      if(isC){var ef=sE,u=1;
        if(p.ptf&&(a.inPTF||PAS)){if(PTFS){var spC=1-ptfsCut(a,sHH,p,true,spPw);ef=ef*spC;if(rsAlt)u=spC;}else if(PTF_MODE==='shipped'){ef=ef*(1-(p.szh?0.12+p.szhCoh*0.04:0.12));if(rsAlt)u=1-(p.szh?0.12+p.szhCoh*0.04:0.12);}else ef=ef-PTF_FOOD_CUT[PTF_MODE]*sF;}
        if(p.pth&&a.inPTH&&!PATHWAY_OFF.pthCost){if(PTH_MODE==='housing')ef-=PTH_HOUSING_CUT*sxH(sH)*u;else ef*=0.65;}
        if(SURP_CUT_MARKUP&&bp&&HCAP&&HCS&&hcM>0&&!(p.pth&&a.inPTH))ef+=hcM*sH;  // v5.3 B2: the bill the cut is applied to (the agent loop adds hcX to a BU customer's essentials)
        e=sM*ef;if(SURP.bu==='cash'&&bp)e=Math.max(0,e-Math.min(12*(sHH?buEff*a._hhBU:buEff),e));if(spPw)e*=paW(a);}  // S55: the share of the essentials bought at PTF prices
      if(spVOn){var vBu=PAS?(bp?Math.max(0,a._spBU||0)*(1-paW(a)):0):(bp&&!(p.ptf&&a.inPTF))?Math.max(0,a._spBU||0):0,vE=0;if(vBu>0){vE=sE;if(p.pth&&a.inPTH&&!PATHWAY_OFF.pthCost){if(PTH_MODE==='housing')vE-=PTH_HOUSING_CUT*sH;else vE*=0.65;}vE*=sM;if(PAS)vE*=1-paW(a);}a._spVw=vBu;a._spVE=vE;spVSum+=vBu;}  // S55: under open access, the BU and essentials outside the PTFs
      a._spE=e;a._spPw=spPw;a._spCutY=0;a._spPay=0;a._spOwn=0;a._spBU=0;a._spWk=!!a._esWk&&(SURP.wk!=='espPart'||!!(p.ccoOn&&a.inCCO));
      spSum+=e;if(a._spWk)spWW+=Math.max(0,a._fwW||0);spWO+=spBase(a);
    });
    spDelta=spSum>0?Math.min(1,spPP/spSum):0;var spUsed=spDelta*spSum;SPS.carry=spPP-spUsed;  // d98: one uniform cut, capped at 1; the rest carries
    if(spVOn){agentSet.forEach(function(a){a._spV=(spVSum>0&&a._spVw>0)?Math.min(spVP*a._spVw/spVSum,a._spVE):0;spVUsed+=a._spV;});SPS.carryV=spVP-spVUsed;}  // plan step 14: shared by last year's BU spent at private ESPs, capped at own essentials; the rest carries
    if(spWW>0)spProfW=spPr/spWW;else{SPS.carryP=spPr;spPr=0;}
    var spRestOn=spRest>0&&FWS.prev&&FWS.prev.wSum>0;spRestW=spRestOn?Math.max(0,spRest)/FWS.prev.wSum:0;
    if(spWO>0)spOwnW=spOwn/spWO;else{SPS.carry+=spOwn;spOwn=0;}
    agentSet.forEach(function(a){var w=a._fwW||0;a._spOwn=spOwnW*spBase(a);a._spRest=spRestOn?spRest*w/FWS.prev.wSum:0;a._spPay=(a._spWk&&spWW>0?spPr*Math.max(0,w)/spWW:0)+a._spRest+a._spOwn;});  // shares all 0 under 'same': exactly today's payout (unit)
    SPS.cap+=spRv;SPS.capPA+=spRv/spIdx/spN;  // d100: the ESP capital account (year-0 dollars per adult for the trigger)
    if(tbY){TB.cur.conv+=spRv;if(PROD)TB.cur.convM+=spRv;}if(PRICE&&PRICE.acc)PRICE.acc.conv+=spRv;  // plan step 2: reinvestment buys capital goods (output at face)  // d105: reinvestment is part of the conversion premium
    spA.pool+=spPool/spIdx;spA.own+=spOwn/spIdx;if(spVOn){spA.privW=(spA.privW||0)+spVW/spIdx;spA.privP=(spA.privP||0)+(spVP-SPS.carryV)/spIdx;}spA.ptf+=spPtf/spIdx;spA.rest+=spRest/spIdx;spA.pricePool+=(spPP-spCarryIn)/spIdx;spA.reinv+=spRv/spIdx;spA.carry=SPS.carry/spIdx;
    if(yr>0){if(spPh===1){spA.d1+=spDelta;spA.n1++;}else{spA.d2+=spDelta;spA.n2++;}spA.yrs++;}
    SPS.y[yr]={pool:spPool,s:spS,own:spOwn,ptf:spPtf,rest:spRest,carryIn:spCarryIn,pp:spPP,sum:spSum,delta:spDelta,used:spUsed,carryOut:SPS.carry,profit:spPr,reinv:spRv,cap:SPS.cap,capPA:SPS.capPA,phase:spPh,cut:0,freed:0,paid:0,pjFreed:0,privW:spVW,privPool:spVP,privUsed:spVUsed,cutV:0,ch:spChD+spChI,chDue:(typeof spChDue==='number'?spChDue:0)};
    if(LEDGER){ledAdd(yr,'spPool',spPool);ledAdd(yr,'spOwners',spOwn);ledAdd(yr,'spPricePool',spPP);ledAdd(yr,'spCarry',SPS.carry);ledAdd(yr,'spProfit',spPr);ledAdd(yr,'spReinvest',spRv);ledAdd(yr,'spRest',spRest);}
  }
  agentSet.forEach(function(a){
    if(isNaN(a.wealth))a.wealth=0;if(isNaN(a.wage)||a.wage<=0)a.wage=1;
    var HHA=HHON&&a._hh&&!a._hh.single,eSA=HHA?a._hhE:eShareCur,fSA=HHA?a._hhFd:fShareCur,hSA=HHA?a._hhH:hShareCur,buA=HHA?buEff*a._hhBU:buEff,dcA=HHA?dollarCost*a._hhD:dollarCost,HHP=HHPOOL&&HHA&&a._hh.a.length>1;tShA=HHA?a._hhT:tShareCur;if(HHON)a._hhPool=HHP;  // v5.3 B3: a household member's shares, BU and BLEI cost; HHP: a pooled couple (finished in hhPool)
    var dsOn=!!(DIS&&DSS&&yr===DIS.yr&&a._disHit);if(dsOn&&p.ccoOn&&a.inCCO&&p.bu>0)buA*=1+DIS.emerg;  // v5.4 item 5: the emergency distribution
    if(svF!==0&&(a.wealth>0||(a.wealth<0&&SAVE.debt==='same'))){var svI=(LVS&&LVS.svc>0?Math.min(a.wealth,LVS.svc*svP):a.wealth)*svF;a.wealth+=svI;if(LVS&&LVS.sv)LVS.svY+=svI;/* S54: o.lv.svc protects savings up to svc year-0 dollars */if(ACCT)a._acI=svI;if(EDCS&&svI<0)a._edcIntP=-svI;SVS.intR+=svI/svP;SVS.realR+=a.wealth/(1+svF)*SAVE.r/svPp;if(LEDGER)ledAdd(yr,'saveInterest',svI);}  // v5.2 step 3
    if(RETURNS){var rtI=rtAdult(a,rtP);if(ACCT)a._acI+=rtI;}  // S59: last year's saving placed, then each class revalued
    a.yrWealthStartUSD=a.wealth;  /* v4.18 parity: start-of-year wealth for housingDistressOf() (no RNG) */
    var agentVar=0.90+RNG()*0.20,incomeShock=popShock*agentVar;
    if(HHON&&HOUSEHOLDS.shock&&a._hh&&a._hh.a.length>1){var hsR=HOUSEHOLDS.shock==='shore'?CFG.HH_SHOCK_CORR[recSt.active?1:0]:+HOUSEHOLDS.shock,hsA=Math.min(1,Math.abs(hsR)),hsS=hsR<0&&a._hh.a[1]===a?-1:1;agentVar=1+Math.sqrt(hsA)*hsS*(a._hh.hv-1)+Math.sqrt(1-hsA)*(agentVar-1);incomeShock=popShock*agentVar;a._shkV=agentVar;a._shkR=!!recSt.active;}  // v5.3 B6: a couple's swings share a household part (off by default)
    if(EDCS){a._edcInt=0;a._edcBU=0;}  // v5.3 B6: the measured EDC's inputs (reporting only)
    var uSpendFrac=0.60+RNG()*0.30;
    var uCipQuality=RNG();
    var uAdvance=RNG();
    var uSzhInduce=RNG();
    var uSzhPtfShare=RNG();
    var uPthAppr=RNG();
    var uPtfAdopt=RNG();
    if(LFS&&LFS.f)lfFlow(a,agP,yr);  // S73: yearly movement in and out of the labour force (own stream)
    if(LF_SCOPE&&a._lf&&!(AGE&&AGS))a._ssY=a._ssB0*agP;  // S61: the own income of an adult outside the labour force, moved with prices
    if(AGE&&AGS&&a._ret){a._ssY=a._ssB0*agP;a.wage=a._ssY/12/CFG.WAGE_TO_USD;if(AGE.ret==='none')a.inCCO=false;}  // v5.2 step 4: a retiree's benefit, moved with prices; BLEI and the stability score read it as the monthly income
    if(GATE_CURRENT&&FWON&&p.ccoOn&&a.inCCO&&p.bu>0&&!PATHWAY_OFF.relief){  // audit V5-02: the framework BLEI gate reads THIS year's BU spend, not last year's (same expression as fwB0 below)
      var gEss=eSA;
      if(p.ptf&&(a.inPTF||PAS))gEss=PTFS?gEss*(1-ptfsCut(a,HHA,p,true)):PTF_MODE==='shipped'?gEss*(1-(p.szh?0.12+p.szhCoh*0.04:0.12)):gEss-PTF_FOOD_CUT[PTF_MODE]*fSA;
      if(p.pth&&a.inPTH&&!PATHWAY_OFF.pthCost){if(PTH_MODE==='housing')gEss-=PTH_HOUSING_CUT*sxH(hSA)*(rsAlt&&p.ptf&&(a.inPTF||PAS)&&(PTFS||PTF_MODE==='shipped')?(PTFS?1-ptfsCut(a,HHA,p,true):1-(p.szh?0.12+p.szhCoh*0.04:0.12)):1);else gEss*=0.65;}
      var gCost=CFG.LIVING_WAGE_ANNUAL*Math.pow(1+inflRate,yr);if(PRICE)gCost*=PRICE.bIdx;if(HHA)gCost*=a._hhF;
      a._fwBUm=Math.min(12*buA,gCost*gEss)/12;
    }
    var bleiCheck=agentBLEI(a,buA,p.ccoOn,p.pth,p.szh,p.szhCoh,p.ptf);
    var tbNB=tbY?tbGate(a,p,buA,tbY):0,wg=CFG.WAGE_BASE_GROWTH,bleiGate=(tbY&&TB.neutralGate)?tbNB:bleiCheck;if(AUD&&AUD.gate)bleiGate/=priceIdx;  // S13 gate: year-0 prices  // session 6 (d28): design-neutral gate for the wage bonus (testbed only)
    var bleiProg=0;a._bleiR=0;a._bleiP=0;  // session 9 (i3-2): harness-only attribution of the BLEI raise (no RNG)
    if(bleiGate>CFG.BLEI_PRECARIOUS_MAX&&!PATHWAY_OFF.bleiWage){  // v4.21: harness-only pathway switch
      var drFactor=1/(1+0.5*Math.max(0,a.wage/CFG.WAGE_MEDIAN_SIU-1));
      wg+=CFG.WAGE_BLEI_BONUS*Math.max(0.1,drFactor);
      a._bleiR=1;if(!(agentBLEI(a,0,false,false,false,0,false)/(AUD&&AUD.gate?priceIdx:1)>CFG.BLEI_PRECARIOUS_MAX)){a._bleiP=1;if(N7_BLEI)bleiProg=CFG.WAGE_BLEI_BONUS*Math.max(0.1,drFactor);}
    }
    if(!PATHWAY_OFF.octaveWage)wg+=a.octave*CFG.WAGE_OCTAVE_BONUS;  // v4.21: harness-only pathway switch
    if(p.cip)wg+=p.cipDemo*0.005;
    if(LABOR&&a._lwNB===undefined)a._lwNB=a.wage;  // session 4 (A3): the wage without program-induced raises
    if(PRICE){if(a._wNB===undefined)a._wNB=a.wage;if(PRICE.wIdx)wg+=PRICE.wIdx*PRICE.piG;}if(AUD&&AUD.wOut)wg+=inflRate;  // S13 wOut (a reading)  // session 2: wage indexation to P_G (price module; 0 = nominal drift)
    if(!(EMPL&&EMPL.auto==='jobs'))wg-=popAIDisp*((typeof a.automationRisk==='number'&&!isNaN(a.automationRisk))?a.automationRisk:0.5);  /* v4.17 parity: `||0.5` read a draw of exactly 0 as 0.5 */
    a.wage=Math.max(a.wage*0.80,a.wage*(1+wg));
    if(isNaN(a.wage))a.wage=1;
    if(a._ret)a.wage=a._ssY/12/CFG.WAGE_TO_USD;  // v5.2 step 4: a retiree's income is the benefit (no wage growth)
    if(a._ret){if(LABOR)a._lwNB=a.wage;if(PRICE)a._wNB=a.wage;}  // v5.2 step 4: no programme raise on a benefit
    if(LABOR){var lbProg=(PATHWAY_OFF.octaveWage?0:a.octave*CFG.WAGE_OCTAVE_BONUS)+(p.cip?p.cipDemo*0.005:0)+bleiProg;a._lwNB=Math.max(a._lwNB*0.80,a._lwNB*(1+wg-lbProg));}
    if(PRICE){var pmProg=(PATHWAY_OFF.octaveWage?0:a.octave*CFG.WAGE_OCTAVE_BONUS)+(p.cip?p.cipDemo*0.005:0)+bleiProg;a._wNB=Math.max(a._wNB*0.80,a._wNB*(1+wg-pmProg));}  // N7: the wage without program-induced raises
    var cf=1.0,rsPtfU=1,rsRel=1;
    if(!rsAlt){
    if(p.ptf&&(a.inPTF||PAS)){if(PTFS)cf*=1-ptfsCut(a,HHA,p);else if(PTF_MODE==='shipped')cf*=(1-(p.szh?0.12+p.szhCoh*0.04:0.12));else cf*=(1-PTF_FOOD_CUT[PTF_MODE]*fSA);}  // session 2: PTF_MODE (D4); 'shipped' is index.html
    var cfPTF=cf;  // A1 ledger (reporting only)
    if(p.pth&&a.inPTH&&!PATHWAY_OFF.pthCost)cf*=0.65;  // v4.21: harness-only pathway switch
    var cfPreCCO=cf;  // A1 ledger (reporting only)
    if(p.ccoOn&&a.inCCO&&p.bu>0){if(!PATHWAY_OFF.relief&&!FWON)cf*=ccoReliefF;}  // v4.19: was a flat 0.80 (see ccoReliefF). v4.21: pathway switch
    else if(emergLine>=0&&p.ccoOn&&p.bu>0&&!a.inCCO&&!a._inel&&typeof a.uCCO==='number'&&a.uCCO<emergLine){cf*=ccoReliefF;emergN++;}  // v4.19: emergency enrollment
    } else {  // session 5 (d4/d5): the same chain with PTH_MODE and DISC_BASE (harness-only)
    if(p.ptf&&(a.inPTF||PAS)){if(PTFS){rsPtfU=1-ptfsCut(a,HHA,p);cf=discMul(cf,rsPtfU);}else if(PTF_MODE==='shipped'){rsPtfU=1-(p.szh?0.12+p.szhCoh*0.04:0.12);cf=discMul(cf,rsPtfU);}else cf-=PTF_FOOD_CUT[PTF_MODE]*fSA;}
    var cfPTF=cf;
    if(p.pth&&a.inPTH&&!PATHWAY_OFF.pthCost){if(PTH_MODE==='housing')cf-=PTH_HOUSING_CUT*sxH(hSA)*rsPtfU;else cf=discMul(cf,0.65);}
    var cfPreCCO=cf;
    if(p.ccoOn&&a.inCCO&&p.bu>0){if(!PATHWAY_OFF.relief&&!FWON){cf=discMul(cf,ccoReliefF);rsRel=ccoReliefF;}}
    else if(emergLine>=0&&p.ccoOn&&p.bu>0&&!a.inCCO&&!a._inel&&typeof a.uCCO==='number'&&a.uCCO<emergLine){cf=discMul(cf,ccoReliefF);rsRel=ccoReliefF;emergN++;}
    }
    var lvRcT=!!(LVS&&LVS.rc&&FWON&&p.ccoOn&&a.inCCO&&p.bu>0&&!(p.pth&&a.inPTH)),lvRc=lvRcT&&PRICE&&PRICE.comp.housing>PRICE.comp.other?hSA*(1-PRICE.comp.other/PRICE.comp.housing):0;if(lvRc>0){cf-=lvRc;cfPreCCO-=lvRc;}  // S54: a BU tenant's rent rises no faster than the general price level (o.lv.rc; landlords bear it, not programme cost)
    var hcOn=!lvRcT&&!!(HCAP&&HCS&&!(p.pth&&a.inPTH)&&(HCAP.all||(FWON&&p.ccoOn&&a.inCCO&&p.bu>0&&!PATHWAY_OFF.relief))),hcX=hcOn&&hcM>0?hcM*hSA:0,hcDone=false;  // v5.2 step 7: whose rent is marked up, and by how much (a share of the basket)
    var mainLoopCostUSD=CFG.LIVING_WAGE_ANNUAL*Math.pow(1+inflRate,yr);
    if(PRICE)mainLoopCostUSD*=PRICE.bIdx;  // session 2: endogenous basket index
    if(HHA)mainLoopCostUSD*=a._hhF;  // v5.3 B3: this adult's share of the household's needs at the household's own prices
    if(SXS){a._sxPf=mainLoopCostUSD*(1-cfPTF);a._sxPh=mainLoopCostUSD*(cfPTF-cfPreCCO);a._sxBU=0;}  // S47: S52's payer breakdown (reporting only): PTF's and PTH's cuts in dollars (PTH's includes S54's rent cap, which landlords bear); BU spent below
    if(C22S&&tbY){var c2N=mainLoopCostUSD*(HHA?a._hhC22:c22Cur),c2B=(p.ccoOn&&a.inCCO&&p.bu>0&&!PATHWAY_OFF.relief)?12*buA:0;C22S.n++;if(c2B>0)C22S.b++;if(c2B>=c2N*(1-1e-9))C22S.k++;C22S.r+=c2N>0?Math.min(1,c2B/c2N):1;}  // S6: C2.2 coverage (reporting only); amendment 1: covered within a relative 1e-9, so a BU equal to the needs is not lost to rounding
    if(hcOn)HCS.h+=mainLoopCostUSD*(hSA+hcX);  // v5.2 step 7: the rent bill of the adults the mark-up falls on
    if(EDCS){a._edcR=(p.pth&&a.inPTH)?0:mainLoopCostUSD*(hSA+hcX);a._edcInt=a._edcIntP||0;a._edcIntP=0;}  // v5.3 B6: rent to a landlord (housing with utilities, MIT; PTH payments are not extractive: the glossary's EDC = 0) and interest on debt
    if(FWON&&p.ccoOn&&a.inCCO&&p.bu>0&&!PATHWAY_OFF.relief){  // session 2, N3/N4: BU buy essentials at the agent's own prices, up to 12 x BU a year
      var essF=eSA;
      if(p.ptf&&(a.inPTF||PAS))essF=PTFS?essF*(1-ptfsCut(a,HHA,p,true)):PTF_MODE==='shipped'?essF*(1-(p.szh?0.12+p.szhCoh*0.04:0.12)):essF-PTF_FOOD_CUT[PTF_MODE]*fSA;
      if(p.pth&&a.inPTH&&!PATHWAY_OFF.pthCost){if(PTH_MODE==='housing')essF-=PTH_HOUSING_CUT*sxH(hSA)*rsPtfU;else essF*=0.65;}  // session 5 (d4)
      if(hcX>0)essF+=hcX;if(lvRc>0)essF-=lvRc;  // v5.2 step 7: BU pay the marked-up rent
      var fwBudget=12*buA,fwB=Math.min(fwBudget,mainLoopCostUSD*essF),spC=0,fwB0=fwB;if(tbY)TB.cur.buIss+=fwBudget;if(EDCS)a._edcBU=fwBudget;if(HEALTH)a._hlBU=fwBudget;  // plan step 3: BU the Source issues (reporting)
      if(SPON&&a._spE>0&&spDelta>0){var spE=mainLoopCostUSD*essF;  // plan step 1 (d99): the cut lowers essentials; BU buy the discounted essentials first
        if(SURP.bu==='cash')spC=a._spPw?spDelta*a._spE:spDelta*Math.max(0,spE-fwB);else{spC=a._spPw?spDelta*a._spE:spDelta*spE;fwB=Math.min(fwBudget,spE-spC);}  // S55: under open access the cut is on what is bought at PTFs (the split's own figure)
        a._spCutY=spC;var spY=SPS.y[yr];spY.cut+=spC;spY.freed+=fwB0-fwB;SPS.acc.cut+=spC/spIdx;SPS.acc.cutP+=spC/spIdx;SPS.acc.freed+=(fwB0-fwB)/spIdx;SPS.acc.cash+=(spC-(fwB0-fwB))/spIdx;}
      if(SPON&&a._spV>0){var vSpE=mainLoopCostUSD*essF,vC=Math.min(a._spV,Math.max(0,vSpE-spC)),vB=fwB;  // plan step 14 (d140): a private ESP's lower BU price; BU buy the discounted essentials first, the BU it frees expire
        if(vC>0){spC+=vC;fwB=Math.min(fwBudget,vSpE-spC);a._spCutY=spC;var vY=SPS.y[yr];vY.cut+=vC;vY.cutV+=vC;vY.freed+=vB-fwB;SPS.acc.cut+=vC/spIdx;SPS.acc.cutP+=vC/spIdx;SPS.acc.cutV=(SPS.acc.cutV||0)+vC/spIdx;SPS.acc.freed+=(vB-fwB)/spIdx;SPS.acc.cash+=(vC-(vB-fwB))/spIdx;}}
      var fwLeft=fwBudget-fwB;
      if(HCAP&&HCS&&!(p.pth&&a.inPTH)&&fwB>0)HCS.hb+=fwB*Math.min(1,(hSA+hcX)/Math.max(1e-9,essF));  // v5.2 step 7: BU spent on rent outside PTH (at shares of the essentials they buy)
      cf=cfPreCCO+hcX-fwB/mainLoopCostUSD;hcDone=true;if(spC)cf-=spC/mainLoopCostUSD;a._fwBUm=fwB0/12;if(SXS)a._sxBU=fwB;  // S47: BU spent (reporting only)  // the neutral BLEI gate counts the BU that would be spent without the cut (no price cut enters it)
      if(SPON){a._spBU=fwB;if(PAS)FWS.next.bizBUptf=(FWS.next.bizBUptf||0)+fwB*paW(a);else if(p.ptf&&a.inPTF)FWS.next.bizBUptf=(FWS.next.bizBUptf||0)+fwB;}  // S55: under open access, the zone's share of every holder's BU  // plan step 1: BU accepted by PTFs (PTF members' purchases)
      if(SPON&&PJON)SPS.y[yr].pjFreed+=(fwB0-fwB)*PROJ.share;
      FWS.next.bizBU+=fwB;FWS.next.expiredBU+=fwLeft;FWS.next.projBU+=fwLeft*FW.directedShare;FWS.next.destroyedBU+=fwLeft*(1-FW.directedShare);
      if(PJON){PJS.next.pool+=fwLeft*PROJ.share;PJS.acc.exp+=fwLeft/pjIdx;PJS.acc.pool+=fwLeft*PROJ.share/pjIdx;}  // N1 (session 15): the same pool, paid as project hiring
      if(LEDGER){ledAdd(yr,'fwBudget',fwBudget);ledAdd(yr,'fwBUSpent',fwB);ledAdd(yr,'fwBUExpired',fwLeft);ledAdd(yr,'fwBUDirected',fwLeft*FW.directedShare);}
      if(ACCT){a._acBi=fwBudget;a._acBs=fwB;a._acBk+=PJON?fwLeft*(1-PROJ.share):fwLeft*(1-FW.directedShare);}  // v5.3 B2: issued, spent, and the expired BU not directed (destroyed)
    } else if(SPON&&a._spE>0&&spDelta>0){var spC2=spDelta*a._spE;cf-=spC2/mainLoopCostUSD;a._spCutY=spC2;SPS.y[yr].cut+=spC2;SPS.acc.cut+=spC2/spIdx;SPS.acc.cash+=spC2/spIdx;if(!a.inCCO)SPS.acc.cutN+=spC2/spIdx;else SPS.acc.cutP+=spC2/spIdx;}  // plan step 1: a customer without BU saves the cut in cash
    if(hcX>0&&!hcDone)cf+=hcX;  // v5.2 step 7: without BU the higher rent is paid in cash
    var emQ=null,emWk=0;if(EMPL&&EMS){var emU=[EMS.r(),EMS.r(),EMS.r(),EMS.r(),EMS.r(),EMS.r()];emWk=a.wage*12*CFG.WAGE_TO_USD*incomeShock/52;if(!a._ret)emQ=emplYear(a,recSt.active,popAIDisp,emU,emWk);}  // v5.4 item 2: job loss (own stream, six draws whatever the state)
    var annualWageUSD=a._ret?0:a.wage*12*CFG.WAGE_TO_USD*incomeShock*(1+mlNT);
    if(emQ)annualWageUSD*=1-emQ.out;
    if(HEALTH)a._hlOut=emQ?emQ.out:0;  // session 2a: a year mostly out of work loses employer coverage next year
    if(dsOn)annualWageUSD*=1-Math.min(52,DIS.weeks)/52;  // v5.4 item 5: weeks of work lost to the disaster  // v5.2 step 4: a retiree earns no wage  // v5.2 step 6: mlNT = 0 unless the spending layer fills normal-times slack
    var tbG=0,tbPT=0;if(tbY&&POS&&p.ptf){a._csFree=poFree(a,mainLoopCostUSD,cfPTF,fSA,hSA);a._csFreeY=a._csFree;a._poS=Math.max(0,mainLoopCostUSD*(1-cfPTF)-a._csFree);a._poF=a._csFree;}else if(tbY&&COST&&p.ptf&&(a.inPTF||PAS)){a._csFree=Math.min(mainLoopCostUSD*(1-cfPTF),PAS?mainLoopCostUSD*(fSA*COST.food+hSA*COST.util)*paW(a):mainLoopCostUSD*(fSA*COST.food+hSA*COST.util));a._csFreeY=a._csFree;}  // S55: under open access, on the share bought at PTFs  // plan step 5: the PTF discount a PTF funds from forgone profit (accounting only)
    if(tbY){tbPT=mainLoopCostUSD*(1-cfPreCCO);if(lvRc>0)tbPT-=mainLoopCostUSD*lvRc;if(p.tb.groc&&a._tbU<p.tb.groc.cover)tbG=mainLoopCostUSD*p.tb.groc.cut*(fSA+(p.tb.groc.housing?hSA:0));}  // session 11: X-Cents Power of 1 on housing too (groc.housing)  // session 6: PTF/PTH price-cut dollars; public-grocery cut on the food component
    if(LABOR){  // session 4 (A3): the labor-supply response replaces this year's wage earnings (no RNG)
      var lbE0=annualWageUSD,lbBU=0,lbR=0,lbC=a._labC||0,lbU=p.ubi||0;
      if(p.ccoOn&&a.inCCO&&p.bu>0&&!PATHWAY_OFF.relief){if(FWON){lbBU=fwB;lbR=fwLeft;}else lbBU=mainLoopCostUSD*(cfPreCCO-cf);}
      var lbBiz=(FWON&&FWS.prev&&FWS.prev.wSum>0)?Math.max(0,FWS.prev.bizNet)/FWS.prev.wSum:0;
      if(ESON&&ESP.rest==='esp')lbBiz=(a._esWk&&ESS.wW>0&&FWS.prev)?Math.max(0,FWS.prev.bizNet)/ESS.wW:0;  // d75 alternative: the ESP's premium reaches its own workers only
      if(SPON)lbBiz=(a._spWk?spProfW:0)+spRestW;  // plan step 1 (d104): the profit share is a raise for ESP workers only; a remainder paid as today stays a raise for all
      var lbRaise=Math.pow(Math.max(1,LFS&&a._lf&&!(a._lwNB>0)?1:a.wage/a._lwNB)*(1+lbBiz)*(ESON?1+a._esX:1),LABOR.eps-LABOR.rho);  // uncompensated: Slutsky e_u = e_c + eta, eta = -rho. Session 19: x the ESP payroll raise (earned: one elasticity, no income effect)
      var tbQ=tbY?tbLab(a,tbY,lbE0,lvRc>0?tbPT+tbG+(SPON?a._spCutY:0)+mainLoopCostUSD*lvRc:tbPT+tbG+(SPON?a._spCutY:0)):null;if(tbQ)lbRaise*=tbQ.F;  // session 6: phase-out and contribution rates (one elasticity), extra unconditional dollars (one income effect)
      var lbInc=LABOR.rho*lbU+LABOR.rhoBU*lbBU+LABOR.rhoR*lbR+LABOR.rho*(1-LABOR.delta)*lbC+(tbQ?LABOR.rho*tbQ.V:0),lbDisp=LABOR.delta*lbC+(tbQ?tbQ.D:0);
      if(SPON&&a._spOwn>0){lbInc+=LABOR.rho*a._spOwn;if(LABOR.acc)LABOR.acc.cash+=LABOR.rho*a._spOwn;}  // plan step 1: owners' dollars are unconditional (one income effect)
      if(emQ){lbInc*=1-emQ.out;lbDisp*=1-emQ.out;}  // v5.4 item 2: the hours response applies to the part of the year at work
      var bgG=0;if(BARGAIN&&lbE0>0&&!a._ret){  // S60: the outside option (the income effect's unconditional dollars at its weights, no safety net) and the year's bargained raise (no RNG)
        var bgO=lbU+(LABOR.rho>0?LABOR.rhoBU/LABOR.rho:1)*lbBU+(LABOR.rho>0?LABOR.rhoR/LABOR.rho:0)*lbR+(1-LABOR.delta)*lbC+(tbQ?tbQ.O:0)+(SPON&&a._spOwn>0?a._spOwn:0),bgEf=a.wage*12*CFG.WAGE_TO_USD*incomeShock*(1+mlNT);
        bgG=bgRaise(bgO,bgEf,BARGAIN);a._bgG=bgG;if(POS){POS.gN+=lbE0*bgG;POS.gD+=lbE0;}var bgE1=Math.max(0,lbE0*lbRaise-lbInc-lbDisp);if(bgG>0)lbRaise*=Math.pow(1+bgG,1+LABOR.eps-LABOR.rho);  // the wage and the hours response to it at the one elasticity (guardrail 7)
        if(BGS)bgAcc(a,yr,BGS.T,lbE0,bgG,bgO,bgEf,Math.max(1,LFS&&a._lf&&!(a._lwNB>0)?1:a.wage/a._lwNB)*(1+lbBiz)*(ESON?1+a._esX:1),Math.max(0,lbE0*lbRaise-lbInc-lbDisp)-bgE1,Math.pow(1+inflRate,yr)*(PRICE?PRICE.bIdx:1));}
      else if(BARGAIN)a._bgG=0;  // S60: reporting state (the year's raise; 0 for a non-worker)
      annualWageUSD=LFS&&LFS.pm>0&&lbE0>0&&!a._ret?lfPM(a,lbE0*lbRaise-lbDisp,lbInc,(LABOR.rho*lbU+LABOR.rhoBU*lbBU+LABOR.rhoR*lbR+LABOR.rho*(1-LABOR.delta)*lbC+(tbQ?LABOR.rho*tbQ.O:0)+(SPON&&a._spOwn>0?LABOR.rho*a._spOwn:0))*(emQ?1-emQ.out:1),emQ,yr,agP):Math.max(0,lbE0*lbRaise-lbInc-lbDisp);a._lbE0=bgG>0?lbE0*(1+bgG):lbE0;if(LFS&&LFS.ac)lfAcc(a,annualWageUSD,yr);  // S73: the programme's participation margin (lf.pm) and the flows' tallies  // session 8 (A5): earnings with no response, for the hours measure (S60: at the bargained wage)
      if(tbQ&&LABOR.acc)LABOR.acc.cash+=LABOR.rho*tbQ.V;
      if(LABOR.acc){var LA=LABOR.acc;LA.n++;if(a.inCCO)LA.nP++;LA.E0+=lbE0;LA.E+=annualWageUSD;LA.raise+=lbE0*(lbRaise-1);LA.cash+=LABOR.rho*lbU;LA.bu+=LABOR.rhoBU*lbBU;LA.buR+=LABOR.rhoR*lbR;
        LA.rent+=LABOR.rho*(1-LABOR.delta)*lbC;LA.disp+=lbDisp;LA.C+=lbC;LA.U+=lbU+lbBU;LA.projH+=lbE0>0?lbDisp/lbE0:0;if(annualWageUSD===0&&lbE0>0)LA.zero++;}
    }
    if(PJON){a._pjHW=0;if(a._pjBU>0){var pjH=a._pjBU/pjPay,pjHw=a.wage*12*CFG.WAGE_TO_USD*incomeShock/PROJ.hrsYr*(BARGAIN&&a._bgG>0?1+a._bgG:1),pjD=pjH*pjHw;  // N1 (session 15): project hours
      if(PROJ.hours==='displace'){pjD=Math.min(pjD,Math.max(0,annualWageUSD));annualWageUSD-=pjD;if(LABOR&&LABOR.acc)LABOR.acc.E-=pjD;}
      a._pjHW=pjD;PJS.acc.hrs+=pjH;PJS.acc.disp+=(PROJ.hours==='displace'?pjD:0)/pjIdx;}}
    if(SNET&&SNET.abawd){var abW=emQ?emQ.out*52:0,abUi=emQ&&emWk>0?Math.min(abW,emQ.ui/(CFG.EMPL_UI_REPL*emWk)):0,abB=LABOR?(a._lbE0||0):annualWageUSD,abR=abB>0?(LABOR?annualWageUSD/abB:1):0;a._snAbC=a._ret?0:12*Math.max(0,(abR<0.5?52:abW)-abUi)/52;if(FX&&FX.ab&&a._snAbC<1e-9)a._snAbC=0;}  // session 7: SNAP's work rule, this year's months not meeting it (read next year)
    if(tbG)cf-=tbG/mainLoopCostUSD;  // session 6: public grocery (applied after the labor block reads the CCO relief)
    var costUSD=mainLoopCostUSD*cf;
    if(HEALTH&&HLS&&a._hlD)costUSD+=a._hlD*HLS.mIdx;  // session 2a: the household's medical bill above (or below) its basket line, in cash, at medical prices
    a.wealth+=annualWageUSD-costUSD;
    if(SPEND_GRADE&&!(AUD&&AUD.sg)){var grA=annualWageUSD+(a._ret?a._ssY:0)+(p.ubi>0?p.ubi:0)+(emQ?emQ.ui:0);if(SNET&&SNS&&a._snB)grA+=a._snB;a._grCut=0;if(HHP){a._grA=grA;a._grC=costUSD;}else if(costUSD>0&&grA<costUSD){a._grCut=DEBT_READ&&DEBT_READ.fl==='fpl'?drFloorCut(grA,costUSD,SPEND_GRADE.eps,drFloorShare(a._hh)):costUSD-costUSD*Math.pow(Math.max(0,grA)/costUSD,SPEND_GRADE.eps);if(DEBT_READ)a._grCut+=drExtra(grA,costUSD,a._grCut,a.yrWealthStartUSD);a.wealth+=a._grCut;if(ACCT)a._acGr=a._grCut;}}  // v5.3 B7: less income, less spending (off by default)
    a.yrSSUSD=a._ret?a._ssY:0;if(a._ret){a.wealth+=a._ssY;if(LEDGER)ledAdd(yr,'ssBenefit',a._ssY);}  // v5.2 step 4: the Social Security benefit (money income)
    if(SURPLUS_CONSUMPTION_SHARE>0&&SURPLUS_CONSUMPTION_BASE==='wage'&&!HHP)a.wealth-=SURPLUS_CONSUMPTION_SHARE*Math.max(0,annualWageUSD-costUSD);  // v4.21: harness-only (saving mode)
    if(ACCT&&SURPLUS_CONSUMPTION_SHARE>0&&SURPLUS_CONSUMPTION_BASE==='wage'&&!HHP)a._acSc+=SURPLUS_CONSUMPTION_SHARE*Math.max(0,annualWageUSD-costUSD);  // v5.3 B2
    if(HHP)a._hhWS=annualWageUSD-costUSD;  // v5.3 B3: a pooled couple's spending rule is applied to the couple (hhPool)
    if(p.ubi>0){a.wealth+=p.ubi;a.yrUbiUSD=p.ubi;if(ACCT)a._acU=p.ubi;}
    if(EMPL){var emUI=emQ?emQ.ui:0;a.yrUbiUSD=(p.ubi>0?p.ubi:0)+emUI;if(emUI>0){a.wealth+=emUI;if(ACCT)a._acU=(p.ubi>0?p.ubi:0)+emUI;}}  // v5.4 item 2: unemployment insurance (cash, like the UBI comparator's)
    if(dsOn){var dsP=Math.pow(1+inflRate,yr)*(PRICE?PRICE.bIdx:1),dsD=((a._disAid?CFG.DIS_AID:0)-DIS.loss)*dsP/a._disN;a.wealth+=dsD;if(ACCT)a._acU=(a._acU||0)+dsD;}  // v5.4 item 5: the damage and federal aid (both runs)  // session 4: UBI comparator (harness-only; unset in every preset)
    var yrCashSurplus=annualWageUSD-costUSD+(p.ubi>0?p.ubi:0)+(a._ret?a._ssY:0);
    if(RETURNS&&RETURNS.ci){var rtCk=a._rtCk||0;a.yrCapUSD=rtCk;if(rtCk!==0){a.wealth+=rtCk;yrCashSurplus+=rtCk;if(ACCT)a._acU=(a._acU||0)+rtCk;}}  // S59 part 2: the income wealth pays (cash; untaxed)
    if(emQ&&emQ.ui>0)yrCashSurplus+=emQ.ui;  // v5.4 item 2  // v5.2 step 4: + the benefit  // session 1: for SURPLUS_CONSUMPTION_BASE 'cash' (harness-only; no RNG)
    if(tbY){var tbK=tbCashFlow(a,tbY,annualWageUSD,yr);a.wealth+=tbK.net+tbK.endow;yrCashSurplus+=tbK.net;if(HEALTH)a._hlTb=SNET&&SNS&&a._snB?tbK.net-a._snB:tbK.net;if(ACCT)a._acT=tbK.net+tbK.endow;}  // session 6: cash transfers less the contribution; an endowment is wealth, not consumable surplus
    if(LEDGER){  // A1 ledger (reporting only): no RNG, no state read by any dynamic
      ledAdd(yr,'agentYears',1);if(a.inCCO)ledAdd(yr,'partYears',1);
      ledAdd(yr,'wage',annualWageUSD);ledAdd(yr,'cost',costUSD);ledAdd(yr,'basket',mainLoopCostUSD);
      if(SURPLUS_CONSUMPTION_SHARE>0&&SURPLUS_CONSUMPTION_BASE==='wage'&&!HHP)ledAdd(yr,'surplusConsumed',SURPLUS_CONSUMPTION_SHARE*Math.max(0,annualWageUSD-costUSD));
      ledAdd(yr,'ptfRelief',mainLoopCostUSD*(1-cfPTF));ledAdd(yr,'pthRelief',mainLoopCostUSD*(cfPTF-cfPreCCO));
      ledAdd(yr,a.inCCO?'ccoRelief':'emergRelief',mainLoopCostUSD*(cfPreCCO-cf));
    }
    a.yrWageUSD=annualWageUSD;a.yrCostUSD=costUSD;a.yrBasketUSD=mainLoopCostUSD;a.yrConvUSD=0;  /* v4.17: income/basket poverty inputs (no RNG) */
    if(FWON){  // session 2, N1: last year's business conversion premium, paid to every agent in proportion to last year's wage income
      a._fwPayY=0;  // session 19: reporting only (the testbed's premium-by-group columns)
      if(FWS.prev&&FWS.prev.wSum>0){var fwPay=FWS.prev.bizNet*(a._fwW||0)/FWS.prev.wSum;
        if(ESON&&ESP.rest==='esp')fwPay=(a._esWk&&ESS.wW>0)?FWS.prev.bizNet*(a._fwW||0)/ESS.wW:0;  // d75 alternative (session 19): a worker cooperative
        if(SPON){fwPay=a._spPay;SPS.y[yr].paid+=fwPay;SPS.acc.profit+=(fwPay-a._spOwn-a._spRest)/spIdx;if(!a.inCCO)SPS.acc.non+=fwPay/spIdx;if(a._spWk&&yr>0){SPS.acc.wkY1++;SPS.acc.profitN+=(fwPay-a._spOwn-a._spRest)/spIdx;}}  // plan step 1: profit share, owners' dollars and any remainder paid as today
        a.wealth+=fwPay;a.yrConvUSD+=fwPay;yrCashSurplus+=fwPay;FWS.next.bizPaid+=fwPay;a._fwPayY=fwPay;
        if(PRICE)PRICE.acc.conv+=fwPay;if(LEDGER)ledAdd(yr,'fwBizPayout',fwPay);}
      if(ESON){a._esPrY=0;if(a._esC>0){  // session 19 (s38, d73): ESP payroll BU converted at the worker's own rate; the premium over face value is conversion income
        var esTx=pjTax(p,a._esR),esG=PATHWAY_OFF.conversion?0:a._esC*a._esR*esCipB*incomeShock,esPr=PATHWAY_OFF.conversion?0:esG*(1-esTx)-a._esC;
        a.wealth+=esPr;a.yrConvUSD+=esPr;yrCashSurplus+=esPr;a._esPrY=esPr;a._esShk=incomeShock;
        if(tbY)TB.cur.ctax+=esG*esTx;var esAc=ESS.acc;esAc.conv+=a._esC/esIdx;esAc.gross+=esG/esIdx;esAc.tax+=esG*esTx/esIdx;esAc.prem+=esPr/esIdx;esAc.rateXbu+=a._esR*a._esC/esIdx;
        if(PRICE)PRICE.acc.conv+=esPr;if(LEDGER){ledAdd(yr,'espGross',esG);ledAdd(yr,'espTax',esG*esTx);ledAdd(yr,'espPremium',esPr);}}}
      a._fwW=annualWageUSD;FWS.next.wSum+=annualWageUSD;
    }
    if(isNaN(a.wealth))a.wealth=0;
    if(p.ccoOn&&a.inCCO&&FWON){
      /* Session 2, CONVERSION_MODEL 'framework' (N1-N4). No personal BU balance and no conversion of one's own spending:
       * the participant converts the BU directed to projects last year (N2), allocated in proportion to octave capacity
       * x quality, capped at their octave capacity, at their own engine rate and under the engine's progressive tax.
       * The draws above are made exactly as in the engine branch, so the two models stay CRN-paired. */
      if(p.cip&&uCipQuality<p.cipDemo*0.15)a.quality=Math.min(p.maxMult,a.quality+0.1);
      var octCeilF=1+(a.octave/Math.max(1,p.maxOct))*(Math.max(1,p.maxMult)-1),qfF=Math.min(1,a.quality/Math.max(1,p.maxMult));
      var phiF=(p.phi&&a.quality>p.maxMult*CFG.PHI_QUALITY_THRESH)?CFG.PHI_RATIO:1.0,ptfBF=POS?poBonus(a,p,clPCB(a)):(p.ptf&&a.inPTF)?clPCB(a):1.0;if(POS&&!PROJ){POS.bn+=ptfBF-1;POS.bc++;}
      var rateF=Math.min((1+qfF*(octCeilF-1))*phiF*ptfBF,p.maxMult*(p.phi?CFG.PHI_RATIO:1.0));
      var bTaxF=p.cip?p.tax*(1-p.cipDemo*0.18):p.tax,taxF=Math.min(CFG.PROG_TAX_MAX,bTaxF+Math.max(0,(rateF-CFG.PROG_PIVOT)*CFG.PROG_RATE));
      var cipBF=p.cip?(1+p.cipDemo*0.12):1.0,capBU=12*FW.octaveCapBase*Math.pow(2,a.octave);
      if(FWS.prev&&FWS.prev.pwSum>0&&!PJON){  // N1 (session 15): project hiring replaces N2's allocation
        var fwWant=FWS.prev.projBU*(a._fwPW||0)/FWS.prev.pwSum,fwAl=Math.min(capBU,fwWant);
        var fwG=PATHWAY_OFF.conversion?0:fwAl*rateF*cipBF*incomeShock,fwN=fwG*(1-taxF);
        if(tbY)TB.cur.ctax+=fwG*taxF;a.wealth+=fwN;a.yrConvUSD+=fwN;yrCashSurplus+=fwN;totalConversion+=fwN;totalBU+=fwAl;if(LABOR)a._labCn=fwN;
        if(ACCT){a._acBc+=fwAl;a._acBk+=fwWant-fwAl;ACCT.cur.want+=fwWant;}  // v5.3 B2
        FWS.next.projAlloc+=fwAl;FWS.next.projGross+=fwG;FWS.next.projTax+=fwG*taxF;FWS.next.projNet+=fwN;FWS.next.projLost+=fwWant-fwAl;
        if(PRICE)PRICE.acc.conv+=fwN;
        if(LEDGER){ledAdd(yr,'fwProjBU',fwAl);ledAdd(yr,'fwProjGross',fwG);ledAdd(yr,'fwProjTax',fwG*taxF);ledAdd(yr,'fwProjNet',fwN);ledAdd(yr,'fwProjLost',fwWant-fwAl);ledAdd(yr,'fwProjRateXbu',rateF*fwAl);}
      }
      a._fwPW=capBU*Math.max(0,a.quality);FWS.next.pwSum+=a._fwPW;
      if(a.octave<p.maxOct){  // as in the engine branch, except that the monthly basic cost is read before the BU purchase, since BU is added as income here
        var YusdF=a.wage*CFG.WAGE_TO_USD,cBasicF=(dcA*cfPreCCO)/12,edcF=(p.pth&&a.inPTH)?CFG.FBS_EDC_RESIDUAL_PTH:CFG.FBS_EDC_RESIDUAL_BASE;
        var fbsF=Math.max(0,YusdF+buA-cBasicF-edcF*YusdF)/(AUD&&AUD.fbs?priceIdx:1),lamF=(typeof a.lambda==='number'&&!isNaN(a.lambda))?a.lambda:(CFG.FBS_LAMBDA_LO+CFG.FBS_LAMBDA_HI)/2;
        if(p.cip)lamF*=(1+p.cipDemo*CFG.FBS_CIP_LAMBDA_BOOST);
        if(FBS50){if(FBS50.dist!=='lambda'||(FBS50.scale||1)!==1){lamF=Math.LN2/fbs50Of(a.lambda);if(p.cip)lamF*=(1+p.cipDemo*CFG.FBS_CIP_LAMBDA_BOOST);}if(FBSS&&tbY){var fbK=!!(a._hh&&a._hh.kids.length);FBSS.n++;if(lamF*fbsF>=Math.LN2)FBSS.a++;if(fbK){FBSS.nK++;if(lamF*fbsF>=Math.LN2)FBSS.aK++;}if(yr===0)FBSS.f.push(Math.LN2/lamF);}}  // v5.3 B7: FBS50 (off by default)
        if(uAdvance<1-Math.exp(-lamF*fbsF)&&!PATHWAY_OFF.octave&&!(OCT&&yr-(a._ocY||0)<OCT.gap)){a.octave++;if(OCT)a._ocY=yr;}  // plan step 6: OCT gap (sensitivity)
      }
      if(uSzhInduce<clPB(a)&&!a.inPTF&&p.ptf&&!(HHA&&!a._hhHead)&&ptfCapAllows()){a.inPTF=uSzhPtfShare<p.ptfShare;if(a.inPTF&&p.ptfCap)ptfLiveCount++;if(a.inPTF&&PDON)pdLive++;}else if(PDON&&PROD.speed==='oneyear'&&uSzhInduce<clPB(a)&&!a.inPTF&&p.ptf&&!(HHA&&!a._hhHead)&&uSzhPtfShare<p.ptfShare&&(!p.ptfCap||ptfLiveCount<ptfLiveTotal*p.ptfShare))PDS.blk++;  // plan step 15: turned away for lack of PTF capacity
    } else if(p.ccoOn&&a.inCCO){
      /* v4.14 parity fix — ported from index.html: this was a step function (decay=0 at
       * expiry=1, decay=0.7 at every other slider value, 2-6 all identical) rather than a
       * continuous function of the slider. Replaced with decay=1-1/expiry, a documented
       * annual-approximation interpretation. At expiry=1 (used by every shipped preset and
       * this harness's own FULL_INTEGRATION/BASELINE configs) decay=0, identical to the
       * prior behaviour — zero effect on any documented regression figure. See
       * CONTRIBUTING.md's v4.14 Release Notes. */
      var decay=Math.max(0,1-1/Math.max(1,p.expiry||1));
      if(stabOn&&p.stabSusp)decay=1;  // v4.19: expiry suspended while triggered  /* v4.15 parity: || 1 guards a missing expiry — Math.max(1,undefined) is NaN */
      if(LEDGER){var lbK=a.buBalance*decay,lbI=buEff*BU_ALLOCATIONS_PER_YEAR,lbC=buEff*3*BU_ALLOCATIONS_PER_YEAR;ledAdd(yr,'buIssued',lbI);ledAdd(yr,'buExpired',(a.buBalance-lbK)+Math.max(0,lbK+lbI-lbC));}  // A1 ledger
      if(ACCT){var acK=a.buBalance*decay;a._acBi=buEff*BU_ALLOCATIONS_PER_YEAR;a._acBx=(a.buBalance-acK)+Math.max(0,acK+a._acBi-buEff*3*BU_ALLOCATIONS_PER_YEAR);}  // v5.3 B2
      if(PJON){var pjK=a.buBalance*decay,pjAl=buEff*BU_ALLOCATIONS_PER_YEAR,pjX=(a.buBalance-pjK)+Math.max(0,pjK+pjAl-buEff*3*BU_ALLOCATIONS_PER_YEAR);PJS.next.pool+=pjX*PROJ.share;PJS.acc.exp+=pjX/pjIdx;PJS.acc.pool+=pjX*PROJ.share/pjIdx;}  // N1 (session 15): expired BU go to projects
      a.buBalance=Math.min(a.buBalance*decay+buEff*BU_ALLOCATIONS_PER_YEAR,buEff*3*BU_ALLOCATIONS_PER_YEAR);  // v4.19: buEff; allocations/yr is a harness-only switch (index.html: 1)
      var spend=a.buBalance*uSpendFrac;a.buBalance-=spend;totalBU+=spend;if(ACCT){a._acBs=spend;a._acBc+=spend;}
      if(p.cip&&uCipQuality<p.cipDemo*0.15)a.quality=Math.min(p.maxMult,a.quality+0.1);
      var octCeiling=1+(a.octave/Math.max(1,p.maxOct))*(Math.max(1,p.maxMult)-1);
      var qualityFactor=Math.min(1,a.quality/Math.max(1,p.maxMult));
      var baseRate=1+qualityFactor*(octCeiling-1);
      var phi=(p.phi&&a.quality>p.maxMult*CFG.PHI_QUALITY_THRESH)?CFG.PHI_RATIO:1.0;
      var ptfB=POS?poBonus(a,p,clPCB(a)):(p.ptf&&a.inPTF)?clPCB(a):1.0;
      var cipB=p.cip?(1+p.cipDemo*0.12):1.0;
      var rate=Math.min(baseRate*phi*ptfB,p.maxMult*(p.phi?CFG.PHI_RATIO:1.0));
      var bTax=p.cip?p.tax*(1-p.cipDemo*0.18):p.tax;
      var progTax=Math.min(CFG.PROG_TAX_MAX,bTax+Math.max(0,(rate-CFG.PROG_PIVOT)*CFG.PROG_RATE));
      var convGain=PATHWAY_OFF.conversion?0:spend*rate*(1-progTax)*cipB*incomeShock;  // v4.21: pathway switch
      a.wealth+=convGain;totalConversion+=convGain;a.yrConvUSD=convGain;yrCashSurplus+=convGain;if(LABOR)a._labCn=convGain;
      if(PRICE)PRICE.acc.conv+=convGain;  // session 2: price module (P_G injection)
      if(LEDGER){var lcG=PATHWAY_OFF.conversion?0:spend*rate*cipB*incomeShock,lcT=lcG*progTax,lcI=0;while(lcI<LEDGER_RATE_TIERS.length&&rate>=LEDGER_RATE_TIERS[lcI])lcI++;
        var lcTier=LEDGER.tiers[lcI];lcTier.bu+=spend;lcTier.gross+=lcG;lcTier.tax+=lcT;lcTier.net+=convGain;lcTier.n++;
        ledAdd(yr,'buSpent',spend);ledAdd(yr,'convGross',lcG);ledAdd(yr,'convTax',lcT);ledAdd(yr,'convNet',convGain);ledAdd(yr,'convRateXspend',rate*spend);}  // A1 ledger
      if(isNaN(a.wealth))a.wealth=0;
      if(a.octave<p.maxOct){
        var Yusd=a.wage*CFG.WAGE_TO_USD;
        var cBasicMonthly=(dollarCost*(FBS_BU_ONCE?cfPreCCO:cf))/12;  // session 7: harness-only switch (i3-1); index.html reads cf
        var edcResidual=(p.pth&&a.inPTH)?CFG.FBS_EDC_RESIDUAL_PTH:CFG.FBS_EDC_RESIDUAL_BASE;
        var fbs=Math.max(0,Yusd+buEff-cBasicMonthly-edcResidual*Yusd);
        var lam=(typeof a.lambda==='number'&&!isNaN(a.lambda))?a.lambda:(CFG.FBS_LAMBDA_LO+CFG.FBS_LAMBDA_HI)/2;
        if(p.cip)lam*=(1+p.cipDemo*CFG.FBS_CIP_LAMBDA_BOOST);
        var pAdvance=1-Math.exp(-lam*fbs);
        if(uAdvance<pAdvance&&!PATHWAY_OFF.octave)a.octave++;  // v4.21: pathway switch
      }
      if(uSzhInduce<clPB(a)&&!a.inPTF&&p.ptf&&!(HHA&&!a._hhHead)&&ptfCapAllows()){a.inPTF=uSzhPtfShare<p.ptfShare;if(a.inPTF&&p.ptfCap)ptfLiveCount++;if(a.inPTF&&PDON)pdLive++;}else if(PDON&&PROD.speed==='oneyear'&&uSzhInduce<clPB(a)&&!a.inPTF&&p.ptf&&!(HHA&&!a._hhHead)&&uSzhPtfShare<p.ptfShare&&(!p.ptfCap||ptfLiveCount<ptfLiveTotal*p.ptfShare))PDS.blk++;  // plan step 15: turned away for lack of PTF capacity
    }
    if(PJON&&p.ccoOn&&a.inCCO){  // N1 (session 15): convert project BU (and a holder's own gift) within octave capacity; the rest is saved
      var pjA=PJS.acc,pjCapR=PROJ.cap?Math.max(0,a._pjCap-(FWON?0:spend)):Infinity,pjE=(a._pjSaved||0)+(a._pjBU||0),pjC1=Math.min(pjE,pjCapR);a._pjSaved=pjE-pjC1;pjCapR-=pjC1;
      var pjGh=a._pjGiftH||0,pjC2=Math.min(pjGh,pjCapR);a._pjGiftH=pjGh-pjC2;if(ACCT)a._acBc+=pjC1+pjC2;
      if(PROJ.cap&&pjC1+pjC2>Math.max(0,a._pjCap-(FWON?0:spend))+1e-6)pjA.overCap++;  // project BU fill the capacity the engine's own-spending conversion leaves (that conversion is not capped; at $1,200 BU it never reaches 12,000)
      var rvR=a._pjRu,rvU=false,rvE=0;if(REVIEW&&REVS&&a._pjRu>1&&a._rvU<REVIEW.u){if(a._rvU<REVIEW.u*REVIEW.q)rvR=1;else rvU=true;}  // v5.2 step 7: an unearned high rate, caught (paid at 1x) or not
      var pjTx=pjTax(p,rvR),pjG1=PATHWAY_OFF.conversion?0:pjC1*rvR*pjCipB*incomeShock,pjN1=pjG1*(1-pjTx);
      if(REVIEW&&REVS&&!PATHWAY_OFF.conversion&&a._pjRu>1&&a._rvU<REVIEW.u){var rvF=pjC1*a._pjRu*pjCipB*incomeShock*(1-pjTax(p,a._pjRu));rvE=pjC1*pjCipB*incomeShock*(1-pjTax(p,1));if(rvU)REVS.x+=(pjN1-rvE)/pjIdx;else REVS.c+=(rvF-pjN1)/pjIdx;}
      var pjTg=pjTax(p,a._pjR),pjG2=PATHWAY_OFF.conversion?0:pjC2*a._pjR*pjCipB*incomeShock,pjN2=pjG2*(1-pjTg);
      if(PROD&&FWON){var pdH=pjC1/pjPay,pdV=pdH*(PROD.match==='face'?pjPay:a.wage*12*CFG.WAGE_TO_USD*incomeShock/PROJ.hrsYr)*(1+(PROD.mat||0));a._pdM=PROD.match==='market'?Math.max(0,rvU?rvE:pjN1):Math.min(Math.max(0,pjN1),pdV);a._pdMy=a._pdM;a._pdNy=pjN1;a._pdVy=pdV;}  // plan step 2: project output at the cost of the hours (_pd*y: reporting only)
      if(tbY)TB.cur.ctax+=pjG1*pjTx+pjG2*pjTg;a.wealth+=pjN1+pjN2;a.yrConvUSD+=pjN1+pjN2;yrCashSurplus+=pjN1+pjN2;totalConversion+=pjN1+pjN2;totalBU+=pjC1+pjC2;
      if(LABOR&&pjN2)a._labCn=(a._labCn||0)+pjN2;  // the holder's gift is an unconditional dollar: the rent channel
      a.yrPjGift=pjN1*pjFg+pjN2;  // d66: gift-funded proceeds, tallied so the testbed can finance them as you go or over the run (the carried share is approximate)
      if(PRICE)PRICE.acc.conv+=pjN1+pjN2;
      pjA.conv+=pjC1/pjIdx;pjA.giftConv+=pjC2/pjIdx;pjA.gross+=(pjG1+pjG2)/pjIdx;pjA.net+=pjN1/pjIdx;pjA.giftNet+=pjN2/pjIdx;
      if(LEDGER){ledAdd(yr,'pjBU',a._pjBU||0);ledAdd(yr,'pjConvBU',pjC1+pjC2);ledAdd(yr,'pjNet',pjN1+pjN2);}
      if(isNaN(a.wealth))a.wealth=0;
    }
    if(p.pth&&a.inPTH&&!PATHWAY_OFF.pthEquity&&!PATHWAY_OFF.pthCost){  // v4.21: pathway switches (off: no routing, no appreciation)
      if(typeof a.pthTenure!=='number'||isNaN(a.pthTenure))a.pthTenure=0;
      a.pthTenure+=1;
      var cfWithoutPTH=cf/0.65;
      var pthSaving=Math.max(0,dcA*cfWithoutPTH*(1-0.65));
      if(rsAlt)pthSaving=Math.max(0,dcA*(cfPTF-cfPreCCO)*rsRel);  // session 5 (d4/d5): PTH's own cut on the post-relief basket
      var equityContrib=pthSaving*CFG.PTH_EQUITY_CONTRIB_SHARE;
      a.acreEquity+=equityContrib;a.wealth-=equityContrib;yrCashSurplus-=equityContrib;  // session 1: equity routing is not discretionary cash
      var ar=0.030+uPthAppr*0.020+pthApprBonus;var pbS=PTHB&&PBS?a._pbS:null,pbV0=0,pbVn=0;if(pbS){if(!pbS.V){pbS.V=CFG.PTHB_PR*hSA*(FX&&FX.hb?mainLoopCostUSD:dcA);pbS.D=pbS.V-(a.acreEquity-equityContrib);}pbV0=pbS.V;pbVn=pbV0*(1+PBS.pi)*(1+CFG.PTHB_G);if(PTHB.cap==='hub')ar=Math.min(pbVn/pbV0-1,PBS.pi+0.02);}  // v5.4 item 3: Acre Equity grows with the home, at most at the price rise + 2%
      var appr=a.acreEquity*ar,lqs=pthLiquidShare(a.pthTenure);
      if(pbS)lqs*=appr>0?Math.max(0,appr-PBS.pi*a.acreEquity)/appr:0;  // v5.4 item 3: only the gain above the price rise is paid out in cash; what keeps up with prices stays as equity
      a.acreEquity+=PTH_APPR_CONSERVE?appr*(1-lqs):appr;a.wealth+=appr*lqs;yrCashSurplus+=appr*lqs;  /* v4.16: PTH_APPR_CONSERVE=false is bit-identical to index.html */
      if(tbY)a._tbPthNow=appr*lqs;  // session 6
      if(LEDGER){ledAdd(yr,'pthEquityContrib',equityContrib);ledAdd(yr,'pthAppr',appr);ledAdd(yr,'pthApprLiquid',appr*lqs);}  // A1 ledger
      if(ACCT){a._acPc=equityContrib;a._acPa=appr;a._acPl=appr*lqs;}  // v5.3 B2
      if(pbS){var pbR=hSA*(FX&&FX.hb?mainLoopCostUSD:dcA),pbI=((1+CFG.PTHB_RREAL)*(1+PBS.pi)-1)*pbS.D,pbU=CFG.PTHB_UPK*(1-CFG.PTHB_LAND)*pbV0,pbT=CFG.PTHB_TAX*pbV0,pbL=appr*lqs;  // v5.4 item 3: the trust's books for this home
        pbS.D-=pbR+equityContrib-pbI-pbU-pbT-pbL;pbS.CE+=(pbVn-pbV0)+pbR-pbI-pbU-pbT-appr;pbS.V=pbVn;
        PBS.n++;if(pbR+equityContrib>=pbI-PBS.pi*(pbS.D+pbR+equityContrib-pbI-pbU-pbT-pbL)+pbU+pbT+pbL)PBS.cover++;PBS.aP+=pbV0*PBS.pi/PBS.P;PBS.aR+=pbV0*(1+PBS.pi)*CFG.PTHB_G/PBS.P;PBS.aC+=(pbVn-pbV0-appr)/PBS.P;
        if(ACCT)acctChk('pth-books',yr,(pbS.V-pbS.D)-a.acreEquity-pbS.CE,pbS.V,a._id!==undefined?a._id:null);}
      if(PRICE)PRICE.acc.pthLiq+=appr*lqs;  // session 2: price module
    } else if(a.pthTenure){
      a.pthTenure=0;
    }
    if(p.ptf&&!a.inPTF&&p.ptfShare>0&&yr>0&&!(HHA&&!a._hhHead)&&ptfCapAllows()){var ap=0.005+CFG.PTF_BASS_Q*(CMS&&COMM.bass!=='pop'?CMS.sh[a._cm]:ptfAdoptFrac);if(bleiCheck/(AUD&&AUD.gate?priceIdx:1)<CFG.BLEI_PRECARIOUS_MAX)ap+=0.015;if(uPtfAdopt<ap){a.inPTF=true;if(p.ptfCap)ptfLiveCount++;if(PDON)pdLive++;}}
    else if(PDON&&PROD.speed==='oneyear'&&p.ptf&&!a.inPTF&&p.ptfShare>0&&yr>0&&!(HHA&&!a._hhHead)&&(!p.ptfCap||ptfLiveCount<ptfLiveTotal*p.ptfShare)){var apB=0.005+CFG.PTF_BASS_Q*(CMS&&COMM.bass!=='pop'?CMS.sh[a._cm]:ptfAdoptFrac);if(bleiCheck/(AUD&&AUD.gate?priceIdx:1)<CFG.BLEI_PRECARIOUS_MAX)apB+=0.015;if(uPtfAdopt<apB)PDS.blk++;}  // plan step 15: turned away for lack of PTF capacity
    if(SPEND_GRADE&&AUD&&AUD.sg){var grS=annualWageUSD+(a._ret?a._ssY:0)+(p.ubi>0?p.ubi:0)+(emQ?emQ.ui:0)+(tbY?(a.yrTbCash||0)-(a.yrTax||0):(SNET&&SNS&&a._snB?a._snB:0))+(a.yrConvUSD||0)+(RETURNS&&RETURNS.ci?(a.yrCapUSD||0):0);a._grCut=0;  // S13 sg: all of the year's cash income (S59 part 2: + capital income)
      if(HHP){a._grA=grS;a._grC=costUSD;}else if(costUSD>0&&grS<costUSD){a._grCut=DEBT_READ&&DEBT_READ.fl==='fpl'?drFloorCut(grS,costUSD,SPEND_GRADE.eps,drFloorShare(a._hh)):costUSD-costUSD*Math.pow(Math.max(0,grS)/costUSD,SPEND_GRADE.eps);if(DEBT_READ)a._grCut+=drExtra(grS,costUSD,a._grCut,a.yrWealthStartUSD);a.wealth+=a._grCut;if(ACCT)a._acGr=a._grCut;}}
    if(HHP)a._hhCS=yrCashSurplus;  // v5.3 B3: pooled in hhPool
    if(SURPLUS_CONSUMPTION_SHARE>0&&SURPLUS_CONSUMPTION_BASE==='cash'&&!HHP){var scC=SURPLUS_CONSUMPTION_SHARE*Math.max(0,yrCashSurplus);a.wealth-=scC;if(ACCT)a._acSc+=scC;if(LEDGER)ledAdd(yr,'surplusConsumed',scC);}  // session 1: harness-only
    if(PRICE){  // session 2 (D1/N5): a write-off at the floor is basket consumption that did not happen (unmet need), not spending
      var pmW=(!HHP&&a.wealth<CFG.WEALTH_FLOOR)?CFG.WEALTH_FLOOR-a.wealth:0,pmB=mainLoopCostUSD*cfPreCCO,pmU=pmB>0?Math.min(1,(SPEND_GRADE&&!HHP?pmW+a._grCut:pmW)/pmB):0,A=PRICE.acc;  /* v5.3 B7: + the spending cut */
      A.n++;A.essD+=1-pmU;A.unmet+=pmW;A.basketOwn+=pmB;if(pmW>0)A.unmetN++;A.Y+=annualWageUSD+a.yrConvUSD+(a.yrSSUSD||0);A.Yw+=annualWageUSD+(a.yrSSUSD||0);if(p.ptf&&a.inPTF)A.ptfN++;
      if(HHP)a._hhPmB=pmB;  // v5.3 B3: a pooled couple's unmet need is counted after pooling (hhPool)
      A.wageBonus+=Math.max(0,a.wage-a._wNB)*12*CFG.WAGE_TO_USD*incomeShock;A.wageBonusNS+=Math.max(0,a.wage-a._wNB)*12*CFG.WAGE_TO_USD;  // session 3: the premium before the income shock, for aw's increment reading
    }
    if(LABOR){a._labC=a._labCn||0;a._labCn=0;if(LABOR.acc){LABOR.acc.conv+=a.yrConvUSD||0;if(a.inCCO)LABOR.acc.convP+=a.yrConvUSD||0;}}  // session 4: creator proceeds carried to next year's labor response
    if(tbY)tbAccount(a,tbY,yr,mainLoopCostUSD,cf,cfPreCCO+hcX,costUSD,annualWageUSD,tbG,tbPT);  // v5.2 step 7: + hcX, so BU spent on the higher rent count as BU relief  // session 6: uniform cost ledger and basket FGT (reporting; no RNG)
    if(ACCT&&!HHP&&a.wealth<CFG.WEALTH_FLOOR)a._acFl=CFG.WEALTH_FLOOR-a.wealth;  // v5.3 B2: debt written off at the floor
    if(!HHP&&a.wealth<CFG.WEALTH_FLOOR){if(LEDGER){var lfA=CFG.WEALTH_FLOOR-a.wealth;ledAdd(yr,'floor',lfA);ledAdd(yr,'floorHits',1);a._ledFloor=(a._ledFloor||0)+lfA;}a.wealth=CFG.WEALTH_FLOOR;}  // A1 ledger inside the clamp
    if(ACCT&&!HHP)acctAgent(a,yr);  // v5.3 B2: this adult's identities for the year
  });
  if(HHON){if(HHPOOL)hhPool(yr,!!tbY);hhSync('ptf');}  // v5.3 B3: couples' end of year (pooling), then partners follow the first adult's PTF decision
  if(FWON){  // session 2, N1: businesses convert this year's accepted BU; the premium over a cash sale is paid out next year
    var nx=FWS.next,bTaxB=p.cip?p.tax*(1-p.cipDemo*0.18):p.tax;
    var taxR=Math.min(CFG.PROG_TAX_MAX,bTaxB+Math.max(0,(FW.bizRate-CFG.PROG_PIVOT)*CFG.PROG_RATE)),taxP=Math.min(CFG.PROG_TAX_MAX,bTaxB);if(LVS){bTaxB=lvBizBase(p,bTaxB);taxR=Math.min(LVS.pc,bTaxB+Math.max(0,(FW.bizRate-CFG.PROG_PIVOT)*LVS.pr));taxP=Math.min(LVS.pc,bTaxB);}  // S54: o.lv's business rate, progression and cap
    var bzB=ESON?nx.bizBU*(1-ESP.lam):nx.bizBU;if(ACCT)ACCT.cur.bz=bzB;  // session 19 (d71): with ESP payroll the ESP converts the share it keeps; lam of what it accepted is next year's payroll
    nx.bizGross=bzB*(FW.bizCap*FW.bizRate+(1-FW.bizCap));nx.bizTax=bzB*(FW.bizCap*FW.bizRate*taxR+(1-FW.bizCap)*taxP);
    nx.bizNet=PATHWAY_OFF.conversion?0:nx.bizGross-nx.bizTax-bzB;if(LVS&&nx.bizNet<0){nx.bizTax+=nx.bizNet;nx.bizNet=0;}  /* S54: a business is never paid less than face value */if(tbY)TB.cur.ctax+=nx.bizTax;  // plan step 3: conversion tax kept by the Source (reporting)  // session 7: the conversion switch also covers business-side conversion (harness-only)
    if(LEDGER){ledAdd(yr,'fwBizGross',nx.bizGross);ledAdd(yr,'fwBizTax',nx.bizTax);ledAdd(yr,'fwBizPremium',nx.bizNet);}
    if(ESON){ESS.next={pool:nx.bizBU*ESP.lam};ESS.acc.accBU+=nx.bizBU/esIdx;ESS.acc.ownBU+=bzB/esIdx;ESS.y[yr].acc=nx.bizBU;ESS.y[yr].own=bzB;ESS.y[yr].poolNext=ESS.next.pool;
      if(LEDGER){ledAdd(yr,'espOwnBU',bzB);ledAdd(yr,'espPoolNext',ESS.next.pool);}}
    FWS.prev=nx;
  }
  if(ESON)ESS.prev=ESS.next;  // N1 (session 19)
  if(PJON)PJS.prev=PJS.next;  // N1 (session 15)
  if(ACCT)acctYearEnd(agentSet,yr,p);  // v5.3 B2: the year's BU stock, the premium paid out and the Source's books
  return{bu:totalBU,conversion:totalConversion,stabOn:stabOn,stabM:stabM,colaF:colaF,buEff:buEff,emergN:emergN};  // v4.19
}


// index.html line 6557
var FULL_INTEGRATION = {
  bu:1200, maxOct:6, expiry:1, tax:0.12, maxMult:9,
  nAgents:500, partRate:0.78, years:20,
  ptfShare:0.18, pthUptake:0.20, szhCoh:0.72, cipDemo:0.65,
  phi:true, ptf:true, pth:true, szh:true, cip:true,
  shock:false, automation:false, inflRate:0, ccoOn:true, ptfCap:false
};

// index.html line 6564
var BASELINE = {
  bu:0, maxOct:1, expiry:1, tax:0, maxMult:1,
  nAgents:500, partRate:0, years:20,
  ptfShare:0, pthUptake:0, szhCoh:0, cipDemo:0,
  phi:false, ptf:false, pth:false, szh:false, cip:false,
  shock:false, automation:false, inflRate:0.03, ccoOn:false, ptfCap:false
};


// index.html line 6601
/* v4.18: CCO Only exactly as simulate() builds pCCO for a given scenario — every CCO setting kept,
 * PTF/PTH/SZH/CIP off. */
function ccoOnlyFor(p){ return Object.assign({}, p, {ptfShare:0, pthUptake:0, szhCoh:0, cipDemo:0, ptf:false, pth:false, szh:false, cip:false}); }

// index.html line 6604
/* The Baseline as simulate() builds it for a given scenario's comparison: shocks and
 * automation follow the scenario, inflation stays at BASELINE_CPI_RATE unless matched. */
function baselineFor(p, matchInfl){ var b = Object.assign({}, BASELINE, {shock:!!p.shock, automation:!!p.automation, inflRate: matchInfl ? p.inflRate : CFG.BASELINE_CPI_RATE}); if (p.sx) b.sx = p.sx; return b; }  /* S52: the outside supply shock is the environment's, so the Baseline sees it too */


// index.html line 6612
/* ─── Session 2: the next round's default rule (D1) and the A2 issuance and price module ───────────────
 * NEXT_ROUND: D1, adopted Sep 26 (session-1-handoff.md): consume 0.9 of ALL cash surplus; basket consumption is financed
 * only down to the floor, and a write-off at the floor is reported as unmet need. It is a profile, not a new default for the
 * global switches, so validate/unit/domtest keep testing index.html; the next round's modes apply it (`price`, and
 * `ledger --next`). Setting the share back to 0 restores v4.21. nextRoundPreset(): D6, the hub's 5% COLA trigger, for any
 * preset with CCO on. */
var NEXT_ROUND = {SURPLUS_CONSUMPTION_SHARE:0.9, SURPLUS_CONSUMPTION_BASE:'cash'};

// index.html line 6613
function applyRule(r){ var old = {SURPLUS_CONSUMPTION_SHARE:SURPLUS_CONSUMPTION_SHARE, SURPLUS_CONSUMPTION_BASE:SURPLUS_CONSUMPTION_BASE};
  SURPLUS_CONSUMPTION_SHARE = r.SURPLUS_CONSUMPTION_SHARE; SURPLUS_CONSUMPTION_BASE = r.SURPLUS_CONSUMPTION_BASE; return old; }

// index.html line 6615
function nextRoundPreset(p){ return p.ccoOn ? Object.assign({}, p, {cola:true, colaThresh:CFG.COLA_HUB_THRESH}) : Object.assign({}, p); }

// index.html line 6642
/* A2 defaults. Sources and status in session-2-handoff.md; nothing here is tuned to a target.
 *  a        additionality share: the part of conversion-created primary currency matched by new output. Swept [0,1].
 *  lamG     P_G pass-through of unmatched new money, as a share of that year's aggregate cash income: 1 = the quantity-
 *           theory benchmark (velocity 1, matched output permanent). A logged placeholder, swept 0.25-1.
 *  theta    P_E: each essentials price rises by theta x the % gap between effective essentials demand and supply.
 *           housing 0.6: sourced range 0 (Eriksen & Ross 2015, no overall rent effect) to 0.78 (Fack 2006), with Gibbons &
 *           Manning 2006 at 0.60-0.67. food 0: Cunha, De Giorgi & Jayachandran 2019 find cash transfers raise food prices
 *           negligibly where villages are tied to outside markets. medical 0.5: an unsourced, logged placeholder.
 *  ptfCap   the share of PTF's cost reduction that is added real capacity rather than a transferred margin (supply side of
 *           P_E). No evidence yet, so 0 (the plan's rule); swept.
 *  pthUnmatched  PTH appreciation credited to liquid wealth has no counterparty: counted as unmatched new money (a = 0).
 *  floorUnmatched  N5: false = a floor write-off is unmet need, not money; true = the plan's original treatment.
 *  aw       N7: share of program-induced raises (octave, CIP) matched by output. 1 by default. Session 3 (S3-1): the unmatched
 *           part enters U as the year's CHANGE in the aggregate premium (measured before the income shock): a raise paid from
 *           revenue with no added output passes through to prices once, as a level shift. awLevel: true restores session 2's
 *           reading, which counts the whole premium as new money every year (the raise re-created as currency each year).
 *  wIdx     wage indexation to P_G (0 = the engine's nominal drift).
 *  pgOnE    general (monetary) inflation raises essentials prices too. The plan's text reprices essentials by P_E only;
 *           applying P_G to them as well is the conservative reading (flagged in the hand-off).
 *  lines    D2: 'deflate' (both poverty lines move with the price index) or 'nominal'.
 *  supply   essentials supply (N11, new in session 2). 'capacity' (default; the plan's "baseline growth"): capacity is the
 *           matched Baseline's first-year effective demand, growing at gS a year (0: the model has a fixed population and a
 *           fixed real basket), and prices move only with the demand the program adds ABOVE that capacity, net of any
 *           excess the Baseline itself has. 'baseline': capacity is the matched Baseline's demand in the same year. That
 *           reading shrinks capacity whenever the Baseline impoverishes (Adverse: to about half by year 19) and is kept
 *           as an upper bound. */
var PM_DEFAULTS = {a:0, lamG:1, theta:{food:0, housing:0.6, medical:0.5}, ptfCap:0, pthUnmatched:true, floorUnmatched:false,
  aw:1, awLevel:false, wIdx:0, pgOnE:true, noDamp:false, essMatched:false, lines:'deflate', supply:'capacity', gS:0};

// index.html line 6644
function pmOpts(o){ o = o || {}; var r = Object.assign({}, PM_DEFAULTS, o); r.theta = Object.assign({}, PM_DEFAULTS.theta, o.theta || {}); return r; }

// index.html line 6646
/* Pure price rules (tested by priceUnitSuite). */
function pmEssLevel(D, S, cap, theta){ var s = S*(1 + cap); return s > 0 ? Math.max(0, 1 + theta*(D - s)/s) : 1; }

// index.html line 6647
function pmGenStep(PG, U, Y, lam){ return Y > 0 ? PG*(1 + lam*U/Y) : PG; }

// index.html line 6648
function pmBasketIdx(comp){ var b = 1; CFG.BASKET_KEYS.forEach(function(k){ b += CFG.BASKET[k]*(comp[k] - 1); }); return b; }  /* 1 + weighted deviations: exactly 1 when no price moved */

// index.html line 6649
function newPMAcc(){ return {n:0, essD:0, unmet:0, basketOwn:0, unmetN:0, Y:0, Yw:0, ptfN:0, conv:0, pthLiq:0, wageBonus:0, wageBonusNS:0}; }  /* v5.2 step 6: Yw, earned income (wages and Social Security) */

// index.html line 6691
/* S58 (Nov 9, 2026; research-update prereg/2026-11-s58-price-rule.md; dev/reports/s58-price-rule.md): THE CAPACITY PRICE RULE, behind PRICE_RULE
 * ('qt' = the quantity rule above, pmGenStep, unchanged and the default; 'capacity' = this rule), row option pr (true, or {k, k2, r, a, h, rs, um, ks, q, bv, bd}),
 * testbed runs only (tbRunCore; priceRun keeps 'qt', a stated limit). State: n, the log of the money-implied demand level; p[s], the log price level
 * of sector s (gen = the general basket, food, housing, medical); all 0 at the start. Each year, after the year's flows (setting next year's prices,
 * the same timing as today):
 *   n += ln(1 + lamG x U/Y);   h[s] = h0[s] + ln(1/(1 - slk)) - ks[s];   x[s] = n - p[s];
 *   p[s] += a[s] x w + r x piE + k x max(0, x[s] - h[s]) + k2 x min(0, x[s]),
 * where w = ln(1 + wIdx x piG) is the year's wage indexation to the general level, piE = ln(B_t/B_t-1) the year's endogenous basket inflation
 * (adaptive expectations) and slk the share of the year's income the recession left idle after the spending layer (PRICE.acc.slk, set in runYear).
 * Next year: P_G = exp(p.gen); an essential's price = PE x exp(p[s]) (PE: the essentials rule, unchanged); every other item P_G. With k = 1 and
 * r = a = h = 0 and rs false the rule is the quantity rule (p.gen = n) in every year with U >= 0; with no new money and no capacity loss every term is 0.
 *  k   0.445   price response to excess demand (a year, on the log gap): derived, sources/s58_price_rule.py (OLS of annual CPI-U inflation on last
 *              year's inflation and last year's CBO output gap split above and below potential, 1960-2024, 65 years: slope above 0.445, s.e. 0.189).
 *              Swept 0.25 and 1.
 *  k2  0.051   the pull of demand below normal (x < 0, only after prices overshoot the money): the same regression's slope below potential (s.e.
 *              0.147; not distinguishable from 0). Swept 0.657 (1960-1983). Research-update prereg Amendment 1: without it nothing slows the price
 *              level once it overshoots; with it, little does (a stated limit).
 *  r   0.275   weight of last year's inflation: the same regression's persistence 0.783 (s.e. 0.073) less a x wIdx, the share the wage channel
 *              already carries. Swept 0 (1984-2024: persistence 0.488, below a) and 0.45 (a + r must stay under 1, or inflation runs on with no money).
 *  a   MULT_LS cost share of wages (0.5079, compensation of employees over gross domestic income 2025), every sector (no sector shares opened). Reading 0.
 *  h   0       slack in normal years (log; a number for every sector, or {gen, food, housing, medical}): each sourced sector is at or past its no-pressure
 *              level (CBO output gap 2025 +1.4%; food manufacturing utilisation 84.9% against its 1972-2025 mean 82.2%; rental vacancy 7.1% against 7.3%).
 *              Reading {gen: 0.0446}: total-industry utilisation 2025 (75.95%) against its 1972-2025 mean (79.41%).
 *  rs  true    count the recession's idle share as slack (false: only h; the nesting point; research-update prereg Amendment 2).
 *  um  0.0593  the most output can stretch above its no-pressure level: the largest positive CBO gap since 1949 (1966 Q1, +6.1%). Reporting only.
 *  q   1       S67: sub-steps a year (prStepQ; 1 = one yearly step, as S58). Reading 4 (quarters), with k, k2 and r per quarter: 'wy' {q:4, k:0.0788,
 *              k2:0, r:0.2333} (S58's regression form on quarterly data, sources/s67_pstar.py) and 'wyroot' {q:4, a:0, r:0.9406, k:0.0317, k2:0.0036}
 *              (the quarterly rule whose roots are the fourth roots of the yearly main rule's: the same waves by construction).
 *  bv  0       S67: the velocity response (years): the money-implied level is n + bv x expected inflation (the general level's log change over the
 *              last year). Readings 0.0043 and 0.0022 (sources/s67_panel.py, P4: 77 episodes of sustained inflation above 20%, World Bank data; not
 *              distinguishable from 0). The closed form is stable while a + r + k x bv < 1.
 *  bd  0       S67 (prereg Amendment 1): the velocity drift: the money-implied level grows (1 + bd) times the money. Reading 0.132 (the same panel, P3:
 *              mean velocity growth over mean growth of money per unit of output inside episodes). Pass-through (prPT*) stays measured on the money.
 *  ks  0       capacity loss (log; a number, {sector: v}, or an array of either by year): a supply shock with no new money (unit tests; no study row).
 * Reporting (PR_KEYS, with the rule on, or under 'qt' with study option mf; nothing reported feeds back), on the general basket: prPT3/10/19/39
 * pass-through ln P_G / n after 3, 10, 19, 39 years (0 before or without new money); means over the run of excess demand at the year's prices prX,
 * the slack prH, the recession's idle share prSlk, the output response prOut, the rationed share prRat (demand no output can meet, beyond h + um)
 * and the output loss prLoss (when prices overshoot the money, x < 0), all % of no-pressure output; the last year's prXE, prRatE and shadow ratio
 * prSh = exp(max(0, x - h - um)), how far the measured level sits below one that would clear demand; prWsh median real wealth at shadow prices;
 * prPovSh wealth poverty at shadow prices; prAvg (S67) the mean over the run of the within-year average price level over the year's opening level (1 with
 * q = 1). With q > 1 each year's x, out, rat and loss are means over the sub-steps. No RNG. */
var PRICE_RULE = 'qt', PR_OPTS = null, PRS = null, PR_SECT = ['gen', 'food', 'housing', 'medical'];

// index.html line 6692
var PR_DEFAULTS = {k:0.445, k2:0.051, r:0.275, a:MULT_LS, h:0, rs:true, um:0.0593, ks:0, q:1, bv:0, bd:0};

// index.html line 6693
var PR_KEYS = ['prOn', 'prPT3', 'prPT10', 'prPT19', 'prPT39', 'prX', 'prH', 'prSlk', 'prOut', 'prRat', 'prLoss', 'prXE', 'prRatE', 'prSh', 'prWsh', 'prPovSh', 'prAvg'];

// index.html line 6694
function prOpts(o){ return Object.assign({}, PR_DEFAULTS, o === true || !o ? {} : o); }

// index.html line 6695
function prSec(v, s, d){ return typeof v === 'number' ? v : v && typeof v[s] === 'number' ? v[s] : d; }  /* a sector's value: a number for every sector, or {sector: v} */

// index.html line 6696
function prNew(o, on){ return {on:!!on, o:prOpts(o), n:0, m:0, p:{gen:0, food:0, housing:0, medical:0}, bPrev:1, y:[], pt:{}, dg:0, dl:0, dq:[]}; }

// index.html line 6700
/* One year's step. U, Y: the year's unmatched new money and cash income (as pmGenStep); lam: lamG; wIdx, piG: the wage indexation and this year's general
 * inflation; bIdx: this year's endogenous basket index; slk: the recession's idle share; PGq: the quantity rule's next level (used under 'qt', S.on false,
 * where the state only records). Returns next year's P_G. */
function prStep(S, U, Y, lam, wIdx, piG, bIdx, slk, yr, PGq){
  var o = S.o, dn = Y > 0 ? Math.log(Math.max(1e-12, 1 + lam*U/Y)) : 0, w = Math.log(Math.max(1e-12, 1 + (wIdx || 0)*(piG || 0))), piE = Math.log(bIdx/S.bPrev);
  var hR = o.rs !== false && slk > 0 ? -Math.log(1 - Math.min(0.999, slk)) : 0, ks = Array.isArray(o.ks) ? (o.ks[yr] || 0) : o.ks, xG = 0, hG = 0, p0 = S.p.gen;
  S.m += dn; if (o.bd) dn *= 1 + o.bd;  /* S67: the velocity drift (the money-implied level runs ahead of the money) */
  if (o.q > 1 && S.on) return prStepQ(S, o, dn, w, hR, ks, yr, bIdx);  /* S67: sub-steps within the year */
  S.n += dn; S.bPrev = bIdx;
  var nE = o.bv ? S.n + o.bv*S.dg : S.n;  /* S67: the velocity response (expected inflation = the general level's last yearly log change) */
  PR_SECT.forEach(function(s){ var h = prSec(o.h, s, 0) + hR - prSec(ks, s, 0), x = nE - S.p[s];
    if (s === 'gen'){ xG = x; hG = h; }
    if (S.on) S.p[s] += prSec(o.a, s, MULT_LS)*w + o.r*piE + o.k*Math.max(0, x - h) + o.k2*Math.min(0, x); });
  if (!S.on) S.p.gen = Math.log(PGq);
  var cap = hG + o.um, rec = {x:xG, h:hG, slk:hR > 0 ? Math.min(0.999, slk) : 0, out:Math.min(Math.max(0, xG), Math.max(0, cap)), rat:Math.max(0, xG - cap), loss:Math.min(0, xG)};
  S.y.push(rec); if (S.n > 0) S.pt[yr + 1] = S.p.gen/(o.bd ? S.m : S.n); S.dg = S.p.gen - p0;
  return S.on ? Math.exp(S.p.gen) : PGq; }

// index.html line 6736
function prRes(r, S, agents, lineF){ var Y = S.y, T = Y.length, m = function(f){ return T ? Y.reduce(function(a, y){ return a + f(y); }, 0)/T*100 : 0; }, L = T ? Y[T - 1] : {x:0, h:0, rat:0};
  var pct = function(v){ return Math.exp(v) - 1; }, sh = Math.exp(L.rat || 0), ws = agents.map(function(a){ return a.wealth; }), pv = 0;
  ws.forEach(function(w){ if (w < CFG.POVERTY_LINE*lineF*sh) pv++; });
  r.prOn = S.on ? 1 : 0; [3, 10, 19, 39].forEach(function(t){ r['prPT' + t] = S.pt[t] || 0; });
  r.prX = m(function(y){ return pct(y.x); }); r.prH = m(function(y){ return pct(y.h); }); r.prSlk = m(function(y){ return y.slk; });
  r.prOut = m(function(y){ return pct(y.out); }); r.prRat = m(function(y){ return 1 - Math.exp(-y.rat); }); r.prLoss = m(function(y){ return 1 - Math.exp(y.loss); });
  r.prXE = pct(L.x)*100; r.prRatE = (1 - Math.exp(-(L.rat || 0)))*100; r.prSh = sh; r.prAvg = T ? Y.reduce(function(a, y){ return a + Math.exp(y.avg || 0); }, 0)/T : 1;
  r.prWsh = medianOf(ws)/(agents[0].yrBasketUSD/CFG.LIVING_WAGE_ANNUAL/(agents[0]._hhF || 1))/sh; r.prPovSh = agents.length ? pv/agents.length*100 : 0;
  return r; }

// index.html line 6750
/* S58 study option mf (reporting only): the consolidated money-flow table, year-0 dollars per adult-year, means over the run (MF_KEYS):
 * mfIss BU issued; mfBU BU spent at face value; mfCvG conversion gross; mfTax the conversion tax withheld; mfCvN conversion paid, net; mfPay the Source's
 * payout (BU at face plus net conversion); mfM output matched to it; mfCut price cuts paid (PTF and PTH; outside U under Source financing); mfPth PTH
 * appreciation credited; mfReSp the tax re-spent (0: no row's Source spends it); mfU new money U; mfY cash income Y; mfUY mean of U/Y (%); mfTaxSh the
 * tax over gross conversion (%); mfChk the identity |U - (payout - matched)| (0 on a plain Source-financed row). */
var MF_KEYS = ['mfIss', 'mfBU', 'mfCvG', 'mfTax', 'mfCvN', 'mfPay', 'mfM', 'mfCut', 'mfPth', 'mfReSp', 'mfU', 'mfY', 'mfUY', 'mfTaxSh', 'mfChk'];

// index.html line 6751
function mfNew(){ return {iss:0, bu:0, tax:0, cv:0, M:0, cut:0, pth:0, U:0, Y:0, uy:0, chk:0, T:0}; }

// index.html line 6752
function mfYear(F, C, U, Y){ var i = C.idx || 1; F.iss += C.buIss/i; F.bu += C.bu/i; F.tax += C.ctax/i; F.cv += C.conv/i; F.M += C.convM/i; F.cut += (C.cutPT - C.cutFree + C.cutG)/i;
  F.pth += C.pthLiq/i; F.U += U/i; F.Y += Y/i; F.uy += Y > 0 ? U/Y : 0; F.chk += Math.abs(U - (C.bu + C.conv - C.convM))/i; F.T++; }

// index.html line 6754
function mfRes(r, F, NY){ r.mfIss = F.iss/NY; r.mfBU = F.bu/NY; r.mfCvG = (F.cv + F.tax)/NY; r.mfTax = F.tax/NY; r.mfCvN = F.cv/NY; r.mfPay = (F.bu + F.cv)/NY; r.mfM = F.M/NY;
  r.mfCut = F.cut/NY; r.mfPth = F.pth/NY; r.mfReSp = 0; r.mfU = F.U/NY; r.mfY = F.Y/NY; r.mfUY = F.T ? F.uy/F.T*100 : 0; r.mfTaxSh = F.cv + F.tax > 0 ? F.tax/(F.cv + F.tax)*100 : 0; r.mfChk = F.chk/NY; return r; }

// index.html line 6759
/* One run with the price module. S: the supply path for effective essentials demand (per-agent share of basket consumed,
 * by year), normally the matched Baseline's own path under the same rule; null holds P_E at 1. Draws exactly as
 * runScenario() does. Returns the demand path D (for use as S), the price path, and end-of-run metrics under D2. */
function priceRun(p, seed, o, S){
  o = pmOpts(o);
  var CALM0 = {active:false, incomeMultiplier:1.0, yearsLeft:0};
  RNG = mulberry32(seed + 700003);
  var agents = makeLatentPopulation(p.nAgents).map(function(l){ return instantiateAgent(l, p); });
  RTO = RETURNS && RETURNS.bo ? mulberry32(seed + 600091) : null;  /* S59 part 2: the owners' stream */
  if (HOUSEHOLDS) hhInit(agents, seed);  /* v5.3 B3: the same households as the testbed run of this seed */
  if (LF_SCOPE) lfInit(agents, seed); else LFS = null;  /* S61: the same adults outside the labour force as the testbed run */
  BGS = null;  /* S60: BARGAIN's tallies are kept by testbed runs only */
  var recPath = p.shock ? (REC_SCRIPT ? recScriptPath(p.years) : buildRecessionPath(p.years, seed)) : null;  /* session 9: REC_SCRIPT (comment above tbOpts), so the supply path sees the same scripted path */
  RNG = mulberry32(seed);
  var comp = {}; CFG.BASKET_KEYS.forEach(function(k){ comp[k] = 1; });
  PRICE = {bIdx:1, comp:comp, piG:0, colaLevel:1, lastFull:1, wIdx:o.wIdx, noDamp:o.noDamp, acc:null};
  var SXp = p.sx ? sxOpts(p.sx) : null;  /* S52 */
  var PG = 1, D = [], path = [], tot = newPMAcc(), wbPrev = 0, labAcc = null;
  THETA_DENS = null;
  if (o.labor){ labAcc = newLabAcc(); LABOR = Object.assign({}, o.labor, {acc:labAcc}); }  /* session 5: the joint price and labor run */
  try {
    for (var yr = 0; yr < p.years; yr++){
      PRICE.acc = newPMAcc();
      runYear(agents, yr, p, recPath ? recPath[yr] : CALM0);
      var A = PRICE.acc, d = A.n ? A.essD/A.n : 1; D.push(d);
      Object.keys(tot).forEach(function(k){ tot[k] += A[k]; });
      var wbInc = A.wageBonusNS - wbPrev; wbPrev = A.wageBonusNS;  /* session 3 (S3-1): an unmatched raise is a cost-push level shift, so only the year's change in the premium is new */
      var U = (1 - o.a)*A.conv + (o.pthUnmatched ? A.pthLiq : 0) + (o.floorUnmatched ? A.unmet : 0) + (1 - o.aw)*(o.awLevel ? A.wageBonus : wbInc);
      var PGn = pmGenStep(PG, U, A.Y, o.lamG), capShare = o.ptfCap*(A.n ? A.ptfN/A.n : 0), PE = {};
      CFG.ESSENTIALS.forEach(function(k){
        var cut = !p.ptf ? 0 : PTF_MODE === 'shipped' ? (p.szh ? 0.12 + p.szhCoh*0.04 : 0.12) : (k === 'food' ? PTF_FOOD_CUT[PTF_MODE] : 0);
        if (!S || o.essMatched){ PE[k] = 1; return; }
        var sRef = o.supply === 'baseline' ? S[yr] : S[0]*Math.pow(1 + o.gS, yr);
        var dEff = o.supply === 'baseline' ? d : sRef + Math.max(0, d - sRef) - Math.max(0, S[yr] - sRef);
        PE[k] = pmEssLevel(dEff, sRef, capShare*cut, o.theta[k]);
      });
      path.push({bIdx:PRICE.bIdx, PG:PG, PEh:PRICE.comp.housing/(o.pgOnE ? PG : 1), d:d, U:U, Y:A.Y, conv:A.conv, unmet:A.unmet, basketOwn:A.basketOwn, unmetN:A.unmetN/A.n, colaLevel:PRICE.colaLevel});
      PRICE.piG = PGn/PG - 1; PG = PGn;
      CFG.BASKET_KEYS.forEach(function(k){ comp[k] = CFG.ESSENTIALS.indexOf(k) >= 0 ? PE[k]*(o.pgOnE ? PG : 1) : PG; });
      if (SXp) sxApply(comp, SXp, yr + 1);  /* S52: the outside supply shock's factors for next year (only with p.sx) */
      PRICE.bIdx = pmBasketIdx(comp);
    }
  } finally { PRICE = null; if (labAcc) LABOR = null; }
  var T = p.years, full = agents[0].yrBasketUSD/CFG.LIVING_WAGE_ANNUAL/(agents[0]._hhF || 1), lineF = o.lines === 'nominal' ? 1 : full, n = agents.length;
  var ws = agents.map(function(a){ return a.wealth; }), pov = 0, bpov = 0;
  ws.forEach(function(w){ if (w < CFG.POVERTY_LINE*lineF) pov++; });
  agents.forEach(function(a){ if (agentBLEI(a, p.bu, p.ccoOn, p.pth, p.szh, p.szhCoh, p.ptf)/lineF < CFG.BLEI_PRECARIOUS_MAX) bpov++; });
  var ib = incomeBasketMetrics(agents), bI = path[T-1].bIdx, mx = 0;
  for (var t = 1; t < T; t++) mx = Math.max(mx, path[t].bIdx/path[t-1].bIdx - 1);
  var colaLast = path[T-1].colaLevel;
  return {D:D, path:path, agents:agents, tot:tot, res:{
    endoAnn: Math.pow(bI, 1/(T - 1)) - 1, endoMax: mx, endoIdx: bI, PG: path[T-1].PG, PEh: path[T-1].PEh, fullIdx: full,
    pov: pov/n*100, bleiPov: bpov/n*100, basketPov: ib.basketPov, medWealthReal: medianOf(ws)/full,
    unmetShare: tot.basketOwn > 0 ? tot.unmet/tot.basketOwn : 0, unmetYears: tot.unmetN/tot.n, convShare: tot.Y > 0 ? tot.conv/tot.Y : 0,
    buReal: p.bu*(p.cola ? colaLast : 1)/full,
    dE: labAcc && labAcc.E0 > 0 ? (labAcc.E - labAcc.E0)/labAcc.E0 : 0, labE: labAcc ? labAcc.E/Math.max(1, labAcc.n) : 0}};
}

// index.html line 6826
/* ─── Session 3 (Sep 26 2026; Duke assigns the version): A2 sweeps and the breakeven report ─────────────────
 * Harness-only, and nothing here changes a run: these functions only drive priceRun(). CRN makes the mean over a fixed
 * set of seeds a deterministic function of every input, so each point below is an exact mean, not a noisy estimate,
 * and breakeven additionality can be found by a bracketed secant search instead of a coarse grid.
 *  s3BaseS    the matched Baseline's effective-demand path for P_E (the supply side). The Baseline has no conversion,
 *             no PTH and no floor money under the adopted rules, so its prices never move and the path depends only on
 *             the seed, the environment and the consumption rule: cached.
 *  s3Point    per-seed results at one a (kept, for a bootstrap over seeds and the share of seeds above tolerance).
 *  s3Breakeven  the smallest a at which mean endogenous inflation is at or below tol: anchors at a = 1, 0 and 0.9,
 *             then secant steps inside the tightest bracket until it is 0.002 wide or an end is within 0.01 point of
 *             tol; the estimate interpolates the final bracket. 95% interval: 2,000 bootstrap resamples of the seeds at
 *             the two bracket points (linear inside the bracket, which is narrow).
 *  s3Config   one scenario under one sweep row (switches, preset overrides and module options), both tolerances. */
var S3_CACHE = {};

// index.html line 6827
function s3BaseS(p, seed){
  var bp = baselineFor(p, true);
  if (p.years > bp.years) bp.years = p.years;  /* session 33: the supply path covers runs longer than the Baseline's 20 years (unchanged for 20) */
  var k = JSON.stringify(bp) + '|' + SURPLUS_CONSUMPTION_SHARE + '|' + SURPLUS_CONSUMPTION_BASE + '|' + seed + '|' + JSON.stringify(HOUSEHOLDS) + '|' + JSON.stringify(SPEND_GRADE) + (DEBT_READ ? '|dr' + JSON.stringify(DEBT_READ) : '') + (LF_SCOPE ? '|lf' + JSON.stringify(LF_SCOPE) : '') + (RETURNS ? '|rt' + JSON.stringify(RETURNS) : '') + (WEALTH_TAIL ? '|wt' + JSON.stringify(WEALTH_TAIL) : '') + (LW ? '|lw' + LW : '') + (AUD ? '|au' + JSON.stringify(AUD) : '');  /* S14: + the line (key unchanged when off) */  /* S35: + the debt reading (key unchanged when off). v5.3 B3: + households (the reference path of an economy of households); B7: + income-graded spending */
  if (!S3_CACHE[k]) S3_CACHE[k] = priceRun(bp, seed, {}, null).D;
  return S3_CACHE[k];
}

// index.html line 6845
/* S47 fx.sp (Nov 5, 2026; research-update prereg/run-manifest.md section 6 item 1; Simulation GAPS.md item 2): THE SUPPLY PATH FROM THE REPORTED
 * NO-PROGRAMME RUN. The demand path (each year's mean share of the basket consumed) of the study's own no-programme row, tbComp(envP, {}), run as
 * a testbed run (job loss, the safety net, the labour response, wage indexation, households, the population and horizon of envP) with essentials
 * prices held at 1 (S null). A no-programme row given this path reproduces it exactly, so its essentials prices never move (fixed point: in every
 * year its demand equals the path, and pmEssLevel(d, d, 0, theta) = 1).
 *   The run takes the row's economy-wide switches (households, spending rule, debt reading, the line, audit and fx parts, health, safety net,
 * prevention, wage reading, savings, ageing, the v5.4 round, the restudy and G profiles) and the row's options other than those that only act on
 * a programme. The programme's own switches (projects, ESP, surplus split, production, spending layer, octaves, cost and joining, coverage,
 * community layer, FBS50, housing capture, review, BU scope, conversion model, current-year gate, measured EDC) are set to their defaults for
 * the run, as on the no-programme row, so every row of a seed gets the same path whatever the order of rows. No draw is added to any run;
 * health's no-programme record (HL_GOVREF) is left as the study's own rows write it, and a reporting hook (REP_HOOK) does not see the run. Cached per seed and context. */
var SPD = null, SP_PROG_OPTS = ['fin', 'a', 'aT', 'eP', 'X', 'tauMax', 'taxBase', 'lv', 'bkm', 'sec', 'rep52', 'giniNN1'];

// index.html line 6846
function tbBaseS(envP, seed, o){
  var bp = tbComp(envP, {}), oS = {};
  Object.keys(o || {}).forEach(function(k){ if (SP_PROG_OPTS.indexOf(k) < 0) oS[k] = o[k]; });
  var k = 'sp|' + seed + '|' + JSON.stringify(bp) + '|' + JSON.stringify(oS) + '|' + JSON.stringify([SURPLUS_CONSUMPTION_SHARE, SURPLUS_CONSUMPTION_BASE, HOUSEHOLDS, SPEND_GRADE,
    DEBT_READ, LF_SCOPE, LW, AUD, FX, HEALTH, SNET, PREV, LATENT, SAVE, AGE, RISK_MEASURE, EMPL, PTHB, PTFS, DIS, THETA_GATE, PTH_MODE, DISC_BASE, PTF_MODE, PATHWAY_OFF,
    FBS_BU_ONCE, PTH_APPR_CONSERVE, N7_BLEI, SURP_CUT_MARKUP, REC_SCRIPT]) + (RETURNS ? '|rt' + JSON.stringify(RETURNS) : '') + (WEALTH_TAIL ? '|wt' + JSON.stringify(WEALTH_TAIL) : '');  /* S59 (key unchanged when off) */
  if (S3_CACHE[k]) return S3_CACHE[k];
  var sv = {pj:PROJ, es:ESP, sp:SURP, pd:PROD, ml:MULT, oc:OCT, cs:COST, jn:JOIN, c22:C22, cl:COMM, fb:FBS50, hc:HCAP, rv:REVIEW, bs:BU_SCOPE, cm:CONVERSION_MODEL,
    gc:GATE_CURRENT, em:EDC_MEASURE, hg:HL_GOVREF, rh:REP_HOOK};
  PROJ = null; ESP = null; SURP = null; PROD = null; MULT = null; OCT = null; COST = null; JOIN = null; C22 = null; COMM = null; FBS50 = null; HCAP = null; REVIEW = null;
  BU_SCOPE = 'core'; CONVERSION_MODEL = 'engine'; GATE_CURRENT = false; EDC_MEASURE = false; HL_GOVREF = null; REP_HOOK = null; SPD = [];
  try { tbRun(bp, seed, Object.assign({grp:{part:envP.partRate, pth:envP.pthUptake}}, oS), null); S3_CACHE[k] = SPD; }
  finally { SPD = null; PROJ = sv.pj; ESP = sv.es; SURP = sv.sp; PROD = sv.pd; MULT = sv.ml; OCT = sv.oc; COST = sv.cs; JOIN = sv.jn; C22 = sv.c22; COMM = sv.cl; FBS50 = sv.fb;
    HCAP = sv.hc; REVIEW = sv.rv; BU_SCOPE = sv.bs; CONVERSION_MODEL = sv.cm; GATE_CURRENT = sv.gc; EDC_MEASURE = sv.em; HL_GOVREF = sv.hg; REP_HOOK = sv.rh; }
  return S3_CACHE[k];
}

// index.html line 6868
/* ─── Session 4 (Sep 27 2026; Duke assigns the version): A3 labor supply ─────────────────────────────────────────────
 * laborRun   one run with LABOR set to L (null = off). Draws exactly as runScenario() does, so runs are CRN-paired
 *            across every L and preset. Returns end-of-run poverty (wealth, BLEI, basket) and, per agent-year, the
 *            earnings response by channel, the program's gross cost (BU spent on own essentials + conversion + UBI) and,
 *            with wantBound, the BU that expired unconverted (the most extra conversion could draw on).
 * laborStudy the mean over seeds 1..N of laborRun, under the D1 consumption rule (NEXT_ROUND) and D6 COLA. */
function newLabAcc(){ return {n:0, nP:0, E0:0, E:0, raise:0, cash:0, bu:0, buR:0, rent:0, disp:0, C:0, U:0, projH:0, zero:0, conv:0, convP:0}; }

// index.html line 6874
/* ─── Session 6 (A4): testbed runs, presets, matching and tests (harness-only). ─────────────────────────────────────────────
 * NR6, the next-round accounting profile Duke confirmed on Sep 27 (dashboard d22, d23): the D1 consumption rule, plus the three
 * text-versus-engine corrections (theta on realised PTF density, PTH cuts housing only, discounts skip the tax share). TB_RUN adds
 * wage indexation to P_G (d23; applied to every preset, since wage indexation is a property of the economy, not of a program)
 * and the A3 labor response at its central values. The globals keep their v4.21 defaults, so the checks still test index.html. */
var NR6 = {rule:NEXT_ROUND, rs:{THETA_GATE:'density', PTH_MODE:'housing', DISC_BASE:'pretax'}};

// index.html line 6875
function applyNR6(){ return {rule:applyRule(NR6.rule), rs:setRestudy(NR6.rs)}; }

// index.html line 6876
function resetNR6(sv){ applyRule(sv.rule); setRestudy(sv.rs); }

// index.html line 6877
var TB_RUN = {wIdx:1, labor:LABOR_DEFAULTS};

// index.html line 6888
/* Session 9 (Oct 14, 2026; ledger s146; dev/plans/s146-history-check.md; dev/reports/v5-34-history-check.md): A SCRIPTED RECESSION PATH for the history check.
 * REC_SCRIPT null (the default) adds nothing: the testbed draws its recessions as before (buildRecessionPath, its own stream). When an array of
 * {active, incomeMultiplier}, a testbed run with p.shock (and the price run that gives its supply path) uses it, year by year, for every seed and both
 * arms (years past its end are calm); the random path is not built, and since buildRecessionPath draws only from its own stream and restores the main one, no other draw moves. No draw is added. */
var REC_SCRIPT = null;

// index.html line 6890
function tbOpts(o){ o = o || {}; var r = Object.assign({}, PM_DEFAULTS, TB_DEFAULTS, TB_RUN, o); r.theta = Object.assign({}, PM_DEFAULTS.theta, o.theta || {}); return r; }

// index.html line 6892
/* Session 8 (A5): Gini coefficient of a list of incomes (negatives count as 0), the standard sorted-rank formula. */
function giniOfArr(x){ var v = x.map(function(z){ return Math.max(0, +z || 0); }).sort(function(a, b){ return a - b; }), n = v.length, t = 0, w = 0;
  for (var i = 0; i < n; i++){ t += v[i]; w += (i + 1)*v[i]; } return n > 0 && t > 0 ? 2*w/(n*t) - (n + 1)/n : 0; }

// index.html line 6895
/* One testbed run: priceRun()'s loop (same draws, same price rules) with TB set. Returns the run's metrics; see tbStudy for keys. */
function tbRunCore(p, seed, o, S, tau0, yMax){
  var CALM0 = {active:false, incomeMultiplier:1.0, yearsLeft:0};
  RNG = mulberry32(seed + 700003);
  var latent = makeLatentPopulation(p.nAgents); if (LATENT) latent.forEach(latentAdjust);  /* v5.2 step 5: the readings that close known gaps with US data (no draw added) */
  var agents = latent.map(function(l){ return instantiateAgent(l, p); });
  var recPath = p.shock ? (REC_SCRIPT ? recScriptPath(p.years) : buildRecessionPath(p.years, seed)) : null;  /* session 9: REC_SCRIPT, a fixed recession path (comment above tbOpts) */
  var spec = p.tb || {}, gR = mulberry32(seed + 900001), grp = o.grp || {part:0, pth:0};
  var wq = latent.map(function(l){ return l.wage; }).sort(function(x, y){ return x - y; }), w1 = wq[Math.floor(wq.length/3)], w2 = wq[Math.floor(2*wq.length/3)];
  agents.forEach(function(a, i){ var l = latent[i]; a._tbU = gR(); a._tbEl = !!(spec.endow && l.wealth < spec.endow.thresh); a._tbPart = l.uCCO < grp.part; a._tbPTH = l.uPTH < grp.pth; a._tbLow = l.wage < w1; a._tbTop = l.wage >= w2; });
  if (EMPL) emplInit(agents, seed); else EMS = null;
  if (HEALTH){ hlInit(agents, seed); HLS.noProg = !p.ccoOn && !Object.keys(spec).length; HLS.govKey = (seed | 0) + '|' + JSON.stringify(HEALTH) + '|' + JSON.stringify(SNET) + '|' + JSON.stringify(PREV); if (HLS.noProg && HL_GOVREF && HEALTH.gov === 'fixed') HL_GOVREF[HLS.govKey] = []; } else HLS = null;  /* session 2a: health coverage (no draw on any stream); session 2c: the no-programme run records government's share (d194) */
  if (SNET) snInit(agents, seed); else SNS = null;  /* session 2b: today's safety net (no draw on any stream) */
  if (PTHB && p.pth && !(FX && FX.pthb)) pthbInit(agents, latent, seed); else PBS = null;  /* S47 fx.pthb: opened after households instead (below) */
  if (DIS) DSS = {r:mulberry32(seed + 600053), hit:0, n:0, list:[], ctl:[]}; else DSS = null;  /* v5.4 item 5 */
  if (PTFS && p.ptf) PFS = {r:mulberry32(seed + 600047), cut:0, cn:0, leave:0, mem:0, yrs:0, dens:1}; else PFS = null;  /* v5.4 item 4 */  /* v5.4 item 3: the PTH trust's books */  /* v5.4 item 2: job loss, on its own stream */
  if (WEALTH_TAIL && !(HOUSEHOLDS && HOUSEHOLDS.wealth === 'scf')) throw new Error('wt (the weighted top tail) needs households with SCF wealth (hh.wealth \'scf\')');
  RTO = RETURNS && RETURNS.bo ? mulberry32(seed + 600091) : null;  /* S59 part 2: the owners' stream (one draw per household, when rt first sees it) */
  if (HOUSEHOLDS) hhInit(agents, seed); else HHS = null;  /* v5.3 B3: households drawn once, on their own stream (no draw on the main or construction streams) */
  if (PTHB && p.pth && FX && FX.pthb) pthbInit(agents, latent, seed);  /* S47 fx.pthb: the books follow the household's PTH decision (no draw at set-up) */
  if (COMM && p.ptf) clInit(agents, seed, p); else CMS = null;
  if (PTF_ACCESS === 'open' && p.ptf){ if (!PTFS) throw new Error('pa open: needs PTF by sector (v54 ptfs)'); paInit(agents); } else PAS = null;  if (PTF_OPS){ if (PTF_ACCESS !== 'open') throw new Error('po: needs open PTF access (pa open)'); if (PA.ops === 'outside') throw new Error('po: replaces ops outside (the payer readings)'); if (PAS) poInit(agents); else POS = null; } else POS = null;  /* S62 */  /* S55: the zones' PTF shares of essential sales (after the layer places members; no draw) */
  if (C22) c22Init(agents, seed); else C22S = null;  /* S6: eligibility and automatic distribution (own stream); coverage tallies */  /* S37: the community layer (its own stream; nothing to do without PTF) */
  if (HOUSEHOLDS && HOUSEHOLDS.wealth === 'scf' && spec.endow) agents.forEach(function(a){ a._tbEl = a.wealth < spec.endow.thresh; });  /* v5.3 B7: an endowment's test reads the household's starting wealth */
  var RHH = HOUSEHOLDS && HHS ? hhRepAcc() : null;  /* v5.3 B3: the household reading's measures (reporting only) */
  EDCS = EDC_MEASURE ? edcNew() : null;  /* v5.3 B6: the measured EDC (reporting only) */
  FBSS = FBS50 ? {n:0, a:0, nK:0, aK:0, f:[]} : null;  /* v5.3 B7: FBS50 tallies (reporting only) */
  if (AGE) ageInit(agents, seed, function(b, l, r){ b._tbU = r(); b._tbEl = false; b._tbPart = l.uCCO < grp.part; b._tbPTH = l.uPTH < grp.pth; b._tbLow = l.wage < w1; b._tbTop = l.wage >= w2; });  /* v5.2 step 4: ages; a new adult gets the same group tests from its own draws */
  else AGS = null;
  if (AGE && HHS) hhAges(agents, seed);  /* v5.3 B4: ages, sexes and the family stream for households with ageing */
  if (AGE && AGE.earn === 'cps') ageEarn0(agents);  /* v5.3 B7: wages by age, after every age is set */
  if (LF_SCOPE) lfInit(agents, seed); else LFS = null;  /* S61: adults outside the labour force (own stream; after households and ages) */
  if (BARGAIN && !o.labor) throw new Error('bg (BARGAIN) acts inside the labour response: the row needs o.labor');
  BGS = BARGAIN ? bgNew() : null; if (BGS) BGS.T = p.years;  /* S60: BARGAIN's tallies (reporting only) */
  DR_ACC = DEBT_READ ? {n:0, h:0, c:0} : null; DR_PL = 1;  /* S61: the debt reading's tally (reporting only) */
  REVS = REVIEW ? {rng:mulberry32(seed + 800023), x:0, c:0} : null; HCS = null;  /* v5.2 step 7: the review stream and the rent state, per run */
  RNG = mulberry32(seed);
  var comp = {}; CFG.BASKET_KEYS.forEach(function(k){ comp[k] = 1; });
  PRICE = {bIdx:1, comp:comp, piG:0, colaLevel:1, lastFull:1, wIdx:o.wIdx, noDamp:o.noDamp, acc:null};
  var SXp = p.sx ? sxOpts(p.sx) : null; SXS = SXp ? sxNew(SXp, p.years) : null; if (SXS) SXS.p = p;  /* S52 (reporting state only with p.sx) */
  SECS = o.sec ? secNew(o.sec, p.years) : null;  /* S53 (reporting state only with o.sec) */
  WYS = o.wy ? {cur:[], f0:0, f1:0, f2:0, n:0, fs:0, ny:0} : null;  /* S68 (reporting only) */
  DMS = o.dm ? dmNew(o.dm) : null;  /* S57 (reporting state only with o.dm) */
  RTR = RETURNS ? {} : null;  /* S59 (reporting state only with rt) */
  WTS = WEALTH_TAIL || o.wtm ? {} : null;  /* S59 part 2 (reporting state only with wt or o.wtm) */
  PRS = PRICE_RULE === 'capacity' || o.mf ? prNew(PR_OPTS, PRICE_RULE === 'capacity') : null; var MFS = o.mf ? mfNew() : null;  /* S58: the capacity rule (or, under 'qt' with o.mf, its record only); the money-flow table (o.mf) */
  LVS = o.lv ? lvNew(o.lv, p) : null;  /* S54 (only with o.lv) */
  TB = {fin:o.fin, tau:tau0, X:o.X, inkindRho:o.inkindRho, neutralGate:o.neutralGate, cur:null, tb:o.taxBase, tauMax:o.tauMax};
  GVS = GOV ? gvNew() : null; var gvCap = GOV ? (FX && FX.fin === 'cap' ? GOV.capHi : o.tauMax) : 0; if (GOV) TB.capE = gvCap;  /* S72: the government account (per run) and the effective rate cap */  /* v5.2 step 7: taxBase 'prog' | 'land' (undefined = the flat contribution) */
  var PG = 1, path = [], wbPrev = 0, labAcc = null, T = p.years;
  var L = {pjg:0, cost:0, cash:0, endow:0, bu:0, conv:0, cutPT:0, cutG:0, cap:0, pth:0, tax:0, need:0, treas:0, f0:0, f1:0, f2:0, n:0, endowTot:0, need0:0, base0:0, pd:0, tgt:0, emp:0, hrs:0, Er:0, bR:0, bP:0,
    bz:0, es:0, n1:0, nP1:0, nN1:0, pyP:0, pyN:0, nWP1:0, esWP:0, convM:0, buIss:0, ctax:0, cutFree:0, bkP:0, bkU:0, bkY:0, ntR:0};  /* session 19 (s38); convM: plan step 2; buIss, ctax: plan step 3; bk*, ntR: v5.2 step 6 */
  THETA_DENS = null;
  FWS = null; PJS = null; ESS = null; SPS = null; PDS = null; JNS = null; HCS = null;  /* S68 (Nov 9 audit, finding 4): per-run state starts empty in every run, so a row cannot read the previous run's (each mechanism rebuilds its own at year 0) */
  var epD0 = housingDistressYear0(agents), epSum = 0;  /* plan step 9: unhoused person-years (reporting only) */
  var BG = tbBleiAcc();  /* session 21 (s41; i10-1): BLEI by group, every year (reporting only, no RNG) */
  var dbt20 = 0, dbt40 = 0;  /* S35: families in debt (reporting only) */
  var R52 = o.rep52 ? tbRepAcc() : null;  /* v5.2 step 2: Year 7, the poverty line, fixed-dollar lines, the wealth Gini (reporting only, no RNG) */
  if (o.labor){ labAcc = newLabAcc(); LABOR = Object.assign({}, o.labor, {acc:labAcc}); }
  try {
    for (var yr = 0; yr < yMax; yr++){
      PRICE.acc = newPMAcc(); if (SXS) SXS.y = yr; if (SECS) SECS.y = yr; if (LVS) lvYear(yr);
      runYear(agents, yr, p, recPath ? recPath[yr] : CALM0);
      tbBleiYear(BG, agents, p, o, yr === T - 1, yr === 19);
      if (!o.noEP){ var epY = extremePovertyOf(housingDistressOf(agents), epD0, p); epSum += epY ? epY.total/100 : 0; }  /* plan step 9 */  /* session 21 (s41): year-end state, before this year's price step (which moves no agent) */
      if (R52) tbRepYear(R52, agents, p, o, yr, T, (!o.noEP && epY) ? epY.total : 0);  /* v5.2 step 2 */
      if (SECS) secYear(agents, p, yr, (!o.noEP && epY) ? epY.total : 0);  /* S53 */
      if (DMS) dmYear(DMS, agents, p, o, yr, T);  /* S57 (reporting only) */
      if (RTR) rtRep(RTR, agents, o, yr, T);  /* S59 (reporting only) */
      if (WTS) wtRep(WTS, agents, o, yr, T);  /* S59 part 2 (reporting only) */
      if (BGS) bgYear(agents, yr, BGS.yIdx || 1);  /* S60 (reporting only) */
      if (RHH) hhRepYear(RHH, agents, p, o, yr, T);  /* v5.3 B3 */
      if (yr === 19) dbt20 = tbDebtShare(agents); else if (yr === 39) dbt40 = tbDebtShare(agents);  /* S35 (reporting only) */
      if (EDCS) edcYear(EDCS, agents, p);  /* v5.3 B6 */
      var A = PRICE.acc, C = TB.cur || tbNewAcc(), d = A.n ? A.essD/A.n : 1, tauUsed = TB.tau;  if (SPD && yMax >= T) SPD.push(d);  /* S47 fx.sp: tbBaseS records the no-programme run's demand path (off: SPD null) */
      var wbInc = A.wageBonusNS - wbPrev; wbPrev = A.wageBonusNS;
      var extra = (o.floorUnmatched ? A.unmet : 0) + (1 - o.aw)*(o.awLevel ? A.wageBonus : wbInc);
      if (yr === 0) L.endowTot = C.endow;
      /* d26: what the treasury must fund this year: every program dollar at face value (the endowment amortized over the run),
       * less the efficiency share eP of price cuts (added capacity, not a transfer; 0 by the plan's rule). */
      /* d66 (sessions 15-16; issue i7): the launch gift's proceeds are one-time spending. 'payg' (Duke's pick) finances them in the
       * year they are paid, like every other conversion; 'run' spreads them over the remaining years, like the endowment (d26). */
      L.pjg += C.pjg; var gRun = !!(PROJ && PROJ.giftFin === 'run');
      var need = C.cash + L.endowTot/T + (o.fin === 'source' ? 0 : C.bu) + (o.fin === 'hybrid' || o.fin === 'source' ? 0 : gRun ? C.conv - C.pjg + L.pjg/(T - 1) : C.conv) + C.cap + (1 - o.eP)*(C.cutPT - C.cutFree + C.cutG) + C.pthLiq, U;  /* plan step 3: the Source pays every conversion (BU face value included) */  /* session 7 (d26): hybrid leaves conversion rewards to money creation */
      /* d24: created money counted by one rule for every design. aT: output matched to transfer dollars (cash, BU spent at face
       * value, the endowment, capital spending); a: output matched to conversion rewards (H1); eP: price-cut efficiency. */
      /* Session 7 (d24 option b, o.buAtA): output matched at a to a converted BU's face value as well as its reward. */
      if (o.fin === 'money') U = (1 - o.aT)*(C.cash + C.endow + C.cap) + (1 - (o.buAtA ? o.a : o.aT))*C.bu + (1 - o.eP)*(C.cutPT - C.cutFree + C.cutG) + (1 - o.a)*(C.conv - C.convM) + (o.pthUnmatched ? C.pthLiq : 0) + extra;
      else if (o.fin === 'tax') U = extra + (o.taxBase ? Math.max(0, need - C.tax) : 0);  /* v5.2 step 7: the progressive and land taxes pay what they can (marginal rates capped at tauMax); the Source pays the rest as new money */
      else if (o.fin === 'source'){ var cvS = gRun ? C.conv - C.pjg + L.pjg/(T - 1) : C.conv, bkP = (o.faceM ? 0 : C.bu) + cvS - C.convM, bkU = (1 - o.a)*bkP;  /* v5.2 step 7: with the gift over the run, the Source's new money for the launch gift is spread over the run (d66's 'run', as for the contribution) */  /* plan step 3 (S1-S6): the Source's net payout is new money, less output that backs it; faceM: essentials bought with BU count as backed */
        if (o.aK) bkU = Math.max(0, bkU - o.aK*A.Yw);  /* v5.2 step 6 (decision B): the middle reading; output backs the payout up to aK of the year's earned income (CFG.KENYA_ABSORB_*) */
        if (o.bkm) bkU = bkmStep(L, o.bkm, bkP, bkU, C.idx, yr, A.Yw);  /* S51: backing as a mechanism (off unless the row sets o.bkm): the funded projects' output backs the payout */
        if (LVS) bkU = lvStep(L, o, C, bkP, bkU, A.Yw, yr);  /* S54: the Source keeps project proceeds, pays the protected account's interest, sets next year's rationing */
        U = bkU + extra; L.bkP += bkP/C.idx; L.bkU += bkU/C.idx; L.bkY += A.Yw/C.idx;
        if (ACCT && !gRun){ var srcB = bkP - bkU + C.convM + (o.faceM ? C.bu : 0); acctChk('source', yr, C.bu + C.conv - bkU - srcB, Math.abs(C.bu) + Math.abs(C.conv) + Math.abs(bkU) + Math.abs(srcB), null); } }  /* v5.3 B2: what the Source pays (BU face value and conversion) = new money + the output that backs it */
      else if (o.fin === 'hybrid') U = (1 - o.a)*(C.conv - C.convM) + extra;  /* plan step 2: matched output (0 unless PROD) */  /* session 7 (d26 option c): transfers taxed, conversion rewards created at a */
      else U = (1 - o.a)*A.conv + (o.pthUnmatched ? A.pthLiq : 0) + extra;  /* 'none': the session 2-5 rule (transfers and price cuts unfinanced) */
      if ((FX && FX.fin) || ACCT){ L.yr = yr; U = finStep(L, o, C, A, need, U, extra, gRun, o.fin === 'source' ? bkP : 0, o.fin === 'source' ? bkU : 0, T, tauUsed); }  /* S68: the financing identity; fx.fin 'money' makes the capped contribution's gap new money */
      if (GVS) gvStep(GVS, o, C, need, agents, yr, T, recPath ? recPath[yr].incomeMultiplier : 1, tauUsed);  /* S72: the government account (fx.fin 'debt' borrows the unpaid part) */
      if (LVS) lvAcc(U, A.Yw, C.idx);  /* S54 */
      if (MFS) mfYear(MFS, C, U, A.Y);  /* S58 (reporting only) */
      if (yr === 0){ L.need0 = need; L.base0 = C.base; if (C.Es){ L.Es0 = C.Es; L.xi0 = 1; } }  /* v5.2 step 7: year 0's earnings for the progressive schedule (its brackets are in year-0 terms) */
      if (MULT && MLS && MLS.y[yr] && MLS.y[yr].ntR) L.ntR += MLS.y[yr].ntR/C.idx;  /* v5.2 step 6: wages added by filling normal-times slack (year-0 $) */
      if (MULT && MLS) MLS.push = o.fin === 'source' ? Math.max(0, C.bu + C.conv - C.ctax) : 0;  /* plan step 16: next year's push, the net Source payout */
      L.cost += (C.cash + C.endow + C.bu + C.conv + C.cap + C.cutPT - C.cutFree + C.cutG + C.pthLiq)/C.idx; L.cutFree += C.cutFree/C.idx;  /* plan step 5: the PTF discount funded by forgone profit is not programme cost */
      L.cash += C.cash/C.idx; L.endow += C.endow/C.idx; L.bu += C.bu/C.idx; L.conv += C.conv/C.idx; L.cutPT += C.cutPT/C.idx; L.cutG += C.cutG/C.idx; L.cap += C.cap/C.idx; L.pth += C.pthLiq/C.idx;
      L.pd += C.pd/C.idx; L.tgt += C.tgt/C.idx; L.tax += C.tax/C.idx; L.need += need/C.idx; L.treas += (C.tax - need)/C.idx; L.f0 += C.f0; L.f1 += C.f1; L.f2 += C.f2; L.n += C.n;
      L.emp += C.emp; L.hrs += C.hrs; L.Er += C.E/C.idx; L.bR += C.bR; L.bP += C.bP;  /* session 8 (A5): employment, hours, real wage earnings */
      L.convM += C.convM/C.idx; L.buIss += C.buIss/C.idx; L.ctax += C.ctax/C.idx;  /* plan steps 2-3 */
      if (SXS) sxSrcYear(yr, C, o.fin === 'source' ? bkP : 0, o.fin === 'source' ? bkU : 0);  /* S47: S52's payout series (reporting only) */
      L.bz += C.bz/C.idx; L.es += C.es/C.idx; L.pyP += C.pyP/C.idx; L.pyN += C.pyN/C.idx; L.esWP += C.esWP/C.idx; L.n1 += C.n1; L.nP1 += C.nP1; L.nN1 += C.nN1; L.nWP1 += C.nWP1;  /* session 19 */
      if (o.fin === 'tax' || o.fin === 'hybrid' || o.fin === 'source'){
        if (o.taxBase === 'prog' && C.Es && L.Es0){ var pm = function(v){ return v.reduce(function(x, e){ return x + e[0]; }, 0)/Math.max(1, v.length); }; TB.pxi = pm(L.Es0) > 0 ? pm(C.Es)/pm(L.Es0) : 1; }  /* v5.2 step 7: the brackets move with mean earnings (as the Social Security wage base does), not with prices */
        TB.tau = C.base > 0 ? (o.taxBase === 'prog' ? progLam(C.Es, TB.pxi || 1, o.tauMax, need, LABOR ? LABOR.eps - LABOR.rho : 0) : GOV ? Math.min(TB.capE, gvTarget(need)/C.base) : Math.min(o.tauMax, need/C.base)) : 0; }  /* S72: with gv, the share sh of need (plus last year's interest under fx.fin 'debt', ip 'tax'), up to the effective cap */  /* v5.2 step 7: for the progressive tax, the multiplier on the schedule that raises need (its marginal rates are capped instead) */
      var PGn = pmGenStep(PG, U, A.Y, o.lamG), capShare = o.ptfCap*(A.n ? A.ptfN/A.n : 0), PE = {};
      CFG.ESSENTIALS.forEach(function(k){
        var cut = !p.ptf ? 0 : PTF_MODE === 'shipped' ? (p.szh ? 0.12 + p.szhCoh*0.04 : 0.12) : (k === 'food' ? PTF_FOOD_CUT[PTF_MODE] : 0);
        if (!S || o.essMatched){ PE[k] = 1; return; }
        var sRef = o.supply === 'baseline' ? S[yr] : S[0]*Math.pow(1 + o.gS, yr);
        var dEff = o.supply === 'baseline' ? d : sRef + Math.max(0, d - sRef) - Math.max(0, S[yr] - sRef);
        PE[k] = pmEssLevel(dEff, sRef, capShare*cut, k === 'medical' && HEALTH && (HEALTH.set === 'B' || HEALTH.set === 'C') && yr + 1 >= HEALTH.start ? 0 : o.theta[k]);  /* session 2a, d-health-price rule a: under single payer the public payer sets rates (a shortage shows as waits); this step sets next year's prices */
      });
      var wyN = PRS ? PRS.y.length : 0;
      if (PRS) PGn = prStep(PRS, U, A.Y, o.lamG, PRICE.wIdx, PRICE.piG, PRICE.bIdx, PRICE.acc.slk || 0, yr, PGn);  /* S58: the capacity rule's general level (under 'qt' the record only; PGn unchanged) */
      if (WYS) wyYear(WYS, PRS && PRS.y.length > wyN ? Math.exp(PRS.y[PRS.y.length - 1].avg || 0) : 1);  /* S68 (reporting only): this year's within-year level, known after the price step */
      path.push({bIdx:PRICE.bIdx, PG:PG, U:U, Y:A.Y, tau:tauUsed, colaLevel:PRICE.colaLevel, full:C.idx});  /* session 8: full price level (exogenous x endogenous) */
      PRICE.piG = PGn/PG - 1; PG = PGn;
      CFG.BASKET_KEYS.forEach(function(k){ comp[k] = CFG.ESSENTIALS.indexOf(k) >= 0 ? PE[k]*(o.pgOnE ? PG : 1) : PG; });
      if (PRS && PRS.on) prComp(PRS, comp, PE, o.pgOnE);  /* S58: each essential at its own sector level under the capacity rule */
      if (SXp) sxApply(comp, SXp, yr + 1);  /* S52: the outside supply shock's factors for next year (only with p.sx) */
      PRICE.bIdx = pmBasketIdx(comp);
    }
  } finally { PRICE = null; TB = null; if (labAcc) LABOR = null; var prK = PRS; PRS = null; var lvK = LVS; if (LVS){ lvEnd(); LVS = null; } }
  if (yMax < T) return {tau0: L.base0 > 0 ? (o.taxBase === 'prog' ? progLam(L.Es0, L.xi0, o.tauMax, L.need0, LABOR ? LABOR.eps - LABOR.rho : 0) : GOV ? Math.min(gvCap, GOV.sh*L.need0/L.base0) : Math.min(o.tauMax, L.need0/L.base0)) : 0};  /* S72: the share sh, and the effective cap */
  var n = agents.length, NY = n*T, full = agents[0].yrBasketUSD/CFG.LIVING_WAGE_ANNUAL/(agents[0]._hhF || 1), lineF = o.lines === 'nominal' ? 1 : full, pov = 0, bpov = 0, g0 = 0, g1 = 0, g2 = 0;
  var nbpov = 0;  /* session 7 (d28): design-neutral BLEI, Baseline rules plus one month of the design's regular support (the d28 gate's measure) */
  agents.forEach(function(a){ if (a.wealth < CFG.POVERTY_LINE*lineF) pov++; if (agentBLEI(a, p.bu, p.ccoOn, p.pth, p.szh, p.szhCoh, p.ptf)/lineF < CFG.BLEI_PRECARIOUS_MAX) bpov++;
    if ((agentBLEI(a, 0, false, false, false, 0, false) + (a._tbM || 0)/CFG.BASE_DAILY_COST)/lineF < CFG.BLEI_PRECARIOUS_MAX) nbpov++;
    var g = a._tbGap || 0; if (g > 0) g0++; g1 += g; g2 += g*g; });
  /* Groups: mean real resources per year, person-year basket FGT0, and wealth poverty at year 20 (the inflation tax on nominal wealth
   * shows only here: income terms are indexed, wealth is not). */
  function grpOf(f){ var m = 0, k = 0, f0 = 0, f2 = 0, wp = 0; agents.forEach(function(a){ if (f(a)){ k++; m += a._tbRes/a._tbYrs; f0 += a._tbF0/a._tbYrs; f2 += (a._tbF2 || 0)/a._tbYrs; if (a.wealth < CFG.POVERTY_LINE*lineF) wp++; } });
    return k ? {res:m/k, f0:f0/k*100, f2:f2/k*100, wp:wp/k*100, k:k} : {res:0, f0:0, f2:0, wp:0, k:0}; }  /* session 21 (s41): + person-year FGT2 (f2) */
  var gP = grpOf(function(a){ return a._tbPart; }), gN = grpOf(function(a){ return !a._tbPart; }), gH = grpOf(function(a){ return a._tbPTH; }), gL = grpOf(function(a){ return a._tbLow; }), gT = grpOf(function(a){ return a._tbTop; });
  /* Session 8 (A5): spells, persistence, and the year-20 income distribution (reporting only). */
  var sp = 0, spY = 0, ever = 0, chron = 0; agents.forEach(function(a){ sp += a._tbSp || 0; spY += a._tbF0 || 0; if (a._tbF0 > 0) ever++; if ((a._tbF0 || 0) >= T/2) chron++; });
  var gcF = o.giniNN1 && n > 1 ? n/(n - 1) : 1;  /* v5.2 step 2: the n/(n - 1) correction (x 1 exactly when off) */
  var giniD = giniOfArr(agents.map(function(a){ return a._tbDisp || 0; }))*gcF, giniX = giniOfArr(agents.map(function(a){ return a._tbExt || 0; }))*gcF;
  var pT = path[T-1], p10 = path[Math.min(T-1, 9)], realT = (p.cola ? pT.colaLevel : 1)/pT.full;
  function pjQ(k){ return (PROJ && PJS && PJS.acc.partY > 0) ? PJS.acc[k]/PJS.acc.partY : 0; }  /* N1 (session 15) */
  var pjSv = 0; if (PROJ && PJS && PJS.acc.partY > 0){ agents.forEach(function(a){ pjSv += (a._pjSaved || 0) + (a._pjGiftH || 0); }); pjSv /= Math.max(1, PJS.acc.partY/T); }
  var esOn = !!(ESP && ESS && CONVERSION_MODEL === 'framework'), eA = esOn ? ESS.acc : null;  /* session 19 (s38) */
  var spOn = !!(SURP && SPS && CONVERSION_MODEL === 'framework'), sA = spOn ? SPS.acc : null;  /* plan step 1 */
  function spQ(k){ return spOn && L.n1 ? sA[k]/L.n1 : 0; }
  var jnOn = !!(JOIN && JNS && CONVERSION_MODEL === 'framework' && p.ccoOn); function jnQ(y){ return jnOn && JNS.y[y] ? JNS.y[y].part*100 : 0; }  /* plan step 4 */
  function pdQ(y, k){ return (PROD && PDS && PDS.y[y] && CONVERSION_MODEL === 'framework') ? PDS.y[y][k]*100 : 0; }  /* plan step 2 */
  var bI = path[T-1].bIdx, mx = 0, tauS = 0;
  for (var t = 1; t < T; t++) mx = Math.max(mx, path[t].bIdx/path[t-1].bIdx - 1);
  path.forEach(function(q){ tauS += q.tau; });
  var emR = EMPL && EMS ? emplRes({}) : null;  /* v5.4 item 2 */
  if (PTHB) emR = pthbRes(emR || {});
  if (PTFS) emR = ptfsRes(emR || {});  /* v5.4 item 4 */
  if (COMM) emR = clRes(emR || {});  /* S37 */
  if (PAS) emR = paRes(emR || {});  /* S55 */
  if (POS) emR = poRes(emR || {}, NY, L.cost/NY);  /* S62 */
  if (FX && FX.fin) emR = finRes(emR || {}, L.fi, NY);  /* S68 */
  if (GVS){ emR = gvRes(emR || {}, GVS, NY, T); GVS = null; }  /* S72 (only with gv) */
  if (WYS){ emR = wyRes(emR || {}, WYS); WYS = null; }  /* S68 (only with o.wy) */
  if (C22) emR = c22Res(emR || {}, grpOf(function(a){ return !!a._inel; }), n);  /* S6 */
  if (HEALTH && HLS) emR = hlRes(emR || {});  /* session 2a */
  if (SNET && SNS) emR = snRes(emR || {});  /* session 2b */
  if (DIS) emR = disRes(emR || {});  /* v5.4 item 5 */
  if (o.bkm && L.bkm) emR = bkmRes(emR || {}, L.bkm, T);  /* S51 (only with o.bkm) */
  if (SXS) emR = sxRes(emR || {}, T);  /* S52 (only with p.sx) */
  if (SECS){ emR = secRes(emR || {}); SECS = null; }  /* S53 (only with o.sec) */
  if (DMS){ emR = dmRes(emR || {}); DMS = null; }  /* S57 (only with o.dm) */
  if (RTR){ emR = Object.assign(emR || {}, RTR); RTR = null; }  /* S59 (only with rt) */
  if (WTS){ emR = Object.assign(emR || {}, WTS); WTS = null; }  /* S59 part 2 (only with wt or o.wtm) */
  if (prK) emR = prRes(emR || {}, prK, agents, lineF);  /* S58 (with the capacity rule, or o.mf) */
  if (MFS) emR = mfRes(emR || {}, MFS, NY);  /* S58 (only with o.mf) */
  if (lvK) emR = lvRes(emR || {}, lvK, T, !!(JOIN && JNS && CONVERSION_MODEL === 'framework' && p.ccoOn));  /* S54 (only with o.lv) */
  var plv = {}; TB_PLV_KEYS.forEach(function(k, t){ plv[k] = t < path.length ? path[t].full : 0; });  /* S35 (reporting only) */  /* v5.4 item 3 (zeros in the no-programme run) */
  return {path:path, res:Object.assign(lfRes(fbsRes(FBSS, edcRes(EDCS, hhRes(RHH, tbRepRes(R52, tbBleiRes(BG, {
    endoAnn:Math.pow(bI, 1/(T - 1)) - 1, endoMax:mx, pov:pov/n*100, bleiPov:bpov/n*100, nbleiPov:nbpov/n*100, tgt:L.pd > 0 ? L.tgt/L.pd : 0, medWealthReal:medianOf(agents.map(function(a){ return a.wealth; }))/full,
    fgt0:g0/n*100, fgt1:g1/n*100, fgt2:g2/n*100, fgt0PY:L.f0/L.n*100, fgt1PY:L.f1/L.n*100, fgt2PY:L.f2/L.n*100,
    cost:L.cost/NY, cCash:L.cash/NY, cEndow:L.endow/NY, cBU:L.bu/NY, cConv:L.conv/NY, cCut:(L.cutPT + L.cutG)/NY, cCap:L.cap/NY, cPth:L.pth/NY,
    tax:L.tax/NY, need:L.need/NY, treas:L.treas/NY, tauMean:tauS/T, tauLast:path[T-1].tau,
    dE:labAcc && labAcc.E0 > 0 ? (labAcc.E - labAcc.E0)/labAcc.E0 : 0, E:labAcc ? labAcc.E/Math.max(1, labAcc.n) : 0, E0:labAcc ? labAcc.E0/Math.max(1, labAcc.n) : 0, zero:labAcc ? labAcc.zero/Math.max(1, labAcc.n) : 0,
    gPartRes:gP.res, gPartF0:gP.f0, gNonRes:gN.res, gNonF0:gN.f0, gPthRes:gH.res, gPthF0:gH.f0, gLowRes:gL.res, gLowF0:gL.f0, gTopRes:gT.res, gTopF0:gT.f0,
    gPartW:gP.wp, gNonW:gN.wp, gPthW:gH.wp, gLowW:gL.wp, gTopW:gT.wp,
    pyPoor:spY/n, everPoor:ever/n*100, spellMean:sp > 0 ? spY/sp : 0, chronic:chron/n*100, emp:L.emp/L.n*100, hrs:L.hrs/L.n - 1, Er:L.Er/NY,
    giniD:giniD, giniX:giniX, pLev10:p10.full, pLev20:pT.full, realT:realT, bleiR:L.bR/L.n*100, bleiP:L.bP/L.n*100,
    /* N1 (session 15): project hiring, per participant-year, year-0 dollars (0 when PROJ is off) */
    pjNet:pjQ('net'), pjGift:pjQ('giftNet'), pjBU:pjQ('alloc'), pjExp:pjQ('exp'), pjHrs:pjQ('hrs'), pjDisp:pjQ('disp'), pjWork:pjQ('work')*100,
    pjRc:(PROJ && PJS && PJS.acc.rcN) ? PJS.acc.rc/PJS.acc.rcN : 0, pjSaved:pjSv,
    /* Session 19 (s38): the business premium and ESP payroll, years 1-19, year-0 dollars. bzPay: the ESP's own premium as paid out
     * (today's whole premium when ESP is off); esPrem: payroll premium; per adult-year, participant-year, non-participant-year and
     * participating ESP worker-year. From ESS (0 when ESP is off): payroll BU per ESP worker-year, BU share of ESP pay (%), mean rate
     * on payroll BU, the share of participating ESP worker-years where the octave cap binds (%), and BU converted or returned per
     * adult-year. */
    bzPay:L.n1 ? L.bz/L.n1 : 0, esPrem:L.n1 ? L.es/L.n1 : 0, payPart:L.nP1 ? L.pyP/L.nP1 : 0, payNon:L.nN1 ? L.pyN/L.nN1 : 0, esPremW:L.nWP1 ? L.esWP/L.nWP1 : 0,
    esBUW:eA && eA.wkY1 ? eA.alloc/eA.wkY1 : 0, esShare:eA && eA.wage > 0 ? eA.alloc/eA.wage*100 : 0, esRate:eA && eA.conv > 0 ? eA.rateXbu/eA.conv : 0,
    esCapB:eA && eA.partWkY ? eA.capBind/eA.partWkY*100 : 0, esConv:eA && L.n1 ? eA.conv/L.n1 : 0, esRet:eA && L.n1 ? eA.ret/L.n1 : 0,
    /* Session 21 (s41): person-year FGT2 (x100) and size by group; BLEI by group (tbBleiRes adds the b* keys) */
    gPartF2:gP.f2, gNonF2:gN.f2, gPartK:gP.k, gNonK:gN.k,
    /* Plan step 1 (Oct 1, 2026): the ESP surplus split, years 1-19, year-0 dollars per adult-year unless stated (0 when SURP is off). spSw: the
     * first year of phase 2 (99 = never); spCap: the capital account per adult at the end (year-0 $); spD1/spD2: mean cut by phase (%); spNon: share
     * of the pool reaching non-participants (%, cuts and dollars); spPtfS: the PTFs' share of the pool (%). */
    spPool:spQ('pool'), spOwn:spQ('own'), spPtfS:spOn && sA.pool > 0 ? sA.ptf/sA.pool*100 : 0, spCut:spQ('cut'), spCutN:spQ('cutN'), spFreed:spQ('freed'), spCash:spQ('cash'),
    spProfit:spQ('profit'), spProfW:spOn && sA.wkY1 ? sA.profitN/sA.wkY1 : 0, spReinv:spQ('reinv'), spRest:spQ('rest'), spCap:spOn ? SPS.capPA : 0, spSw:spOn ? (SPS.sw < 0 ? 99 : SPS.sw) : 0,
    spD1:spOn && sA.n1 ? sA.d1/sA.n1*100 : 0, spD2:spOn && sA.n2 ? sA.d2/sA.n2*100 : 0, spNon:spOn && sA.pool > 0 ? (sA.non + sA.cutN)/sA.pool*100 : 0, spCarry:spOn ? sA.carry/n : 0,
    /* Plan step 2: PTF capacity share at the start of years 5, 10 and 19 and PTF members' share in year 19 (%); matched output as a share of conversion (%) */
    pdC5:pdQ(5, 'cap'), pdC10:pdQ(10, 'cap'), pdC19:pdQ(T - 1, 'cap'), pdMem19:pdQ(T - 1, 'mem'), pdMatch:L.conv > 0 ? L.convM/L.conv*100 : 0,
    /* Plan step 3: the Source's ledger, year-0 dollars per adult-year: BU issued, dollars paid at conversion (BU face value spent + conversion
     * proceeds), conversion tax kept, output backing (matched), and the tax kept as a share of the BU issued (%). */
    srcIss:L.buIss/NY, srcPay:(L.bu + L.conv)/NY, srcTax:L.ctax/NY, srcM:L.convM/NY, srcCover:L.buIss > 0 ? L.ctax/L.buIss*100 : 0,
    /* Plan step 4: participation share at years 5, 10 and 19 (%), and joins and leaves over the run per 100 adults */
    jnP5:jnQ(5), jnP10:jnQ(10), jnP19:jnQ(T - 1), jnJoin:jnOn ? JNS.join/n*100 : 0, jnLeave:jnOn ? JNS.leave/n*100 : 0,
    csFree:L.cutFree/NY, epPY:epSum/T*100,
    /* v5.2 step 4: ageing (0 when AGE is off): retired share at the end (%), mean age at the start and the end, deaths per 1,000 adult-years, new adults over the run (% of the population) */
    agRet:AGE && AGS ? agents.filter(function(a){ return a._ret; }).length/n*100 : 0, agAge0:AGE && AGS ? AGS.ageSum0/n : 0, agAge:AGE && AGS ? agents.reduce(function(m, a){ return m + a.age; }, 0)/n : 0,
    agDeaths:AGE && AGS ? AGS.deaths/NY*1000 : 0, agBorn:AGE && AGS ? AGS.born/n*100 : 0, svInt:SAVE && SVS ? SVS.intR/NY : 0, svIntR:SAVE && SVS ? SVS.realR/NY : 0,
    bkA:L.bkP > 0 ? (1 - L.bkU/L.bkP)*100 : 0, bkPY:L.bkY > 0 ? L.bkP/L.bkY*100 : 0, mlNT:L.ntR/NY,
    hcM:HCAP && HCS ? HCS.mSum/T*100 : 0, rvX:REVS ? REVS.x/NY : 0, rvC:REVS ? REVS.c/NY : 0, taxAvg:L.Er > 0 ? L.tax/L.Er*100 : 0,  /* v5.2 step 7: mean rent mark-up outside PTH (%), unearned pay not caught and pay clawed back by audits (year-0 $ per adult-year), the contribution as a share of wages (%) */  /* v5.2 step 6: the share of the Source's net payout backed by output (%), that payout as a share of earned income (%), and wages added by filling normal-times slack (year-0 $ per adult-year) */
    hhDebt20:dbt20, hhDebt40:dbt40,  /* S35 */
    octMean:agents.reduce(function(m, a){ return m + (a.inCCO ? a.octave : 0); }, 0)/Math.max(1, agents.filter(function(a){ return a.inCCO; }).length)})))))), emR || {}, plv)};  /* plan step 6: mean octave of participants at year 20 */  /* plan step 5: PTF discount funded by forgone profit, year-0 $ per adult-year */
}

// index.html line 7152
/* S51: the mechanism's measures (only with o.bkm). bkmA: share of the net payout backed by the funded output over the run (%; bkA counts every backing);
 * bkm5, bkm10, bkm19: that share in years 5, 10 and 19 (%); bkmO19: the output a year in year 19 as a share of that year's earned income (%);
 * bkmF: the dollars funded as a share of the net payout (%; equals f unless a year's payout is negative). */
var BKM_KEYS = ['bkmA', 'bkm5', 'bkm10', 'bkm19', 'bkmO19', 'bkmF'];

// index.html line 7183
var SXS = null;

// index.html line 7195
function sxH(h){ return PRICE && PRICE.sxF ? h/PRICE.sxF.h : h; }  /* the housing share before the shock (PTH's cut) */

// index.html line 7205
/* Measures (reporting only, no draw). Groups this year: F PTF members; H PTH members not in PTF; P CCO participants in neither; N adults in none of the
 * three; X adults who chose not to take part (a._tbPart false: the same adults in every design and in the no-programme run); A all. Own cost is what the
 * adult pays in money: BU spent on essentials is not in it, so the BU's part of the insulation shows in P (and in F and H, whose members mostly hold BU too). Windows: B before the shock, D during it, After. For each group
 * and window: own cost (sxC, dollars a year, the adult's basket at its own prices), market basket (sxM, the same basket at market prices) and basket
 * poverty (sxP, % of adult-years below the own cost). The share of the shock reaching a group is read by pairing a shocked row with its unshocked twin
 * (the same seed): the rise in own cost over the rise in the market basket. sxV: the volatility of the group's essential costs, the standard deviation of
 * the year-on-year change in its mean own cost, years 1 to the end (%). */
var SX_GRPS = ['A', 'F', 'H', 'P', 'N', 'X'], SX_WINS = ['B', 'D', 'A'];

// index.html line 7206
var SX_KEYS = [].concat.apply([], SX_GRPS.map(function(g){ return [].concat.apply([], SX_WINS.map(function(w){ return ['sxC' + w + g, 'sxM' + w + g, 'sxP' + w + g]; })).concat(['sxV' + g]); }));

// index.html line 7218
/* S47 (Nov 6, 2026; research-update prereg/2026-11-supply-shock-addendum.md, Amendment 1 item 2; reporting only, no draw, nothing any rule reads; only with p.sx).
 * 1. Essential costs by payer, per group and window (dollars a year per adult-year, the adult's own figures: a pooled couple's member is read on its own basket
 *    and cost, not the household's average): sxE the essentials (what BU can buy, buEss()) at market prices; who pays them: sxEb BU spent (face value), sxEf
 *    PTF's cut, sxEh PTH's cut, sxEm money (own cost less the non-essentials at market prices, as secXb), sxEo the rest (other price cuts: public grocery, an
 *    ESP's, the S54 rent cap's part; a medical bill above the basket line counts negative), so sxEb + sxEf + sxEh + sxEm + sxEo = sxE. And by category, at
 *    market prices: sxKf food, sxKh housing with utilities, sxKm medical, sxKt transport. The model does not record which essential a BU or a cut buys (PTF's
 *    cut is on food and utilities, PTH's on housing, the BU on any essential), so payer and category are given as two margins, not crossed.
 * 2. The Source's payout by year (year-0 dollars per adult; 0 past the run and on rows not paid by the Source): sxQb_t backed by output, sxQu_t unbacked (the
 *    new money), sxQi_t BU issued at face value (the BU's cost to the Source, spent or not).
 * 3. sxVd: a dollar-based volatility, the standard deviation of the year-on-year change in the group's mean own cost over its mean market basket the year
 *    before (%), years 1 to the end (sxV's change is over the group's own cost). */
var SX_PAY = ['E', 'Eb', 'Ef', 'Eh', 'Em', 'Eo', 'Kf', 'Kh', 'Km', 'Kt'], SX_KCAT = ['food', 'housing', 'medical', 'transport'], SX_QN = 40;

// index.html line 7219
var SX_KEYS2 = [].concat.apply([], SX_GRPS.map(function(g){ return [].concat.apply([], SX_WINS.map(function(w){ return SX_PAY.map(function(m){ return 'sx' + m + w + g; }); })).concat(['sxVd' + g]); }))
  .concat([].concat.apply([], ['b', 'u', 'i'].map(function(m){ var r = []; for (var t = 0; t < SX_QN; t++) r.push('sxQ' + m + '_' + t); return r; })));
SX_KEYS = SX_KEYS.concat(SX_KEYS2);

// index.html line 7271
/* S53 (Nov 2, 2026; research-update PLAN.md S53, prereg/2026-11-security-addendum.md; reading dev/reports/s53-security-reading.md): SECURITY OUTCOMES BEYOND
 * WEALTH, and the per-year poverty series the public-costs step (S19) needs. Reporting only: no draw, nothing any rule reads. Off unless the study options set
 * o.sec (true, or an object overriding SEC_DEFAULTS); off, no key is added and no figure moves (guard test). Groups: A all adults; P the adults who take part
 * (a._tbPart: the same latent adults in every design and in the no-programme run); X the adults who choose not to (the no-harm group).
 * Each adult-year (tbPov, after the year's money flows):
 *   resources  real money income plus in-kind support, (inc + market basket - own cost) / price level, as the engine's own resources measure (a._tbRes);
 *   liquid     liq (0.20, the BLEI's liquid share of wealth, agentBLEI) x positive savings; 'all' readings use every dollar of savings;
 *   without wages  income that does not depend on work this year: cash transfers, unemployment insurance, the UBI comparator, Social Security. Conversion
 *              proceeds are left out (they follow work or BU use; the cautious reading); the 'c' readings add them. The contribution is ignored (a tax on
 *              earnings); BU, PTF and PTH are in own cost already.
 *   need       own cost less income without wages (at least 0).
 * Keys (g = A, P, X):
 *   secD25g, secU25g  real resources fall by 25% or more from the year before (per 100 adult-years with a year before); U: and liquid savings at the start of
 *                     the year are below the fall (no buffer to cover it). secU50g: a 50% fall, uncovered. secU25mg: the same as U25 on money income alone.
 *   secM1g, secM3g    % of adult-years whose liquid savings cover less than 1 / 3 months of need; secM3wg: 3 months on all savings; secMdg: the median months
 *                     (need 0 counts as cap, 120 months).
 *   secHrg, secH40g   hours of work a week needed to cover need at the adult's own wage (a.wage, before the year's recession and job loss), the median over
 *                     working-age adults with a wage; % needing more than 40. secHrcg: the median with conversion proceeds counted.
 *   secXbg, secXeg    exposure: essentials (what BU can buy, buEss()) paid in money at the adult's prices, as % of the full cost of living at market prices
 *                     (Xb) and of the essentials at market prices (Xe); ratios of sums. With no programme Xb is the essentials' budget share by construction.
 *   secPxg            PTH tenancies ended per 100 PTH member-years (any cause; the model has no rule that ends one against the member's will: with the PTH books
 *                     on, members leave at a drawn moving rate);
 *   secDsg            displacement by price (a proxy: the model has no moving decision): adults outside PTH who could pay this year's own cost last year from
 *                     income and savings and cannot this year (the engine's housing-distress test, housingDistressOf), per 100 adult-years with a year before.
 * Per-year series for S19, s19<m>_<t>, t = 0..39 (0 past the run): f0 basket poverty (%), f1 FGT1 (%), gD mean poverty-gap dollars per adult (year-0 $), gDc the
 * same with each gap capped at gapCap ($10,000, the income range of Deshpande and Mueller-Smith 2022, which avoidWide's justice row applies), dp deep poverty
 * (own cost not met by half or more, %), hd housing distress (%), ep the engine's extreme-poverty estimate (%; extremePovertyOf, 0 with o.noEP), n adults,
 * f0X basket poverty of X (%). */
var SEC = null, SEC_DEFAULTS = {liq:0.20, cap:120, hrsYr:2080, gapCap:10000}, SECS = null;

// index.html line 7272
var SEC_GRPS = ['A', 'P', 'X'], SEC_M = ['D25', 'U25', 'U50', 'U25m', 'M1', 'M3', 'M3w', 'Md', 'Hr', 'H40', 'Hrc', 'Xb', 'Xe', 'Px', 'Ds', 'F25', 'F25w', 'F25c', 'F25o', 'U25b'];

// index.html line 7280
/* S47 (Nov 6, 2026; research-update prereg/2026-11-security-addendum.md, Amendment 1 item 3; reporting only, no draw, nothing any rule reads; only with o.sec):
 *   secF25g           any fall of 25% or more in real money income (inc / price level, as U25m) from the year before, covered or not, per 100 adult-years with a
 *                     year before; split by its main cause, the part whose real amount fell most: secF25wg wage earnings, secF25cg conversion proceeds,
 *                     secF25og everything else in money income (cash transfers, the UBI comparator, Social Security, the endowment's yearly part, less the
 *                     contribution). Ties go to wages, then conversion. F25w + F25c + F25o = F25.
 *   secU25bg          the uncovered 25% falls in resources (U25) that leave the adult below their own cost of living that year (gap > 0), per 100 adult-years
 *                     with a year before; U25b <= U25. A pooled couple's members are read on the household's totals per adult, as every other measure here. */
var SEC_KEYS = [].concat.apply([], SEC_GRPS.map(function(g){ return SEC_M.map(function(m){ return 'sec' + m + g; }); }));

// index.html line 7281
var S19_M = ['f0', 'f1', 'gD', 'gDc', 'dp', 'hd', 'ep', 'n', 'f0X'], S19_N = 40;

// index.html line 7282
var S19_KEYS = [].concat.apply([], S19_M.map(function(m){ var r = []; for (var t = 0; t < S19_N; t++) r.push('s19' + m + '_' + t); return r; }));

// index.html line 7335
/* S57 (Nov 9, 2026; research-update PLAN.md S57, prereg/2026-11-s57-distribution-measures.md): DISTRIBUTION MEASURES. Reporting only: no draw, nothing any rule
 * reads (the only write is a mobility tag on each adult, a._dmQ, which no rule reads). Off unless the study options set o.dm (true, or an object, reserved);
 * off, no key is added and no figure moves (guard test). Every share, percentile and rate is weighted by a._w (1 until S59's tail exists); at weight 1 it equals
 * the plain version (unit test). Two moments: the end of Year 0 (suffix S, the start) and the end of the last year (suffix E). Dollars are Year-0 dollars (nominal over the
 * year's price level, as tbRepYear does). Wealth is a.wealth (net worth, debts kept); income is a._tbDisp (disposable income, the Gini's income).
 * Keys (s = S or E):
 *   dmWt1s, dmWt10s, dmWb50s   top 1%, top 10% and bottom 50% share of wealth (%, of the weighted total net worth; the bottom share is negative if debts exceed assets)
 *   dmYt1s, dmYt10s, dmYb50s   the same for disposable income
 *   dmYps, dmYpOks             Palma ratio of income (top 10% over bottom 40%); dmYpOk 1 when the bottom 40% hold positive income (ratio 0 otherwise)
 *   dmWrs, dmWrOks             wealth top-10-to-bottom-40 ratio; dmWrOk 1 when the bottom 40% hold positive wealth (ratio 0 otherwise)
 *   dmWp<q>s, dmYp<q>s         real wealth and real income at percentile q of DM_GRID (1, 5, 10, ..., 95, 99), Year-0 dollars
 *   dmLss, dmLcs, dmLsPY, dmLcPY   labour's share of money income (tbCashIncome): wages; wages plus conversion proceeds (%); s = the year, PY = ratio of the real sums over all years
 *   dmFds, dmDms, dmDis        families in debt (%, tbDebtShare's family); median debt of those families (Year-0 $, 0 if none); their debt over their members' disposable income (0 if none)
 *   dmNs                       adults
 *   dmMob<i><j>, dmMobN        (last year only) % of the adults present at Year 0 in wealth fifth i (0 poorest) found in fifth j; the number followed */
var DM_GRID = [1, 5, 10, 15, 20, 25, 30, 35, 40, 45, 50, 55, 60, 65, 70, 75, 80, 85, 90, 95, 99], DMS = null;

// index.html line 7336
var DM_KEYS = (function(){ var k = [];
  ['S', 'E'].forEach(function(s){ ['Wt1', 'Wt10', 'Wb50', 'Yt1', 'Yt10', 'Yb50', 'Yp', 'YpOk', 'Wr', 'WrOk', 'Ls', 'Lc', 'Fd', 'Dm', 'Di', 'N'].forEach(function(m){ k.push('dm' + m + s); });
    DM_GRID.forEach(function(q){ k.push('dmWp' + q + s); k.push('dmYp' + q + s); }); });
  k.push('dmLsPY', 'dmLcPY', 'dmMobN'); for (var i = 0; i < 5; i++) for (var j = 0; j < 5; j++) k.push('dmMob' + i + j); return k; })();

// index.html line 7340
function dmNew(o){ return {o:o === true ? {} : o, snap:{}, pyW:0, pyC:0, pyY:0, mob:null}; }

// index.html line 7341
function dmSort(v){ var idx = v.map(function(x, i){ return i; }); idx.sort(function(a, b){ return v[a] - v[b] || a - b; }); return idx; }

// index.html line 7343
/* the weighted quantile: order statistic k sits at (cumulative weight - its weight)/(total - mean weight), which is type 7 (quantileOf) at weight 1 */
function dmQuantiles(v, w, qs){ var n = v.length; if (!n) return qs.map(function(){ return 0; });
  var idx = dmSort(v), W = 0, p = [], c = 0; idx.forEach(function(i){ W += w[i]; });
  var den = W - W/n; idx.forEach(function(i){ p.push(den > 0 ? c/den : 0); c += w[i]; });
  return qs.map(function(q){ if (n === 1 || den <= 0) return v[idx[0]]; var k = 0; while (k < n - 2 && p[k + 1] <= q + 1e-12) k++;
    var a = p[k], b = p[k + 1], t = b > a ? Math.min(1, Math.max(0, (q - a)/(b - a))) : 0; return v[idx[k]] + (v[idx[k + 1]] - v[idx[k]])*t; }); }

// index.html line 7349
/* the weighted sum of x over the top (or bottom) fraction f of the weighted population; the boundary adult counts for the part needed */
function dmTail(v, w, f, top){ var idx = dmSort(v); if (top) idx.reverse(); var W = 0, s = 0; idx.forEach(function(i){ W += w[i]; }); var rem = f*W;
  for (var t = 0; t < idx.length && rem > 0; t++){ var i = idx[t], u = Math.min(w[i], rem); s += u*v[i]; rem -= u; } return s; }

// index.html line 7351
function dmTot(v, w){ var s = 0; for (var i = 0; i < v.length; i++) s += w[i]*v[i]; return s; }

// index.html line 7352
function dmMeasure(v, w, out, pre, s){  /* shares, ratios and (for the grid) percentiles of one variable */
  var T = dmTot(v, w), sh = function(f, top){ return T > 0 ? dmTail(v, w, f, top)/T*100 : 0; };
  out['dm' + pre + 't1' + s] = sh(0.01, true); out['dm' + pre + 't10' + s] = sh(0.10, true); out['dm' + pre + 'b50' + s] = sh(0.50, false);
  var b40 = dmTail(v, w, 0.40, false), t10 = dmTail(v, w, 0.10, true), ok = b40 > 0 ? 1 : 0;
  out['dm' + (pre === 'W' ? 'Wr' : 'Yp') + s] = ok ? t10/b40 : 0; out['dm' + (pre === 'W' ? 'WrOk' : 'YpOk') + s] = ok;
  var qs = dmQuantiles(v, w, DM_GRID.map(function(q){ return q/100; })); DM_GRID.forEach(function(q, j){ out['dm' + pre + 'p' + q + s] = qs[j]; }); }

// index.html line 7358
function dmFifths(v, w){ var idx = dmSort(v), W = 0, c = 0, q = new Array(v.length); idx.forEach(function(i){ W += w[i]; });
  idx.forEach(function(i){ q[i] = W > 0 ? Math.min(4, Math.floor(5*(c + w[i]/2)/W)) : 0; c += w[i]; }); return q; }

// index.html line 7360
function dmYear(S, agents, p, o, yr, T){
  var n = agents.length; if (!n || yr >= T) return;
  var lf = o.lines === 'nominal' ? 1 : agents[0].yrBasketUSD/CFG.LIVING_WAGE_ANNUAL/(agents[0]._hhF || 1);
  var wt = agents.map(function(a){ return a._w === undefined ? 1 : +a._w; }), wg = 0, wc = 0, mi = 0;
  agents.forEach(function(a, i){ var wgi = +a.yrWageUSD || 0, cv = +a.yrConvUSD || 0; wg += wt[i]*wgi; wc += wt[i]*(wgi + cv); mi += wt[i]*tbCashIncome(a); });
  S.pyW += wg/lf; S.pyC += wc/lf; S.pyY += mi/lf;
  if (yr !== 0 && yr !== T - 1) return;
  var s = yr === 0 ? 'S' : 'E', o2 = {}, W = agents.map(function(a){ return a.wealth/lf; }), Y = agents.map(function(a){ return (+a._tbDisp || 0)/lf; });
  dmMeasure(W, wt, o2, 'W', s); dmMeasure(Y, wt, o2, 'Y', s);
  o2['dmLs' + s] = mi > 0 ? wg/mi*100 : 0; o2['dmLc' + s] = mi > 0 ? wc/mi*100 : 0; o2['dmN' + s] = n;
  var fam = [];
  if (HHS && HHS.list) HHS.list.forEach(function(H){ if (H.a.length) fam.push(H.a); }); else agents.forEach(function(a){ fam.push([a]); });
  var fd = 0, fw = 0, dv = [], dw = [], dy = 0, dd = 0;
  fam.forEach(function(m){ var wl = 0, y = 0, ww = 0; m.forEach(function(a){ wl += a.wealth; y += (+a._tbDisp || 0); ww += (a._w === undefined ? 1 : +a._w); }); ww /= m.length; fw += ww;
    if (wl < 0){ fd += ww; dv.push(-wl/lf); dw.push(ww); dd += ww*(-wl/lf); dy += ww*y/lf; } });
  o2['dmFd' + s] = fw > 0 ? fd/fw*100 : 0; o2['dmDm' + s] = dv.length ? dmQuantiles(dv, dw, [0.5])[0] : 0; o2['dmDi' + s] = dy > 0 ? dd/dy : 0;
  S.snap[s] = o2;
  var q = dmFifths(W, wt);
  if (yr === 0) agents.forEach(function(a, i){ a._dmQ = q[i]; });
  else { var M = [0, 1, 2, 3, 4].map(function(){ return [0, 0, 0, 0, 0]; }), N = 0; agents.forEach(function(a, i){ if (a._dmQ !== undefined){ M[a._dmQ][q[i]] += wt[i]; N++; } }); S.mob = {M:M, N:N}; } }

// index.html line 7380
function dmRes(r, S0){ var S = S0 || DMS; DM_KEYS.forEach(function(k){ r[k] = 0; });
  ['S', 'E'].forEach(function(s){ var o2 = S.snap[s]; if (o2) Object.keys(o2).forEach(function(k){ r[k] = o2[k]; }); });
  r.dmLsPY = S.pyY > 0 ? S.pyW/S.pyY*100 : 0; r.dmLcPY = S.pyY > 0 ? S.pyC/S.pyY*100 : 0;
  if (S.mob){ r.dmMobN = S.mob.N; S.mob.M.forEach(function(row, i){ var t = row.reduce(function(x, y){ return x + y; }, 0); row.forEach(function(c, j){ r['dmMob' + i + j] = t > 0 ? c/t*100 : 0; }); }); }
  return r; }

// index.html line 7417
/* S54 (Nov 5, 2026; research-update PLAN.md S54, ledger D12 and D13; dev/reports/s54-levers-reading.md): THE POLICY LEVERS, behind the row option o.lv
 * (undefined = off: nothing here runs and every figure is unchanged; o.lv = {} sets every lever at the design's own value and moves no figure either, unit test).
 * Each field is one lever a government running the programme could set; each is a design parameter swept by study N (research-update
 * prereg/2026-11-levers-addendum.md). Levers that are already row settings are set there, not here: the base conversion tax (p.tax), the BU (p.bu), the top
 * multiplier (p.maxMult), the number of octaves (p.maxOct), the Phi tier (p.phi), expired BU recycled to projects (row option pj.share; the rest is retired),
 * outside finance (o.fin 'tax' with o.taxBase), BU indexation (p.colaThresh -1: every year; c22.idx 'needs'), savings that keep up with prices (row option sv),
 * the rent risk (row option hc).
 *  jn    'conv': joining sees what joining pays. An adult joins when the BU they would use plus their expected conversion income after the row's tax is at least
 *        (12 x BU + the same income after the released tax) x their latent cost share (the revealed cost's uCCO / partRate). Expected conversion income: last
 *        year's project BU per unit of allocation weight (year-0 dollars, at this year's prices) x the adult's weight (octave capacity x quality) x their rate
 *        (PROJ.rate 'max' against last year's pool rate) after tax x the CIP bonus, and only if project work would pay more than an hour of their wage (the
 *        hiring rule). At the released tax with the BU fully used this is exactly year 0's rule (uCCO < partRate). tref: the released base rate (default p.tax).
 *  pr, pc  the conversion tax's progression (points per rate point above 3x; CFG.PROG_RATE 0.04) and its cap (CFG.PROG_TAX_MAX 0.75)
 *  bt    a separate base rate on business (ESP) conversions (the year-close conversion and the ESP's returned payroll), with the base rate's CIP adjustment
 *  keep  the share of the projects' sales the Source keeps and retires: the projects' output is counted at what the work was paid (matched project output, as
 *        the release row already counts it); the retired dollars are at most the year's new money
 *  br    the business conversion rate (FW.bizRate; 3 as released)
 *  oc    octave capacity enforced on project work: PROJ.cap on, at oc x 12 x FW.octaveCapBase x 2^octave BU a year (the ESP payroll cap moves with it)
 *  ph    a phase-in over ph years: in year t every conversion rate's premium above par is scaled by min(1, (t + 1)/ph)
 *  cap   the issuance cap: the Source's net new money at most cap x the year's earned income. Each year the Source sets next year's factor q from this year's
 *        figures: (cap x earned income - the new money that is not conversion premium) / (what the premiums would pay at q = 1 and next year's phase),
 *        between 0 and 1; every conversion rate's premium above par is then scaled by q (with the phase-in, by q x phase). BU face value is always honoured,
 *        so when the BU spent alone exceed the cap it cannot be met (lvCap reports the share of years it is met).
 *  sv    true: the Source pays the interest that savings that keep up with prices credit (row option sv must be on), as new money and programme cost
 *  svc   protect savings only up to svc dollars a person (year-0 dollars; 0 = all): above it savings earn nothing, as without the account
 *  rc    true: a BU tenant outside PTH pays rent that rises no faster than the general price level: the housing price above the general level is taken off
 *        their costs (landlords bear it: not programme cost; counted once as unconditional dollars, rule 7), and landlords may not mark up their rent (HCAP)
 * Under o.lv a business is never paid less than the face value of the BU it accepted (modelling assumption: it would stop accepting them). No random draw.
 * LVS: per-run state. FW.bizRate, FW.octaveCapBase and PROJ.cap are set for the run and restored by lvEnd. Keys (LV_KEYS): participation at years 1, 7, 19
 * and its mean over years 1 to the last (lvJ*); the Source's net new money and its payout before backing as % of earned income over the run (lvU, lvP); the
 * share of the payout backed or retired (lvBk); project sales kept and protected-account interest as % of earned income (lvKp, lvSv); the mean conversion
 * premium factor (lvQ; 1 = full rates); the % of years the issuance cap was met (lvCap; 0 without a cap). */
var LV_KEYS = ['lvJ1', 'lvJ7', 'lvJ19', 'lvJm', 'lvU', 'lvP', 'lvBk', 'lvKp', 'lvSv', 'lvQ', 'lvCap'], LVS = null;

// index.html line 7452
function tbRun(p, seed, o, S){
  o = tbOpts(o);
  var tau0 = ((o.fin === 'tax' || o.fin === 'hybrid' || o.fin === 'source') && p.tb) ? tbRunCore(p, seed, o, S, 0, 1).tau0 : 0;
  return tbRunCore(p, seed, o, S, tau0, p.years);
}

// index.html line 7457
var TB_KEYS = ['endoAnn','endoMax','pov','bleiPov','nbleiPov','tgt','medWealthReal','fgt0','fgt1','fgt2','fgt0PY','fgt1PY','fgt2PY','cost','cCash','cEndow','cBU','cConv','cCut','cCap','cPth',
  'tax','need','treas','tauMean','tauLast','dE','E','E0','zero','gPartRes','gPartF0','gNonRes','gNonF0','gPthRes','gPthF0','gLowRes','gLowF0','gTopRes','gTopF0',
  'gPartW','gNonW','gPthW','gLowW','gTopW','pyPoor','everPoor','spellMean','chronic','emp','hrs','Er','giniD','giniX','pLev10','pLev20','realT','bleiR','bleiP',
  'pjNet','pjGift','pjBU','pjExp','pjHrs','pjDisp','pjWork','pjRc','pjSaved',  /* N1 (session 15) */
  'bzPay','esPrem','payPart','payNon','esPremW','esBUW','esShare','esRate','esCapB','esConv','esRet',  /* N1 (session 19, s38) */
  'gPartF2','gNonF2','gPartK','gNonK',
  'spPool','spOwn','spPtfS','spCut','spCutN','spFreed','spCash','spProfit','spProfW','spReinv','spRest','spCap','spSw','spD1','spD2','spNon','spCarry',
  'pdC5','pdC10','pdC19','pdMem19','pdMatch','srcIss','srcPay','srcTax','srcM','srcCover','jnP5','jnP10','jnP19','jnJoin','jnLeave','csFree','octMean','epPY','svInt','svIntR','agRet','agAge0','agAge','agDeaths','agBorn','bkA','bkPY','mlNT','hcM','rvX','rvC','taxAvg'].concat(TB_PROG_KEYS, TB_REP_KEYS, TB_BLEI_DEFS.reduce(function(r, d){ TB_BLEI_GRPS.forEach(function(g){ ['Py','Cr','20','Md'].forEach(function(m){ r.push('b' + d + g + m); }); }); return r; }, []));  /* session 21 (s41) */

// index.html line 7469
/* Paired study over seeds 1..N (optionally lo..hi). envP: the Compassionism scenario that defines the environment, the essentials
 * supply path (its matched Baseline, as in sessions 2-5) and the groups (participants: latent uCCO < its partRate; PTH members:
 * latent uPTH < its pthUptake, the same agents in every design). cfgs: [{p, o, cm, pw}]; pw switches PATHWAY_OFF entries for that
 * row only (d19). Returns means and per-seed arrays. */
function tbStudy(cfgs, N, envP, o0, lo){
  if (o0 && typeof o0.sc === 'number'){ var scS = SURPLUS_CONSUMPTION_SHARE; SURPLUS_CONSUMPTION_SHARE = o0.sc;  /* plan step 7: a study-level spending rule (the supply path and every row) */
    try { var oS = Object.assign({}, o0); delete oS.sc; return tbStudy(cfgs, N, envP, oS, lo); } finally { SURPLUS_CONSUMPTION_SHARE = scS; } }
  cfgs.forEach(function(c){ if (c.pr && c.pr !== 'qt' && typeof c.pr === 'object' && c.pr.h && c.ml && c.ml.nt) throw new Error('pr.h and ml.nt both read the normal-years slack: use one');
    if (c.gv) gvOpts(c.gv); var ff = c.fx && c.fx !== true ? c.fx.fin : null; if ((ff === 'debt' || ff === 'cap') && !c.gv) throw new Error("fx.fin '" + ff + "' needs gv (the government account, S72)"); });  /* S72: refusals before any switch is set */  /* S68 part 2: a hazard made a refusal, before any switch is set */
  lo = lo || 1; var M = N - lo + 1, grp = {part:envP.partRate, pth:envP.pthUptake};
  var out = cfgs.map(function(){ var r = {_s:{}}; TB_KEYS.forEach(function(k){ r[k] = 0; r._s[k] = new Float64Array(M); }); return r; });
  for (var sd = lo; sd <= N; sd++){
    var S = s3BaseS(envP, sd); HL_GOVREF = {};  /* session 2c (d194): each seed's no-programme health runs record government's share for its programme runs */
    cfgs.forEach(function(c, i){ var lw0 = lwSet(c.lw);  /* S14: the cost-of-living line for this row (first, so project pay follows it) */
      var cm0 = CONVERSION_MODEL, pw0 = Object.assign({}, PATHWAY_OFF); if (c.cm) CONVERSION_MODEL = c.cm;
      if (c.pw) Object.assign(PATHWAY_OFF, c.pw);  /* d19: e.g. {octaveWage:true}, the octave wage bonus off for this row only */
      var g0 = tbSetG(c.g);  /* session 7: per-row engine-question switches (i3), restored below */
      var pj0 = PROJ; if (c.pj) PROJ = Object.assign({}, PROJ_DEFAULTS, c.pj === true ? {} : c.pj);  /* N1 (session 15): project hiring for this row only */
      var es0 = ESP; if (c.es) ESP = Object.assign({}, ESP_DEFAULTS, c.es === true ? {} : c.es);  /* N1 (session 19): ESP payroll for this row only */
      var sp0 = SURP; if (c.sp) SURP = Object.assign({}, SURP_DEFAULTS, c.sp === true ? {} : c.sp);  /* plan step 1: the ESP surplus split for this row only */
      var pd0 = PROD; if (c.pd) PROD = Object.assign({}, PROD_DEFAULTS, c.pd === true ? {} : c.pd);  /* plan step 2: the production side for this row only */
      var sc0 = SURPLUS_CONSUMPTION_SHARE; if (typeof c.sc === 'number') SURPLUS_CONSUMPTION_SHARE = c.sc;  /* plan step 7: the spending rule for this row only */
      var oc0 = OCT; if (c.oc) OCT = Object.assign({}, OCT_DEFAULTS, c.oc === true ? {} : c.oc);  /* plan step 6 */
      var cs0 = COST; if (c.cs) COST = Object.assign({}, COST_DEFAULTS, c.cs === true ? {} : c.cs);  /* plan step 5 */
      var jn0 = JOIN; if (c.jn) JOIN = Object.assign({}, JOIN_DEFAULTS, c.jn === true ? {} : c.jn);  /* plan step 4: joining and leaving for this row only */
      var ml0 = MULT; if (c.ml) MULT = Object.assign({}, MULT_DEFAULTS, c.ml === true ? {} : c.ml);  /* plan step 16: the spending layer for this row only */
      var gc0 = GATE_CURRENT; if (typeof c.gc === 'boolean') GATE_CURRENT = c.gc;  /* audit V5-02: the framework BLEI gate reads this year's BU, for this row only */
      var sv0 = SAVE; if (c.sv) SAVE = Object.assign({}, SAVE_DEFAULTS, c.sv === true ? {} : c.sv);  /* v5.2 step 3: savings that keep up with prices, for this row only (no programme rows too) */
      var ag0 = AGE; if (c.ag) AGE = Object.assign({}, AGE_DEFAULTS, c.ag === true ? {} : c.ag);  /* v5.2 step 4: ageing, for this row only (no programme rows too) */
      var hc0 = HCAP; if (c.hc) HCAP = Object.assign({all:false}, c.hc);  /* v5.2 step 7: housing capture for this row ({c, all}) */
      var rv0 = REVIEW; if (c.rv) REVIEW = Object.assign({q:CFG.REVIEW_AUDIT}, c.rv);  /* v5.2 step 7: review errors and collusion for this row */
      var bs0 = BU_SCOPE; if (c.bs) BU_SCOPE = c.bs;  /* v5.3 B3f: what BU can buy, for this row ('core' | 'hub') */
      var em0 = EDC_MEASURE; if (c.em) EDC_MEASURE = true;  /* v5.3 B6: the measured EDC for this row (reporting only) */
      var au0 = AUD; if (c.au) AUD = c.au === true ? {gate:true, sg:true, fbs:true} : Object.assign({}, c.au);  /* S13: the audit's corrections for this row (no programme rows too) */
      var fx0 = FX; if (c.fx) FX = c.fx === true ? {pthb:true, hb:true, ab:true, sp:true} : Object.assign({}, c.fx);  /* S47: the second implementation's fixes for this row (no programme rows too) */
      var dr0 = DEBT_READ; if (c.dr) DEBT_READ = Object.assign({lim:0}, c.dr === true ? {} : c.dr);  /* S35: the debt reading for this row (no programme rows too) */
      var wt0 = WEALTH_TAIL; if (c.wt) WEALTH_TAIL = wtOpts(c.wt);  /* S59 part 2: the weighted top tail for this row (no programme rows too) */
      var rt0 = RETURNS; if (c.rt) RETURNS = rtOpts(c.rt);  /* S59: wealth held by asset class for this row (no programme rows too) */
      var lf0 = LF_SCOPE; if (c.lf) LF_SCOPE = Object.assign({}, LF_DEFAULTS, c.lf === true ? {} : c.lf);  /* S61: adults outside the labour force for this row (no programme rows too) */
      var po0 = PTF_OPS; if (c.po) PTF_OPS = poOpts(c.po);  /* S62: PTF realism for this row (needs pa open) */
      var gv0 = GOV; if (c.gv) GOV = gvOpts(c.gv);  /* S72: the government account for this row (no programme rows too) */
      var bg0 = BARGAIN; if (c.bg) BARGAIN = bgOpts(c.bg);  /* S60: a worker's outside option and an employer markdown for this row (no programme rows too) */
      var pr0 = [PRICE_RULE, PR_OPTS]; if (c.pr && c.pr !== 'qt'){ PRICE_RULE = 'capacity'; PR_OPTS = c.pr === true || c.pr === 'capacity' ? {} : c.pr; }  /* S58: the capacity price rule for this row (no programme rows too) */
      var pa0 = [PTF_ACCESS, PA]; if (c.pa && c.pa !== 'members'){ if (c.pa !== 'open' && typeof c.pa !== 'object') throw new Error('pa: members, open or {fix}'); PTF_ACCESS = 'open'; PA = Object.assign({}, PA_DEFAULTS, typeof c.pa === 'object' ? c.pa : {}); }  /* S55: open PTF access for this row */
      var cl0 = COMM; if (c.cl) COMM = Object.assign({}, COMM_DEFAULTS, c.cl === true ? {} : c.cl);  /* S37: the community layer for this row */
      var c220 = C22; if (c.c22) C22 = Object.assign({}, C22_DEFAULTS, c.c22 === true ? {} : c.c22);  /* S6: coverage and adequacy for this row */
      var sg0 = SPEND_GRADE; if (c.sg) SPEND_GRADE = {eps:typeof c.sg === 'number' ? c.sg : CFG.CE_SPEND_ELAST};  /* v5.3 B7: income-graded spending for this row (no programme rows too) */
      var fb0 = FBS50; if (c.fb) FBS50 = Object.assign({dist:'lambda', scale:1}, c.fb === true ? {} : c.fb);  /* v5.3 B7: FBS50 for this row */
      var hh0 = HOUSEHOLDS; if (c.hh) HOUSEHOLDS = Object.assign({}, HH_DEFAULTS, c.hh === true ? {} : c.hh);  /* v5.3 B3: households for this row ({} = the defaults) */
      var v540 = tbSetV54(c.v54);  /* v5.4: the round's switches for this row */
      var hl0 = HEALTH; if (c.hl) HEALTH = Object.assign({}, HEALTH_DEFAULTS, c.hl === true ? {} : c.hl);  /* session 2a: the health setting for this row (no programme rows too) */
      var sn0 = SNET; if (c.sn) SNET = Object.assign({}, SNET_DEFAULTS, c.sn === true ? {} : c.sn);  /* session 2b: today's safety net for this row */
      var pv0 = PREV; if (c.pv) PREV = Object.assign({}, PREV_DEFAULTS, c.pv === true ? {} : c.pv);  /* session 2c: the prevention link for this row */
      var lt0 = LATENT; if (c.lt) LATENT = {wealth:c.lt.w ? CFG.SCF_WAGE_WEALTH_RHO : 0, risk:c.lt.r ? CFG.FO_RISK_WAGE_RHO : 0, wsd:c.lt.s ? (CFG.CPS_EARN[c.lt.s] ? CFG.CPS_EARN[c.lt.s].sigma : CFG.SCF_WAGE_SIGMA) : 0, wmed:c.lt.m ? (CFG.CPS_EARN[c.lt.m] ? CFG.CPS_EARN[c.lt.m].median : CFG.SCF_WAGE_MEDIAN) : 0};  /* v5.2 step 5: {w, r, s, m} flags; S34: s, m 'all' or 'ft' read the CPS's earnings (CFG.CPS_EARN) */
      try { var r = tbRun(c.p, sd, Object.assign({grp:grp}, o0 || {}, c.o || {}), FX && FX.sp ? tbBaseS(envP, sd, Object.assign({}, o0 || {}, c.o || {})) : HOUSEHOLDS || SPEND_GRADE || LW ? s3BaseS(envP, sd) : S).res;  /* S47 fx.sp: the supply path from the reported no-programme run */  /* v5.3 B3: a household row's supply reference is the no-programme economy of households (B7: likewise with income-graded spending) */
        TB_KEYS.forEach(function(k){ out[i][k] += r[k]/M; out[i]._s[k][sd - lo] = r[k]; });
        if (r.fbsAbove !== undefined) FBS_KEYS.forEach(function(k){ if (!out[i]._s[k]){ out[i][k] = 0; out[i]._s[k] = new Float64Array(M); } out[i][k] += r[k]/M; out[i]._s[k][sd - lo] = r[k]; });  /* v5.3 B7 */
        if (r.sxCBA !== undefined) SX_KEYS.forEach(function(k){ if (!out[i]._s[k]){ out[i][k] = 0; out[i]._s[k] = new Float64Array(M); } out[i][k] += r[k]/M; out[i]._s[k][sd - lo] = r[k]; });  /* S52 */
        if (r.secU25A !== undefined) SEC_KEYS.concat(S19_KEYS).forEach(function(k){ if (!out[i]._s[k]){ out[i][k] = 0; out[i]._s[k] = new Float64Array(M); } out[i][k] += r[k]/M; out[i]._s[k][sd - lo] = r[k]; });  /* S53 */
        if (r.prOn !== undefined) PR_KEYS.forEach(function(k){ if (!out[i]._s[k]){ out[i][k] = 0; out[i]._s[k] = new Float64Array(M); } out[i][k] += r[k]/M; out[i]._s[k][sd - lo] = r[k]; });  /* S58 */
        if (r.mfU !== undefined) MF_KEYS.forEach(function(k){ if (!out[i]._s[k]){ out[i][k] = 0; out[i]._s[k] = new Float64Array(M); } out[i][k] += r[k]/M; out[i]._s[k][sd - lo] = r[k]; });  /* S58 */
        if (r.rtE !== undefined) RT_KEYS.forEach(function(k){ if (!out[i]._s[k]){ out[i][k] = 0; out[i]._s[k] = new Float64Array(M); } out[i][k] += r[k]/M; out[i]._s[k][sd - lo] = r[k]; });  /* S59 */
        if (r.crRel !== undefined) CR_KEYS.forEach(function(k){ if (!out[i]._s[k]){ out[i][k] = 0; out[i]._s[k] = new Float64Array(M); } out[i][k] += r[k]/M; out[i]._s[k][sd - lo] = r[k]; });  /* S71 */
        if (r.wtW !== undefined) WT_KEYS.forEach(function(k){ if (!out[i]._s[k]){ out[i][k] = 0; out[i]._s[k] = new Float64Array(M); } out[i][k] += r[k]/M; out[i]._s[k][sd - lo] = r[k]; });  /* S59 part 2 */
        if (r.dmWt1E !== undefined) DM_KEYS.forEach(function(k){ if (!out[i]._s[k]){ out[i][k] = 0; out[i]._s[k] = new Float64Array(M); } out[i][k] += r[k]/M; out[i]._s[k][sd - lo] = r[k]; });  /* S57 */
        if (r.lvU !== undefined) LV_KEYS.forEach(function(k){ if (!out[i]._s[k]){ out[i][k] = 0; out[i]._s[k] = new Float64Array(M); } out[i][k] += r[k]/M; out[i]._s[k][sd - lo] = r[k]; });  /* S54 */
        if (r.bkmA !== undefined) BKM_KEYS.forEach(function(k){ if (!out[i]._s[k]){ out[i][k] = 0; out[i]._s[k] = new Float64Array(M); } out[i][k] += r[k]/M; out[i]._s[k][sd - lo] = r[k]; });  /* S51 */
        if (r.dsHit !== undefined) DIS_KEYS.forEach(function(k){ if (!out[i]._s[k]){ out[i][k] = 0; out[i]._s[k] = new Float64Array(M); } out[i][k] += r[k]/M; out[i]._s[k][sd - lo] = r[k]; });  /* v5.4 item 5 */
        if (r.pfCut !== undefined) PTFS_KEYS.forEach(function(k){ if (!out[i]._s[k]){ out[i][k] = 0; out[i]._s[k] = new Float64Array(M); } out[i][k] += r[k]/M; out[i]._s[k][sd - lo] = r[k]; });  /* v5.4 item 4 */
        if (r.c22PY !== undefined) C22_KEYS.forEach(function(k){ if (!out[i]._s[k]){ out[i][k] = 0; out[i]._s[k] = new Float64Array(M); } out[i][k] += r[k]/M; out[i]._s[k][sd - lo] = r[k]; });  /* S6 */
        if (r.clN !== undefined) CL_KEYS.forEach(function(k){ if (!out[i]._s[k]){ out[i][k] = 0; out[i]._s[k] = new Float64Array(M); } out[i][k] += r[k]/M; out[i]._s[k][sd - lo] = r[k]; });  /* S37 */
        if (r.poSub !== undefined) PO_KEYS.forEach(function(k){ if (!out[i]._s[k]){ out[i][k] = 0; out[i]._s[k] = new Float64Array(M); } out[i][k] += r[k]/M; out[i]._s[k][sd - lo] = r[k]; });  /* S62 */
        if (r.gvPay !== undefined) GV_KEYS.forEach(function(k){ if (!out[i]._s[k]){ out[i][k] = 0; out[i]._s[k] = new Float64Array(M); } out[i][k] += r[k]/M; out[i]._s[k][sd - lo] = r[k]; });  /* S72 */
        if (r.finPay !== undefined) FIN_KEYS.forEach(function(k){ if (!out[i]._s[k]){ out[i][k] = 0; out[i]._s[k] = new Float64Array(M); } out[i][k] += r[k]/M; out[i]._s[k][sd - lo] = r[k]; });  /* S68 */
        if (r.wyAvg !== undefined) WY_KEYS.forEach(function(k){ if (!out[i]._s[k]){ out[i][k] = 0; out[i]._s[k] = new Float64Array(M); } out[i][k] += r[k]/M; out[i]._s[k][sd - lo] = r[k]; });  /* S68 */
        if (r.paSh !== undefined) PA_KEYS.forEach(function(k){ if (!out[i]._s[k]){ out[i][k] = 0; out[i]._s[k] = new Float64Array(M); } out[i][k] += r[k]/M; out[i]._s[k][sd - lo] = r[k]; });  /* S55 */
        if (r.pbV !== undefined) PTHB_KEYS.forEach(function(k){ if (!out[i]._s[k]){ out[i][k] = 0; out[i]._s[k] = new Float64Array(M); } out[i][k] += r[k]/M; out[i]._s[k][sd - lo] = r[k]; });  /* v5.4 item 3 */
        if (r.snAbN !== undefined) SN_AB_KEYS.forEach(function(k){ if (!out[i]._s[k]){ out[i][k] = 0; out[i]._s[k] = new Float64Array(M); } out[i][k] += r[k]/M; out[i]._s[k][sd - lo] = r[k]; });  /* session 7 */
        if (r.snSnap !== undefined) SN_KEYS.forEach(function(k){ if (!out[i]._s[k]){ out[i][k] = 0; out[i]._s[k] = new Float64Array(M); } out[i][k] += r[k]/M; out[i]._s[k][sd - lo] = r[k]; });  /* session 2b */
        if (r.hlEsi !== undefined) HL_KEYS.forEach(function(k){ if (!out[i]._s[k]){ out[i][k] = 0; out[i]._s[k] = new Float64Array(M); } out[i][k] += r[k]/M; out[i]._s[k][sd - lo] = r[k]; });  /* session 2a */
        if (r.emUrate !== undefined) EMPL_KEYS.forEach(function(k){ if (!out[i]._s[k]){ out[i][k] = 0; out[i]._s[k] = new Float64Array(M); } out[i][k] += r[k]/M; out[i]._s[k][sd - lo] = r[k]; });  /* v5.4 item 2 */
        if (r.rkEv !== undefined) RISK_KEYS.forEach(function(k){ if (!out[i]._s[k]){ out[i][k] = 0; out[i]._s[k] = new Float64Array(M); } out[i][k] += r[k]/M; out[i]._s[k][sd - lo] = r[k]; });  /* v5.4 item 1 */
        if (r.edcM !== undefined) EDC_KEYS.forEach(function(k){ if (!out[i]._s[k]){ out[i][k] = 0; out[i]._s[k] = new Float64Array(M); } out[i][k] += r[k]/M; out[i]._s[k][sd - lo] = r[k]; });  /* v5.3 B6 */
        if (r.drHit !== undefined) ['drHit', 'drCut'].forEach(function(k){ if (!out[i]._s[k]){ out[i][k] = 0; out[i]._s[k] = new Float64Array(M); } out[i][k] += r[k]/M; out[i]._s[k][sd - lo] = r[k]; });  /* S61: the debt reading's tally (rows with dr only) */
        if (r.bgN !== undefined) BG_KEYS.forEach(function(k){ if (!out[i]._s[k]){ out[i][k] = 0; out[i]._s[k] = new Float64Array(M); } out[i][k] += r[k]/M; out[i]._s[k][sd - lo] = r[k]; });  /* S60: bargaining (rows with bg only) */
        if (r.lfShare !== undefined) LF_KEYS.forEach(function(k){ if (!out[i]._s[k]){ out[i][k] = 0; out[i]._s[k] = new Float64Array(M); } out[i][k] += r[k]/M; out[i]._s[k][sd - lo] = r[k]; });  /* S61: adults outside the labour force (rows with lf only) */  /* S73 */
        if (r.lfOut !== undefined) LF_FLOW_KEYS.forEach(function(k){ if (!out[i]._s[k]){ out[i][k] = 0; out[i]._s[k] = new Float64Array(M); } out[i][k] += r[k]/M; out[i]._s[k][sd - lo] = r[k]; });  /* S61: adults outside the labour force (rows with lf only) */
        if (r.hhPer !== undefined) HH_KEYS.concat(HH_REP_KEYS, r.hhBirthR !== undefined ? HH_LIFE_KEYS : []).forEach(function(k){ if (!out[i]._s[k]){ out[i][k] = 0; out[i]._s[k] = new Float64Array(M); } out[i][k] += r[k]/M; out[i]._s[k][sd - lo] = r[k]; }); }  /* v5.3 B3: the household reading's measures, where the row has households (B4: and children's lives, with ageing) */
      finally { GOV = gv0; GVS = null; PRICE_RULE = pr0[0]; PR_OPTS = pr0[1]; tbResetV54(v540); HEALTH = hl0; HLS = null; SNET = sn0; SNS = null; PREV = pv0; CONVERSION_MODEL = cm0; Object.assign(PATHWAY_OFF, pw0); tbSetG(g0); PROJ = pj0; ESP = es0; SURP = sp0; PROD = pd0; JOIN = jn0; COST = cs0; OCT = oc0; SURPLUS_CONSUMPTION_SHARE = sc0; MULT = ml0; GATE_CURRENT = gc0; SAVE = sv0; AGE = ag0; AGS = null; LATENT = lt0; HCAP = hc0; HCS = null; REVIEW = rv0; REVS = null; HOUSEHOLDS = hh0; HHS = null; BU_SCOPE = bs0; EDC_MEASURE = em0; EDCS = null; SPEND_GRADE = sg0; DEBT_READ = dr0; RETURNS = rt0; RTR = null; RTO = null; WEALTH_TAIL = wt0; WTS = null; LF_SCOPE = lf0; LFS = null; BARGAIN = bg0; BGS = null; PTF_OPS = po0; POS = null; DR_PL = 1; AUD = au0; FX = fx0; COMM = cl0; CMS = null; PTF_ACCESS = pa0[0]; PA = pa0[1]; PAS = null; C22 = c220; C22S = null; FBS50 = fb0; FBSS = null; lwReset(lw0); } });
  }
  HL_GOVREF = null;  /* session 2c */
  return out;
}

// index.html line 7559
/* Session 7: set the i3 engine-question switches for one row; returns the previous values. */
function tbSetG(g){ var old = {FBS_BU_ONCE:FBS_BU_ONCE, PTH_APPR_CONSERVE:PTH_APPR_CONSERVE, N7_BLEI:N7_BLEI, SURP_CUT_MARKUP:SURP_CUT_MARKUP};
  if (g){ if ('FBS_BU_ONCE' in g) FBS_BU_ONCE = !!g.FBS_BU_ONCE; if ('PTH_APPR_CONSERVE' in g) PTH_APPR_CONSERVE = !!g.PTH_APPR_CONSERVE; if ('N7_BLEI' in g) N7_BLEI = !!g.N7_BLEI; if ('SURP_CUT_MARKUP' in g) SURP_CUT_MARKUP = !!g.SURP_CUT_MARKUP; }  /* v5.3 B2: + SURP_CUT_MARKUP */
  return old; }

// index.html line 7567
/* Presets. The environment (shocks, automation, exogenous inflation, years, population) comes from the Compassionism scenario P.
 * Every comparator gets the same COLA rule as BU (the Inflation Surge Protocol, 5%; D6). */
var TB_XC_AMT = 9.90*365;          /* X-Cents adult daily exchange (d17): a dime for $10 a day, net $9.90: derived, $3,613.50 a year */

// index.html line 7568
var TB_GROC = {cut:0.15, cap:140}; /* d27. cut: nyc.gov (Jul 27, 2026): 30% off a core basket, projected to cut the average grocery bill 15%; a promise,
                                    * not an observed result. cap: the $70M capital budget for five stores over 20 years, per covered adult-year, at an
                                    * assumed 5,000 regular adult shoppers per store: a logged placeholder (the shopper count is unsourced), swept. */

// index.html line 7571
var TB_ENDOW_THRESH = 25000;       /* d27: year-0 wealth below the model's wealth-poverty line (CFG.POVERTY_LINE) */

// index.html line 7572
var TB_NIT_T = 0.5;                /* d27: central phase-out rate; 0.3 and 0.7 swept */

// index.html line 7590
/* Session 11 (Duke's notes on the v4.22 page; dashboard d44-d47).
 * TB_GROC_PILOT  the NYC plan's five stores serve a small share of the city's shoppers: the Mayor puts the existing count at
 *                "more than the thousand existing grocery stores" (nyc.gov transcript, Jul 27, 2026), so five equal-sized stores
 *                would serve 5/1,005 = 0.5%; the first sites are 9,000 sq ft, smaller than a typical supermarket, so this is if
 *                anything high. Derived. The full-cover row (cover 1) is the network at a scale that serves every adult.
 * TB_XC_P1       X-Cents "Power of 1" (the CurrentSea X-Change paper, s3.2): at designated times every coin is worth $1 for
 *                necessities, so food bought with pennies costs 1 cent per dollar (a 99% cut). One designated day a week
 *                (Duke, Sep 28): the share of food bought that day, f, is 1 if adults do their weekly food shopping on it (central)
 *                and 1/7 if they do not shift any (swept). Food only: rent and utilities need the paper's phase-2 service-provider
 *                integration, which the model does not assume centrally; the X-Cents site names food and housing, so a row with
 *                housing (rent and utilities, HUD FMR incl. tenant-paid utilities) paid the same way is shown beside it (d48).
 * TB_UBI_PROP, TB_NIT_PROP, TB_ENDOW_PROP  each comparator at its proposers' size (d45): $1,000 a month (the amount paid in
 *                Vivalt et al.'s study); the guarantee at the 2026 HHS poverty guideline for one person ($15,960, aspe.hhs.gov),
 *                50% phase-out, inside the range the 1968-82 NIT experiments tested; the stakeholder grant's $80,000 of 1999
 *                (Ackerman and Alstott) in 2025 dollars, x 321.943/166.6 (BLS CPI-U annual averages) = $154,594.
 * TB_TOPUP_S     d39/N3: the share of the flat BU moved to the needs-based top-up at equal cost in `topup` (0.1, 0.25 and 0.5 swept).
 *                TB_TOPUP_S_A5 = 0.1 in a5 and on the page (d44): the only share tested that deepens the FGT2 cut in all four cells. */
var TB_GROC_PILOT = 0.005, TB_XC_P1 = 0.99, TB_UBI_PROP = 12000, TB_NIT_PROP = 15960, TB_ENDOW_PROP = 154594, TB_TOPUP_S = 0.25, TB_TOPUP_S_A5 = 0.1;

// index.html line 7591
function tbComp(P, spec){ return Object.assign({}, baselineFor(P, true), {nAgents:P.nAgents, years:P.years, cola:true, colaThresh:CFG.COLA_HUB_THRESH, tb:spec}); }

// index.html line 7592
function tbCCO(P, bu){ var q = nextRoundPreset(Object.assign({}, P, bu !== undefined ? {bu:bu} : {})); q.tb = {}; return q; }

// index.html line 7593
function tbPresets(P){
  return {
    baseline: function(){ return tbComp(P, {}); },
    ubi: function(x){ return tbComp(P, {ubi:x}); },
    nit: function(G, t){ return tbComp(P, {nit:{G:G, t:t === undefined ? TB_NIT_T : t}}); },
    groc: function(cover, cap){ return tbComp(P, {groc:{cut:TB_GROC.cut, cover:cover, cap:cap === undefined ? TB_GROC.cap : cap}}); },
    endow: function(W){ return tbComp(P, {endow:{amt:W, thresh:TB_ENDOW_THRESH}}); },
    xc: function(delta){ return tbComp(P, {xc:{amt:TB_XC_AMT, delta:delta || 0}}); },
    cco: function(bu){ return tbCCO(P, bu); },
    ccoAlone: function(bu){ return tbCCO(ccoOnlyFor(P), bu); },
    /* session 11 */
    grocPilot: function(){ return tbComp(P, {groc:{cut:TB_GROC.cut, cover:TB_GROC_PILOT, cap:TB_GROC.cap}}); },
    xcFull: function(f, h){ return tbComp(P, {xc:{amt:TB_XC_AMT, delta:0}, groc:{cut:TB_XC_P1*(f === undefined ? 1 : f), cover:1, cap:0, housing:!!h}}); },
    ccoTop: function(G, s, t){ var q = tbCCO(P, P.bu*(1 - (s === undefined ? TB_TOPUP_S : s))); q.tb = {nit:{G:G, t:t === undefined ? TB_NIT_T : t, part:true}}; return q; }
  };
}

// index.html line 7617
/* Session 23 (s34; d86-d90; N1-design-damping-theta.md): the N1 Compassionism rows, built one way for the testbed's projcore, esp
 * and match sections (unit s34-4: match's tax-financed rows equal projcore's and esp's). The main row: project hiring with Duke's
 * d58-d66 picks, the octave wage raise off (d46), the launch gift paid as you go (d66), the PTF/PTH inflation damping off (d86,
 * under d53), the price module's capacity term at 0 (d87); in the Hub-spec (framework) model, ESP payroll at the defaults (d76).
 * v: {gift:'run'} the gift financed over the run (d67); {raise:true} the octave wage raise kept on; {damp:true} the damping kept on;
 * {cap:x} the capacity term (PM ptfCap, not the engine presets' membership cap) at x; {esp:false} the Hub-spec model's business
 * rule before ESP payroll; {es:{...}} an ESP setting (d71-d75); {fin, a} the financing. The damping is set on the row itself, so
 * the comparators and every other testbed section are untouched. */
function n1Row(PR, cm, v){
  v = v || {}; var c = {p:PR.cco(), cm:cm, pj:v.gift === 'run' ? {giftFin:'run'} : {}, o:{noDamp:!v.damp}};
  if (!v.raise) c.pw = {octaveWage:true};
  if (cm === 'framework' && v.esp !== false) c.es = v.es || {};
  if (cm === 'framework' && v.sp) c.sp = v.sp;  /* plan step 1: the ESP surplus split ({} = the defaults) */
  if (cm === 'framework' && v.pd) c.pd = v.pd;  /* plan step 2: the production side ({} = the defaults) */
  if (typeof v.sc === 'number') c.sc = v.sc;  /* plan step 7: the spending rule (share of cash surplus consumed) */
  if (cm === 'framework' && v.oc) c.oc = v.oc;  /* plan step 6: slower octave advancement */
  if (cm === 'framework' && v.cs) c.cs = v.cs;  /* plan step 5: PTF running costs ({} = the defaults) */
  if (cm === 'framework' && v.jn) c.jn = v.jn;  /* plan step 4: joining and leaving ({} = the defaults) */
  if (v.ml) c.ml = v.ml;  /* plan step 16: the spending layer ({} = the defaults) */
  if (typeof v.gc === 'boolean') c.gc = v.gc;  /* audit V5-02: the BLEI gate reads this year's BU (framework only) */
  if (v.sv) c.sv = v.sv;  /* v5.2 step 3: savings that keep up with prices ({} = the defaults) */
  if (v.ag) c.ag = v.ag;  /* v5.2 step 4: ageing ({} = the defaults; ret and ss as in AGE_DEFAULTS) */
  if (v.lt) c.lt = v.lt;  /* v5.2 step 5: the readings that close known gaps with US data ({w, r, s}) */
  if (v.ci) c.p.colaThresh = -1;  /* v5.2 step 3 (Duke's answer d147): the BU indexed to prices every year, not only in a year prices rise faster than 5% (the Hub's rule, the main reading) */
  if (v.cap) c.o.ptfCap = v.cap;
  if (v.fin){ c.o.fin = v.fin; c.o.a = v.a || 0; }
  if (v.aK) c.o.aK = v.aK;  /* v5.2 step 6 (decision B): the middle backing reading */
  if (v.hc) c.hc = v.hc;  /* v5.2 step 7: housing capture ({c: dollars of higher rent per BU dollar spent on rent outside PTH, all: the rise reaches every renter outside PTH}) */
  if (v.rv) c.rv = v.rv;  /* v5.2 step 7: review errors and collusion ({u, q}) */
  if (v.hh) c.hh = v.hh;  /* v5.3 B3: households ({pool, childBU}) */
  if (v.bs) c.bs = v.bs;  /* v5.3 B3f: what BU can buy ('hub': the Hub's list) */
  if (v.sg) c.sg = v.sg;  /* v5.3 B7: income-graded spending */
  if (v.em) c.em = v.em;  /* v5.3 B6: the measured EDC (reporting only) */
  if (v.fb) c.fb = v.fb;  /* v5.3 B7: FBS50 */
  if (v.g) c.g = Object.assign({}, c.g || {}, v.g);  /* v5.3 B2: engine-question switches for the row (the accounting corrections) */
  if (v.drop) v.drop.forEach(function(k){ delete c[k]; });  /* v5.3 B9: a part of the design removed (a module's row option: pj, es, sp, pd, jn, ml, cs) */
  if (v.pset) Object.assign(c.p, v.pset);  /* v5.3 B9: a part of the preset switched off (ptf, pth, szh, cip) */
  if (v.pwOff) c.pw = Object.assign({}, c.pw || {}, v.pwOff);  /* v5.3 B9: a pathway closed (relief, conversion, octave) */
  if (v.v54) c.v54 = v.v54;  /* v5.4 step 9: the round's switches (REL_V54) */
  return c;
}

// index.html line 7652
/* Audit F3 (v5.1): the q-quantile (0 <= q <= 1) of an array of numbers by linear interpolation between order statistics (the default of numpy.percentile). The input is
 * not changed. Reporting only: no engine code calls it. */
function quantileOf(arr, q){ var v = Array.prototype.slice.call(arr).sort(function(x, y){ return x - y; }), h = (v.length - 1)*q, lo = Math.floor(h), hi = Math.ceil(h); return v[lo] + (v[hi] - v[lo])*(h - lo); }


// index.html line 7682
function medianOf(arr){var s=arr.slice().sort(function(a,b){return a-b;}),n=s.length;return n?(n%2===0?(s[n/2-1]+s[n/2])/2:s[Math.floor(n/2)]):0;}

// index.html line 7683
function incomeBasketMetrics(agents){
  if(!agents||!agents.length||agents[0].yrBasketUSD===undefined)return null;
  var inc=agents.map(function(a){var w=+a.yrWageUSD,c=+a.yrConvUSD;return (isNaN(w)?0:w)+(isNaN(c)?0:c)+(a.yrUbiUSD||0);});  /* v5.3 (B1): + the UBI comparators' cash (harness.js's studies; 0 on the page, which never sets it) */
  var ext=agents.map(function(a,i){return inc[i]+Math.max(0,(+a.yrBasketUSD||0)-(+a.yrCostUSD||0));});
  var n=inc.length,med=medianOf(inc),medX=medianOf(ext),rel=0,relX=0,net=0,gross=0;
  agents.forEach(function(a,i){if(inc[i]<0.6*med)rel++;if(ext[i]<0.6*medX)relX++;if(inc[i]<a.yrCostUSD)net++;if(inc[i]<a.yrBasketUSD)gross++;});
  return{medianIncome:med,incPov:rel/n*100,incPovExt:relX/n*100,basketPov:net/n*100,basketPovGross:gross/n*100};
}

// index.html line 7724
function housingDistressOf(agents){
  if(!agents||!agents.length||agents[0].yrWealthStartUSD===undefined)return null;
  var n=0;
  agents.forEach(function(a){var inc=(+a.yrWageUSD||0)+(+a.yrConvUSD||0)+(+a.yrSSUSD||0),w=+a.yrWealthStartUSD||0;if(inc+Math.max(0,w)<(+a.yrCostUSD||0))n++;});  /* v5.2 step 4: + the Social Security benefit (0 without ageing) */
  return n/agents.length;
}

// index.html line 7730
function housingDistressYear0(agents){
  if(!agents||!agents.length)return null;
  var n=0;
  agents.forEach(function(a){var inc=Math.max(isNaN(a.wage)?0:a.wage,0)*12*CFG.WAGE_TO_USD,w=isNaN(a.wealth)?0:a.wealth;if(inc+Math.max(0,w)<CFG.LIVING_WAGE_ANNUAL)n++;});
  return n/agents.length;
}

// index.html line 7736
function wellnessZoneReach(p){return(p&&p.pth&&p.szh)?CFG.EP_WZ_EFFECT*Math.max(0,Math.min(1,+p.szhCoh||0)):0;}

// index.html line 7738
function extremePovertyOf(d,d0,p){
  if(d===null||d===undefined||isNaN(d)||!(d0>0))return null;
  var R=CFG.EP_Y0_RATE,s=CFG.EP_SMI_SHARE,v=CFG.EP_VOL_SHARE,wz=p==='year0'?0:wellnessZoneReach(p);
  var econ=R*(1-s-v)*d/d0,smi=R*s*(1-wz),vol=R*v;
  return{total:(econ+smi+vol)*100,econ:econ*100,smi:smi*100,vol:vol*100,distress:d*100,wz:wz};
}


// index.html line 9240
function lognormal(mu,sigma){var u=Math.max(1e-14,1-RNG()),v=RNG();return Math.exp(mu+sigma*Math.sqrt(-2*Math.log(u))*Math.cos(2*Math.PI*v));}

// index.html line 9241
function beta(a,b){var x=gamma(a);return x/(x+gamma(b));}

// index.html line 9255
function gamma(a){if(a===1)return -Math.log(Math.max(1e-14,RNG()));if(a<1)return gamma(1+a)*Math.pow(Math.max(1e-14,RNG()),1/a);for(var i=0;i<5000;i++){var u=RNG(),v=RNG(),y=Math.tan(Math.PI*u),x=Math.sqrt(2*a-1)*y+a-1;if(x>0&&v<=(1+y*y)*Math.exp((a-1)*Math.log(x/(a-1))-Math.sqrt(2*a-1)*y))return x;}return a;}


// harness.js line 46
/* v5.2 round (Oct 3, 2026): the study-level options the v5.2 release panel adds to every row, the no-programme row included (step 2: the Year 7 and poverty-line reporting
 * and the n/(n - 1) Gini correction; reporting only). The testbed's release section uses them unless run with --v51. */
var REL_V52_STUDY = {rep52:true, giniNN1:true};

// harness.js line 3714
/* S47 (Nov 6, 2026; research-update prereg/run-manifest.md section 1): the frozen model, as one place for the testbed, explore_export.js and the batch's job
 * scripts to build it from. frozenRow(c): a study row on the frozen engine, the outside audit's corrections (au: gate, sg, fbs) and the second implementation's
 * four fixes (fx: pthb, hb, ab, sp) and the frozen spending share (SPEND_FROZEN), on every row a study runs, its no-programme rows included. c22Design(c): a programme row (relMainCfgs' second) turned into the
 * headline C2.2 design (study programme Amendment 4): automatic distribution, the BU at the cost of food, housing with utilities and medical care for one adult
 * (c22NeedsBU()) and indexed to those prices; the child allowance stays a quarter of the adult BU (the households setting). Both return the row they change. */
/* The frozen model's spending share (S47, Nov 6; research-update prereg/run-manifest.md Amendment 3; dev/DECISIONS.md S47; dev/reports/s47-spend.md): the share
 * of cash surplus consumed re-derived by SPEND_SOURCED's own method on the frozen no-programme run (dev/tools/s47_spend.js, dev/runs/s47-spend/rederive.json):
 * the share at which the run's saving over disposable income, counted on the row's own years, equals the 2025 US personal saving rate, 5.4% (BEA NIPA Table
 * 2.1, line 35), Reference, seeds 1-100. 0.877; the method's formula over wages alone gives 0.862. SPEND_SOURCED (0.593) stays the published engine's. frozenRow
 * sets it on the row (c.sc); under fx.sp the row's supply path is its own no-programme run at the same share, so no study-level share is needed. */
var SPEND_FROZEN = 0.877;

// harness.js line 3715
var FROZEN = {au:true, fx:true, sc:SPEND_FROZEN};

// harness.js line 3716
function frozenRow(c){ c.au = FROZEN.au; c.fx = FROZEN.fx; c.sc = FROZEN.sc; return c; }

// harness.js line 3717
function c22Design(c){ c.c22 = {auto:true, idx:'needs'}; c.p = Object.assign({}, c.p, {bu:c22NeedsBU()}); return c; }

// harness.js line 3729
/* S68 part 2 (Nov 14, 2026): the candidate main row of round 2, Claude's recommendation for S63's main-row decision (research-update PLAN S63, S69),
 * as each round-2 report recommends it: the frozen engine (frozenRow) with today's safety net and CPS earnings (the frozen yardstick); wealth by asset class
 * with business owners, capital income and the creditor side at its main reading (rt; S59, S71); the weighted top tail (wt; S59); adults outside the labour
 * force (lf; S61) and the borrowing limit for ordinary spending at $2,500 (dr; S61); bargaining at pass-through 0 with the markdown 1/1.21 (bg; S60:
 * identical to off); open PTF access with growth (pa; S55); PTF running costs and who pays at their main readings (po; S62); the financing identity reported
 * (fx.fin 'report'; S68: moves no figure under the Source); today's price rule (no pr; S67 section 9). Applied to both runs of a pair. Study options:
 * R2_MAIN_STUDY (distribution measures dm, the money-flow table mf, the tail's measures wtm, costs at the within-year price level wy). S72 added the
 * government account (gv {}: reporting, and the contribution's books at each adult's weight, which moves the Source rows' small contribution because
 * the weighted tail is on). S73 added lf {fl: 'stock', pm: 0.43} (yearly movement in and out of the labour force, and the share of the income effect
 * taken by leaving work; dev/reports/s73-participation.md); the packet for S69 is rebuilt now. */
var R2_MAIN = {sn:{abawd:true, slope:true}, lt:{s:'all', m:'all'}, rt:{bo:true, ci:true, ng:'base', cr:true}, wt:true, lf:{fl:'stock', pm:0.43}, dr:{lim:2500}, bg:{pi:0, m:1/1.21}, pa:'open', po:true, gv:{}};  /* S72: the government account (gv, with its weighted books). S73: yearly flows in and out of the labour force and the participation margin (lf fl, pm) */

// harness.js line 3730
var R2_MAIN_STUDY = {dm:true, rep52:true, wtm:true, mf:true, wy:true};

// harness.js line 3731
function r2MainRow(c){ Object.assign(c, JSON.parse(JSON.stringify(R2_MAIN))); c.bg.m = R2_MAIN.bg.m; frozenRow(c); c.fx = {pthb:true, hb:true, ab:true, sp:true, fin:'report', pe:true}; return c; }

// harness.js line 3733
/* The pair (row 0 no programme, row 1 the design: 'c22' the C2.2 design, 'rel' the release design) and the study options, environment P. */
function r2MainPair(P, design){ var cf = relMainCfgs(tbPresets(P)).map(function(c){ c.sc = SPEND_SOURCED; return r2MainRow(c); }); if (design !== 'rel') c22Design(cf[1]); return cf; }

// harness.js line 3734
function r2MainStudy(){ return Object.assign({fin:'tax', aT:0, a:0, X:0, sc:SPEND_SOURCED}, REL_V52_STUDY, R2_MAIN_STUDY); }
