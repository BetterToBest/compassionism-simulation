// Real engine, core part (index.html). Excerpted by dev/packets/build_s118_packet.py. runScenario is from harness.js.
// Mechanisms listed in later-modules.md are OFF in every preset used here (the switches default to off), so their branches never run.

function runScenario(p, seed){
  RNG = mulberry32(seed + 700003);
  var latentPop = makeLatentPopulation(p.nAgents);
  var agents = latentPop.map(function(lat){ return instantiateAgent(lat, p); });
  /* v4.17: year-0 reference (before any year runs; draws no RNG). Wealth poverty and the
   * income measures are policy-neutral (same latent population in every scenario); BLEI is
   * not — agentBLEI() credits BU, γ=0.20 and reduced daily cost to participants — so the
   * policy-neutral BLEI figure evaluates the same agents under Baseline rules. */
  var m0 = calcMetrics(agents);
  var bN0 = bleiMetrics(agents, 0, false, false, false, 0, false), bY0 = bleiMetrics(agents, p.bu, p.ccoOn, p.pth, p.szh, p.szhCoh, p.ptf);
  var ib0 = incomeBasketYear0(agents);
  var d0 = housingDistressYear0(agents);  /* v4.18 */
  var yearZero = {pov:+(m0.pov*100).toFixed(1), bleiPovNeutral:+((bN0.tc[0]+bN0.tc[1])/bN0.n*100).toFixed(1),
    bleiPovScenario:+((bY0.tc[0]+bY0.tc[1])/bY0.n*100).toFixed(1), incPov:+ib0.incPov.toFixed(1), incPovExt:+ib0.incPovExt.toFixed(1), basketPov:+ib0.basketPov.toFixed(1), basketPovGross:+ib0.basketPovGross.toFixed(1),
    distress:d0*100, ep:extremePovertyOf(d0,d0,'year0').total};  /* v4.18: unrounded, for the overlay's parity checks */
  /* v4.17: recessions (NEEC note 5). p.shock was silently ignored before this release. */
  var recPath = p.shock ? buildRecessionPath(p.years, seed) : null;
  RNG = mulberry32(seed);
  var aWealth = [], aBlei = [];
  for (var yr = 0; yr < p.years; yr++){
    runYear(agents, yr, p, recPath ? recPath[yr] : {active:false, incomeMultiplier:1.0, yearsLeft:0});
    var m = calcMetrics(agents, p.ccoOn, p.pth);
    var bMed = calcMedianBLEI(agents, p);
    aWealth.push(Math.round(m.med));
    aBlei.push(Math.round(bMed));
  }
  var finalM = calcMetrics(agents, p.ccoOn, p.pth);
  var stab = structuralStability(aWealth, aBlei);
  var top = (p.ccoOn && p.ptf) ? 'Flourishing' : 'Comfortable';
  var bMain = bleiMetrics(agents, p.bu, p.ccoOn, p.pth, p.szh, p.szhCoh, p.ptf, top);
  var floor = CFG.WEALTH_FLOOR;
  var atFloor = agents.filter(function(a){ return a.wealth <= floor + 1e-6; }).length;
  var ib = incomeBasketMetrics(agents);
  var dEnd = housingDistressOf(agents), ep = extremePovertyOf(dEnd, d0, p);  /* v4.18 */
  function dShare(ag){ return ag.length ? housingDistressOf(ag)*100 : null; }
  return {
    pov: +(finalM.pov*100).toFixed(1),
    gini: +finalM.gini.toFixed(3),
    wealth: Math.round(finalM.med),
    p10: Math.round(finalM.p10),
    p90: Math.round(finalM.p90),
    bleiMed: Math.round(bMain.med),
    bleiPovPct: +((bMain.tc[0]+bMain.tc[1])/bMain.n*100).toFixed(1),
    pctFlourishing: +bMain.pctF.toFixed(1),
    avgEDC: +(bMain.avgEDC*100).toFixed(1),
    stab: +(stab*100).toFixed(1),
    fracAtFloor: atFloor/agents.length,
    medianPinned: Math.round(finalM.med) === floor,
    incPov: +ib.incPov.toFixed(1),            /* v4.17 */
    incPovExt: +ib.incPovExt.toFixed(1),
    basketPov: +ib.basketPov.toFixed(1),      /* v4.17 */
    basketPovGross: +ib.basketPovGross.toFixed(1),
    yearZero: yearZero,                       /* v4.17 */
    epTotal: ep.total, epEcon: ep.econ, epSmi: ep.smi, epVol: ep.vol,   /* v4.18: percentages, unrounded */
    distress: dEnd*100, distressY0: d0*100, wz: ep.wz,
    distressPart: dShare(agents.filter(function(a){ return a.inCCO; })), distressNonPart: dShare(agents.filter(function(a){ return !a.inCCO; })),
    recessionYears: recPath ? recPath.filter(function(r){ return r.active; }).length : 0
  };
}



// index.html line 2072
var CFG = {
  /* v4.13: POVERTY_LINE carries no citation anywhere in this codebase — flagged as an open
   * `calibration:` item in CONTRIBUTING.md's Calibration Validation table since v4.10, but
   * with nothing at the constant itself to warn a reader who only ever looks at the code.
   * Noted here so the gap is visible where the number lives. It is a pure post-hoc
   * reporting threshold with exactly one read site (calcMetrics()), never touching RNG or
   * dynamics — which is why the v4.10 Threshold Sensitivity charts can sweep across it
   * freely, and why an uncited value here is a reporting-clarity problem rather than a
   * mechanics one. For reference, the 2026 HHS one-person federal guideline is $15,960
   * (FED_POVERTY_LINE_1P, below); $25,000 is noticeably higher and its basis is unknown.
   * v5.3 (B3, Oct 7, 2026; DECISIONS Session 39): settled as a design threshold with a stated reading. Where $25,000 came from is still
   * undocumented, but it is within 1.3% of six months of one adult's cost of living (half of LIVING_WAGE_ANNUAL, $24,685), which is how the
   * model reads it from v5.3: the household reading uses six months of each household's own costs (CFG.HH_WEALTH_MONTHS). Stricter than the
   * asset-poverty literature's line (net worth below three months of the poverty line: Haveman and Wolff 2004). Kept at $25,000 here so the
   * adult-only figures stay comparable across releases. */
  POVERTY_LINE:25000, BLEI_CRISIS_MAX:7, BLEI_PRECARIOUS_MAX:30,
  BLEI_THRESHOLD_MAX:120, BLEI_STABLE_MAX:365, BLEI_SECURE_MAX:730,
  BASE_DAILY_COST:68.33, CCO_PTH_DAILY_COST:31.67,
  /* v4.7: previously an anonymous lognormal(10.5,1.2) literal inline in
   * makeLatentAgent() — promoted to named constants purely for discoverability
   * (identical values, so zero change to RNG consumption or any simulation
   * output). Comment doubles as an open calibration flag: median wealth =
   * e^WEALTH_INIT_MU ≈ $36,316, matching this constant's own long-standing
   * "Fed SCF 2022" citation elsewhere in this file and in the ODD panel below
   * — but the actual 2022 Survey of Consumer Finances reports median
   * household net worth at ≈$193,000 (Kuhn & Ríos-Rull, NBER working paper,
   * 2025, using 2022 SCF microdata), roughly 5.3x higher. Gini of a lognormal
   * is 2Φ(σ/√2)−1 — a function of WEALTH_INIT_SIGMA alone, no μ term — so this
   * is independent of the wealth-init distribution's separately-documented
   * inherent Gini ≈0.60 (see the Empirical Calibration panel); correcting the
   * median here would shift absolute wealth-poverty rates, especially in
   * early simulated years against the fixed-dollar POVERTY_LINE, without
   * moving Gini at all. Not changed this pass — every downstream wealth/Gini/
   * BLEI/poverty figure the model produces starts from this draw, so revising
   * it needs the same mechanics-audit-plus-large-N-restudy treatment as
   * v4.0/v4.3/v4.4, not a value swap in a hygiene release. Logged as an open
   * calibration: item in CONTRIBUTING.md's Model Architecture Feedback. */
  WEALTH_INIT_MU:10.5, WEALTH_INIT_SIGMA:1.2,
  SZH_ALL_RESIDENTS:0.06, SZH_PTF_BONUS:0.05,
  /* v4.0: network-density-gated synergy coefficient θ (BLEI paper Table 6: "Synergy
   * coefficient θ ... Network-density-gated: 0 below 55% PTF density; scales to 0.25
   * at 90%"). Previously applied as a plain linear function of szhCoh with no
   * threshold — see szhTheta().
   * v4.17 correction: the threshold is applied to szhCoh, the SZH zone-coherence SLIDER, as a
   * stand-in for PTF merchant density. Realised PTF density never enters θ — the reference
   * run's θ is 0.121 whether realised PTF membership is 18% or 53%. Logged as a decision. */
  SZH_THETA_THRESHOLD:0.55, SZH_THETA_MAX_COH:0.90, SZH_THETA_MAX:0.25,
  EDC_BASELINE_LO:0.62, EDC_BASELINE_HI:0.72, EDC_PTH_CAP:0.10,
  PROG_PIVOT:3.0, PROG_RATE:0.040, PROG_TAX_MAX:0.75,
  /* v4.13: corrected comment. This previously read "retained for CCO/PTF/PTH cost-factor
   * calc only" — not true: the cost factor (cf) in runYear() is a product of dimensionless
   * multipliers (0.88 / 0.65 / 0.80) and never touches this constant. Grep confirms
   * CFG.SIM_COST_SCALE has ZERO read sites in the live code today; it appears only here and
   * in prose. Kept rather than deleted so pre-v4.3 exported CSV/JSON files and this file's
   * own historical worked examples (which quote a wage×12/SIM_COST_SCALE ratio) stay
   * interpretable — that is now its entire remaining purpose. */
  SIM_COST_SCALE:1500,     // historical constant only — read by no function in this file (v4.3 wealth loop uses WAGE_TO_USD/LIVING_WAGE_ANNUAL; v4.4 retired SIU_TO_USD, its last consumer)
  WAGE_MEDIAN_SIU:35,      // reference for diminishing-returns calculation
  WEALTH_FLOOR:-10000,     // v4.8: N=500-seed sweep across 4 candidate values run and validated — see CONTRIBUTING.md; default unchanged, this is data for a decision not a decision itself
  WAGE_BASE_GROWTH:0.010, WAGE_BLEI_BONUS:0.008, WAGE_OCTAVE_BONUS:0.003,
  AI_DISPLACEMENT_YEAR_1:5, AI_DISPLACEMENT_YEAR_2:15,
  AI_DISPLACEMENT_RATE_1:0.012, AI_DISPLACEMENT_RATE_2:0.022,
  TARGET_WEALTH:82000, TARGET_STABILITY:0.90, TARGET_POVERTY:0.05,
  TARGET_FLOURISHING:0.50, TARGET_GINI:0.25, TARGET_EDC:0.10,
  NORDIC_GINI:0.28, CCO_OPTIMAL_BU:1200,
  /* v4.17: the papers' "minimum viable" CCO participation. Used ONLY for a run warning — no
   * line of runYear() reads aggregate CCO participation, so nothing in the dynamics changes
   * at 55% (sweep in CONTRIBUTING.md v4.17; NEEC maintainers' note 7). Whether to build a
   * participation-dependent network effect is logged as a decision for Duke. */
  CCO_MIN_PARTICIPATION:0.55,
  PTF_OPTIMAL_SHARE:0.18, PTF_DISTORTION:0.30,
  PHI_RATIO:1.618, PHI_QUALITY_THRESH:0.70,
  /* v4.0 additions — see BLEI paper (basic-living-economic-index.html) §8 Table 6
   * and Index IV (FBS) for the specification these implement. */
  FBS_LAMBDA_LO:0.0001654, FBS_LAMBDA_HI:0.0013233,   // per-agent capability coefficient λ ~ U(lo,hi), units 1/USD — v4.4: rescaled ÷(WAGE_TO_USD/legacy SIU_TO_USD ≈6.0456) from the pre-v4.4 0.001/0.008. The FBS gate's wage-derived income term (Yusd, below) was redefined from the legacy SIU_TO_USD anchor to the empirically-grounded WAGE_TO_USD anchor as part of the v4.4 wage-scale unification, ~6.05× larger at any given wage — but FBS also includes fixed-dollar terms (BU face value, basic cost) that did NOT rescale, so FBS as a whole does not scale by a single clean factor, and this rescale is a CHOSEN behavioral recalibration to restore useful advancement-probability variation across the population, not a dimensionally-forced conversion (an earlier version of this comment overstated that). Left unscaled, λ×fbs saturates pAdvance (→1) for nearly all agents regardless of BU level, which measurably weakened the BU-monotonicity VAL_TEST (4/5→ties at n=200, one seed) AND, more fundamentally, leaves little of λ's intended role as an "individual capability coefficient": even the BLEI paper's own published range (0.001-0.008) already produces 89.8-100% advancement probability at the paper's own $2,281/month worked example. Rescaling preserves the HI/LO=8× heterogeneity shape and restores 5/5 on VAL_TESTS — that demonstrates internal behavioral consistency, not empirical correctness of these specific values; λ's empirical grounding remains open, same as before v4.4 (see the BLEI paper's own Index IV note and CONTRIBUTING.md's "λ Calibration Status — Open" for the full account, including a recommended future reparameterization by half-saturation point FBS₅₀=ln(2)/λ rather than a raw 1/USD coefficient).
  FBS_EDC_RESIDUAL_BASE:0.12, FBS_EDC_RESIDUAL_PTH:0.025, // EDC_residual (consumer-debt-only), Table 1b worked values
  FBS_CIP_LAMBDA_BOOST:0.20,   // CIP support raises effective λ by up to +20% at cipDemo=1 (replaces old flat advancement-probability bump)
  BASELINE_CPI_RATE:0.03,      // US Welfare Baseline anchors to documented 3% CPI, not the user's inflation slider
  PTH_EQUITY_CONTRIB_SHARE:0.25, // share of PTH's annual housing-cost saving that routes to Acre Equity (payment→equity), vs. staying as direct liquid relief
  /* v4.5: tenure-cohort-varying liquidity haircut, replacing the flat 50% share of
   * annual Acre Equity appreciation that counted as immediately-liquid wealth (see
   * pthLiquidShare() and the runYear() PTH block). BLEI paper Table 1a describes this
   * schedule qualitatively as "~10-20% at 6 months rising to ~80-90% at 5+ years" —
   * we don't have a closed-form curve from the paper, only these two anchor points, so
   * this is a linear interpolation between them, a documented interpretation choice
   * pending a fuller citation, same honesty standard as PTH_EQUITY_CONTRIB_SHARE above.
   * Anchors use the midpoint of each cited range (15%/85%) rather than either endpoint.
   * pthTenure is incremented to 1 on an agent's first year in PTH (see runYear()), so
   * tenure=1 is the point in the schedule closest to the paper's "6 months" anchor;
   * tenure>=5 holds flat at the "5+ years" anchor rather than continuing to rise. */
  PTH_LIQUID_SHARE_YEAR1:0.15, PTH_LIQUID_SHARE_YEAR5PLUS:0.85, PTH_LIQUID_SHARE_MATURE_YR:5,
  PTF_BASS_Q:0.05,      // Bass (1969) imitation coefficient for PTF adoption — see runYear
  /* v4.3: main wealth-accumulation loop unit fix (highest-priority open item as of
   * v4.2 — see CONTRIBUTING.md Model Architecture Feedback). Two new constants:
   * WAGE_TO_USD converts the wage side; LIVING_WAGE_ANNUAL anchors the cost side.
   * WAGE_TO_USD ≈ 100.52 = $42,220 median personal income (Census/BLS CPS ASEC 2023,
   * all workers 15+) ÷ (35 SIU × 12). LIVING_WAGE_ANNUAL = $49,370/yr — a national
   * living-wage figure for a single adult, no children ($23.735/hr average across
   * 50 states + DC × 2,080 hrs/yr; World Population Review's MIT-sourced table; an
   * *unweighted* average across jurisdictions, not population-weighted like MIT's
   * own Living Wage Calculator product, which is paid and requests no scraping —
   * see CONTRIBUTING.md for that caveat). Replaces netting WAGE_TO_USD-converted wage
   * against BASE_DAILY_COST (a bare-subsistence floor, correct for BLEI's poverty-line
   * use, wrong for a 20-year compounding loop netted against real wage): that anchor
   * produced an ~11x wealth explosion and broke BU-monotonicity (2/5 seeds). All six
   * VAL_TESTS pass under the LIVING_WAGE_ANNUAL anchor, including BU-monotonicity
   * (5/5) — the strongest evidence this anchor is structurally right, not just
   * numerically smaller. dollarCost/BASE_DAILY_COST — the COST side — is unchanged
   * everywhere else (BLEI, FBS, Gini) — only the main loop's cost side changes here.
   * (v4.4 note: this is about the cost side specifically. BLEI/FBS/Gini's WAGE-side
   * conversion, separately, moved off the legacy SIU_TO_USD approximation onto this
   * same WAGE_TO_USD constant in v4.4 — see Cumulative Bug Fixes. The two changes
   * are independent; this comment's claim about the cost side is still accurate.)
   * This is NOT a clean win: correcting the units also redistributes, not just grows
   * — see the redistribution note under CONTRIBUTING.md Model Architecture Feedback
   * and the Known Limitations entry below before reading the headline wealth figure
   * alone. */
  WAGE_TO_USD:100.52,
  LIVING_WAGE_ANNUAL:49370,
  /* v4.3: Social Security-anchored income-comparison figures — reference points only,
   * not a simulated cohort mechanism (see the fixed-income cohort study, Known
   * Limitations, and CONTRIBUTING.md). SSA 2026 COLA Fact Sheet
   * (ssa.gov/news/en/cola/factsheets/2026.html): SSI federal payment standard,
   * individual, $994/mo; SSDI average, all disabled workers, $1,630/mo; average
   * retired-worker benefit, $2,071/mo. */
  SS_ANCHOR_SSI_ANNUAL:11928, SS_ANCHOR_SSDI_ANNUAL:19560, SS_ANCHOR_RETIRE_ANNUAL:24852,
  /* v4.10: external reference only — NOT a simulation parameter, same category as
   * NORDIC_GINI above (never read by runYear()/calcMetrics()/agentBLEI() or any other
   * mechanics function; used only as a labeled comparison point in
   * renderThresholdSensitivity's callout text, below). 2026 HHS ASPE federal poverty
   * guideline, one-person household, 48 contiguous states + DC: $15,960/yr. Verified this
   * session directly against aspe.hhs.gov/poverty-guidelines's cited methodology plus an
   * independently-dated primary-source PDF (a Lifeline Safe Connections Act eligibility
   * table, citing HHS directly and dated January 15, 2026, showing 200% of this same
   * guideline as $31,920 for one person — i.e. the underlying guideline is exactly
   * $15,960); a first fetch attempt against the live ASPE page returned a stale cached
   * 2017 snapshot, caught and cross-checked rather than used — see CONTRIBUTING.md's v4.10
   * Release Notes for the full verification trail. Published annually, ~mid-to-late
   * January; update this figure — and its year label in the callout text — when a fresher
   * guideline is published, the same discipline CONTRIBUTING.md already applies to
   * SS_ANCHOR_* above. */
  FED_POVERTY_LINE_1P:15960, FED_POVERTY_LINE_YEAR:2026,
  /* v4.18: EXTREME POVERTY OVERLAY — homeless, with necessities provided by charity if at all.
   * The engine has no housing market, mental-health state or vocation, so this measure is an
   * overlay on engine state, not an engine output (see extremePovertyOf()). Draws no RNG. */
  EP_Y0_RATE:0.0022,     // year-0 rate: HUD 2025 AHAR Part 1 PIT count, 745,652 people on one night in Jan 2025, ~22 per 10,000
  EP_SMI_SHARE:0.25,     // share of that total unhoused because of serious mental illness: Gutwinski et al. 2021 (PLoS Med 18(8)) meta-analysis, schizophrenia spectrum 12.4% + major depression 12.6%
  EP_VOL_SHARE:0.02,     // share living this way by choice (ascetics, itinerant monastics, renunciants). Set by Duke (v4.18); no US source located. The true share may vary and should be updated as data sources become available
  EP_WZ_EFFECT:0.50,     // relative reduction in SMI homelessness from PTH+SZH wellness zones at full zone coherence: At Home/Chez Soi RCT, last 6 months housed none of the time 16% (Housing First) vs 46% (usual care); housed all of the time 62% vs 31%
  /* v4.19: AUTOMATIC STABILIZERS. Every lever is off by default (ST.stab, ST.cola), so no
   * documented figure moves. Reference values are the Research Hub's own crisis protocols
   * (Integrated Implementation Roadmap, Appendix G) and this engine's calibration of them —
   * `node harness.js stabilizer` reproduces every figure. See CONTRIBUTING.md v4.19. */
  /* v4.19, Option B: CCO cost relief = min(CCO_RELIEF_CAP, CCO_RELIEF_AT_REF x effective BU / CCO_RELIEF_REF_BU).
   * v4.21: effective BU is read in year-0 dollars (divided by the basket's price index), because
   * CCO_RELIEF_REF_BU is a year-0 amount and the relief multiplies the nominal basket. See runYear(). */
  CCO_RELIEF_AT_REF:0.20, // the historical flat relief, now its value at the reference BU
  CCO_RELIEF_REF_BU:1200, // the reference BU ($/month) at which relief is 20% of the basket
  CCO_RELIEF_CAP:0.50,    // ceiling on the relief share. PLACEHOLDER set in v4.19 (binds from $3,000 of effective BU); no source located
  STAB_HUB_MULT:1.20,    // Recession Protocol: "increase basic units 20%"
  STAB_HUB_THRESH:0.02,  // ...when "GDP decline >2% for 2 quarters". No GDP in the engine: read as a >=2% population income loss. Every engine recession (5-30% loss) clears it
  STAB_NEUTRAL_MULT:1.35,// shock-neutral multiplier for CCO participants at the reference settings, with cost relief scaling with BU (harness.js stabilizer 300: x1.36 unrounded; x1.35 in Adverse Environment and CCO Only)
  STAB_NEUTRAL_K:2.8,    // the scaled rule's equivalent: BU increase = k x income-loss share (k ~ 2.8 at the reference settings)
  STAB_MULT_MAX:4,       // slider maximum; the in-page shock-neutral search stops here
  STAB_EMERG_TAKEUP:0.50,// share of non-participants taking up emergency enrollment when triggered. PLACEHOLDER set in v4.19: no source located
  COLA_HUB_THRESH:0.05,  // Inflation Surge Protocol: "CPI >5%" -> COLA adjustments to basic units
  STAB_STUDY_SEEDS:30,   // paired seeds for the in-page shock-response study
  /* v4.20: automationRisk mixture, pi x Beta(AUTO_HIGH_A,1) + (1-pi) x Beta(1,AUTO_LOW_B).
   * Source: Frey & Osborne (2013), appendix (pp. 57-72), 702 SOC-2010 occupations, weighted by
   * May-2016 BLS OES employment (plotly/datasets job-automation-probability.csv, numbEmployed;
   * every row checked against the paper's appendix in v4.20 and matching on SOC code, rank
   * and probability). Employment-weighted mean probability 0.592; share at or above 0.5,
   * 0.660; share above 0.7, 0.501. v4.3-v4.19 used 0.47 — F&O's headline share of 2010 US
   * employment above 0.7 — as the mixture weight, which gives a mean of 0.479. 0.63 matches
   * the data's mean, and automationRisk enters runYear() linearly (wage drag = displacement
   * rate x risk), so the mean sets the population's aggregate drag; it is also the closest of
   * the candidates to the data's distribution (harness.js automation fit). Shapes are kept
   * from v4.3; the within-group means they imply (0.857/0.143) are close to the data's
   * (0.835/0.120). Drawn INDEPENDENTLY of wage, although across occupations log median wage
   * and probability correlate at -0.65 (employment-weighted): see CONTRIBUTING.md v4.20. */
  AUTO_HIGH_SHARE:0.63,
  AUTO_HIGH_A:6,
  AUTO_LOW_B:6
};
/* v4.6: FBS₅₀ (half-saturation bandwidth) reporting constants — CONTRIBUTING.md's "λ
 * Calibration Status — Open" note recommended this exact reparameterization ("reporting the
 * half-saturation point FBS₅₀=ln(2)/λ instead of a raw 1/USD coefficient... far easier for a
 * reviewer to interrogate directly") and had already hand-computed the resulting range in
 * prose (≈$524–$4,191/month). Promoted here to a named, DERIVED constant so it can't drift out
 * of sync with FBS_LAMBDA_LO/HI if those are ever revised again — computed from them, not
 * independently set. Note the inversion: higher λ means faster saturation, i.e. LOWER FBS50,
 * so FBS_HALF_SAT_LO derives from FBS_LAMBDA_HI and vice versa.
 * This is a REPORTING/display change only — makeLatentAgent() still draws λ directly and
 * uniformly from FBS_LAMBDA_LO/HI exactly as in v4.5, so every per-agent λ value, RNG stream
 * position, and downstream simulation output is byte-identical to v4.5. A genuine
 * reparameterization — sampling FBS50 as uniform and DERIVING λ=ln(2)/FBS50 from it, rather
 * than the reverse — would change the shape of the λ distribution (a uniform-in-1/x transform
 * is not uniform in x) and is a distinct, larger design decision needing its own validation
 * pass; tracked as a separate open item in CONTRIBUTING.md, not attempted here. */
CFG.FBS_HALF_SAT_LO=Math.log(2)/CFG.FBS_LAMBDA_HI;
CFG.FBS_HALF_SAT_HI=Math.log(2)/CFG.FBS_LAMBDA_LO;
/* v4.0-v4.3: CFG.SIU_TO_USD = (BASE_DAILY_COST×365)/SIM_COST_SCALE ≈ 16.63 lived here —
 * a cost-derived approximation for converting wage to USD in agentBLEI, calcBLEIComponents,
 * the FBS gate, and the Gini net-wealth adjustment, invented in v4.0 before any real
 * wage-side dollar anchor existed. v4.4: RETIRED. Now that WAGE_TO_USD (above) is a
 * genuine Census/BLS-sourced wage→USD anchor — added v4.3 for the main wealth loop — an
 * agent's wage resolved to two different real-dollar figures depending which formula
 * asked (external audit: "the same a.wage cannot simultaneously represent ~$42,220/yr for
 * wealth accumulation and ~$6,985/yr for welfare measurement without a substantive
 * transformation between those concepts" — a ~6× divergence at the median wage). All four
 * formulas above now use CFG.WAGE_TO_USD directly — see each call site. agentEDC() was
 * and remains unaffected: it never used SIU_TO_USD (dimensionless SIU/SIU ratio, see its
 * own comment). Validated against all six VAL_TESTS and a fresh N=5,000 study — see
 * CONTRIBUTING.md Cumulative Bug Fixes, v4.4, for the before/after figures. */


// index.html line 2287
var ST={phi:true,ptf:true,pth:true,szh:true,cip:true,shock:false,automation:false,ptfCap:false,baseInflMatch:false,
  stab:false,stabSev:false,stabSusp:false,emerg:false,cola:false};  // v4.19: automatic stabilizers, all off

// index.html line 2289
var charts={};var running=false;var SIM_RESULTS=null;
/* v3.6: previously assigned without declaration inside the load listener at the
 * bottom of this file, creating an implicit global. Declared explicitly here. */

// index.html line 2301
var CANCELLED=false;
/* v4.16: run generation counter. Incremented by every runSim() call; an attribution ablation
 * batch launched by an earlier run checks it before each chunk and abandons itself if a newer
 * run has started, instead of drawing on the shared RNG global mid-way through that run and
 * later rendering its stale result. See runAblation() and CONTRIBUTING.md v4.16. */

// index.html line 2306
var SIM_GEN=0;

// index.html line 2307
var MR={active:false,numRuns:3,current:0,results:[],baseSeed:0,userSeed:'',suppressUI:false};

// index.html line 2312
var RNG=Math.random;

// index.html line 2313
function mulberry32(seed){var s=seed>>>0;return function(){s=(s+0x6D2B79F5)>>>0;var t=Math.imul(s^(s>>>15),1|s);t=(t+Math.imul(t^(t>>>7),61|t))^t;return((t^(t>>>14))>>>0)/4294967296;};}

// index.html line 2314
function initRNG(v){var n=parseInt(v);RNG=(!isNaN(n)&&v!==''&&v!==null&&n>=0&&n<=999999)?mulberry32(n):Math.random;}

/* ─── SLIDERS ─────────────────────────────────────────────────────────── */

// index.html line 2317
var FMT={bu:function(v){return v==0?'$0 (off)':'$'+parseInt(v).toLocaleString();},oct:function(v){return v;},exp:function(v){return v+' mo';},phi:function(v){return v?'On':'Off';},tax:function(v){return v+'%';},mult:function(v){return v+'×';},agents:function(v){return parseInt(v).toLocaleString();},part:function(v){return v+'%';},yrs:function(v){return v+' yr';},ptf:function(v){return v+'%';},pth:function(v){return v+'%';},szh:function(v){return(v/100).toFixed(2);},cip:function(v){return v+'%';},infl:function(v){return parseFloat(v).toFixed(1)+'%';},
  stabm:function(v){return '×'+parseFloat(v).toFixed(2);},stabk:function(v){return '+'+parseFloat(v).toFixed(1)+'%';},stabth:function(v){return v+'%';},emtk:function(v){return v+'%';},colath:function(v){return parseFloat(v).toFixed(1)+'%';}};  // v4.19

// index.html line 2319
function sv(key,raw){var el=document.getElementById('v-'+key);if(el)el.textContent=FMT[key]?FMT[key](raw):raw;var sl=document.getElementById('s-'+key);if(sl&&el)sl.setAttribute('aria-valuetext',el.textContent);if(key==='mult')updateEffMax();updatePills();}  // v4.20: aria-valuetext
/* v4.13: toggle state is now also exposed via aria-pressed. Before this, every On/Off pair
 * in the sidebar communicated its state through color and a CSS class alone — a screen
 * reader heard two identically-labeled buttons with no indication of which was active,
 * the same class of gap v3.7 closed for the charts (which had no accessible name at all).
 * Purely an attribute; no visual, class, or behavioral change. */

// index.html line 2330
function updateEffMax(){var el=document.getElementById('v-mult-eff');if(!el)return;var m=gp('s-mult');var eff=(m*CFG.PHI_RATIO).toFixed(2);el.textContent=ST.phi?('Effective max with Phi: '+eff+'×'):('Phi off — effective max: '+m+'×');}

// index.html line 2331
function gp(id){return parseFloat(document.getElementById(id).value);}

// index.html line 2332
function updatePills(){var bv=gp('s-bu'),ccoOn=bv>0;setPill('pill-cco',ccoOn,'CCO: $'+bv+'/mo','CCO: Off','sp-on');setPill('pill-ptf',ST.ptf,'PTF: '+gp('s-ptf')+'%','PTF: Off','sp-on');setPill('pill-pth',ST.pth,'PTH: '+gp('s-pth')+'%','PTH: Off','sp-on');setPill('pill-szh',ST.szh,'SZH: '+(gp('s-szh')/100).toFixed(2),'SZH: Off','sp-on-b');setPill('pill-cip',ST.cip,'CIP: '+gp('s-cip')+'%','CIP: Off','sp-on-p');}

// index.html line 2333
function setPill(id,active,onTxt,offTxt,onCls){var el=document.getElementById(id);if(!el)return;el.textContent=active?onTxt:offTxt;el.className='sys-pill '+(active?onCls:'sp-off');}

/* ─── PRESETS (v3.3: adds hiAI) ────────────────────────────── */

// index.html line 2336
var PRESETS={
  baseline:{bu:0,oct:1,exp:1,tax:0,mult:1,agents:500,part:0,yrs:20,ptfShare:0,pthUptake:0,szh:0,cip:0,phi:false,ptf:false,pth:false,szh_tog:false,cip_tog:false,shock:true,inflRate:3,automation:false},
  cco:{bu:1200,oct:6,exp:1,tax:12,mult:9,agents:500,part:75,yrs:20,ptfShare:0,pthUptake:0,szh:0,cip:0,phi:true,ptf:false,pth:false,szh_tog:false,cip_tog:false,shock:false,inflRate:0,automation:false},
  reference:{bu:1200,oct:6,exp:1,tax:12,mult:9,agents:500,part:78,yrs:20,ptfShare:18,pthUptake:20,szh:72,cip:65,phi:true,ptf:true,pth:true,szh_tog:true,cip_tog:true,shock:false,inflRate:0,automation:false},
  stress:{bu:900,oct:4,exp:1,tax:18,mult:6,agents:500,part:40,yrs:20,ptfShare:8,pthUptake:10,szh:35,cip:30,phi:true,ptf:true,pth:true,szh_tog:true,cip_tog:true,shock:true,inflRate:2,automation:true},
  /* v4.17: the Stress Test's adverse ENVIRONMENT (recessions, 2% inflation, AI automation)
   * at the unchanged reference SETTINGS — NEEC maintainers' note 6. Stress Test changes both
   * at once, so it cannot say whether a poor result comes from the environment or from the
   * weaker settings; this one isolates the environment, which is what a stress criterion
   * tests. harness.js ADVERSE_REFERENCE mirrors it; see CONTRIBUTING.md v4.17. */
  adverse:{bu:1200,oct:6,exp:1,tax:12,mult:9,agents:500,part:78,yrs:20,ptfShare:18,pthUptake:20,szh:72,cip:65,phi:true,ptf:true,pth:true,szh_tog:true,cip_tog:true,shock:true,inflRate:2,automation:true},
  hiAI:{bu:1200,oct:6,exp:1,tax:12,mult:9,agents:500,part:78,yrs:25,ptfShare:18,pthUptake:20,szh:72,cip:65,phi:true,ptf:true,pth:true,szh_tog:true,cip_tog:true,shock:false,inflRate:0,automation:true}
};

// index.html line 2701
var TIERS=[{name:'Crisis',num:0,cls:'t-crisis',color:'rgba(163,45,45,0.82)'},{name:'Precarious',num:1,cls:'t-precarious',color:'rgba(192,64,64,0.8)'},{name:'Threshold',num:2,cls:'t-threshold',color:'rgba(186,117,23,0.8)'},{name:'Stable',num:3,cls:'t-stable',color:'rgba(206,143,26,0.8)'},{name:'Secure',num:4,cls:'t-secure',color:'rgba(29,158,117,0.8)'},{name:'Flourishing',num:5,cls:'t-flourishing',color:'rgba(122,92,0,0.8)'}];

// index.html line 2702
function getTier(days,top){top=top||'Flourishing';if(days<CFG.BLEI_CRISIS_MAX)return TIERS[0];if(days<CFG.BLEI_PRECARIOUS_MAX)return TIERS[1];if(days<CFG.BLEI_THRESHOLD_MAX)return TIERS[2];if(days<CFG.BLEI_STABLE_MAX)return TIERS[3];if(days<CFG.BLEI_SECURE_MAX)return TIERS[4];return top==='Comfortable'?{name:'Comfortable',num:5,cls:'t-flourishing',color:TIERS[5].color}:TIERS[5];}

/* v4.0: network-density-gated SZH synergy coefficient θ. Replaces the previous
 * plain-linear-in-szhCoh treatment for the specific "cooperative synergy" effects
 * tied to PTF merchant density (external review + BLEI paper Table 6: "Synergy
 * coefficient θ ... 0 below 55% PTF density; scales to 0.25 at 90%"). The broader
 * SZH_ALL_RESIDENTS zone-coherence term is left linear — it represents general
 * zone-stability benefits available to all residents, not the specific PTF-network
 * threshold effect θ names. Magnitudes are scaled so the value AT full density
 * (coh→1) matches the pre-v4.0 ceiling, preserving prior calibration at the top end
 * while fixing the missing threshold below it. */
/* v4.17 correction: "PTF density" above is the paper's quantity; the argument here is the
 * SZH zone-coherence slider, used as a proxy. See CFG.SZH_THETA_THRESHOLD. */

// index.html line 2715
function szhTheta(coh){
  coh=isNaN(coh)?0:coh;
  if(coh<CFG.SZH_THETA_THRESHOLD)return 0;
  return Math.min(CFG.SZH_THETA_MAX,(coh-CFG.SZH_THETA_THRESHOLD)/(CFG.SZH_THETA_MAX_COH-CFG.SZH_THETA_THRESHOLD)*CFG.SZH_THETA_MAX);
}

/* v4.5: tenure-cohort-varying PTH liquidity haircut (see CFG.PTH_LIQUID_SHARE_* for the
 * calibration note). Linear ramp from PTH_LIQUID_SHARE_YEAR1 at tenure=1 to
 * PTH_LIQUID_SHARE_YEAR5PLUS at tenure>=PTH_LIQUID_SHARE_MATURE_YR, clamped flat outside
 * that range (tenure is always >=1 by the time this is called — see runYear() — but the
 * lower clamp guards a defensive default of tenure=1 all the same). Replaces the flat
 * 0.5 share used through v4.4. */

// index.html line 2727
function pthLiquidShare(tenure){
  var t=Math.max(1,Math.min(CFG.PTH_LIQUID_SHARE_MATURE_YR,isNaN(tenure)?1:tenure));
  var span=CFG.PTH_LIQUID_SHARE_MATURE_YR-1;
  return span>0?CFG.PTH_LIQUID_SHARE_YEAR1+(t-1)/span*(CFG.PTH_LIQUID_SHARE_YEAR5PLUS-CFG.PTH_LIQUID_SHARE_YEAR1):CFG.PTH_LIQUID_SHARE_YEAR1;
}

/* v3.3: NaN guards added throughout.
 * v4.0: gamma*mInc term converted SIU→USD via CFG.SIU_TO_USD (see UNIT SYSTEM note) —
 * previously a raw SIU number was added directly to USD-valued liquid/buFood terms.
 * v4.1: added the ptfOn parameter (audit finding — see AUDIT NOTE at top of file).
 * ccoOn and pthOn were already threaded through and checked alongside a.inCCO/a.inPTH
 * everywhere they're used below; PTF had no equivalent, so the θ bonus trusted a.inPTF
 * alone. That's harmless in the main simulation (a.inPTF can't be true when p.ptf is
 * false there — makeAgent() short-circuits on cfgP.ptf), but runAblation() deliberately
 * builds every scenario's population under the FULL p (for RNG-pairing — see its
 * comment) while simulating under a per-scenario pCfg, so a "PTF removed" ablation run
 * can have agents with a leftover a.inPTF=true from construction even though PTF is off
 * for that run. Without ptfOn, this function had no way to tell — the θ bonus leaked
 * into the "remove PTF" attribution result whenever SZH was also active, understating
 * PTF's true contribution on the Attribution chart. Now gated exactly like pthOn. */
/* plan step 10: harness.js version (ported by dev/tools/port_engine.py) */

// index.html line 2748
function agentBLEI(a,buAlloc,ccoOn,pthOn,szhOn,szhCoh,ptfOn){
  var liquid=Math.max(0,(isNaN(a.wealth)?0:a.wealth)*0.20);
  var gammaV=(ccoOn&&a.inCCO)?0.20:0.12;
  var mInc=Math.max(isNaN(a.wage)?1:a.wage,0.1)*CFG.WAGE_TO_USD;
  var buFood=(ccoOn&&a.inCCO&&buAlloc>0)?((CONVERSION_MODEL==='framework'&&a._fwBUm!==undefined)?a._fwBUm:buAlloc*(990/1200)):0;  // session 2, N3: framework credits one month of the BU the agent spends on essentials (fwB0 in runYear: the budget capped at essentials, before any price cut; audit V5-02: this year's with GATE_CURRENT)
  var szhD=szhOn?szhCoh*CFG.SZH_ALL_RESIDENTS:0;
  if(szhOn&&ptfOn&&a.inPTF)szhD+=szhTheta(THETA_GATE==='density'&&THETA_DENS!==null?THETA_DENS:szhCoh)*0.20;  // session 5 (C08): harness-only gate
  var baseCost=(ccoOn&&a.inCCO&&pthOn&&a.inPTH)?CFG.CCO_PTH_DAILY_COST:CFG.BASE_DAILY_COST;
  var dc=Math.max(baseCost*(1-szhD),0.1)*(a._hhD||1);  // v5.3 B3: an adult's share of the household's daily cost of basic living (households only)
  var r=(liquid+gammaV*mInc+buFood)/dc;
  return(isNaN(r)||!isFinite(r))?0:Math.max(0,r);
}

/* v3.3: NaN guard; actual wage (v3.2 fix retained)
 * v3.5: documenting EDC constants — these are scenario-calibrated targets, not
 * derived from a closed-form model. 18/1100/820 are numerators chosen so that
 * agentEDC(medianWage≈33) lands inside the corresponding EDC_BASELINE band
 * (CFG.EDC_BASELINE_LO/HI) for each participation tier; the additive terms
 * (+0.08/+0.03) and caps (0.75/0.42/CFG.EDC_PTH_CAP) bound the curve at low
 * and high income. Treat as design targets pending empirical EDC validation,
 * not as parameters fit to external data (see Assumptions panel).
 * v4.0 fix: the original numerators (1100, 820, 18) were roughly 30-60x the
 * median wage (~33-35 SIU), so 1100/mInc, 820/mInc and 18/mInc exceeded their
 * caps at every realistic wage — the min(cap, ratio) always picked the cap,
 * making EDC a constant regardless of income (external review: "EDC becomes
 * effectively fixed ... losing its intended income responsiveness"). Rescaled
 * each numerator to cap × WAGE_MEDIAN_SIU, so the ratio equals the cap exactly
 * AT the median wage (identical EDC value at the median to pre-v4.0: 0.58 non-
 * participant, 0.38 participant, 0.10 CCO+PTH — calibration anchor unchanged)
 * while now declining smoothly for above-median earners instead of staying flat
 * everywhere. At/below the median the ratio still saturates at the cap, which is
 * the intended floor (EDC does not improve further for the most cash-strapped
 * agents at a given tier). */

// index.html line 2781
function agentEDC(a,ccoOn,pthOn){
  var mInc=Math.max(isNaN(a.wage)?1:a.wage,1);
  var w=CFG.WAGE_MEDIAN_SIU;
  if(ccoOn&&a.inCCO&&pthOn&&a.inPTH)return Math.min(CFG.EDC_PTH_CAP,(CFG.EDC_PTH_CAP*w)/mInc);
  if(!ccoOn||!a.inCCO)return Math.min(0.75,Math.min(0.50,(0.50*w)/mInc)+0.08);
  return Math.min(0.42,Math.min(0.35,(0.35*w)/mInc)+0.03);
}


// index.html line 2789
function bleiMetrics(agents,buAlloc,ccoOn,pthOn,szhOn,szhCoh,ptfOn,top){
  top=top||'Flourishing';
  var sc=agents.map(function(a){return agentBLEI(a,buAlloc,ccoOn,pthOn,szhOn,szhCoh,ptfOn);});
  sc.sort(function(a,b){return a-b;});
  var n=sc.length,med=n%2===0?(sc[n/2-1]+sc[n/2])/2:sc[Math.floor(n/2)];
  var tc=[0,0,0,0,0,0];sc.forEach(function(d){tc[getTier(d,top).num]++;});
  var sumEDC=agents.reduce(function(s,a){return s+agentEDC(a,ccoOn,pthOn);},0);
  return{med:med,pctF:tc[5]/n*100,avgEDC:sumEDC/n,tc:tc,n:n};
}


// index.html line 2799
function calcBLEIComponents(agents,p){
  var cash=[],inc=[],ben=[];
  agents.forEach(function(a){
    var liq=Math.max(0,(isNaN(a.wealth)?0:a.wealth)*0.20);
    var g=(p.ccoOn&&a.inCCO)?0.20:0.12;
    var buF=(p.ccoOn&&a.inCCO&&p.bu>0)?p.bu*(990/1200):0;
    var sD=p.szh?p.szhCoh*CFG.SZH_ALL_RESIDENTS:0;if(p.szh&&p.ptf&&a.inPTF)sD+=szhTheta(p.szhCoh)*0.20;  // v4.0: threshold-gated; v4.1: +p.ptf gate (see agentBLEI)
    var dc=Math.max(((p.ccoOn&&a.inCCO&&p.pth&&a.inPTH)?CFG.CCO_PTH_DAILY_COST:CFG.BASE_DAILY_COST)*(1-sD),0.1);
    cash.push(liq/dc);inc.push(g*Math.max(isNaN(a.wage)?0:a.wage,0)*CFG.WAGE_TO_USD/dc);ben.push(buF/dc);  // v4.4: WAGE_TO_USD on income term (was SIU_TO_USD)
  });
  function med(arr){arr.sort(function(a,b){return a-b;});var n=arr.length;return n?n%2===0?(arr[n/2-1]+arr[n/2])/2:arr[Math.floor(n/2)]:0;}
  return{cash:med(cash),inc:med(inc),ben:med(ben)};
}

/* ─── RECESSION (v3.3: beta(5,2) distribution — realistic right-skew)
 * Distribution note (v4.0 documentation fix): incomeMultiplier = 0.70 + beta(5,2)×0.25.
 * beta(5,2)'s mode is (5-1)/(5+2-2) = 0.80, so the multiplier's mode is 0.70+0.80×0.25 =
 * 0.90 (a 10% income loss at the single most likely point) — not the "≈0.86 / 14% loss"
 * previously stated throughout the docs (external review: "the stated recession mode is
 * mathematically incorrect"). The distribution's MEAN is 0.70+(5/7)×0.25 ≈ 0.879 (≈12.1%
 * loss) and its median ≈0.884 (≈11.6% loss) — both close to the cited NBER post-WWII
 * target of "median US recession ≈ 12% peak income loss." The formula itself is
 * unchanged; only the mode/percentage figures quoted in prose across the three HTML
 * pages have been corrected to match what beta(5,2) actually produces. ── */

// index.html line 2823
function updateRecession(recSt){
  if(recSt.active){recSt.yearsLeft--;if(recSt.yearsLeft<=0){recSt.active=false;recSt.incomeMultiplier=1.0;}}
  else if(RNG()<0.10){recSt.active=true;recSt.yearsLeft=1+Math.floor(RNG()*3);recSt.incomeMultiplier=0.70+beta(5,2)*0.25;}
}
/* v4.0: precompute a full recession path (active/incomeMultiplier per year) on its own
 * dedicated stream, so that when shocks are enabled the main trajectory, baseline, and
 * CCO-only comparison all experience the SAME shock timing/severity — "paired shocks"
 * (external review, Counterfactual scenario isolation section). Each trajectory's OTHER
 * stochastic draws (wage variance, adoption checks, octave advancement) remain on their
 * own independent streams, unaffected by this. Unseeded (Math.random) runs fall back to
 * the live stream — no reproducibility claim applies there, matching the existing v3.8
 * convention for comparison-run streams. */

// index.html line 2835
function buildRecessionPath(years,seed){
  var path=[],saved=RNG;
  RNG=(seed===null||seed===undefined||isNaN(seed))?saved:mulberry32(seed+700000);
  var st={active:false,incomeMultiplier:1.0,yearsLeft:0};
  for(var y=0;y<years;y++){
    if(y>0)updateRecession(st);
    path.push({active:st.active,incomeMultiplier:st.incomeMultiplier});
  }
  RNG=saved;
  return path;
}
/* v4.0: shared agent-construction factory — used by the main population, the baseline
 * and CCO-only comparison populations, and the ablation batch, so every population is
 * built the same way (including the new per-agent λ for FBS-gated advancement) instead
 * of three-plus slightly-diverging copies of the same object literal. */
/* v4.2: canonical latent population — common-random-numbers fix for counterfactual
 * pairing (external review, Aug 2026: "the baseline and CCO-only populations are not
 * actually the same individuals"; CONTRIBUTING.md's own note that a shared-population
 * pairing "isn't well-defined once maxOct/maxMult differ in support between scenarios").
 * That objection is correct against the OUTCOME (octave/quality are scenario-scaled and
 * can't be shared as final values) but not against the underlying DRAW: the pre-policy
 * SHAPE variate that produces octave/quality can be shared and then scaled independently
 * per scenario, which is exactly what a "same individuals, different policy" experiment
 * needs. makeLatentAgent() draws that shape once; instantiateAgent() is a pure function
 * (zero RNG calls) that turns one latent draw into a scenario-specific agent.
 *
 * This also fixes a real, independently-found bug: v4.1's makeAgent() drew its three
 * eligibility uniforms via `cfgP.ccoOn&&RNG()<cfgP.partRate` etc. — short-circuit `&&`
 * means the RNG call itself was skipped whenever a toggle was off, so the number of RNG
 * calls consumed during agent construction depended on which subsystems were enabled.
 * Two scenarios built from the "same" seed but different toggle states (e.g. the
 * validation suite's PTF-on vs PTF-off comparison, VAL_TESTS[2]) therefore silently
 * diverged in EVERY subsequent draw, not just PTF membership — the seed matched but the
 * populations didn't. instantiateAgent() draws all three eligibility uniforms
 * unconditionally in makeLatentAgent(), so toggling a subsystem changes only that
 * subsystem's membership flag, nothing else. */

// index.html line 2871
function standardNormal(){var u=Math.max(1e-14,1-RNG()),v=RNG();return Math.sqrt(-2*Math.log(u))*Math.cos(2*Math.PI*v);}
/* v4.3: bimodal automationRisk (Frey & Osborne 2013; Autor 2015). Replaced uniform[0.2,1.0].
 * v4.20 corrections and two changes (Duke's sign-off; CONTRIBUTING.md v4.20):
 *  - Correction: v4.3's comment here said the 0.47 weight was a share "of occupations". It is
 *    F&O's headline share of US EMPLOYMENT with a computerisation probability above 0.7 (the
 *    in-app v4.3 entry already said so). Used as the weight of a Beta(6,1)/Beta(1,6) mixture it
 *    puts 41.5% of people above 0.7, against 50.1% in the employment-weighted data.
 *  - Recalibrated: the weight is CFG.AUTO_HIGH_SHARE (0.63), sourced at the constant.
 *  - Sampled by inverse CDF, exact for these shapes: Beta(a,1) = U^(1/a) and
 *    Beta(1,b) = 1-(1-U)^(1/b). beta() draws through gamma()'s rejection loop, a VARIABLE number
 *    of RNG calls, so under v4.3-v4.19 any change to the weight re-streamed every later draw of
 *    agent construction and moved the seed-42 regression even with automation off (share 0.47 ->
 *    0.63 moved it to 15.0% / $583,843). Two draws per call, always: the weight now reaches only
 *    the runs that read automationRisk, i.e. those with AI automation on. The switch itself moved
 *    the regression once (every later construction draw shifted). */
/* v5.3 (B1, one engine copy): harness.js now runs this file's engine, so the legacy sampler it used to carry on its own copy lives here, off by default.
 * AUTOMATION_SAMPLER_LEGACY = true restores the v4.3-v4.19 sampler (a mixture weight draw, then a gamma-based Beta draw); with CFG.AUTO_HIGH_SHARE set back to 0.47 it
 * reproduces v4.19 exactly (checked by `node harness.js validate`). The page never sets it. */

// index.html line 2889
var AUTOMATION_SAMPLER_LEGACY = false;

// index.html line 2890
function drawAutomationRisk(){
  if(AUTOMATION_SAMPLER_LEGACY){
    if(RNG()<CFG.AUTO_HIGH_SHARE)return beta(6,1);
    return beta(1,6);
  }
  var c=RNG(),v=RNG();
  return c<CFG.AUTO_HIGH_SHARE?Math.pow(v,1/CFG.AUTO_HIGH_A):1-Math.pow(1-v,1/CFG.AUTO_LOW_B);
}

// index.html line 2898
function makeLatentAgent(){
  var uCCO=RNG(),uPTF=RNG(),uPTH=RNG();  // unconditional — see comment above
  return{uCCO:uCCO,uPTF:uPTF,uPTH:uPTH,
    wealth:lognormal(CFG.WEALTH_INIT_MU,CFG.WEALTH_INIT_SIGMA),wage:lognormal(3.5,0.5),
    octaveShape:beta(2,5),qualityZ:standardNormal(),
    automationRisk:drawAutomationRisk(),lambda:CFG.FBS_LAMBDA_LO+RNG()*(CFG.FBS_LAMBDA_HI-CFG.FBS_LAMBDA_LO)};
}

// index.html line 2905
function makeLatentPopulation(n){var pop=[];for(var i=0;i<n;i++)pop.push(makeLatentAgent());return pop;}

// index.html line 2906
function instantiateAgent(latent,cfgP){
  var qN=cfgP.cip?(1-cfgP.cipDemo*0.5):1.0;
  var maxOct=cfgP.maxOct||1,maxMult=cfgP.maxMult||1;
  var inPTH=!!(cfgP.pth&&latent.uPTH<cfgP.pthUptake);
  return{wealth:latent.wealth,wage:latent.wage,
    /* v4.5: snapshot of year-0 wage, kept alongside the mutable a.wage (which grows
     * every runYear() call). Needed to tag agents into the Social Security-anchored
     * cohorts by their INITIAL wage, matching CONTRIBUTING.md's documented methodology
     * ("agents tagged by initial wage at or below each anchor's SIU-equivalent") — see
     * ssAnchorCohorts(). Purely additive; nothing existing reads this field. */
    initialWage:latent.wage,
    octave:Math.floor(latent.octaveShape*maxOct),
    quality:Math.min(maxMult,Math.max(0,Math.exp(Math.log(maxMult*0.5)+0.4*latent.qualityZ)*qN)),
    automationRisk:latent.automationRisk,lambda:latent.lambda,
    uCCO:latent.uCCO,  // v4.19: kept for deterministic emergency take-up (no RNG)
    inCCO:!!(cfgP.ccoOn&&latent.uCCO<cfgP.partRate),inPTF:!!(cfgP.ptf&&latent.uPTF<cfgP.ptfShare),inPTH:inPTH,
    buBalance:0,acreEquity:inPTH?5000:0,
    /* v4.3: per-agent PTH tenure in years (first step toward tenure-cohort liquidity
     * haircut per BLEI paper Table 1a / CONTRIBUTING.md). Incremented each year the
     * agent remains in PTH; reset to 0 on exit. Variable haircut formula itself is a
     * follow-up PR — this only gets the tracking data flowing and exported. */
    pthTenure:0};
}
/* Retained as a thin wrapper: OAT mini-simulations and the ablation engine each still
 * want one independently-sampled population per call (they don't need cross-population
 * pairing the way the main/baseline/CCO-only comparison does — ablation pairs by reusing
 * the SAME already-built population across removal scenarios, not by regenerating one).
 * Equivalent to instantiateAgent(makeLatentAgent(),cfgP). */

// index.html line 2934
function makeAgent(cfgP){
  return instantiateAgent(makeLatentAgent(),cfgP);
}

/* ─── SIMULATION ENGINE ───────────────────────────────────────────────── */
/* v3.6: Cancel control. Sets a flag checked at the top of step() (per simulated
 * year) and in the multi-run chain in finish() (between chained MC runs), so a
 * long single run or 50× Monte Carlo batch can be interrupted without a reload. */

// index.html line 2947
function resetRunUIAfterCancel(){
  running=false;CANCELLED=false;MR.active=false;MR.suppressUI=false;
  document.getElementById('sdot').className='dot';
  document.getElementById('stxt').textContent='Run canceled.';
  document.getElementById('spct').textContent='';
  document.getElementById('pbar').style.width='0%';
  document.getElementById('run-btn').disabled=false;document.getElementById('run-btn').textContent='▶ Run Simulation';
  var cancelBtn=document.getElementById('cancel-btn');if(cancelBtn)cancelBtn.style.display='none';
  ['multi-btn','mc10-btn','mc50-btn','oat-btn','lhs-btn','val-btn'].forEach(function(id){var el=document.getElementById(id);if(el)el.disabled=false;});
}

// index.html line 2957
function runSim(){
  if(running)return;
  running=true;CANCELLED=false;SIM_GEN++;  // v4.16: see SIM_GEN
  /* v4.0 fix: this line used to unconditionally clear MR.active the instant runSim()
   * started — but runMulti() sets MR.active=true and then calls runSim() immediately,
   * so that flag was wiped before finish() ever got a chance to see it, and finish()'s
   * MC collection/chaining branch (`if(MR.active){...}`) was dead code. The net effect:
   * every 3×/10×/50× Monte Carlo request silently ran exactly once (external review:
   * "The Monte Carlo controls are non-functional"). The Run Simulation button is
   * disabled while running=true, so runSim() is never reachable via a direct user click
   * while a real MC sequence is mid-flight — MR.active being true whenever runSim() is
   * called always legitimately means "part of an MC chain," so simply not touching it
   * here is correct; MR.active is still cleared normally at chain completion (finish())
   * and on cancel (resetRunUIAfterCancel()). */
  var btns=['multi-btn','mc10-btn','mc50-btn','oat-btn','lhs-btn','val-btn'];
  btns.forEach(function(id){var el=document.getElementById(id);if(el)el.disabled=true;});
  var cancelBtn=document.getElementById('cancel-btn');if(cancelBtn)cancelBtn.style.display='block';
  var seedEl=document.getElementById('s-seed'),seedVal=seedEl?seedEl.value.trim():'';
  initRNG(seedVal);
  /* v4.16: capture THIS run's stream now and hand it to simulate() explicitly. simulate()
   * used to read the RNG global 50ms later, inside the setTimeout below — so anything that
   * reassigned the global in that window (a still-running ablation chunk, a validation check)
   * silently became this run's main stream. */
  var runRNG=RNG;
  var buVal=gp('s-bu');
  var p=Object.assign({bu:buVal,maxOct:gp('s-oct'),expiry:gp('s-exp'),tax:gp('s-tax')/100,maxMult:gp('s-mult'),nAgents:Math.round(gp('s-agents')),partRate:gp('s-part')/100,years:Math.round(gp('s-yrs')),ptfShare:gp('s-ptf')/100,pthUptake:gp('s-pth')/100,szhCoh:gp('s-szh')/100,cipDemo:gp('s-cip')/100,phi:ST.phi,ptf:ST.ptf,pth:ST.pth,szh:ST.szh,cip:ST.cip,shock:ST.shock,automation:ST.automation,inflRate:gp('s-infl')/100,ccoOn:buVal>0,ptfCap:ST.ptfCap,baseInflMatch:ST.baseInflMatch,seed:seedVal||null},stabParamsFromUI());  // v4.19
  var warns=[];
  if(p.ccoOn&&p.partRate<CFG.CCO_MIN_PARTICIPATION)warns.push('CCO participation below the papers\' '+Math.round(CFG.CCO_MIN_PARTICIPATION*100)+'% minimum-viable level — a design reference only; this engine models no network effect or collapse below it (v4.17)');
  if(p.ptfShare>CFG.PTF_DISTORTION)warns.push('PTF share above '+Math.round(CFG.PTF_DISTORTION*100)+'%: a caution threshold with no source (the model applies no efficiency loss)');
  if(p.ccoOn&&p.bu<800)warns.push('BU below $800 — poverty reduction targets unlikely');
  if(p.automation&&p.years>10)warns.push('AI automation active — heterogeneous wage displacement after yr 5');
  if(p.inflRate>0.04)warns.push('Inflation >4%/yr — cost compounding significant; PTF/PTH apply deflationary offset');
  if(p.ptf&&p.ptfCap)warns.push('PTF adoption capped at the Initial PTF share slider (v4.6 opt-in) — non-default behavior, see CONTRIBUTING.md');
  /* v4.16: disclose the Baseline inflation mismatch on every run where it exists (see pBase). */
  if(!p.baseInflMatch&&Math.abs(p.inflRate-CFG.BASELINE_CPI_RATE)>1e-9)warns.push('Baseline comparison runs at a fixed '+(CFG.BASELINE_CPI_RATE*100).toFixed(1)+'% CPI vs. your '+(p.inflRate*100).toFixed(1)+'% — every vs-Baseline gap includes this inflation difference, not only policy (turn on Match Baseline inflation to isolate it; v4.16)');
  /* v4.19: disclose opt-in stabilizers, and say so when they cannot act in this run. */
  if(p.stab)warns.push('Automatic BU increase on (v4.19 opt-in): '+stabRuleText(p)+(p.shock?'':' — recessions are off, so it never fires in this run'));
  if(p.cola)warns.push('Cost-of-living adjustment (COLA) on: BU indexed to inflation (v4.19 opt-in)'+(p.inflRate>p.colaThresh?'':' — inflation is not above the '+(p.colaThresh*100).toFixed(1)+'% trigger, so no indexation in this run'));
  if(!MR.suppressUI){
    document.getElementById('run-btn').disabled=true;document.getElementById('run-btn').textContent='⏳ Running…';
    document.getElementById('sdot').className='dot run';document.getElementById('stxt').textContent='Initialising agents…';
    document.getElementById('pbar').style.width='0%';
    ['warn-note','sec-insights','sec-sens','sec-export','sec-attribution','run-conf']  /* session 8: the caveats box (#uncertainty-notice) moved into the front door and stays visible */.forEach(function(id){var el=document.getElementById(id);if(el)el.style.display='none';});
    ['sec-policy-kpis','label-policy','sec-dist-charts','label-dist','sec-milestones','sec-ss-cohorts','sec-strat-kpis','label-strat','sec-strat-charts','label-strat-chart','sec-threshold-sens','label-threshold-sens','sec-exposure-kpis','label-exposure','sec-floor-kpis','label-floor','sec-poverty4','sec-shock'].forEach(function(id){var el=document.getElementById(id);if(el)el.style.display='none';});
  }
  setTimeout(function(){
    RNG=runRNG;  // v4.16: see runRNG above
    try{simulate(p,warns);}
    catch(e){
      running=false;CANCELLED=false;
      document.getElementById('sdot').className='dot';
      document.getElementById('stxt').textContent='Error: '+e.message+' — check console. Try resetting parameters.';
      document.getElementById('run-btn').disabled=false;document.getElementById('run-btn').textContent='▶ Run Simulation';
      var cancelBtnErr=document.getElementById('cancel-btn');if(cancelBtnErr)cancelBtnErr.style.display='none';
      btns.forEach(function(id){var el=document.getElementById(id);if(el)el.disabled=false;});
    }
  },50);
}


// index.html line 3016
function simulate(p,warns){
  var n=p.nAgents,years=p.years;
  var mainRNG=RNG,seedNum=(p.seed!==null&&p.seed!==undefined&&p.seed!=='')?parseInt(p.seed):NaN;

  /* v4.2: canonical latent population, drawn ONCE on its own dedicated stream, then
   * instantiated three times below — once per scenario config — via instantiateAgent()
   * (see its definition, above makeAgent(), for the full rationale). This makes the
   * main run, "CCO Only", and baseline genuinely the same n individuals evaluated under
   * three policies, not three independently-sampled populations that merely share a
   * distribution shape. Closes the open item from the Aug 2026 external review and
   * CONTRIBUTING.md's Model Architecture Feedback ("baseline and CCO-only populations
   * are not actually the same individuals").
   * REPRODUCIBILITY NOTE: this changes the RNG call sequence relative to v4.1, so a given
   * seed no longer reproduces v4.1's numeric output — expected, not a regression; flagged
   * per CONTRIBUTING.md's "intentionally a mechanics fix" PR convention. New seed-42
   * reference numbers are in the v4.1→v4.2 changelog entry, above. */
  RNG=isNaN(seedNum)?mainRNG:mulberry32(seedNum+700003);
  var latentPop=makeLatentPopulation(n);
  RNG=mainRNG;

  var agents=latentPop.map(function(lat){return instantiateAgent(lat,p);});

  /* v4.0: baseline & CCO-only comparison isolation (external review, "Counterfactual
   * scenario isolation" + BLEI paper Table 6 "matched initial agents").
   * v4.4: automation exposure now paired too — was hardcoded false for baseline while
   * CCO-only already mirrored the user's setting below (external audit: "baseline is
   * exempt from AI automation even when the tested scenario enables it," a genuine
   * confound whenever High Automation is toggled on). No effect on the standard
   * reference config, where automation defaults off. */
  var pBase={bu:0,maxOct:1,expiry:1,tax:0,maxMult:1,partRate:0,ptfShare:0,pthUptake:0,szhCoh:0,cipDemo:0,phi:false,ptf:false,pth:false,szh:false,cip:false,
    /* v4.0: paired with the main run's shock toggle (was hardcoded true — "baseline is
       also universally exposed to recessions, even when disabled for the main scenario") */
    shock:p.shock,
    /* v4.0: anchored to the documented "US baseline + 3% CPI" (was copying the user's
       inflation slider — the baseline is meant to be a fixed real-world reference point) */
    inflRate:CFG.BASELINE_CPI_RATE,
    automation:p.automation,ccoOn:false,nAgents:n,years:years};
  /* v4.16: opt-in inflation matching. The fixed 3% anchor above is kept as the DEFAULT so every
   * documented figure is unchanged — but it is a confound whenever the user's slider differs:
   * Full Integration, CCO Only and High AI all run at 0%, so every vs-Baseline gap in those
   * presets mixes the policy effect with a 3-point inflation difference. Measured (harness.js
   * infl-match, seeds 1-500, shocks off): Baseline wealth poverty 71.8% at 3% vs 50.5% at 0%,
   * median pinned at WEALTH_FLOOR in 100% vs 0.6% of runs; Full Integration 15.3% at 0% vs
   * 28.8% at 3% — about 24-38% of the headline poverty gap is inflation, not policy. CCO Only
   * already copies the slider (pCCO, below); with baseInflMatch on, Baseline does too. Changes
   * the Baseline trajectory only — never Your Settings' own. Which should be the default is
   * logged for Duke in CONTRIBUTING.md (Model Architecture Feedback, v4.16). */
  if(p.baseInflMatch)pBase.inflRate=p.inflRate;
  /* v4.0: "CCO Only" now mirrors the user's own CCO-related settings (BU, octave ceiling,
   * tax, quality ceiling, participation rate, Phi, automation) rather than a fixed
   * reference calibration (was: bu 1200/oct 6/tax 12%/mult 9/part 78% regardless of the
   * user's actual configuration — external review: "hardcodes participation at 78%
   * regardless of the selected configuration"). This isolates the marginal effect of
   * PTF/PTH/SZH/CIP specifically: CCO Only vs. Your Settings now differ ONLY in whether
   * those four systems are active, holding every CCO parameter fixed. */
  var pCCO={bu:p.bu,maxOct:p.maxOct,expiry:p.expiry,tax:p.tax,maxMult:p.maxMult,nAgents:n,years:years,partRate:p.partRate,
    ptfShare:0,pthUptake:0,szhCoh:0,cipDemo:0,phi:p.phi,ptf:false,pth:false,szh:false,cip:false,
    shock:p.shock,ccoOn:p.ccoOn,inflRate:p.inflRate,automation:p.automation};
  STAB_KEYS.forEach(function(k){pCCO[k]=p[k];});  // v4.19: the stabilizers are CCO settings, so CCO Only mirrors them

  var baseAgents=latentPop.map(function(lat){return instantiateAgent(lat,pBase);});
  /* v4.4: removed the baseline ×0.85 initial-wealth haircut ("lower savings absent CCO,"
   * v4.0, previously applied here). External audit: baseline agents share the SAME latent
   * draw as CCO-only/main (v4.2's paired population), but CCO hasn't happened yet at year
   * 0 — a haircut applied before any dynamics run embeds part of the treatment effect into
   * the counterfactual's own starting point, breaking the "matched initial agents" premise
   * Table 6 calls for. No externally-sourced justification existed for 0.85 specifically
   * (see the retired UNIT SYSTEM note above). Baseline now starts from literally the same
   * wealth as its matched counterparts, as CCO-only and Main already did. */
  var ccoAgents=latentPop.map(function(lat){return instantiateAgent(lat,pCCO);});

  /* v4.0: paired shock path — see buildRecessionPath. Built on its own dedicated stream so
   * it never perturbs the main trajectory's sequence (mirrors the CRN-paired trajectory
   * streams below, and the +700003 latent-population stream above). */
  /* v4.17: year-0 reference, measured before any trajectory runs (draws no RNG). Wealth
   * poverty and the income measures are policy-neutral: every scenario starts from the same
   * latent population. BLEI is not — agentBLEI() credits BU, γ=0.20 and a reduced daily cost
   * to participants the moment they are enrolled — so the policy-neutral BLEI figure is the
   * Baseline population's (same agents, no program). Both are kept: see NEEC maintainers'
   * notes 3-4 in CHANGELOG.md's v4.17 Release Notes. */
  var yearZero={pov:calcMetrics(baseAgents).pov*100,
    bleiPovNeutral:bleiPovOf(bleiMetrics(baseAgents,0,false,false,false,0,false)),
    bleiPovScenario:bleiPovOf(bleiMetrics(agents,p.bu,p.ccoOn,p.pth,p.szh,p.szhCoh,p.ptf)),
    income:incomeBasketYear0(baseAgents),
    distress:housingDistressYear0(baseAgents)};  // v4.18: policy-neutral housing distress, the extreme-poverty overlay's anchor
  yearZero.ep=extremePovertyOf(yearZero.distress,yearZero.distress,'year0');
  var sharedRecPath=p.shock?buildRecessionPath(years,isNaN(seedNum)?null:seedNum):null;
  function recAt(yr){return sharedRecPath?sharedRecPath[yr]:{active:false,incomeMultiplier:1.0,yearsLeft:0};}

  var baseYearlyPov=[],baseYearlyWealth=[],baseYearlyBLEI=[],baseYearlyBleiPov=[];
  /* v4.4: true common-random-numbers (CRN) pairing across all three scenarios' annual
   * trajectories (external audit, "Counterfactual pairing is improved, but not yet full
   * CRN pairing": baseline/CCO-only previously ran on their own +700001/+700002 offset
   * streams — decorrelated from Main and from each other, not merely from population
   * construction). Since v4.3 made runYear() draw a FIXED count/order of RNG() calls per
   * agent per year regardless of which policy toggles are active (the runYear() RNG-
   * coupling fix), three independent mulberry32(seedNum) closures — same seed, no offset,
   * mathematically identical to what mainRNG itself already resolves to (see mainRNG
   * capture, top of this function) — necessarily produce IDENTICAL draw sequences at each
   * (agent, year) position. Baseline, CCO-only, and Main now all experience the exact same
   * per-agent "luck" each year (wage-variance draw, BU-spend fraction, adoption checks,
   * appreciation noise, etc.); only which policy mechanisms are active differs — isolating
   * the causal/policy effect from Monte Carlo noise, which is what CRN is for. This has NO
   * effect on Main's own trajectory: mulberry32() returns a fresh, independent closure on
   * every call, so creating one here doesn't touch mainRNG's own object/position. The
   * ablation engine (runAblation, below) already used this same same-seed-across-scenarios
   * pattern successfully; this brings the main 3-way comparison in line with it. Population
   * construction (above) still draws from its own separate +700003 stream, unaffected. */
  RNG=isNaN(seedNum)?mainRNG:mulberry32(seedNum);
  for(var bYr=0;bYr<years;bYr++){
    runYear(baseAgents,bYr,pBase,recAt(bYr));
    var mBYr=calcMetrics(baseAgents,false,false);
    baseYearlyPov.push(+(mBYr.pov*100).toFixed(1));baseYearlyWealth.push(mBYr.med);baseYearlyBLEI.push(calcMedianBLEI(baseAgents,pBase));
    /* v4.13: baseline's per-year BLEI-poverty SHARE, for the new Cumulative Poverty
     * Exposure comparison. Baseline's per-year MEDIAN BLEI was already tracked (line
     * above) but a median can't give a poverty headcount. bleiMetrics() is a pure
     * function of current agent state — no RNG draw, no mutation — so adding this call
     * cannot shift the stream position or change any trajectory; confirmed by the
     * unchanged seed-42 regression. */
    var bBYr=bleiMetrics(baseAgents,0,false,false,false,0,false,'Comfortable');
    baseYearlyBleiPov.push(+((bBYr.tc[0]+bBYr.tc[1])/bBYr.n*100).toFixed(1));
  }
  var mBase=calcMetrics(baseAgents,false,false),bBase=bleiMetrics(baseAgents,0,false,false,false,0,false,'Comfortable');
  var stabBase=structuralStability(baseYearlyWealth,baseYearlyBLEI);
  /* v4.10: final-year sorted wealth/BLEI distributions, captured here purely for the new
   * Threshold Sensitivity charts (see renderThresholdSensitivity, below) — a reporting-only
   * transform of state that already exists at this point in the function; computes nothing
   * new about the agents themselves and touches no RNG. See that function's own comment for
   * the full rationale. */
  var wDistBase=sortedWealthArr(baseAgents),bDistBase=sortedBLEIArr(baseAgents,0,false,false,false,0,false);
  /* v4.14: Wealth Floor Diagnostic — Baseline's share, computed here where baseAgents is
   * still in scope (mirrors how wDistBase/bDistBase are captured at this exact point).
   * Pure snapshot of already-final agent state; no RNG, no new simulation. */
  var atFloorBase=baseAgents.filter(function(a){return a.wealth<=CFG.WEALTH_FLOOR+1e-6;}).length/baseAgents.length;

  var ccoYearlyWealth=[],ccoYearlyBLEI=[];
  RNG=isNaN(seedNum)?mainRNG:mulberry32(seedNum);  // v4.4: CRN-paired with baseline/Main — see comment above
  for(var cYr=0;cYr<years;cYr++){
    runYear(ccoAgents,cYr,pCCO,recAt(cYr));
    var mCYr=calcMetrics(ccoAgents,pCCO.ccoOn,false);
    ccoYearlyWealth.push(mCYr.med);ccoYearlyBLEI.push(calcMedianBLEI(ccoAgents,pCCO));
  }
  var mCCO=calcMetrics(ccoAgents,pCCO.ccoOn,false),bCCO=bleiMetrics(ccoAgents,pCCO.bu,pCCO.ccoOn,false,false,0,false,'Comfortable');
  var stabCCO=structuralStability(ccoYearlyWealth,ccoYearlyBLEI);
  var wDistCCO=sortedWealthArr(ccoAgents),bDistCCO=sortedBLEIArr(ccoAgents,pCCO.bu,pCCO.ccoOn,false,false,0,false);
  /* v4.10: bundles Baseline's and CCO-Only's distributions (Main's own is computed inside
   * finish() itself, where the already-final `agents` array is in scope) into one object so
   * only a single new parameter needs threading through the step()/finish() call below,
   * rather than four more positional ones on an already-27-parameter function.
   * v4.13: renamed to `extras` and given a second key, so this release adds NO new
   * positional parameter at all. A partial, deliberately minimal nod to the external
   * audit's "replace positional arguments with a context object" suggestion — the full
   * refactor across agentBLEI()/bleiMetrics()/runYear() remains open (see CONTRIBUTING.md
   * Good First Issues) because it touches the mechanics engine's own signatures and needs
   * its own regression pass; changing the shape of one already-bundled reporting argument
   * does not. */
  var extras={thresh:{wealth:{base:wDistBase,cco:wDistCCO},blei:{base:bDistBase,cco:bDistCCO}},baseBleiPovYearly:baseYearlyBleiPov,atFloorBase:atFloorBase,
    yearZero:yearZero,ibBase:incomeBasketMetrics(baseAgents),ibCCO:incomeBasketMetrics(ccoAgents),bleiPovCCO:bleiPovOf(bCCO),  // v4.17: +yearZero, income/basket
    epBase:extremePovertyOf(housingDistressOf(baseAgents),yearZero.distress,pBase),epCCO:extremePovertyOf(housingDistressOf(ccoAgents),yearZero.distress,pCCO)};  // v4.18: extreme-poverty overlay
  extras.stabRun=newStabRun();  // v4.19: Your Settings' stabilizer tally, filled in step()
  RNG=mainRNG;

  var yLabels=[],aPov=[],aGini=[],aWealth=[],aVel=[],aBlei=[];
  var aP10=[],aP90=[],aTiersDist=[],aCash=[],aInc=[],aBen=[];
  var aPartPov=[],aNonPartPov=[],aPartBLEI=[],aNonPartBLEI=[];
  var breakEvenYr=null,totalConversionAll=0;

  function step(yr){
    if(CANCELLED){resetRunUIAfterCancel();return;}
    /* v4.16 fix: re-assert this trajectory's own stream at the top of every simulated year.
     * step() yields to the event loop between years (setTimeout, below), and until v4.15 it
     * simply assumed nothing else had touched the RNG global in the meantime. Two things did:
     * runAblation() left the global on ITS stream between chunks and, when done, restored a
     * stream saved before the new run began; and every VAL_TESTS check called initRNG()
     * without restoring. A seed-42 Full Integration run started while the previous run's
     * attribution was still computing gave median wealth $545,506, and one started during
     * the validation suite $555,354 — not the documented $559,223 (reproduced in jsdom
     * against the unmodified v4.15 page). In an uninterrupted run this line is a no-op —
     * RNG already IS mainRNG here — so no documented figure moves. */
    RNG=mainRNG;
    if(yr>=years){finish(p,warns,agents,yLabels,aPov,aGini,aWealth,aVel,aBlei,aP10,aP90,aTiersDist,aCash,aInc,aBen,aPartPov,aNonPartPov,aPartBLEI,aNonPartBLEI,mBase,mCCO,bBase,bCCO,baseYearlyPov,breakEvenYr,totalConversionAll,stabBase,stabCCO,extras);return;}
    var yrRes=runYear(agents,yr,p,recAt(yr));
    var vel=yrRes.bu;totalConversionAll+=yrRes.conversion;
    accStabYear(extras.stabRun,yrRes,p,recAt(yr));  // v4.19 (reporting only)
    var m=calcMetrics(agents,p.ccoOn,p.pth),bMed=calcMedianBLEI(agents,p);
    yLabels.push('Yr '+(yr+1));
    aPov.push(+(m.pov*100).toFixed(1));aGini.push(+m.gini.toFixed(3));
    aWealth.push(Math.round(m.med));aVel.push(Math.round(vel/n));aBlei.push(Math.round(bMed));
    aP10.push(Math.round(m.p10));aP90.push(Math.round(m.p90));
    var tc=[0,0,0,0,0,0];agents.forEach(function(a){tc[getTier(agentBLEI(a,p.bu,p.ccoOn,p.pth,p.szh,p.szhCoh,p.ptf)).num]++;});
    aTiersDist.push(tc.map(function(c){return+(c/n*100).toFixed(1);}));
    var comp=calcBLEIComponents(agents,p);aCash.push(+comp.cash.toFixed(1));aInc.push(+comp.inc.toFixed(1));aBen.push(+comp.ben.toFixed(1));
    /* v3.3: participant stratification */
    var pArr=agents.filter(function(a){return a.inCCO;}),npArr=agents.filter(function(a){return !a.inCCO;});
    aPartPov.push(pArr.length?+(calcMetrics(pArr,p.ccoOn,p.pth).pov*100).toFixed(1):null);
    aNonPartPov.push(npArr.length?+(calcMetrics(npArr,p.ccoOn,p.pth).pov*100).toFixed(1):null);
    aPartBLEI.push(pArr.length?Math.round(calcMedianBLEI(pArr,p)):null);
    aNonPartBLEI.push(npArr.length?Math.round(calcMedianBLEI(npArr,p)):null);
    if(breakEvenYr===null&&baseYearlyPov[yr]!==undefined&&aPov[aPov.length-1]<baseYearlyPov[yr])breakEvenYr=yr+1;
    if(!MR.suppressUI){
      var pct=Math.round((yr+1)/years*100);
      document.getElementById('pbar').style.width=pct+'%';
      document.getElementById('stxt').textContent='Simulating year '+(yr+1)+' of '+years+(MR.active?' ['+MR.current+'/'+MR.numRuns+']':'')+'…';
      document.getElementById('spct').textContent=pct+'%';
    } else {
      var op=Math.round((MR.current/MR.numRuns+(yr+1)/(years*MR.numRuns))*100);
      document.getElementById('pbar').style.width=op+'%';
      document.getElementById('stxt').textContent='MC run '+(MR.current+1)+'/'+MR.numRuns+' — year '+(yr+1)+'/'+years+'…';
    }
    setTimeout(function(){step(yr+1);},0);
  }
  step(0);
}

/* ─── v4.19: AUTOMATIC STABILIZERS — reporting and the shock-response study ─────────────
 * The levers themselves live in runYear() (see "v4.19: automatic stabilizers" there): a
 * recession-triggered BU increase (fixed multiplier, or scaled to the recession's income
 * loss), suspended BU expiry and emergency enrollment of non-participants while triggered,
 * and COLA indexation of BU. All are off by default, so no documented figure moves.
 *
 * The study below answers the question the feature exists for: how much of a recession's
 * rise in housing distress does a given rule offset, and what multiplier offsets all of it
 * for CCO participants ("shock-neutral")? Each seed is run with recessions off (the
 * counterfactual) and on, for several rules. Every run uses the same latent population
 * (seed+700003), the same recession path (seed+700000) and the same main stream (seed), and
 * runYear() draws exactly 8 RNG values per agent-year whatever the rule, so the arms are
 * common-random-number paired and the difference in any recession year is the rule's effect.
 * harness.js shockRun()/shockStudy() mirror these functions line for line; domtest.js checks
 * that page and harness agree exactly. See CONTRIBUTING.md v4.19. */

// index.html line 3245
var STAB_KEYS=['stab','stabSev','stabMult','stabK','stabThresh','stabSusp','emerg','emergTakeup','cola','colaThresh'];

// index.html line 3246
function stabParamsFromUI(){
  return{stab:!!ST.stab,stabSev:!!ST.stabSev,stabMult:gp('s-stabm'),stabK:gp('s-stabk'),stabThresh:gp('s-stabth')/100,
    stabSusp:!!ST.stabSusp,emerg:!!ST.emerg,emergTakeup:gp('s-emtk')/100,cola:!!ST.cola,colaThresh:gp('s-colath')/100};
}
/* Per-run tally from runYear()'s return value. BU amounts are in the engine's own unit: one
 * allocation of p.bu per agent per simulated year (see the Known Limitations entry on the BU
 * allocation cadence), so they are reported as shares of the base allocation, never as dollars. */

// index.html line 3253
function newStabRun(){return{recYears:0,firedYears:0,base:0,stabExtra:0,colaExtra:0,emergAgentYears:0,emergAlloc:0};}

// index.html line 3254
function accStabYear(S,yrRes,p,rec){
  if(!S||!yrRes)return;
  if(rec&&rec.active)S.recYears++;
  if(yrRes.stabOn)S.firedYears++;
  if(p.ccoOn&&p.bu>0){S.base+=p.bu;S.stabExtra+=p.bu*yrRes.colaF*(yrRes.stabM-1);S.colaExtra+=p.bu*(yrRes.colaF-1);}
  S.emergAgentYears+=yrRes.emergN||0;S.emergAlloc+=(yrRes.emergN||0)*(yrRes.buEff||0);
}

// index.html line 3262
function stabRuleText(p){
  if(!p.stab)return 'off';
  return (p.stabSev?'+'+(+p.stabK).toFixed(1)+'% BU per 1% income loss':'×'+(+p.stabMult).toFixed(2)+' BU')+' when income falls ≥'+Math.round((p.stabThresh||0)*100)+'%'+
    (p.stabSusp?', expiry suspended':'')+(p.emerg?', emergency enrollment '+Math.round((p.emergTakeup||0)*100)+'%':'');
}

/* One paired run: distress by group and year, recession flags, BU issued. */

// index.html line 3269
function shockRun(p,seed){
  RNG=mulberry32(seed+700003);
  var ag=makeLatentPopulation(p.nAgents).map(function(l){return instantiateAgent(l,p);});
  var d0=housingDistressYear0(ag);
  var rp=p.shock?buildRecessionPath(p.years,seed):null;
  RNG=mulberry32(seed);
  var part=ag.filter(function(a){return a.inCCO;}),non=ag.filter(function(a){return !a.inCCO;});
  var o={dPart:[],dNon:[],dAll:[],rec:[],d0:d0,base:0,extra:0};
  for(var y=0;y<p.years;y++){
    var rs=rp?rp[y]:{active:false,incomeMultiplier:1.0,yearsLeft:0};
    var r=runYear(ag,y,p,rs);
    o.rec.push(!!rs.active);
    o.dPart.push(part.length?housingDistressOf(part):0);o.dNon.push(non.length?housingDistressOf(non):0);o.dAll.push(housingDistressOf(ag));
    if(p.ccoOn&&p.bu>0){o.base+=p.bu*part.length;o.extra+=p.bu*r.colaF*(r.stabM-1)*part.length;}
    o.extra+=(r.emergN||0)*(r.buEff||0);
  }
  return o;
}

// index.html line 5213
function runYear(agentSet,yr,p,recSt){
  var totalBU=0,totalConversion=0;recSt=recSt||{active:false,incomeMultiplier:1.0,yearsLeft:0};
  if(AGE&&AGS&&yr>0)ageYear(agentSet,yr,p);  // v5.2 step 4: deaths, new adults, a year older (own random stream)
  if(ACCT)acctYearStart(agentSet,yr);  // v5.3 B2: the accounting check (off by default; no RNG, nothing any rule reads)
  var HHON=!!HOUSEHOLDS&&!!HHS&&(CONVERSION_MODEL==='framework'||!p.ccoOn),HHPOOL=HHON&&HOUSEHOLDS.pool!=='individual';if(HHON)hhYear(agentSet);  // v5.3 B3: households (no RNG)
  var pthApprBonus=p.szh?p.szhCoh*0.01:0;
  var szhThetaVal=p.szh?szhTheta(p.szhCoh):0;
  if(THETA_GATE==='density'){var tdN=0;if(p.ptf)agentSet.forEach(function(a){if(a.inPTF)tdN++;});THETA_DENS=tdN/Math.max(1,agentSet.length);szhThetaVal=p.szh?szhTheta(THETA_DENS):0;}  // session 5 (C08/d12): harness-only
  var ptfConvBonus=1.30+((p.szh&&p.ptf)?szhThetaVal:0);
  var szhPartBoost=(p.szh&&p.ccoOn)?szhThetaVal*0.16:0;
  /* v4.14 parity fix — ported from index.html: PTF's inflation-damping term used to read
   * the static initial-share slider (p.ptfShare) rather than the population's actual
   * current PTF membership, which this same function already computes a few lines later
   * (for the Bass-diffusion adoption term) but never reused here. ptfAdoptFrac is moved up
   * and reused for both purposes — it draws no RNG, so this reordering shifts no draw
   * anywhere in the function. Verified inert on the documented seed-42/Full Integration
   * regression (inflRate=0 there, so the guard never fires); see CONTRIBUTING.md's v4.14
   * Release Notes for the full trail and measured effect size on configs it does touch. */
  var ptfAdoptFrac=0;
  if(PTFS&&PFS&&p.ptf)ptfsYear(agentSet,yr);  // v5.4 item 4: PTF leavers and this year's member share
  if(p.ptf&&p.ptfShare>0){var ptfCount0=0;agentSet.forEach(function(a){if(a.inPTF)ptfCount0++;});ptfAdoptFrac=ptfCount0/Math.max(1,agentSet.length);}
  /* v4.15 parity fix — ported from index.html: PTH's inflation damping used to be the flat,
   * toggle-triggered `inflRate*=0.90` below — the same defect class the v4.14 PTF fix closed
   * one line above it, in a coarser form (it referenced no adoption-scale quantity at all,
   * so 5% PTH uptake got the identical 10% population-wide reduction as 50%). Unlike PTF,
   * PTH membership is drawn once at construction and never changes during a run, so
   * pthMemberFrac is simply the population's fixed realised PTH share — counted the same
   * no-RNG way as ptfAdoptFrac (existing a.inPTH flags only), so no draw shifts anywhere.
   * Verified inert on the documented seed-42/Full Integration regression (inflRate=0 there)
   * and on Baseline (pth=false); see CONTRIBUTING.md's v4.15 Release Notes. */
  var pthMemberFrac=0;
  if(p.pth){var pthCount0=0;agentSet.forEach(function(a){if(a.inPTH)pthCount0++;});pthMemberFrac=pthCount0/Math.max(1,agentSet.length);}
  var inflRate=p.inflRate||0;
  if(p.ptf&&inflRate>0&&!(PRICE&&PRICE.noDamp))inflRate*=(1-ptfAdoptFrac*0.5);  // session 2: PRICE.noDamp (price module only)
  /* v4.15: (1-pthMemberFrac*0.10) replaces the flat *0.90. The 0.10 coefficient (=1-0.90) is
   * unchanged from the historical value and is now the ceiling reached at 100% membership. */
  if(p.pth&&inflRate>0&&!(PRICE&&PRICE.noDamp))inflRate*=(1-pthMemberFrac*0.10);
  var dollarCost=CFG.BASE_DAILY_COST*365*Math.pow(1+inflRate,yr);
  if(HEALTH&&HLS)hlYear(agentSet,yr,p,HHON,inflRate);  // session 2a: health coverage (setting A); off by default; its own hashed draws, none from any stream
  if(PRICE)dollarCost*=PRICE.bIdx;  // session 2: endogenous basket index (price module only)
  var popShock=recSt.active?recSt.incomeMultiplier:1.0;
  if(EMPL&&EMPL.rec==='replace'&&recSt.active)popShock=1-Math.max(0,(1-popShock)-(CFG.EMPL_P_REC*CFG.EMPL_W_REC-CFG.EMPL_P*CFG.EMPL_W)/52);  // v5.4 item 2: the recession's job loss is not counted twice
  var mlNT=0;  // v5.2 step 6: the share added to every worker's wage by spending that fills idle labour in a year without a recession
  var hcM=0;if(HCAP){if(yr===0||!HCS)HCS={m:0,hb:0,h:0,mSum:0};else{HCS.m=HCS.h>0?HCAP.c*HCS.hb/HCS.h:0;HCS.hb=0;HCS.h=0;}hcM=HCS.m;HCS.mSum+=hcM;}  // v5.2 step 7: this year's rent mark-up outside PTH, from last year's flows
  if(MULT&&TB&&p.tb){if(yr===0||!MLS)MLS={push:0,y:[]};var mlFill=0,mlLoss=0,mlRest=0;  // plan step 16: the spending layer (testbed only; no RNG)
    if(recSt.active&&popShock<1&&MLS.push>0){var mlW=0;agentSet.forEach(function(a){if(!isNaN(a.wage)&&a.wage>0)mlW+=a.wage*12*CFG.WAGE_TO_USD;});mlLoss=(1-popShock)*mlW;
      if(mlLoss>0){mlRest=Math.min(mlLoss,MULT_LS*MULT.m*MLS.push);mlFill=mlRest/mlLoss;popShock+=(1-popShock)*mlFill;}}
    else if(MULT.nt&&!recSt.active&&MLS.push>0){var ntW=0;agentSet.forEach(function(a){if(!a._ret&&!isNaN(a.wage)&&a.wage>0)ntW+=a.wage*12*CFG.WAGE_TO_USD;});  // v5.2 step 6: normal-times slack
      if(ntW>0){mlRest=Math.min(MULT.nt.s*ntW,MULT_LS*MULT.nt.m*MLS.push);mlNT=mlRest/ntW;}}
    MLS.y[yr]={fill:mlFill,loss:mlLoss,rest:mlRest,push:MLS.push};if(MULT.nt){MLS.y[yr].nt=mlNT;MLS.y[yr].ntR=mlNT>0?mlRest:0;}}
  var ptfLiveCount=0,ptfLiveTotal=agentSet.length;
  if(p.ptf&&p.ptfCap){agentSet.forEach(function(a){if(a.inPTF)ptfLiveCount++;});}
  var PDON=!!PROD&&CONVERSION_MODEL==='framework'&&!!p.ptf&&PROD.cap==='ptf',pdCap=1,pdLive=0;  /* plan step 2: PTF capacity (no RNG) */
  if(PDON){if(yr===0||!PDS){var pdN0=0;agentSet.forEach(function(a){if(a.inPTF)pdN0++;});PDS={c0:pdN0/Math.max(1,agentSet.length),y:[]};}
    var pdK=SURP?SURP.K:Infinity,pdA=(yr>0&&SURP&&SPS)?SPS.capPA:0;pdCap=pdK<=0?1:Math.min(1,PDS.c0+pdA/pdK);
    agentSet.forEach(function(a){if(a.inPTF)pdLive++;});
    var pdOwn=pdCap,pdBor=0;if(PROD.speed==='oneyear'){if(yr>0&&pdK<Infinity&&pdK>0){pdCap=Math.min(1,Math.max(pdOwn,(pdLive+(PDS.blk||0))/Math.max(1,agentSet.length)));pdBor=Math.max(0,pdCap-pdOwn)*pdK;}PDS.blk=0;PDS.borPA=pdBor;}  // plan step 15 (d137): last year's unmet demand is served this year; the capacity reinvestment has not paid for is borrowed (year-0 $ per adult)
    PDS.y[yr]={cap:pdCap,mem:pdLive/Math.max(1,agentSet.length),own:pdOwn,bor:pdBor};}
  function ptfCapAllows(){return (!p.ptfCap||ptfLiveCount<ptfLiveTotal*p.ptfShare)&&(!PDON||pdLive<ptfLiveTotal*pdCap);}
  var popAIDisp=0;
  if(p.automation){
    if(yr>=CFG.AI_DISPLACEMENT_YEAR_2)popAIDisp=CFG.AI_DISPLACEMENT_RATE_1*(CFG.AI_DISPLACEMENT_YEAR_2-CFG.AI_DISPLACEMENT_YEAR_1)+CFG.AI_DISPLACEMENT_RATE_2*(yr-CFG.AI_DISPLACEMENT_YEAR_2+1);
    else if(yr>=CFG.AI_DISPLACEMENT_YEAR_1)popAIDisp=CFG.AI_DISPLACEMENT_RATE_1*(yr-CFG.AI_DISPLACEMENT_YEAR_1+1);
    popAIDisp=Math.min(0.10,popAIDisp);
  }
  /* v4.19: automatic stabilizers (Research Hub Integrated Implementation Roadmap, Appendix G).
   * All off by default: with p.stab and p.cola unset, buEff===p.bu exactly (a multiply by 1),
   * emergLine is -1 and decay is untouched, so every documented figure is bit-identical.
   *  - Recession trigger: the year's recession is active and its population income loss
   *    (1 - incomeMultiplier) is at least p.stabThresh. The engine has no GDP or unemployment
   *    rate, so the hub's ">2% GDP decline" is read as a >=2% income loss; every engine
   *    recession (5-30%) clears it. The trigger reads the CURRENT year's shock (a timely
   *    trigger); harness.js measures what a one-year data lag costs.
   *  - Increase: fixed multiplier p.stabMult, or scaled 1 + p.stabK x loss (p.stabSev).
   *  - COLA: BU indexed by the same cost index mainLoopCostUSD uses, (1+inflRate)^yr, when the
   *    headline rate p.inflRate is above p.colaThresh (Inflation Surge Protocol: 5%).
   *    Inflation is a constant input rate here, so the threshold acts for the whole run.
   *  - buEff replaces p.bu at every read below: allocation, the 3x cap, FBS, and the BLEI
   *    check that gates the wage-growth bonus.
   *  - Suspended expiry (p.stabSusp, hub Natural Disaster Response): unspent BU carries over
   *    while triggered, up to the 3x cap.
   *  - Emergency enrollment (p.emerg, hub "relax requirements"): while triggered, a
   *    non-participant whose latent CCO uniform lies in [partRate, partRate + take-up x
   *    (1 - partRate)) gets the CCO cost relief for that year only. Deterministic: it reads
   *    a.uCCO, drawn at construction, so no RNG draw is added and CRN pairing holds.
   *    Enrollees do not enter octave advancement or conversion.
   * No RNG is drawn here. */
  var stabLoss=recSt.active?Math.max(0,1-recSt.incomeMultiplier):0;
  var stabOn=!!(p.stab&&p.ccoOn&&recSt.active&&stabLoss>=(p.stabThresh||0));
  var stabM=stabOn?(p.stabSev?1+Math.max(0,p.stabK||0)*stabLoss:Math.max(1,p.stabMult||1)):1;
  var colaF=(p.cola&&(p.inflRate||0)>(p.colaThresh||0))?Math.pow(1+inflRate,yr):1;
  /* Session 2, price module only: COLA reads the headline rate, exogenous plus endogenous, year by year, and ratchets BU
   * up to the full price index in any year that rate exceeds p.colaThresh (Inflation Surge Protocol, 5% in D6). */
  if(PRICE){var pmFull=Math.pow(1+inflRate,yr)*PRICE.bIdx;if(p.cola&&pmFull/PRICE.lastFull-1>(p.colaThresh||0))PRICE.colaLevel=pmFull;PRICE.lastFull=pmFull;colaF=p.cola?PRICE.colaLevel:1;}
  var buEff=p.bu*stabM*colaF;if(PRICE)PRICE.buY=buEff;  // v5.2 step 8: this year's BU a month, for the purchasing-power path (reporting only)
  var agP=Math.pow(1+inflRate,yr)*(PRICE?PRICE.bIdx:1);  // v5.2 step 4: the price level the benefit moves with (read only when AGE is on)
  var svF=0;if(SAVE){var svP=Math.pow(1+inflRate,yr)*(PRICE?PRICE.bIdx:1);if(yr===0||!SVS)SVS={prevP:svP,intR:0,realR:0};else svF=(svP/SVS.prevP)*(1+SAVE.r)-1;var svPp=SVS.prevP;SVS.prevP=svP;}  // v5.2 step 3: savings that keep up with prices (no RNG)
  var tbY=(TB&&p.tb)?tbYear(p,colaF):null;  // session 6 (A4 testbed): null unless TB and p.tb are both set (harness-only; no RNG)
  if(SNET&&SNS&&tbY)snYear(agentSet,yr,HHON,inflRate);  // session 2b: today's safety net (SNAP, EITC, the refundable CTC), set on last year's income; off by default; no stream drawn
  if(DIS&&DSS)disYear(agentSet,yr,agP);  // v5.4 item 5: who the disaster hits (and, later, who has recovered)
  if(PTHB&&PBS&&p.pth)pthbYear(agentSet,yr,agP);  // v5.4 item 3: the year's price rise, PTH leavers and their homes' new members
  if(JOIN&&CONVERSION_MODEL==='framework'&&p.ccoOn){  /* plan step 4: open enrolment (no RNG) */
    if(yr===0||!JNS){JNS={y:[],join:0,leave:0};agentSet.forEach(function(a){a._jnY=0;});}
    var jnN=0,jnJ=0,jnL=0;
    if(yr>0){var jnIdx=Math.pow(1+inflRate,yr)*(PRICE?PRICE.bIdx:1),jnM=CFG.LIVING_WAGE_ANNUAL*jnIdx,jnE=0,jnTx=DISC_BASE==='pretax';
      buEss().forEach(function(k){jnE+=CFG.BASKET[k]*(PRICE?PRICE.comp[k]:1);});if(PRICE)jnE/=PRICE.bIdx;  // v5.3 B3f: what BU can buy
      var jnF=CFG.BASKET.food*(PRICE?PRICE.comp.food/PRICE.bIdx:1),jnH=CFG.BASKET.housing*(PRICE?PRICE.comp.housing/PRICE.bIdx:1),jnRs=PTH_MODE!=='basket'||DISC_BASE!=='basket';
      agentSet.forEach(function(a){var jHH=HHON&&a._hh&&!a._hh.single,ef=jHH?a._hhE:jnE,u=1,jF=jHH?a._hhFd:jnF,jH=jHH?a._hhH:jnH,jM=jHH?jnM*a._hhF:jnM,jB=jHH?buEff*a._hhBU:buEff;if(a._ret&&AGE&&AGE.ret==='none'){a.inCCO=false;return;}/* v5.2 step 4: under 'none' a retiree is outside the programme */  /* v5.3 B3: a household member's share of the household's essentials and BU */
        if(p.ptf&&a.inPTF){if(PTFS){var jnC=1-ptfsCut(a,jHH,p,true);ef=ef*jnC;if(jnRs)u=jnC;}else if(PTF_MODE==='shipped'){ef=ef*(1-(p.szh?0.12+p.szhCoh*0.04:0.12));if(jnRs)u=1-(p.szh?0.12+p.szhCoh*0.04:0.12);}else ef=ef-PTF_FOOD_CUT[PTF_MODE]*jF;}
        if(p.pth&&a.inPTH&&!PATHWAY_OFF.pthCost){if(PTH_MODE==='housing')ef-=PTH_HOUSING_CUT*jH*u;else ef*=0.65;}
        var use=Math.min(12*jB,jM*ef),cost=JOIN.cost==='none'?0:12*p.bu*(typeof a.uCCO==='number'?a.uCCO:1)/Math.max(1e-9,p.partRate)*(JOIN.cost==='nominal'?1:jnIdx),want=p.bu>0&&use>=cost;
        if(a.inCCO&&!want&&yr-a._jnY>=JOIN.stay){a.inCCO=false;a._jnY=yr;jnL++;}
        else if(!a.inCCO&&want){a.inCCO=true;a._jnY=yr;jnJ++;}});if(HHON)hhSync('cco');}  // v5.3 B3: partners follow the first adult
    agentSet.forEach(function(a){if(a.inCCO)jnN++;});JNS.join+=jnJ;JNS.leave+=jnL;JNS.y[yr]={part:jnN/Math.max(1,agentSet.length),join:jnJ,leave:jnL};
  }
  var emergLine=(stabOn&&p.emerg)?p.partRate+Math.max(0,Math.min(1,p.emergTakeup||0))*(1-p.partRate):-1;
  var emergN=0;
  /* v4.19, Duke's decision (Option B): CCO's cost relief scales with the effective BU. Through
   * v4.18 it was a flat 0.80 whenever BU > 0, so the BU amount reached a household only through
   * conversion proceeds, credited once a year. BU is "redeemable at PTF businesses for essential
   * goods" (Research Hub glossary), so the amount now moves the relief directly: 20% of the
   * basket at the $1,200 reference, in proportion above and below it, capped at 50%. At $1,200
   * this is exactly 0.80, so every $1,200 preset and the seed-42 regression are bit-identical;
   * Stress Test ($900) and any run at another BU amount move. The 50% cap is a placeholder. */
  /* v4.21 units fix, ported from index.html (see its comment): the relief share reads BU in
   * year-0 dollars, buEff / priceIdx. RELIEF_PRICE_LEGACY (harness-only) restores v4.19-v4.20. */
  var priceIdx=RELIEF_PRICE_LEGACY?1:Math.pow(1+inflRate,yr);
  if(PRICE&&!RELIEF_PRICE_LEGACY)priceIdx*=PRICE.bIdx;  // session 2: BU erodes with the endogenous index too
  var ccoReliefF=CCO_RELIEF_FLAT?0.80:1-Math.min(CFG.CCO_RELIEF_CAP,CFG.CCO_RELIEF_AT_REF*buEff/(CFG.CCO_RELIEF_REF_BU*priceIdx));
  if(LEDGER){LEDGER.idx=Math.pow(1+inflRate,yr);var LY0=LEDGER.y[yr]||(LEDGER.y[yr]={});LY0.pIdx=LEDGER.idx;}  // A1 ledger (reporting only): this year's price index, the one mainLoopCostUSD uses
  /* Session 2: framework conversion state (N1-N4) and the basket's current essentials and food shares (price module). */
  var FWON=CONVERSION_MODEL==='framework';
  if(FWON){if(yr===0||!FWS)FWS={prev:null};FWS.next={bizBU:0,projBU:0,expiredBU:0,destroyedBU:0,wSum:0,pwSum:0,projAlloc:0,projGross:0,projTax:0,projNet:0,projLost:0,bizPaid:0};}
  var PJON=!!PROJ,pjPay=0,pjIdx=1,pjCipB=1,pjFg=0;  /* N1 (session 15): project hiring; see PROJ. No RNG is drawn in any PROJ step. */
  if(PJON){
    if(yr===0||!PJS)PJS={prev:null,acc:pjNewAcc()};PJS.next={pool:0,gpool:0};  // gpool: the launch gift's share, tracked for financing (d66)
    pjIdx=Math.pow(1+inflRate,yr)*(PRICE?PRICE.bIdx:1);pjPay=PROJ.pay*pjIdx;pjCipB=p.cip?(1+p.cipDemo*0.12):1.0;
    var pjP=[],pjWt=0,pjWR=0,pjIn=PJS.prev?PJS.prev.pool+PJS.prev.gpool:0,pjCarry=0;pjFg=pjIn>0?PJS.prev.gpool/pjIn:0;
    if(REVIEW&&REVS)agentSet.forEach(function(a){a._rvU=REVS.rng();});  // v5.2 step 7: one number per adult a year from the review stream
    if(p.ccoOn)agentSet.forEach(function(a){if(!a.inCCO)return;if(a._ret&&AGE&&AGE.ret==='noconv'){a._pjBU=0;return;}/* v5.2 step 4: no conversion after retirement under 'noconv' */var r=pjOwnRate(a,p,ptfConvBonus),cap=12*FW.octaveCapBase*Math.pow(2,a.octave),w=cap*Math.max(0,a.quality);
      a._pjR=r;a._pjCap=cap;a._pjW=w;a._pjBU=0;pjWt+=w;pjWR+=w*r;pjP.push(a);});
    var pjRc=pjWt>0?pjWR/pjWt:1,pjSet=[];PJS.acc.rc+=pjRc;PJS.acc.rcN++;
    pjP.forEach(function(a){var ru=PROJ.rate==='max'?Math.max(a._pjR,pjRc):a._pjR,v=pjPay*ru*(1-pjTax(p,ru))*pjCipB,h=a.wage*12*CFG.WAGE_TO_USD/PROJ.hrsYr;
      a._pjRu=ru;a._pjWill=v>(a._ret?0:h);/* v5.2 step 4: a retiree gives up no wage for project hours */if(PROJ.alloc==='capqAll'||a._pjWill)pjSet.push(a);});
    if(pjIn>0&&pjSet.length){
      if(PROJ.alloc==='low'){pjSet.sort(function(x,y){return x.wage-y.wage;});var pjL=pjIn;for(var pjI=0;pjI<pjSet.length&&pjL>0;pjI++){var pjT=Math.min(pjL,pjSet[pjI]._pjCap);pjSet[pjI]._pjBU=pjT;pjL-=pjT;}pjCarry=pjL;}
      else if(PROJ.alloc==='equal'){pjSet.forEach(function(a){a._pjBU=pjIn/pjSet.length;});}
      else{var pjS=0;pjSet.forEach(function(a){pjS+=a._pjW;});if(pjS>0)pjSet.forEach(function(a){a._pjBU=pjIn*a._pjW/pjS;});else pjCarry=pjIn;}
    } else pjCarry=pjIn;
    pjP.forEach(function(a){if(a._pjBU>0){PJS.acc.alloc+=a._pjBU/pjIdx;PJS.acc.work++;if(!a._pjWill)PJS.acc.unwilling++;}});
    PJS.acc.carry=pjCarry/pjIdx;PJS.next.pool+=pjCarry*(1-pjFg);PJS.next.gpool+=pjCarry*pjFg;PJS.acc.partY+=pjP.length;
    if(yr===0&&PROJ.giftMode==='forward'&&PROJ.gift>0){PJS.next.gpool+=PROJ.gift*pjP.length;if(ACCT)ACCT.cur.gift+=PROJ.gift*pjP.length;PJS.acc.gift+=PROJ.gift*pjP.length;PJS.acc.pool+=PROJ.gift*pjP.length;}
    if(yr===1&&PROJ.giftMode==='holder'&&PROJ.gift>0)pjP.forEach(function(a){a._pjGiftH=(a._pjGiftH||0)+PROJ.gift;PJS.acc.gift+=PROJ.gift;if(ACCT)ACCT.cur.gift+=PROJ.gift;});
  }
  var ESON=FWON&&!!ESP,esIdx=1,esCipB=1;  /* N1 (session 19, s38): ESP payroll. Framework model only; no RNG is drawn in any ESP step. */
  if(ESON){
    if(yr===0||!ESS)ESS={prev:null,acc:esNewAcc(),y:[]};
    esIdx=Math.pow(1+inflRate,yr)*(PRICE?PRICE.bIdx:1);esCipB=p.cip?(1+p.cipDemo*0.12):1.0;
    var esA=ESS.acc,esPool=ESS.prev?ESS.prev.pool:0,esW=0,esRet=0,esSv=0,esY=ESS.y[yr]={pool:esPool,conv:0,ret:0,sv:0};
    agentSet.forEach(function(a,i){
      if(a._esU===undefined)a._esU=((i+1)*ESP_GOLD)%1;  // d72: fixed by agent index
      a._esWk=(ESP.work==='all'?true:ESP.work==='ptf'?!!(p.ptf&&a.inPTF):a._esU<ESP.work)&&!a._ret;  // v5.2 step 4: no paid ESP work after 67
      a._esBU=0;a._esC=0;a._esX=0;a._esR=0;
      if(a._esWk)esW+=Math.max(0,a._fwW||0);
    });
    ESS.wW=esW;esA.poolPaid+=esPool/esIdx;
    agentSet.forEach(function(a){
      if(!a._esWk&&!(a._esSv>0))return;
      var w=Math.max(0,a._fwW||0),sh=0,bu=0;
      if(a._esWk){esA.wkY++;if(yr>0){esA.wkY1++;esA.wage+=w/esIdx;}
        if(esPool>0&&esW>0){sh=esPool*w/esW;bu=Math.min(sh,w);if(sh>bu){esRet+=sh-bu;esA.retWage+=(sh-bu)/esIdx;}if(w>0)esA.maxShare=Math.max(esA.maxShare,bu/w);}
        a._esBU=bu;esA.alloc+=bu/esIdx;}
      if(!(p.ccoOn&&a.inCCO)){esRet+=bu;esA.retNon+=bu/esIdx;return;}  // d73: non-participants have no earned rate; paid in dollars
      if(a._esWk)esA.partWkY++;
      var r=pjOwnRate(a,p,ptfConvBonus),tx=pjTax(p,r),ok=ESP.take==='biz'?r>FW.bizRate:r*(1-tx)*esCipB>1;
      if(!ok){esRet+=bu;esA.retPar+=bu/esIdx;return;}  // below par (or below the ESP's rate, 'biz'): paid in dollars
      var have=bu+(ESP.cap==='save'?(a._esSv||0):0);
      var cap=ESP.cap==='none'?Infinity:Math.max(0,12*FW.octaveCapBase*Math.pow(2,a.octave)-(PJON?(a._pjBU||0)+(a._pjSaved||0):0));  // d74: net of project BU
      var c=Math.min(have,cap);a._esK=cap;  // _esK: reporting only (the capacity test)
      if(have>c+1e-9){esA.capBind++;if(ESP.cap==='save')a._esSv=have-c;else{esRet+=have-c;esA.retCap+=(have-c)/esIdx;}}
      else if(ESP.cap==='save')a._esSv=0;
      if(c>0){a._esC=c;a._esR=r;if(ACCT)a._acBc+=c;a._esX=w>0?c*(r*(1-tx)*esCipB-1)/w:0;esA.tk++;}  // the payroll raise for the labor module (before the income shock)
    });
    if(ESP.cap==='save')agentSet.forEach(function(a){esSv+=a._esSv||0;});
    esY.ret=esRet;esY.sv=esSv;esA.ret+=esRet/esIdx;esA.sv=esSv/esIdx;
    agentSet.forEach(function(a){esY.conv+=a._esC;});
    if(esRet>0&&FWS.prev){  // d73-d75: the BU returned to the ESP convert at FW.bizRate this year, paid with the rest of last year's premium
      var esBT=p.cip?p.tax*(1-p.cipDemo*0.18):p.tax,esTR=Math.min(CFG.PROG_TAX_MAX,esBT+Math.max(0,(FW.bizRate-CFG.PROG_PIVOT)*CFG.PROG_RATE)),esTP=Math.min(CFG.PROG_TAX_MAX,esBT);
      var esRG=esRet*(FW.bizCap*FW.bizRate+(1-FW.bizCap)),esRT=esRet*(FW.bizCap*FW.bizRate*esTR+(1-FW.bizCap)*esTP),esRN=PATHWAY_OFF.conversion?0:esRG-esRT-esRet;
      FWS.prev.bizNet+=esRN;esA.retNet+=esRN/esIdx;if(tbY)TB.cur.ctax+=esRT;if(ACCT)ACCT.cur.esRet+=esRet;
      if(LEDGER){ledAdd(yr,'espRetGross',esRG);ledAdd(yr,'espRetTax',esRT);ledAdd(yr,'espRetPremium',esRN);}
    }
    if(LEDGER){ledAdd(yr,'espPoolPaid',esPool);ledAdd(yr,'espConvBU',esY.conv);ledAdd(yr,'espRetBU',esRet);}
  }
  var eShareCur=0,fShareCur=CFG.BASKET.food;buEss().forEach(function(k){eShareCur+=CFG.BASKET[k]*(PRICE?PRICE.comp[k]:1);});  // v5.3 B3f: the share of the basket BU can buy (BU_SCOPE)
  if(PRICE){eShareCur/=PRICE.bIdx;fShareCur=CFG.BASKET.food*PRICE.comp.food/PRICE.bIdx;}
  var rsAlt=PTH_MODE!=='basket'||DISC_BASE!=='basket';  // session 5 (d4/d5): harness-only
  var tShareCur=DISC_BASE==='pretax'?CFG.BASKET.taxes*(PRICE?PRICE.comp.taxes/PRICE.bIdx:1):0,hShareCur=CFG.BASKET.housing*(PRICE?PRICE.comp.housing/PRICE.bIdx:1);
  var tShA=tShareCur;function discMul(c,m){return DISC_BASE==='pretax'?tShA+(c-tShA)*m:c*m;}  // v5.3 B3: tShA = a household member's own tax share (set per adult below)
  if(ACCT&&FWON)ACCT.cur.bizIn=FWS.prev?FWS.prev.bizNet:0;  // v5.3 B2: the premium to be paid out this year (with the returned BU's)
  var SPON=FWON&&!!SURP,spDelta=0,spProfW=0,spRestW=0,spOwnW=0;  /* plan step 1 (Oct 1, 2026): the ESP surplus split; see SURP. No RNG is drawn in any SURP step. */
  if(SPON){
    if(yr===0||!SPS)SPS={capPA:0,cap:0,carry:0,carryP:0,sw:-1,acc:spNewAcc(),y:[]};
    var spIdx=Math.pow(1+inflRate,yr)*(PRICE?PRICE.bIdx:1),spA=SPS.acc,spN=agentSet.length;
    var spPool=FWS.prev?FWS.prev.bizNet:0,spS=(SURP.priv==='owners'||SURP.priv==='prices')?((FWS.prev&&FWS.prev.bizBU>0)?(FWS.prev.bizBUptf||0)/FWS.prev.bizBU:0):1;  // the PTFs' share: BU PTF members spent last year / all BU accepted
    var spPh=yr===0?1:SURP.swYear!=null?(yr>=SURP.swYear?2:1):((PDON?(SURP.K<=0||PDS.c0+SPS.capPA/SURP.K>=1):SPS.capPA>=SURP.K)?2:1);if(spPh===2&&SPS.sw<0)SPS.sw=yr;  // plan step 2: with PTF capacity on, when c reaches 1  // year 0 has no pool  // d101: phase 2 the year after the capital account reaches K
    var spSh=spPh===1?SURP.p1:SURP.p2,spPtf=spPool*spS,spOwn=spPool-spPtf,spChD=0,spChI=0;
    if(PDON&&PROD.speed==='oneyear'){var spChDue=(PDS.borPA||0)*(PROD_CAP_DEP+PROD_CAP_INT)*spN*spIdx+(PDS.debt||0)*spIdx,spChPd=Math.min(spPtf,spChDue);PDS.debt=(spChDue-spChPd)/spIdx;spPtf-=spChPd;  // plan step 15: depreciation plus real interest on borrowed PTF capital, paid from the PTFs' premium first; any shortfall carries
      spChD=spChPd*PROD_CAP_DEP/(PROD_CAP_DEP+PROD_CAP_INT);spChI=spChPd-spChD;if(tbY){TB.cur.conv+=spChPd;TB.cur.convM+=spChD;}if(PRICE&&PRICE.acc)PRICE.acc.conv+=spChPd;SPS.acc.chD=(SPS.acc.chD||0)+spChD/spIdx;SPS.acc.chI=(SPS.acc.chI||0)+spChI/spIdx;}
    var spRest=spPtf*Math.max(0,1-spSh[0]-spSh[1]-spSh[2]),spCarryIn=SPS.carry;
    var spPP=spPtf*spSh[0]+(SURP.rv==='price'?spPtf*spSh[1]:0)+SPS.carry,spRv=SURP.rv==='price'?0:spPtf*spSh[1],spPr=spPtf*spSh[2]+SPS.carryP;SPS.carryP=0;
    var spCust=SURP.cust==='auto'?((SURP.priv==='owners'||SURP.priv==='prices')?'ptf':'all'):SURP.cust;
    var spVOn=SURP.priv==='prices',spVW=0,spVP=0,spVSum=0,spVUsed=0;  /* plan step 14 (Oct 2, 2026; d140): private ESPs pass their premium to BU customers as lower prices; workers matched */
    if(spVOn){if(SPS.carryV===undefined)SPS.carryV=0;spVW=SURP.privWk==='none'?0:spOwn*spSh[2];spVP=spOwn-spVW+SPS.carryV;spPr+=spVW;spOwn=0;}
    var spMlc=CFG.LIVING_WAGE_ANNUAL*Math.pow(1+inflRate,yr);if(PRICE)spMlc*=PRICE.bIdx;
    var spSum=0,spWW=0,spWO=0;
    if(!ESON)agentSet.forEach(function(a,i){if(a._esU===undefined)a._esU=((i+1)*ESP_GOLD)%1;a._esWk=a._esU<ESP_DEFAULTS.work&&!a._ret;});  // ESP payroll off: the same workforce (d72)
    agentSet.forEach(function(a){  // each customer's essentials at own prices, exactly as the agent loop computes them (start-of-year memberships)
      var bp=p.ccoOn&&a.inCCO&&p.bu>0&&!PATHWAY_OFF.relief,isC=spCust==='all'||(spCust==='pp'&&((p.ccoOn&&a.inCCO)||(p.ptf&&a.inPTF)))||(spCust==='ptf'&&p.ptf&&a.inPTF)||(spCust==='part'&&p.ccoOn&&a.inCCO),e=0;
      var sHH=HHON&&a._hh&&!a._hh.single,sE=sHH?a._hhE:eShareCur,sF=sHH?a._hhFd:fShareCur,sH=sHH?a._hhH:hShareCur,sM=sHH?spMlc*a._hhF:spMlc;  // v5.3 B3: a household member's share of the household's essentials
      if(isC){var ef=sE,u=1;
        if(p.ptf&&a.inPTF){if(PTFS){var spC=1-ptfsCut(a,sHH,p,true);ef=ef*spC;if(rsAlt)u=spC;}else if(PTF_MODE==='shipped'){ef=ef*(1-(p.szh?0.12+p.szhCoh*0.04:0.12));if(rsAlt)u=1-(p.szh?0.12+p.szhCoh*0.04:0.12);}else ef=ef-PTF_FOOD_CUT[PTF_MODE]*sF;}
        if(p.pth&&a.inPTH&&!PATHWAY_OFF.pthCost){if(PTH_MODE==='housing')ef-=PTH_HOUSING_CUT*sH*u;else ef*=0.65;}
        if(SURP_CUT_MARKUP&&bp&&HCAP&&HCS&&hcM>0&&!(p.pth&&a.inPTH))ef+=hcM*sH;  // v5.3 B2: the bill the cut is applied to (the agent loop adds hcX to a BU customer's essentials)
        e=sM*ef;if(SURP.bu==='cash'&&bp)e=Math.max(0,e-Math.min(12*(sHH?buEff*a._hhBU:buEff),e));}
      if(spVOn){var vBu=(bp&&!(p.ptf&&a.inPTF))?Math.max(0,a._spBU||0):0,vE=0;if(vBu>0){vE=sE;if(p.pth&&a.inPTH&&!PATHWAY_OFF.pthCost){if(PTH_MODE==='housing')vE-=PTH_HOUSING_CUT*sH;else vE*=0.65;}vE*=sM;}a._spVw=vBu;a._spVE=vE;spVSum+=vBu;}
      a._spE=e;a._spCutY=0;a._spPay=0;a._spOwn=0;a._spBU=0;a._spWk=!!a._esWk&&(SURP.wk!=='espPart'||!!(p.ccoOn&&a.inCCO));
      spSum+=e;if(a._spWk)spWW+=Math.max(0,a._fwW||0);spWO+=Math.max(0,a.wealth);
    });
    spDelta=spSum>0?Math.min(1,spPP/spSum):0;var spUsed=spDelta*spSum;SPS.carry=spPP-spUsed;  // d98: one uniform cut, capped at 1; the rest carries
    if(spVOn){agentSet.forEach(function(a){a._spV=(spVSum>0&&a._spVw>0)?Math.min(spVP*a._spVw/spVSum,a._spVE):0;spVUsed+=a._spV;});SPS.carryV=spVP-spVUsed;}  // plan step 14: shared by last year's BU spent at private ESPs, capped at own essentials; the rest carries
    if(spWW>0)spProfW=spPr/spWW;else{SPS.carryP=spPr;spPr=0;}
    var spRestOn=spRest>0&&FWS.prev&&FWS.prev.wSum>0;spRestW=spRestOn?Math.max(0,spRest)/FWS.prev.wSum:0;
    if(spWO>0)spOwnW=spOwn/spWO;else{SPS.carry+=spOwn;spOwn=0;}
    agentSet.forEach(function(a){var w=a._fwW||0;a._spOwn=spOwnW*Math.max(0,a.wealth);a._spRest=spRestOn?spRest*w/FWS.prev.wSum:0;a._spPay=(a._spWk&&spWW>0?spPr*Math.max(0,w)/spWW:0)+a._spRest+a._spOwn;});  // shares all 0 under 'same': exactly today's payout (unit)
    SPS.cap+=spRv;SPS.capPA+=spRv/spIdx/spN;  // d100: the ESP capital account (year-0 dollars per adult for the trigger)
    if(tbY){TB.cur.conv+=spRv;if(PROD)TB.cur.convM+=spRv;}if(PRICE&&PRICE.acc)PRICE.acc.conv+=spRv;  // plan step 2: reinvestment buys capital goods (output at face)  // d105: reinvestment is part of the conversion premium
    spA.pool+=spPool/spIdx;spA.own+=spOwn/spIdx;if(spVOn){spA.privW=(spA.privW||0)+spVW/spIdx;spA.privP=(spA.privP||0)+(spVP-SPS.carryV)/spIdx;}spA.ptf+=spPtf/spIdx;spA.rest+=spRest/spIdx;spA.pricePool+=(spPP-spCarryIn)/spIdx;spA.reinv+=spRv/spIdx;spA.carry=SPS.carry/spIdx;
    if(yr>0){if(spPh===1){spA.d1+=spDelta;spA.n1++;}else{spA.d2+=spDelta;spA.n2++;}spA.yrs++;}
    SPS.y[yr]={pool:spPool,s:spS,own:spOwn,ptf:spPtf,rest:spRest,carryIn:spCarryIn,pp:spPP,sum:spSum,delta:spDelta,used:spUsed,carryOut:SPS.carry,profit:spPr,reinv:spRv,cap:SPS.cap,capPA:SPS.capPA,phase:spPh,cut:0,freed:0,paid:0,pjFreed:0,privW:spVW,privPool:spVP,privUsed:spVUsed,cutV:0,ch:spChD+spChI,chDue:(typeof spChDue==='number'?spChDue:0)};
    if(LEDGER){ledAdd(yr,'spPool',spPool);ledAdd(yr,'spOwners',spOwn);ledAdd(yr,'spPricePool',spPP);ledAdd(yr,'spCarry',SPS.carry);ledAdd(yr,'spProfit',spPr);ledAdd(yr,'spReinvest',spRv);ledAdd(yr,'spRest',spRest);}
  }
  agentSet.forEach(function(a){
    if(isNaN(a.wealth))a.wealth=0;if(isNaN(a.wage)||a.wage<=0)a.wage=1;
    var HHA=HHON&&a._hh&&!a._hh.single,eSA=HHA?a._hhE:eShareCur,fSA=HHA?a._hhFd:fShareCur,hSA=HHA?a._hhH:hShareCur,buA=HHA?buEff*a._hhBU:buEff,dcA=HHA?dollarCost*a._hhD:dollarCost,HHP=HHPOOL&&HHA&&a._hh.a.length>1;tShA=HHA?a._hhT:tShareCur;if(HHON)a._hhPool=HHP;  // v5.3 B3: a household member's shares, BU and BLEI cost; HHP: a pooled couple (finished in hhPool)
    var dsOn=!!(DIS&&DSS&&yr===DIS.yr&&a._disHit);if(dsOn&&p.ccoOn&&a.inCCO&&p.bu>0)buA*=1+DIS.emerg;  // v5.4 item 5: the emergency distribution
    if(svF!==0&&(a.wealth>0||(a.wealth<0&&SAVE.debt==='same'))){var svI=a.wealth*svF;a.wealth+=svI;if(ACCT)a._acI=svI;if(EDCS&&svI<0)a._edcIntP=-svI;SVS.intR+=svI/svP;SVS.realR+=a.wealth/(1+svF)*SAVE.r/svPp;if(LEDGER)ledAdd(yr,'saveInterest',svI);}  // v5.2 step 3
    a.yrWealthStartUSD=a.wealth;  /* v4.18 parity: start-of-year wealth for housingDistressOf() (no RNG) */
    var agentVar=0.90+RNG()*0.20,incomeShock=popShock*agentVar;
    if(HHON&&HOUSEHOLDS.shock&&a._hh&&a._hh.a.length>1){var hsR=HOUSEHOLDS.shock==='shore'?CFG.HH_SHOCK_CORR[recSt.active?1:0]:+HOUSEHOLDS.shock,hsA=Math.min(1,Math.abs(hsR)),hsS=hsR<0&&a._hh.a[1]===a?-1:1;agentVar=1+Math.sqrt(hsA)*hsS*(a._hh.hv-1)+Math.sqrt(1-hsA)*(agentVar-1);incomeShock=popShock*agentVar;a._shkV=agentVar;a._shkR=!!recSt.active;}  // v5.3 B6: a couple's swings share a household part (off by default)
    if(EDCS){a._edcInt=0;a._edcBU=0;}  // v5.3 B6: the measured EDC's inputs (reporting only)
    var uSpendFrac=0.60+RNG()*0.30;
    var uCipQuality=RNG();
    var uAdvance=RNG();
    var uSzhInduce=RNG();
    var uSzhPtfShare=RNG();
    var uPthAppr=RNG();
    var uPtfAdopt=RNG();
    if(AGE&&AGS&&a._ret){a._ssY=a._ssB0*agP;a.wage=a._ssY/12/CFG.WAGE_TO_USD;if(AGE.ret==='none')a.inCCO=false;}  // v5.2 step 4: a retiree's benefit, moved with prices; BLEI and the stability score read it as the monthly income
    if(GATE_CURRENT&&FWON&&p.ccoOn&&a.inCCO&&p.bu>0&&!PATHWAY_OFF.relief){  // audit V5-02: the framework BLEI gate reads THIS year's BU spend, not last year's (same expression as fwB0 below)
      var gEss=eSA;
      if(p.ptf&&a.inPTF)gEss=PTFS?gEss*(1-ptfsCut(a,HHA,p,true)):PTF_MODE==='shipped'?gEss*(1-(p.szh?0.12+p.szhCoh*0.04:0.12)):gEss-PTF_FOOD_CUT[PTF_MODE]*fSA;
      if(p.pth&&a.inPTH&&!PATHWAY_OFF.pthCost){if(PTH_MODE==='housing')gEss-=PTH_HOUSING_CUT*hSA*(rsAlt&&p.ptf&&a.inPTF&&(PTFS||PTF_MODE==='shipped')?(PTFS?1-ptfsCut(a,HHA,p,true):1-(p.szh?0.12+p.szhCoh*0.04:0.12)):1);else gEss*=0.65;}
      var gCost=CFG.LIVING_WAGE_ANNUAL*Math.pow(1+inflRate,yr);if(PRICE)gCost*=PRICE.bIdx;if(HHA)gCost*=a._hhF;
      a._fwBUm=Math.min(12*buA,gCost*gEss)/12;
    }
    var bleiCheck=agentBLEI(a,buA,p.ccoOn,p.pth,p.szh,p.szhCoh,p.ptf);
    var tbNB=tbY?tbGate(a,p,buA,tbY):0,wg=CFG.WAGE_BASE_GROWTH,bleiGate=(tbY&&TB.neutralGate)?tbNB:bleiCheck;  // session 6 (d28): design-neutral gate for the wage bonus (testbed only)
    var bleiProg=0;a._bleiR=0;a._bleiP=0;  // session 9 (i3-2): harness-only attribution of the BLEI raise (no RNG)
    if(bleiGate>CFG.BLEI_PRECARIOUS_MAX&&!PATHWAY_OFF.bleiWage){  // v4.21: harness-only pathway switch
      var drFactor=1/(1+0.5*Math.max(0,a.wage/CFG.WAGE_MEDIAN_SIU-1));
      wg+=CFG.WAGE_BLEI_BONUS*Math.max(0.1,drFactor);
      a._bleiR=1;if(!(agentBLEI(a,0,false,false,false,0,false)>CFG.BLEI_PRECARIOUS_MAX)){a._bleiP=1;if(N7_BLEI)bleiProg=CFG.WAGE_BLEI_BONUS*Math.max(0.1,drFactor);}
    }
    if(!PATHWAY_OFF.octaveWage)wg+=a.octave*CFG.WAGE_OCTAVE_BONUS;  // v4.21: harness-only pathway switch
    if(p.cip)wg+=p.cipDemo*0.005;
    if(LABOR&&a._lwNB===undefined)a._lwNB=a.wage;  // session 4 (A3): the wage without program-induced raises
    if(PRICE){if(a._wNB===undefined)a._wNB=a.wage;if(PRICE.wIdx)wg+=PRICE.wIdx*PRICE.piG;}  // session 2: wage indexation to P_G (price module; 0 = nominal drift)
    if(!(EMPL&&EMPL.auto==='jobs'))wg-=popAIDisp*((typeof a.automationRisk==='number'&&!isNaN(a.automationRisk))?a.automationRisk:0.5);  /* v4.17 parity: `||0.5` read a draw of exactly 0 as 0.5 */
    a.wage=Math.max(a.wage*0.80,a.wage*(1+wg));
    if(isNaN(a.wage))a.wage=1;
    if(a._ret)a.wage=a._ssY/12/CFG.WAGE_TO_USD;  // v5.2 step 4: a retiree's income is the benefit (no wage growth)
    if(a._ret){if(LABOR)a._lwNB=a.wage;if(PRICE)a._wNB=a.wage;}  // v5.2 step 4: no programme raise on a benefit
    if(LABOR){var lbProg=(PATHWAY_OFF.octaveWage?0:a.octave*CFG.WAGE_OCTAVE_BONUS)+(p.cip?p.cipDemo*0.005:0)+bleiProg;a._lwNB=Math.max(a._lwNB*0.80,a._lwNB*(1+wg-lbProg));}
    if(PRICE){var pmProg=(PATHWAY_OFF.octaveWage?0:a.octave*CFG.WAGE_OCTAVE_BONUS)+(p.cip?p.cipDemo*0.005:0)+bleiProg;a._wNB=Math.max(a._wNB*0.80,a._wNB*(1+wg-pmProg));}  // N7: the wage without program-induced raises
    var cf=1.0,rsPtfU=1,rsRel=1;
    if(!rsAlt){
    if(p.ptf&&a.inPTF){if(PTFS)cf*=1-ptfsCut(a,HHA,p);else if(PTF_MODE==='shipped')cf*=(1-(p.szh?0.12+p.szhCoh*0.04:0.12));else cf*=(1-PTF_FOOD_CUT[PTF_MODE]*fSA);}  // session 2: PTF_MODE (D4); 'shipped' is index.html
    var cfPTF=cf;  // A1 ledger (reporting only)
    if(p.pth&&a.inPTH&&!PATHWAY_OFF.pthCost)cf*=0.65;  // v4.21: harness-only pathway switch
    var cfPreCCO=cf;  // A1 ledger (reporting only)
    if(p.ccoOn&&a.inCCO&&p.bu>0){if(!PATHWAY_OFF.relief&&!FWON)cf*=ccoReliefF;}  // v4.19: was a flat 0.80 (see ccoReliefF). v4.21: pathway switch
    else if(emergLine>=0&&p.ccoOn&&p.bu>0&&!a.inCCO&&typeof a.uCCO==='number'&&a.uCCO<emergLine){cf*=ccoReliefF;emergN++;}  // v4.19: emergency enrollment
    } else {  // session 5 (d4/d5): the same chain with PTH_MODE and DISC_BASE (harness-only)
    if(p.ptf&&a.inPTF){if(PTFS){rsPtfU=1-ptfsCut(a,HHA,p);cf=discMul(cf,rsPtfU);}else if(PTF_MODE==='shipped'){rsPtfU=1-(p.szh?0.12+p.szhCoh*0.04:0.12);cf=discMul(cf,rsPtfU);}else cf-=PTF_FOOD_CUT[PTF_MODE]*fSA;}
    var cfPTF=cf;
    if(p.pth&&a.inPTH&&!PATHWAY_OFF.pthCost){if(PTH_MODE==='housing')cf-=PTH_HOUSING_CUT*hSA*rsPtfU;else cf=discMul(cf,0.65);}
    var cfPreCCO=cf;
    if(p.ccoOn&&a.inCCO&&p.bu>0){if(!PATHWAY_OFF.relief&&!FWON){cf=discMul(cf,ccoReliefF);rsRel=ccoReliefF;}}
    else if(emergLine>=0&&p.ccoOn&&p.bu>0&&!a.inCCO&&typeof a.uCCO==='number'&&a.uCCO<emergLine){cf=discMul(cf,ccoReliefF);rsRel=ccoReliefF;emergN++;}
    }
    var hcOn=!!(HCAP&&HCS&&!(p.pth&&a.inPTH)&&(HCAP.all||(FWON&&p.ccoOn&&a.inCCO&&p.bu>0&&!PATHWAY_OFF.relief))),hcX=hcOn&&hcM>0?hcM*hSA:0,hcDone=false;  // v5.2 step 7: whose rent is marked up, and by how much (a share of the basket)
    var mainLoopCostUSD=CFG.LIVING_WAGE_ANNUAL*Math.pow(1+inflRate,yr);
    if(PRICE)mainLoopCostUSD*=PRICE.bIdx;  // session 2: endogenous basket index
    if(HHA)mainLoopCostUSD*=a._hhF;  // v5.3 B3: this adult's share of the household's needs at the household's own prices
    if(hcOn)HCS.h+=mainLoopCostUSD*(hSA+hcX);  // v5.2 step 7: the rent bill of the adults the mark-up falls on
    if(EDCS){a._edcR=(p.pth&&a.inPTH)?0:mainLoopCostUSD*(hSA+hcX);a._edcInt=a._edcIntP||0;a._edcIntP=0;}  // v5.3 B6: rent to a landlord (housing with utilities, MIT; PTH payments are not extractive: the glossary's EDC = 0) and interest on debt
    if(FWON&&p.ccoOn&&a.inCCO&&p.bu>0&&!PATHWAY_OFF.relief){  // session 2, N3/N4: BU buy essentials at the agent's own prices, up to 12 x BU a year
      var essF=eSA;
      if(p.ptf&&a.inPTF)essF=PTFS?essF*(1-ptfsCut(a,HHA,p,true)):PTF_MODE==='shipped'?essF*(1-(p.szh?0.12+p.szhCoh*0.04:0.12)):essF-PTF_FOOD_CUT[PTF_MODE]*fSA;
      if(p.pth&&a.inPTH&&!PATHWAY_OFF.pthCost){if(PTH_MODE==='housing')essF-=PTH_HOUSING_CUT*hSA*rsPtfU;else essF*=0.65;}  // session 5 (d4)
      if(hcX>0)essF+=hcX;  // v5.2 step 7: BU pay the marked-up rent
      var fwBudget=12*buA,fwB=Math.min(fwBudget,mainLoopCostUSD*essF),spC=0,fwB0=fwB;if(tbY)TB.cur.buIss+=fwBudget;if(EDCS)a._edcBU=fwBudget;if(HEALTH)a._hlBU=fwBudget;  // plan step 3: BU the Source issues (reporting)
      if(SPON&&a._spE>0&&spDelta>0){var spE=mainLoopCostUSD*essF;  // plan step 1 (d99): the cut lowers essentials; BU buy the discounted essentials first
        if(SURP.bu==='cash')spC=spDelta*Math.max(0,spE-fwB);else{spC=spDelta*spE;fwB=Math.min(fwBudget,spE-spC);}
        a._spCutY=spC;var spY=SPS.y[yr];spY.cut+=spC;spY.freed+=fwB0-fwB;SPS.acc.cut+=spC/spIdx;SPS.acc.cutP+=spC/spIdx;SPS.acc.freed+=(fwB0-fwB)/spIdx;SPS.acc.cash+=(spC-(fwB0-fwB))/spIdx;}
      if(SPON&&a._spV>0){var vSpE=mainLoopCostUSD*essF,vC=Math.min(a._spV,Math.max(0,vSpE-spC)),vB=fwB;  // plan step 14 (d140): a private ESP's lower BU price; BU buy the discounted essentials first, the BU it frees expire
        if(vC>0){spC+=vC;fwB=Math.min(fwBudget,vSpE-spC);a._spCutY=spC;var vY=SPS.y[yr];vY.cut+=vC;vY.cutV+=vC;vY.freed+=vB-fwB;SPS.acc.cut+=vC/spIdx;SPS.acc.cutP+=vC/spIdx;SPS.acc.cutV=(SPS.acc.cutV||0)+vC/spIdx;SPS.acc.freed+=(vB-fwB)/spIdx;SPS.acc.cash+=(vC-(vB-fwB))/spIdx;}}
      var fwLeft=fwBudget-fwB;
      if(HCAP&&HCS&&!(p.pth&&a.inPTH)&&fwB>0)HCS.hb+=fwB*Math.min(1,(hSA+hcX)/Math.max(1e-9,essF));  // v5.2 step 7: BU spent on rent outside PTH (at shares of the essentials they buy)
      cf=cfPreCCO+hcX-fwB/mainLoopCostUSD;hcDone=true;if(spC)cf-=spC/mainLoopCostUSD;a._fwBUm=fwB0/12;  // the neutral BLEI gate counts the BU that would be spent without the cut (no price cut enters it)
      if(SPON){a._spBU=fwB;if(p.ptf&&a.inPTF)FWS.next.bizBUptf=(FWS.next.bizBUptf||0)+fwB;}  // plan step 1: BU accepted by PTFs (PTF members' purchases)
      if(SPON&&PJON)SPS.y[yr].pjFreed+=(fwB0-fwB)*PROJ.share;
      FWS.next.bizBU+=fwB;FWS.next.expiredBU+=fwLeft;FWS.next.projBU+=fwLeft*FW.directedShare;FWS.next.destroyedBU+=fwLeft*(1-FW.directedShare);
      if(PJON){PJS.next.pool+=fwLeft*PROJ.share;PJS.acc.exp+=fwLeft/pjIdx;PJS.acc.pool+=fwLeft*PROJ.share/pjIdx;}  // N1 (session 15): the same pool, paid as project hiring
      if(LEDGER){ledAdd(yr,'fwBudget',fwBudget);ledAdd(yr,'fwBUSpent',fwB);ledAdd(yr,'fwBUExpired',fwLeft);ledAdd(yr,'fwBUDirected',fwLeft*FW.directedShare);}
      if(ACCT){a._acBi=fwBudget;a._acBs=fwB;a._acBk+=PJON?fwLeft*(1-PROJ.share):fwLeft*(1-FW.directedShare);}  // v5.3 B2: issued, spent, and the expired BU not directed (destroyed)
    } else if(SPON&&a._spE>0&&spDelta>0){var spC2=spDelta*a._spE;cf-=spC2/mainLoopCostUSD;a._spCutY=spC2;SPS.y[yr].cut+=spC2;SPS.acc.cut+=spC2/spIdx;SPS.acc.cash+=spC2/spIdx;if(!a.inCCO)SPS.acc.cutN+=spC2/spIdx;else SPS.acc.cutP+=spC2/spIdx;}  // plan step 1: a customer without BU saves the cut in cash
    if(hcX>0&&!hcDone)cf+=hcX;  // v5.2 step 7: without BU the higher rent is paid in cash
    var emQ=null,emWk=0;if(EMPL&&EMS){var emU=[EMS.r(),EMS.r(),EMS.r(),EMS.r(),EMS.r(),EMS.r()];emWk=a.wage*12*CFG.WAGE_TO_USD*incomeShock/52;if(!a._ret)emQ=emplYear(a,recSt.active,popAIDisp,emU,emWk);}  // v5.4 item 2: job loss (own stream, six draws whatever the state)
    var annualWageUSD=a._ret?0:a.wage*12*CFG.WAGE_TO_USD*incomeShock*(1+mlNT);
    if(emQ)annualWageUSD*=1-emQ.out;
    if(HEALTH)a._hlOut=emQ?emQ.out:0;  // session 2a: a year mostly out of work loses employer coverage next year
    if(dsOn)annualWageUSD*=1-Math.min(52,DIS.weeks)/52;  // v5.4 item 5: weeks of work lost to the disaster  // v5.2 step 4: a retiree earns no wage  // v5.2 step 6: mlNT = 0 unless the spending layer fills normal-times slack
    var tbG=0,tbPT=0;if(tbY&&COST&&p.ptf&&a.inPTF){a._csFree=Math.min(mainLoopCostUSD*(1-cfPTF),mainLoopCostUSD*(fSA*COST.food+hSA*COST.util));a._csFreeY=a._csFree;}  // plan step 5: the PTF discount a PTF funds from forgone profit (accounting only)
    if(tbY){tbPT=mainLoopCostUSD*(1-cfPreCCO);if(p.tb.groc&&a._tbU<p.tb.groc.cover)tbG=mainLoopCostUSD*p.tb.groc.cut*(fSA+(p.tb.groc.housing?hSA:0));}  // session 11: X-Cents Power of 1 on housing too (groc.housing)  // session 6: PTF/PTH price-cut dollars; public-grocery cut on the food component
    if(LABOR){  // session 4 (A3): the labor-supply response replaces this year's wage earnings (no RNG)
      var lbE0=annualWageUSD,lbBU=0,lbR=0,lbC=a._labC||0,lbU=p.ubi||0;
      if(p.ccoOn&&a.inCCO&&p.bu>0&&!PATHWAY_OFF.relief){if(FWON){lbBU=fwB;lbR=fwLeft;}else lbBU=mainLoopCostUSD*(cfPreCCO-cf);}
      var lbBiz=(FWON&&FWS.prev&&FWS.prev.wSum>0)?Math.max(0,FWS.prev.bizNet)/FWS.prev.wSum:0;
      if(ESON&&ESP.rest==='esp')lbBiz=(a._esWk&&ESS.wW>0&&FWS.prev)?Math.max(0,FWS.prev.bizNet)/ESS.wW:0;  // d75 alternative: the ESP's premium reaches its own workers only
      if(SPON)lbBiz=(a._spWk?spProfW:0)+spRestW;  // plan step 1 (d104): the profit share is a raise for ESP workers only; a remainder paid as today stays a raise for all
      var lbRaise=Math.pow(Math.max(1,a.wage/a._lwNB)*(1+lbBiz)*(ESON?1+a._esX:1),LABOR.eps-LABOR.rho);  // uncompensated: Slutsky e_u = e_c + eta, eta = -rho. Session 19: x the ESP payroll raise (earned: one elasticity, no income effect)
      var tbQ=tbY?tbLab(a,tbY,lbE0,tbPT+tbG+(SPON?a._spCutY:0)):null;if(tbQ)lbRaise*=tbQ.F;  // session 6: phase-out and contribution rates (one elasticity), extra unconditional dollars (one income effect)
      var lbInc=LABOR.rho*lbU+LABOR.rhoBU*lbBU+LABOR.rhoR*lbR+LABOR.rho*(1-LABOR.delta)*lbC+(tbQ?LABOR.rho*tbQ.V:0),lbDisp=LABOR.delta*lbC+(tbQ?tbQ.D:0);
      if(SPON&&a._spOwn>0){lbInc+=LABOR.rho*a._spOwn;if(LABOR.acc)LABOR.acc.cash+=LABOR.rho*a._spOwn;}  // plan step 1: owners' dollars are unconditional (one income effect)
      if(emQ){lbInc*=1-emQ.out;lbDisp*=1-emQ.out;}  // v5.4 item 2: the hours response applies to the part of the year at work
      annualWageUSD=Math.max(0,lbE0*lbRaise-lbInc-lbDisp);a._lbE0=lbE0;  // session 8 (A5): earnings with no response, for the hours measure
      if(tbQ&&LABOR.acc)LABOR.acc.cash+=LABOR.rho*tbQ.V;
      if(LABOR.acc){var LA=LABOR.acc;LA.n++;if(a.inCCO)LA.nP++;LA.E0+=lbE0;LA.E+=annualWageUSD;LA.raise+=lbE0*(lbRaise-1);LA.cash+=LABOR.rho*lbU;LA.bu+=LABOR.rhoBU*lbBU;LA.buR+=LABOR.rhoR*lbR;
        LA.rent+=LABOR.rho*(1-LABOR.delta)*lbC;LA.disp+=lbDisp;LA.C+=lbC;LA.U+=lbU+lbBU;LA.projH+=lbE0>0?lbDisp/lbE0:0;if(annualWageUSD===0&&lbE0>0)LA.zero++;}
    }
    if(PJON){a._pjHW=0;if(a._pjBU>0){var pjH=a._pjBU/pjPay,pjHw=a.wage*12*CFG.WAGE_TO_USD*incomeShock/PROJ.hrsYr,pjD=pjH*pjHw;  // N1 (session 15): project hours
      if(PROJ.hours==='displace'){pjD=Math.min(pjD,Math.max(0,annualWageUSD));annualWageUSD-=pjD;if(LABOR&&LABOR.acc)LABOR.acc.E-=pjD;}
      a._pjHW=pjD;PJS.acc.hrs+=pjH;PJS.acc.disp+=(PROJ.hours==='displace'?pjD:0)/pjIdx;}}
    if(SNET&&SNET.abawd){var abW=emQ?emQ.out*52:0,abUi=emQ&&emWk>0?Math.min(abW,emQ.ui/(CFG.EMPL_UI_REPL*emWk)):0,abB=LABOR?(a._lbE0||0):annualWageUSD,abR=abB>0?(LABOR?annualWageUSD/abB:1):0;a._snAbC=a._ret?0:12*Math.max(0,(abR<0.5?52:abW)-abUi)/52;}  // session 7: SNAP's work rule, this year's months not meeting it (read next year)
    if(tbG)cf-=tbG/mainLoopCostUSD;  // session 6: public grocery (applied after the labor block reads the CCO relief)
    var costUSD=mainLoopCostUSD*cf;
    if(HEALTH&&HLS&&a._hlD)costUSD+=a._hlD*HLS.mIdx;  // session 2a: the household's medical bill above (or below) its basket line, in cash, at medical prices
    a.wealth+=annualWageUSD-costUSD;
    if(SPEND_GRADE){var grA=annualWageUSD+(a._ret?a._ssY:0)+(p.ubi>0?p.ubi:0)+(emQ?emQ.ui:0);if(SNET&&SNS&&a._snB)grA+=a._snB;a._grCut=0;if(HHP){a._grA=grA;a._grC=costUSD;}else if(costUSD>0&&grA<costUSD){a._grCut=costUSD-costUSD*Math.pow(Math.max(0,grA)/costUSD,SPEND_GRADE.eps);a.wealth+=a._grCut;if(ACCT)a._acGr=a._grCut;}}  // v5.3 B7: less income, less spending (off by default)
    a.yrSSUSD=a._ret?a._ssY:0;if(a._ret){a.wealth+=a._ssY;if(LEDGER)ledAdd(yr,'ssBenefit',a._ssY);}  // v5.2 step 4: the Social Security benefit (money income)
    if(SURPLUS_CONSUMPTION_SHARE>0&&SURPLUS_CONSUMPTION_BASE==='wage'&&!HHP)a.wealth-=SURPLUS_CONSUMPTION_SHARE*Math.max(0,annualWageUSD-costUSD);  // v4.21: harness-only (saving mode)
    if(ACCT&&SURPLUS_CONSUMPTION_SHARE>0&&SURPLUS_CONSUMPTION_BASE==='wage'&&!HHP)a._acSc+=SURPLUS_CONSUMPTION_SHARE*Math.max(0,annualWageUSD-costUSD);  // v5.3 B2
    if(HHP)a._hhWS=annualWageUSD-costUSD;  // v5.3 B3: a pooled couple's spending rule is applied to the couple (hhPool)
    if(p.ubi>0){a.wealth+=p.ubi;a.yrUbiUSD=p.ubi;if(ACCT)a._acU=p.ubi;}
    if(EMPL){var emUI=emQ?emQ.ui:0;a.yrUbiUSD=(p.ubi>0?p.ubi:0)+emUI;if(emUI>0){a.wealth+=emUI;if(ACCT)a._acU=(p.ubi>0?p.ubi:0)+emUI;}}  // v5.4 item 2: unemployment insurance (cash, like the UBI comparator's)
    if(dsOn){var dsP=Math.pow(1+inflRate,yr)*(PRICE?PRICE.bIdx:1),dsD=((a._disAid?CFG.DIS_AID:0)-DIS.loss)*dsP/a._disN;a.wealth+=dsD;if(ACCT)a._acU=(a._acU||0)+dsD;}  // v5.4 item 5: the damage and federal aid (both runs)  // session 4: UBI comparator (harness-only; unset in every preset)
    var yrCashSurplus=annualWageUSD-costUSD+(p.ubi>0?p.ubi:0)+(a._ret?a._ssY:0);
    if(emQ&&emQ.ui>0)yrCashSurplus+=emQ.ui;  // v5.4 item 2  // v5.2 step 4: + the benefit  // session 1: for SURPLUS_CONSUMPTION_BASE 'cash' (harness-only; no RNG)
    if(tbY){var tbK=tbCashFlow(a,tbY,annualWageUSD,yr);a.wealth+=tbK.net+tbK.endow;yrCashSurplus+=tbK.net;if(HEALTH)a._hlTb=SNET&&SNS&&a._snB?tbK.net-a._snB:tbK.net;if(ACCT)a._acT=tbK.net+tbK.endow;}  // session 6: cash transfers less the contribution; an endowment is wealth, not consumable surplus
    if(LEDGER){  // A1 ledger (reporting only): no RNG, no state read by any dynamic
      ledAdd(yr,'agentYears',1);if(a.inCCO)ledAdd(yr,'partYears',1);
      ledAdd(yr,'wage',annualWageUSD);ledAdd(yr,'cost',costUSD);ledAdd(yr,'basket',mainLoopCostUSD);
      if(SURPLUS_CONSUMPTION_SHARE>0&&SURPLUS_CONSUMPTION_BASE==='wage'&&!HHP)ledAdd(yr,'surplusConsumed',SURPLUS_CONSUMPTION_SHARE*Math.max(0,annualWageUSD-costUSD));
      ledAdd(yr,'ptfRelief',mainLoopCostUSD*(1-cfPTF));ledAdd(yr,'pthRelief',mainLoopCostUSD*(cfPTF-cfPreCCO));
      ledAdd(yr,a.inCCO?'ccoRelief':'emergRelief',mainLoopCostUSD*(cfPreCCO-cf));
    }
    a.yrWageUSD=annualWageUSD;a.yrCostUSD=costUSD;a.yrBasketUSD=mainLoopCostUSD;a.yrConvUSD=0;  /* v4.17: income/basket poverty inputs (no RNG) */
    if(FWON){  // session 2, N1: last year's business conversion premium, paid to every agent in proportion to last year's wage income
      a._fwPayY=0;  // session 19: reporting only (the testbed's premium-by-group columns)
      if(FWS.prev&&FWS.prev.wSum>0){var fwPay=FWS.prev.bizNet*(a._fwW||0)/FWS.prev.wSum;
        if(ESON&&ESP.rest==='esp')fwPay=(a._esWk&&ESS.wW>0)?FWS.prev.bizNet*(a._fwW||0)/ESS.wW:0;  // d75 alternative (session 19): a worker cooperative
        if(SPON){fwPay=a._spPay;SPS.y[yr].paid+=fwPay;SPS.acc.profit+=(fwPay-a._spOwn-a._spRest)/spIdx;if(!a.inCCO)SPS.acc.non+=fwPay/spIdx;if(a._spWk&&yr>0){SPS.acc.wkY1++;SPS.acc.profitN+=(fwPay-a._spOwn-a._spRest)/spIdx;}}  // plan step 1: profit share, owners' dollars and any remainder paid as today
        a.wealth+=fwPay;a.yrConvUSD+=fwPay;yrCashSurplus+=fwPay;FWS.next.bizPaid+=fwPay;a._fwPayY=fwPay;
        if(PRICE)PRICE.acc.conv+=fwPay;if(LEDGER)ledAdd(yr,'fwBizPayout',fwPay);}
      if(ESON){a._esPrY=0;if(a._esC>0){  // session 19 (s38, d73): ESP payroll BU converted at the worker's own rate; the premium over face value is conversion income
        var esTx=pjTax(p,a._esR),esG=PATHWAY_OFF.conversion?0:a._esC*a._esR*esCipB*incomeShock,esPr=PATHWAY_OFF.conversion?0:esG*(1-esTx)-a._esC;
        a.wealth+=esPr;a.yrConvUSD+=esPr;yrCashSurplus+=esPr;a._esPrY=esPr;a._esShk=incomeShock;
        if(tbY)TB.cur.ctax+=esG*esTx;var esAc=ESS.acc;esAc.conv+=a._esC/esIdx;esAc.gross+=esG/esIdx;esAc.tax+=esG*esTx/esIdx;esAc.prem+=esPr/esIdx;esAc.rateXbu+=a._esR*a._esC/esIdx;
        if(PRICE)PRICE.acc.conv+=esPr;if(LEDGER){ledAdd(yr,'espGross',esG);ledAdd(yr,'espTax',esG*esTx);ledAdd(yr,'espPremium',esPr);}}}
      a._fwW=annualWageUSD;FWS.next.wSum+=annualWageUSD;
    }
    if(isNaN(a.wealth))a.wealth=0;
    if(p.ccoOn&&a.inCCO&&FWON){
      /* Session 2, CONVERSION_MODEL 'framework' (N1-N4). No personal BU balance and no conversion of one's own spending:
       * the participant converts the BU directed to projects last year (N2), allocated in proportion to octave capacity
       * x quality, capped at their octave capacity, at their own engine rate and under the engine's progressive tax.
       * The draws above are made exactly as in the engine branch, so the two models stay CRN-paired. */
      if(p.cip&&uCipQuality<p.cipDemo*0.15)a.quality=Math.min(p.maxMult,a.quality+0.1);
      var octCeilF=1+(a.octave/Math.max(1,p.maxOct))*(Math.max(1,p.maxMult)-1),qfF=Math.min(1,a.quality/Math.max(1,p.maxMult));
      var phiF=(p.phi&&a.quality>p.maxMult*CFG.PHI_QUALITY_THRESH)?CFG.PHI_RATIO:1.0,ptfBF=(p.ptf&&a.inPTF)?ptfConvBonus:1.0;
      var rateF=Math.min((1+qfF*(octCeilF-1))*phiF*ptfBF,p.maxMult*(p.phi?CFG.PHI_RATIO:1.0));
      var bTaxF=p.cip?p.tax*(1-p.cipDemo*0.18):p.tax,taxF=Math.min(CFG.PROG_TAX_MAX,bTaxF+Math.max(0,(rateF-CFG.PROG_PIVOT)*CFG.PROG_RATE));
      var cipBF=p.cip?(1+p.cipDemo*0.12):1.0,capBU=12*FW.octaveCapBase*Math.pow(2,a.octave);
      if(FWS.prev&&FWS.prev.pwSum>0&&!PJON){  // N1 (session 15): project hiring replaces N2's allocation
        var fwWant=FWS.prev.projBU*(a._fwPW||0)/FWS.prev.pwSum,fwAl=Math.min(capBU,fwWant);
        var fwG=PATHWAY_OFF.conversion?0:fwAl*rateF*cipBF*incomeShock,fwN=fwG*(1-taxF);
        if(tbY)TB.cur.ctax+=fwG*taxF;a.wealth+=fwN;a.yrConvUSD+=fwN;yrCashSurplus+=fwN;totalConversion+=fwN;totalBU+=fwAl;if(LABOR)a._labCn=fwN;
        if(ACCT){a._acBc+=fwAl;a._acBk+=fwWant-fwAl;ACCT.cur.want+=fwWant;}  // v5.3 B2
        FWS.next.projAlloc+=fwAl;FWS.next.projGross+=fwG;FWS.next.projTax+=fwG*taxF;FWS.next.projNet+=fwN;FWS.next.projLost+=fwWant-fwAl;
        if(PRICE)PRICE.acc.conv+=fwN;
        if(LEDGER){ledAdd(yr,'fwProjBU',fwAl);ledAdd(yr,'fwProjGross',fwG);ledAdd(yr,'fwProjTax',fwG*taxF);ledAdd(yr,'fwProjNet',fwN);ledAdd(yr,'fwProjLost',fwWant-fwAl);ledAdd(yr,'fwProjRateXbu',rateF*fwAl);}
      }
      a._fwPW=capBU*Math.max(0,a.quality);FWS.next.pwSum+=a._fwPW;
      if(a.octave<p.maxOct){  // as in the engine branch, except that the monthly basic cost is read before the BU purchase, since BU is added as income here
        var YusdF=a.wage*CFG.WAGE_TO_USD,cBasicF=(dcA*cfPreCCO)/12,edcF=(p.pth&&a.inPTH)?CFG.FBS_EDC_RESIDUAL_PTH:CFG.FBS_EDC_RESIDUAL_BASE;
        var fbsF=Math.max(0,YusdF+buA-cBasicF-edcF*YusdF),lamF=(typeof a.lambda==='number'&&!isNaN(a.lambda))?a.lambda:(CFG.FBS_LAMBDA_LO+CFG.FBS_LAMBDA_HI)/2;
        if(p.cip)lamF*=(1+p.cipDemo*CFG.FBS_CIP_LAMBDA_BOOST);
        if(FBS50){if(FBS50.dist!=='lambda'||(FBS50.scale||1)!==1){lamF=Math.LN2/fbs50Of(a.lambda);if(p.cip)lamF*=(1+p.cipDemo*CFG.FBS_CIP_LAMBDA_BOOST);}if(FBSS&&tbY){var fbK=!!(a._hh&&a._hh.kids.length);FBSS.n++;if(lamF*fbsF>=Math.LN2)FBSS.a++;if(fbK){FBSS.nK++;if(lamF*fbsF>=Math.LN2)FBSS.aK++;}if(yr===0)FBSS.f.push(Math.LN2/lamF);}}  // v5.3 B7: FBS50 (off by default)
        if(uAdvance<1-Math.exp(-lamF*fbsF)&&!PATHWAY_OFF.octave&&!(OCT&&yr-(a._ocY||0)<OCT.gap)){a.octave++;if(OCT)a._ocY=yr;}  // plan step 6: OCT gap (sensitivity)
      }
      if(uSzhInduce<szhPartBoost&&!a.inPTF&&p.ptf&&!(HHA&&!a._hhHead)&&ptfCapAllows()){a.inPTF=uSzhPtfShare<p.ptfShare;if(a.inPTF&&p.ptfCap)ptfLiveCount++;if(a.inPTF&&PDON)pdLive++;}else if(PDON&&PROD.speed==='oneyear'&&uSzhInduce<szhPartBoost&&!a.inPTF&&p.ptf&&!(HHA&&!a._hhHead)&&uSzhPtfShare<p.ptfShare&&(!p.ptfCap||ptfLiveCount<ptfLiveTotal*p.ptfShare))PDS.blk++;  // plan step 15: turned away for lack of PTF capacity
    } else if(p.ccoOn&&a.inCCO){
      /* v4.14 parity fix — ported from index.html: this was a step function (decay=0 at
       * expiry=1, decay=0.7 at every other slider value, 2-6 all identical) rather than a
       * continuous function of the slider. Replaced with decay=1-1/expiry, a documented
       * annual-approximation interpretation. At expiry=1 (used by every shipped preset and
       * this harness's own FULL_INTEGRATION/BASELINE configs) decay=0, identical to the
       * prior behaviour — zero effect on any documented regression figure. See
       * CONTRIBUTING.md's v4.14 Release Notes. */
      var decay=Math.max(0,1-1/Math.max(1,p.expiry||1));
      if(stabOn&&p.stabSusp)decay=1;  // v4.19: expiry suspended while triggered  /* v4.15 parity: || 1 guards a missing expiry — Math.max(1,undefined) is NaN */
      if(LEDGER){var lbK=a.buBalance*decay,lbI=buEff*BU_ALLOCATIONS_PER_YEAR,lbC=buEff*3*BU_ALLOCATIONS_PER_YEAR;ledAdd(yr,'buIssued',lbI);ledAdd(yr,'buExpired',(a.buBalance-lbK)+Math.max(0,lbK+lbI-lbC));}  // A1 ledger
      if(ACCT){var acK=a.buBalance*decay;a._acBi=buEff*BU_ALLOCATIONS_PER_YEAR;a._acBx=(a.buBalance-acK)+Math.max(0,acK+a._acBi-buEff*3*BU_ALLOCATIONS_PER_YEAR);}  // v5.3 B2
      if(PJON){var pjK=a.buBalance*decay,pjAl=buEff*BU_ALLOCATIONS_PER_YEAR,pjX=(a.buBalance-pjK)+Math.max(0,pjK+pjAl-buEff*3*BU_ALLOCATIONS_PER_YEAR);PJS.next.pool+=pjX*PROJ.share;PJS.acc.exp+=pjX/pjIdx;PJS.acc.pool+=pjX*PROJ.share/pjIdx;}  // N1 (session 15): expired BU go to projects
      a.buBalance=Math.min(a.buBalance*decay+buEff*BU_ALLOCATIONS_PER_YEAR,buEff*3*BU_ALLOCATIONS_PER_YEAR);  // v4.19: buEff; allocations/yr is a harness-only switch (index.html: 1)
      var spend=a.buBalance*uSpendFrac;a.buBalance-=spend;totalBU+=spend;if(ACCT){a._acBs=spend;a._acBc+=spend;}
      if(p.cip&&uCipQuality<p.cipDemo*0.15)a.quality=Math.min(p.maxMult,a.quality+0.1);
      var octCeiling=1+(a.octave/Math.max(1,p.maxOct))*(Math.max(1,p.maxMult)-1);
      var qualityFactor=Math.min(1,a.quality/Math.max(1,p.maxMult));
      var baseRate=1+qualityFactor*(octCeiling-1);
      var phi=(p.phi&&a.quality>p.maxMult*CFG.PHI_QUALITY_THRESH)?CFG.PHI_RATIO:1.0;
      var ptfB=(p.ptf&&a.inPTF)?ptfConvBonus:1.0;
      var cipB=p.cip?(1+p.cipDemo*0.12):1.0;
      var rate=Math.min(baseRate*phi*ptfB,p.maxMult*(p.phi?CFG.PHI_RATIO:1.0));
      var bTax=p.cip?p.tax*(1-p.cipDemo*0.18):p.tax;
      var progTax=Math.min(CFG.PROG_TAX_MAX,bTax+Math.max(0,(rate-CFG.PROG_PIVOT)*CFG.PROG_RATE));
      var convGain=PATHWAY_OFF.conversion?0:spend*rate*(1-progTax)*cipB*incomeShock;  // v4.21: pathway switch
      a.wealth+=convGain;totalConversion+=convGain;a.yrConvUSD=convGain;yrCashSurplus+=convGain;if(LABOR)a._labCn=convGain;
      if(PRICE)PRICE.acc.conv+=convGain;  // session 2: price module (P_G injection)
      if(LEDGER){var lcG=PATHWAY_OFF.conversion?0:spend*rate*cipB*incomeShock,lcT=lcG*progTax,lcI=0;while(lcI<LEDGER_RATE_TIERS.length&&rate>=LEDGER_RATE_TIERS[lcI])lcI++;
        var lcTier=LEDGER.tiers[lcI];lcTier.bu+=spend;lcTier.gross+=lcG;lcTier.tax+=lcT;lcTier.net+=convGain;lcTier.n++;
        ledAdd(yr,'buSpent',spend);ledAdd(yr,'convGross',lcG);ledAdd(yr,'convTax',lcT);ledAdd(yr,'convNet',convGain);ledAdd(yr,'convRateXspend',rate*spend);}  // A1 ledger
      if(isNaN(a.wealth))a.wealth=0;
      if(a.octave<p.maxOct){
        var Yusd=a.wage*CFG.WAGE_TO_USD;
        var cBasicMonthly=(dollarCost*(FBS_BU_ONCE?cfPreCCO:cf))/12;  // session 7: harness-only switch (i3-1); index.html reads cf
        var edcResidual=(p.pth&&a.inPTH)?CFG.FBS_EDC_RESIDUAL_PTH:CFG.FBS_EDC_RESIDUAL_BASE;
        var fbs=Math.max(0,Yusd+buEff-cBasicMonthly-edcResidual*Yusd);
        var lam=(typeof a.lambda==='number'&&!isNaN(a.lambda))?a.lambda:(CFG.FBS_LAMBDA_LO+CFG.FBS_LAMBDA_HI)/2;
        if(p.cip)lam*=(1+p.cipDemo*CFG.FBS_CIP_LAMBDA_BOOST);
        var pAdvance=1-Math.exp(-lam*fbs);
        if(uAdvance<pAdvance&&!PATHWAY_OFF.octave)a.octave++;  // v4.21: pathway switch
      }
      if(uSzhInduce<szhPartBoost&&!a.inPTF&&p.ptf&&!(HHA&&!a._hhHead)&&ptfCapAllows()){a.inPTF=uSzhPtfShare<p.ptfShare;if(a.inPTF&&p.ptfCap)ptfLiveCount++;if(a.inPTF&&PDON)pdLive++;}else if(PDON&&PROD.speed==='oneyear'&&uSzhInduce<szhPartBoost&&!a.inPTF&&p.ptf&&!(HHA&&!a._hhHead)&&uSzhPtfShare<p.ptfShare&&(!p.ptfCap||ptfLiveCount<ptfLiveTotal*p.ptfShare))PDS.blk++;  // plan step 15: turned away for lack of PTF capacity
    }
    if(PJON&&p.ccoOn&&a.inCCO){  // N1 (session 15): convert project BU (and a holder's own gift) within octave capacity; the rest is saved
      var pjA=PJS.acc,pjCapR=PROJ.cap?Math.max(0,a._pjCap-(FWON?0:spend)):Infinity,pjE=(a._pjSaved||0)+(a._pjBU||0),pjC1=Math.min(pjE,pjCapR);a._pjSaved=pjE-pjC1;pjCapR-=pjC1;
      var pjGh=a._pjGiftH||0,pjC2=Math.min(pjGh,pjCapR);a._pjGiftH=pjGh-pjC2;if(ACCT)a._acBc+=pjC1+pjC2;
      if(PROJ.cap&&pjC1+pjC2>Math.max(0,a._pjCap-(FWON?0:spend))+1e-6)pjA.overCap++;  // project BU fill the capacity the engine's own-spending conversion leaves (that conversion is not capped; at $1,200 BU it never reaches 12,000)
      var rvR=a._pjRu,rvU=false,rvE=0;if(REVIEW&&REVS&&a._pjRu>1&&a._rvU<REVIEW.u){if(a._rvU<REVIEW.u*REVIEW.q)rvR=1;else rvU=true;}  // v5.2 step 7: an unearned high rate, caught (paid at 1x) or not
      var pjTx=pjTax(p,rvR),pjG1=PATHWAY_OFF.conversion?0:pjC1*rvR*pjCipB*incomeShock,pjN1=pjG1*(1-pjTx);
      if(REVIEW&&REVS&&!PATHWAY_OFF.conversion&&a._pjRu>1&&a._rvU<REVIEW.u){var rvF=pjC1*a._pjRu*pjCipB*incomeShock*(1-pjTax(p,a._pjRu));rvE=pjC1*pjCipB*incomeShock*(1-pjTax(p,1));if(rvU)REVS.x+=(pjN1-rvE)/pjIdx;else REVS.c+=(rvF-pjN1)/pjIdx;}
      var pjTg=pjTax(p,a._pjR),pjG2=PATHWAY_OFF.conversion?0:pjC2*a._pjR*pjCipB*incomeShock,pjN2=pjG2*(1-pjTg);
      if(PROD&&FWON){var pdH=pjC1/pjPay,pdV=pdH*(PROD.match==='face'?pjPay:a.wage*12*CFG.WAGE_TO_USD*incomeShock/PROJ.hrsYr)*(1+(PROD.mat||0));a._pdM=PROD.match==='market'?Math.max(0,rvU?rvE:pjN1):Math.min(Math.max(0,pjN1),pdV);a._pdMy=a._pdM;a._pdNy=pjN1;a._pdVy=pdV;}  // plan step 2: project output at the cost of the hours (_pd*y: reporting only)
      if(tbY)TB.cur.ctax+=pjG1*pjTx+pjG2*pjTg;a.wealth+=pjN1+pjN2;a.yrConvUSD+=pjN1+pjN2;yrCashSurplus+=pjN1+pjN2;totalConversion+=pjN1+pjN2;totalBU+=pjC1+pjC2;
      if(LABOR&&pjN2)a._labCn=(a._labCn||0)+pjN2;  // the holder's gift is an unconditional dollar: the rent channel
      a.yrPjGift=pjN1*pjFg+pjN2;  // d66: gift-funded proceeds, tallied so the testbed can finance them as you go or over the run (the carried share is approximate)
      if(PRICE)PRICE.acc.conv+=pjN1+pjN2;
      pjA.conv+=pjC1/pjIdx;pjA.giftConv+=pjC2/pjIdx;pjA.gross+=(pjG1+pjG2)/pjIdx;pjA.net+=pjN1/pjIdx;pjA.giftNet+=pjN2/pjIdx;
      if(LEDGER){ledAdd(yr,'pjBU',a._pjBU||0);ledAdd(yr,'pjConvBU',pjC1+pjC2);ledAdd(yr,'pjNet',pjN1+pjN2);}
      if(isNaN(a.wealth))a.wealth=0;
    }
    if(p.pth&&a.inPTH&&!PATHWAY_OFF.pthEquity&&!PATHWAY_OFF.pthCost){  // v4.21: pathway switches (off: no routing, no appreciation)
      if(typeof a.pthTenure!=='number'||isNaN(a.pthTenure))a.pthTenure=0;
      a.pthTenure+=1;
      var cfWithoutPTH=cf/0.65;
      var pthSaving=Math.max(0,dcA*cfWithoutPTH*(1-0.65));
      if(rsAlt)pthSaving=Math.max(0,dcA*(cfPTF-cfPreCCO)*rsRel);  // session 5 (d4/d5): PTH's own cut on the post-relief basket
      var equityContrib=pthSaving*CFG.PTH_EQUITY_CONTRIB_SHARE;
      a.acreEquity+=equityContrib;a.wealth-=equityContrib;yrCashSurplus-=equityContrib;  // session 1: equity routing is not discretionary cash
      var ar=0.030+uPthAppr*0.020+pthApprBonus;var pbS=PTHB&&PBS?a._pbS:null,pbV0=0,pbVn=0;if(pbS){if(!pbS.V){pbS.V=CFG.PTHB_PR*hSA*dcA;pbS.D=pbS.V-(a.acreEquity-equityContrib);}pbV0=pbS.V;pbVn=pbV0*(1+PBS.pi)*(1+CFG.PTHB_G);if(PTHB.cap==='hub')ar=Math.min(pbVn/pbV0-1,PBS.pi+0.02);}  // v5.4 item 3: Acre Equity grows with the home, at most at the price rise + 2%
      var appr=a.acreEquity*ar,lqs=pthLiquidShare(a.pthTenure);
      if(pbS)lqs*=appr>0?Math.max(0,appr-PBS.pi*a.acreEquity)/appr:0;  // v5.4 item 3: only the gain above the price rise is paid out in cash; what keeps up with prices stays as equity
      a.acreEquity+=PTH_APPR_CONSERVE?appr*(1-lqs):appr;a.wealth+=appr*lqs;yrCashSurplus+=appr*lqs;  /* v4.16: PTH_APPR_CONSERVE=false is bit-identical to index.html */
      if(tbY)a._tbPthNow=appr*lqs;  // session 6
      if(LEDGER){ledAdd(yr,'pthEquityContrib',equityContrib);ledAdd(yr,'pthAppr',appr);ledAdd(yr,'pthApprLiquid',appr*lqs);}  // A1 ledger
      if(ACCT){a._acPc=equityContrib;a._acPa=appr;a._acPl=appr*lqs;}  // v5.3 B2
      if(pbS){var pbR=hSA*dcA,pbI=((1+CFG.PTHB_RREAL)*(1+PBS.pi)-1)*pbS.D,pbU=CFG.PTHB_UPK*(1-CFG.PTHB_LAND)*pbV0,pbT=CFG.PTHB_TAX*pbV0,pbL=appr*lqs;  // v5.4 item 3: the trust's books for this home
        pbS.D-=pbR+equityContrib-pbI-pbU-pbT-pbL;pbS.CE+=(pbVn-pbV0)+pbR-pbI-pbU-pbT-appr;pbS.V=pbVn;
        PBS.n++;if(pbR+equityContrib>=pbI-PBS.pi*(pbS.D+pbR+equityContrib-pbI-pbU-pbT-pbL)+pbU+pbT+pbL)PBS.cover++;PBS.aP+=pbV0*PBS.pi/PBS.P;PBS.aR+=pbV0*(1+PBS.pi)*CFG.PTHB_G/PBS.P;PBS.aC+=(pbVn-pbV0-appr)/PBS.P;
        if(ACCT)acctChk('pth-books',yr,(pbS.V-pbS.D)-a.acreEquity-pbS.CE,pbS.V,a._id!==undefined?a._id:null);}
      if(PRICE)PRICE.acc.pthLiq+=appr*lqs;  // session 2: price module
    } else if(a.pthTenure){
      a.pthTenure=0;
    }
    if(p.ptf&&!a.inPTF&&p.ptfShare>0&&yr>0&&!(HHA&&!a._hhHead)&&ptfCapAllows()){var ap=0.005+CFG.PTF_BASS_Q*ptfAdoptFrac;if(bleiCheck<CFG.BLEI_PRECARIOUS_MAX)ap+=0.015;if(uPtfAdopt<ap){a.inPTF=true;if(p.ptfCap)ptfLiveCount++;if(PDON)pdLive++;}}
    else if(PDON&&PROD.speed==='oneyear'&&p.ptf&&!a.inPTF&&p.ptfShare>0&&yr>0&&!(HHA&&!a._hhHead)&&(!p.ptfCap||ptfLiveCount<ptfLiveTotal*p.ptfShare)){var apB=0.005+CFG.PTF_BASS_Q*ptfAdoptFrac;if(bleiCheck<CFG.BLEI_PRECARIOUS_MAX)apB+=0.015;if(uPtfAdopt<apB)PDS.blk++;}  // plan step 15: turned away for lack of PTF capacity
    if(HHP)a._hhCS=yrCashSurplus;  // v5.3 B3: pooled in hhPool
    if(SURPLUS_CONSUMPTION_SHARE>0&&SURPLUS_CONSUMPTION_BASE==='cash'&&!HHP){var scC=SURPLUS_CONSUMPTION_SHARE*Math.max(0,yrCashSurplus);a.wealth-=scC;if(ACCT)a._acSc+=scC;if(LEDGER)ledAdd(yr,'surplusConsumed',scC);}  // session 1: harness-only
    if(PRICE){  // session 2 (D1/N5): a write-off at the floor is basket consumption that did not happen (unmet need), not spending
      var pmW=(!HHP&&a.wealth<CFG.WEALTH_FLOOR)?CFG.WEALTH_FLOOR-a.wealth:0,pmB=mainLoopCostUSD*cfPreCCO,pmU=pmB>0?Math.min(1,(SPEND_GRADE&&!HHP?pmW+a._grCut:pmW)/pmB):0,A=PRICE.acc;  /* v5.3 B7: + the spending cut */
      A.n++;A.essD+=1-pmU;A.unmet+=pmW;A.basketOwn+=pmB;if(pmW>0)A.unmetN++;A.Y+=annualWageUSD+a.yrConvUSD+(a.yrSSUSD||0);A.Yw+=annualWageUSD+(a.yrSSUSD||0);if(p.ptf&&a.inPTF)A.ptfN++;
      if(HHP)a._hhPmB=pmB;  // v5.3 B3: a pooled couple's unmet need is counted after pooling (hhPool)
      A.wageBonus+=Math.max(0,a.wage-a._wNB)*12*CFG.WAGE_TO_USD*incomeShock;A.wageBonusNS+=Math.max(0,a.wage-a._wNB)*12*CFG.WAGE_TO_USD;  // session 3: the premium before the income shock, for aw's increment reading
    }
    if(LABOR){a._labC=a._labCn||0;a._labCn=0;if(LABOR.acc){LABOR.acc.conv+=a.yrConvUSD||0;if(a.inCCO)LABOR.acc.convP+=a.yrConvUSD||0;}}  // session 4: creator proceeds carried to next year's labor response
    if(tbY)tbAccount(a,tbY,yr,mainLoopCostUSD,cf,cfPreCCO+hcX,costUSD,annualWageUSD,tbG,tbPT);  // v5.2 step 7: + hcX, so BU spent on the higher rent count as BU relief  // session 6: uniform cost ledger and basket FGT (reporting; no RNG)
    if(ACCT&&!HHP&&a.wealth<CFG.WEALTH_FLOOR)a._acFl=CFG.WEALTH_FLOOR-a.wealth;  // v5.3 B2: debt written off at the floor
    if(!HHP&&a.wealth<CFG.WEALTH_FLOOR){if(LEDGER){var lfA=CFG.WEALTH_FLOOR-a.wealth;ledAdd(yr,'floor',lfA);ledAdd(yr,'floorHits',1);a._ledFloor=(a._ledFloor||0)+lfA;}a.wealth=CFG.WEALTH_FLOOR;}  // A1 ledger inside the clamp
    if(ACCT&&!HHP)acctAgent(a,yr);  // v5.3 B2: this adult's identities for the year
  });
  if(HHON){if(HHPOOL)hhPool(yr,!!tbY);hhSync('ptf');}  // v5.3 B3: couples' end of year (pooling), then partners follow the first adult's PTF decision
  if(FWON){  // session 2, N1: businesses convert this year's accepted BU; the premium over a cash sale is paid out next year
    var nx=FWS.next,bTaxB=p.cip?p.tax*(1-p.cipDemo*0.18):p.tax;
    var taxR=Math.min(CFG.PROG_TAX_MAX,bTaxB+Math.max(0,(FW.bizRate-CFG.PROG_PIVOT)*CFG.PROG_RATE)),taxP=Math.min(CFG.PROG_TAX_MAX,bTaxB);
    var bzB=ESON?nx.bizBU*(1-ESP.lam):nx.bizBU;if(ACCT)ACCT.cur.bz=bzB;  // session 19 (d71): with ESP payroll the ESP converts the share it keeps; lam of what it accepted is next year's payroll
    nx.bizGross=bzB*(FW.bizCap*FW.bizRate+(1-FW.bizCap));nx.bizTax=bzB*(FW.bizCap*FW.bizRate*taxR+(1-FW.bizCap)*taxP);
    nx.bizNet=PATHWAY_OFF.conversion?0:nx.bizGross-nx.bizTax-bzB;if(tbY)TB.cur.ctax+=nx.bizTax;  // plan step 3: conversion tax kept by the Source (reporting)  // session 7: the conversion switch also covers business-side conversion (harness-only)
    if(LEDGER){ledAdd(yr,'fwBizGross',nx.bizGross);ledAdd(yr,'fwBizTax',nx.bizTax);ledAdd(yr,'fwBizPremium',nx.bizNet);}
    if(ESON){ESS.next={pool:nx.bizBU*ESP.lam};ESS.acc.accBU+=nx.bizBU/esIdx;ESS.acc.ownBU+=bzB/esIdx;ESS.y[yr].acc=nx.bizBU;ESS.y[yr].own=bzB;ESS.y[yr].poolNext=ESS.next.pool;
      if(LEDGER){ledAdd(yr,'espOwnBU',bzB);ledAdd(yr,'espPoolNext',ESS.next.pool);}}
    FWS.prev=nx;
  }
  if(ESON)ESS.prev=ESS.next;  // N1 (session 19)
  if(PJON)PJS.prev=PJS.next;  // N1 (session 15)
  if(ACCT)acctYearEnd(agentSet,yr,p);  // v5.3 B2: the year's BU stock, the premium paid out and the Source's books
  return{bu:totalBU,conversion:totalConversion,stabOn:stabOn,stabM:stabM,colaF:colaF,buEff:buEff,emergN:emergN};  // v4.19
}

