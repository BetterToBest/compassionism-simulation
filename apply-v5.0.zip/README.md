# Compassionism Framework Simulation

**Compassionism aspires to enhance cultures by eradicating extreme poverty while incentivizing participation and contribution: see how it does.**

_The math and code of this simulation were engineered by Claude, an AI model made by Anthropic, from the concepts in Duke Johnson's book *Better To Best* and his related vision for eradicating extreme poverty while enriching cultures and supporting human flourishing. The model has not yet been reviewed by an independent economist; the full code is open for anyone to check, and expert collaborators are welcome._

A research-oriented, browser-based agent-based simulation exploring all five [Compassionism](https://bettertobest.github.io/research-hub/) architectures for comparative policy analysis — no installation required. BLEI-calibrated against US Consumer Expenditure Survey data.

The page opens with Compassionism's results: the same 500 simulated adults followed for 20 years, with the programme and with no programme, in three environments (Reference, Adverse, Stress). Basic living covered (BLEI, days of basic living a person's resources cover) leads, followed by one plain sentence each on poverty, savings, who gains, work, prices, cost and how it is paid, and the public costs of homelessness avoided. Every figure is an average over 500 paired runs with its 95% interval, and the page names the command that reproduces it; a button runs the model live in the browser. The model measures poverty, cost and work, not the cultural effects Compassionism aspires to. Poverty is measured against a living-wage basket, a higher bar than extreme poverty.

**[▶ Open the simulation](https://bettertobest.github.io/compassionism-simulation/)** · DOI: [10.17605/OSF.IO/QWTE2](https://doi.org/10.17605/OSF.IO/QWTE2)


[![checks](https://github.com/BetterToBest/compassionism-simulation/actions/workflows/checks.yml/badge.svg)](https://github.com/BetterToBest/compassionism-simulation/actions/workflows/checks.yml)

This file covers what the project is and how to run it. For everything version-specific — the full changelog, current output metrics, methodology, and formulas — see the **[Replication Framework](https://bettertobest.github.io/compassionism-simulation/replication.html)**, which is kept current with each release. For open questions, known limitations, and how to contribute, see **[CONTRIBUTING.md](https://github.com/BetterToBest/compassionism-simulation/blob/main/CONTRIBUTING.md)**.

---

## What this simulates

The simulation models all five integrated Compassionism architectures and their interactions:

| System | Layer | Role in the model |
|--------|-------|-------------------|
| **CCO** (Creative Currency Octaves) | Economic | Distributes flat Basic Units (BU) monthly to participants, redeemable at PTF businesses and convertible to primary currency at merit-scaled rates that improve with an agent's octave level and quality |
| **PTF** (Public Trust Foundations) | Asset | Community-owned essential goods/services that accept BU; modeled as a **cost-reduction mechanism**, not a wealth-addition channel |
| **PTH** (Public Trust Housing) | Asset | Community-owned housing; reduces housing-linked living costs and routes a share of that saving into Acre Equity, which appreciates over time and is accessible at exit subject to a liquidity haircut |
| **SZH** (Social Zone Harmonization) | Spatial | Zone-level coherence gives residents a coherence-linked benefit and gates a separate cooperative-synergy bonus once PTF merchant density crosses a threshold |
| **CIP** (Citizens Internet Portal) | Democratic | Digital platform administering CCO currency operations and democratic voting on PTF/PTH decisions; participation improves octave-advancement capability, quality accuracy, and reduces conversion-tax leakage |

Welfare outcomes are measured against the **Basic Living Economic Index (BLEI)** — a temporal-stability metric expressing how many days of basic living an agent's accessible resources cover, rather than a raw income or wealth snapshot. See the [BLEI paper](https://bettertobest.github.io/research-hub/basic-living-economic-index.html) for the full framework, and the Replication Framework for the current formulas as implemented.

---

## How to use

**No Python. No installation. Just open `index.html` in any browser.**

### Option A — Open locally
1. Download `index.html`
2. Double-click — opens in Chrome, Firefox, Safari, or Edge
3. Adjust controls and click **Run Simulation**

### Option B — Host on GitHub Pages
1. Upload `index.html` to your repository root
2. Go to **Settings → Pages → Source → main branch / root**
3. Live at `https://yourusername.github.io/compassionism-simulation/`

The simulation itself documents its own current controls, presets, calibration constants, and known limitations in-app — see the collapsible **Assumptions, ODD Protocol & Known Limitations** and **References & Citations** panels at the bottom of the page, which are kept in sync with the shipped code.

---

## Where to find version-specific information

This README intentionally stays stable across releases. For anything tied to a specific version:

- **What changed, and when** — the [Replication Framework's Version History](https://bettertobest.github.io/compassionism-simulation/replication.html) has the full line-by-line changelog, newest first, for every release.
- **Current output metrics and large-N study results** — the Replication Framework's Performance Comparison section, refreshed after any mechanics-changing release.
- **Formulas as currently implemented** — the Replication Framework's Mathematical Framework section, and the simulation's own source comments.
- **Open questions, known limitations, and how to contribute** — [CONTRIBUTING.md](https://github.com/BetterToBest/compassionism-simulation/blob/main/CONTRIBUTING.md), which tracks unresolved calibration items, model-architecture feedback, and good-first-issues.

---

## Checking a copy

The simulation needs nothing installed. The checks that keep it honest need Node.js (22 or later) and one development dependency:

```
npm install              # installs jsdom, used only by domtest.js
node harness.js validate # the seed-42 reference run, asserted against the documented figures
node harness.js unit     # pure-function tests
node domtest.js          # drives index.html in a headless DOM (a few minutes)
```

Every `harness.js` study mode also accepts `--agents=N`, the population per run (default 500). For example, `node harness.js largen 500 headline --agents=5000` reruns the headline figures at 5,000 agents per run, in about five minutes on one CPU core.

The same three run automatically on every push (`.github/workflows/checks.yml`). CONTRIBUTING.md explains what each covers and what none of them can see.

---

## License & attribution

Split licensing, since v4.8:

- **Source code** (`index.html`, `harness.js`, `domtest.js`) — [Apache License 2.0](LICENSE-CODE.txt).
- **Documentation and papers** (this README, CONTRIBUTING.md, the Replication Framework, and the Research Hub papers) — [Creative Commons Attribution 4.0 International (CC BY 4.0)](https://creativecommons.org/licenses/by/4.0/).

**Cite as:**
> Johnson, D. & Claude (Anthropic). (2026). *Compassionism Framework Simulation*. Better To Best Research Hub. <https://doi.org/10.17605/OSF.IO/QWTE2> (source code: Apache License 2.0; content and documentation: CC BY 4.0)

The DOI resolves to the archived record; cite the specific version and date you used alongside it if that matters for your purposes (the simulation's own footer and export files record the version and timestamp of any given run).

**Research Hub:** [bettertobest.github.io/research-hub](https://bettertobest.github.io/research-hub/)
**Wiki:** [bettertobest.github.io/research-hub/wiki](https://bettertobest.github.io/research-hub/wiki/)
**BLEI Paper:** [basic-living-economic-index.html](https://bettertobest.github.io/research-hub/basic-living-economic-index.html)
**Replication Framework:** [replication.html](https://bettertobest.github.io/compassionism-simulation/replication.html)
**Contributors' Guide:** [CONTRIBUTING.md](https://github.com/BetterToBest/compassionism-simulation/blob/main/CONTRIBUTING.md)
**DOI:** [10.17605/OSF.IO/QWTE2](https://doi.org/10.17605/OSF.IO/QWTE2)
**Contact:** BetterToBestResearch@gmail.com
